export default function Custom500() {
  return <div>500 - Server-side error occurred</div>;
}
