'use client';

import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { registerPushSubscription } from '@/hooks/use-push';

export interface UserProfile {
  name: string;
  phone: string;
  agentCode: string;
  balance: number;
  uid?: string;
  role?: string;
  status?: string;
}

export interface Transaction {
  id: string;
  type: 'deposit' | 'withdraw' | 'TOOD_WIN';
  amount: number;
  timestamp: string;
  status: 'completed' | 'pending' | 'approved' | 'rejected';
  method: string;
  transactionNumber?: string;
  orderNumber?: string;
  slipImage?: string;
}

export interface BetSubNumber {
  number: string;
  amount: number;
}

export interface BetItem {
  number: string;
  amount: number;
  subNumbers?: BetSubNumber[];
  subCount?: number;
  perItemAmount?: number;
  label?: string;
}

export interface BetRecord {
  id: string;
  type: '2D' | '3D';
  amount: number;
  session: string;
  date: string;
  numbers: string[];
  items?: BetItem[];
  status: 'pending' | 'win' | 'lose' | 'TOOD_WIN';
  winningNumber?: string;
  winAmount?: number;
  winDetails?: string;
  payoutMultiplier?: number;
  isTood?: boolean;
}

export type CurrentViewType =
  | 'main'
  | 'deposit'
  | 'withdraw'
  | '2d_live'
  | '2d_bet'
  | '3d_bet'
  | 'login'
  | 'register';

interface AppContextType {
  isHydrated: boolean;
  user: UserProfile;
  isLoggedIn: boolean;
  activeTab: 'home' | 'wallet' | 'record' | 'profile';
  currentView: CurrentViewType;
  transactions: Transaction[];
  bets: BetRecord[];
  login: (phone: string, password?: string) => Promise<{ success: boolean; error?: string }>;
  logout: () => Promise<void>;
  register: (
    name: string,
    phone: string,
    agentCode: string,
    password?: string
  ) => Promise<{ success: boolean; error?: string }>;
  setActiveTab: (tab: 'home' | 'wallet' | 'record' | 'profile') => void;
  setCurrentView: (view: CurrentViewType) => void;
  deposit: (amount: number, method: string, last6: string, slipImage?: string) => Promise<void>;
  withdraw: (
    amount: number,
    method: string,
    accountName: string,
    accountPhone: string
  ) => Promise<boolean>;
  placeBet: (
    type: '2D' | '3D',
    session: string,
    numbersOrItems: string[] | BetItem[],
    amountPerNumber?: number
  ) => Promise<BetRecord | null>;
  updateProfile: (data: Partial<UserProfile>) => Promise<void>;
  refreshUserData: () => Promise<void>;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const NAV_STATE_KEY = 'fast2d3d_nav_state';

interface NavState {
  activeTab: 'home' | 'wallet' | 'record' | 'profile';
  currentView: CurrentViewType;
  savedAt: number;
}

const DEFAULT_USER: UserProfile = {
  name: '',
  phone: '',
  agentCode: '',
  balance: 0,
  uid: '',
  role: 'user',
  status: 'active',
};

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [isHydrated, setIsHydrated] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [activeTab, setActiveTabState] = useState<'home' | 'wallet' | 'record' | 'profile'>('home');
  const [currentView, setCurrentViewState] = useState<CurrentViewType>('main');
  const [user, setUser] = useState<UserProfile>(DEFAULT_USER);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [bets, setBets] = useState<BetRecord[]>([]);

  const refreshUserData = useCallback(async () => {
    try {
      const userRes = await fetch('/api/auth/me', { cache: 'no-store' });
      if (!userRes.ok) {
        if (userRes.status === 401) {
          setIsLoggedIn(false);
        }
        return;
      }
      const userData = await userRes.json();
      if (userData?.user) {
        setUser((prev) => ({ ...prev, ...userData.user }));
        setIsLoggedIn(true);
      }

      const [txRes, betRes] = await Promise.all([
        fetch('/api/user/transactions', { cache: 'no-store' }).then((r) => (r.ok ? r.json() : null)),
        fetch('/api/user/bets', { cache: 'no-store' }).then((r) => (r.ok ? r.json() : null)),
      ]);

      if (Array.isArray(txRes?.transactions)) setTransactions(txRes.transactions);
      if (Array.isArray(betRes?.bets)) setBets(betRes.bets);
    } catch {

    }
  }, []);

  useEffect(() => {
    let isMounted = true;

    const timer = setTimeout(async () => {
      if (!isMounted) return;
      try {
        const rawNav = localStorage.getItem(NAV_STATE_KEY);
        if (rawNav) {
          try {
            const nav = JSON.parse(rawNav) as NavState;
            if (nav?.activeTab) setActiveTabState(nav.activeTab);
            if (nav?.currentView && nav.currentView !== 'login' && nav.currentView !== 'register') {
              setCurrentViewState(nav.currentView);
            }
          } catch {}
        }

        const meRes = await fetch('/api/auth/me', { cache: 'no-store' });
        if (meRes.ok) {
          const data = await meRes.json();
          if (data?.user) {
            setUser((prev) => ({ ...prev, ...data.user }));
            setIsLoggedIn(true);
            await refreshUserData();
          }
        } else {
          setIsLoggedIn(false);
          setCurrentViewState('login');
        }
      } catch {
        setIsLoggedIn(false);
      } finally {
        if (isMounted) setIsHydrated(true);
      }
    }, 0);

    return () => {
      isMounted = false;
      clearTimeout(timer);
    };
  }, [refreshUserData]);

  const persistNavState = (tab: 'home' | 'wallet' | 'record' | 'profile', view: CurrentViewType) => {
    try {
      const nav: NavState = { activeTab: tab, currentView: view, savedAt: Date.now() };
      localStorage.setItem(NAV_STATE_KEY, JSON.stringify(nav));
    } catch {}
  };

  const setActiveTab = (tab: 'home' | 'wallet' | 'record' | 'profile') => {
    setActiveTabState(tab);
    persistNavState(tab, currentView);
  };

  const setCurrentView = (view: CurrentViewType) => {
    setCurrentViewState(view);
    persistNavState(activeTab, view);
  };

  const login = async (phone: string, password?: string): Promise<{ success: boolean; error?: string }> => {
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone, password }),
      });
      const data = await res.json();
      if (!res.ok || !data.success) {
        return { success: false, error: data.error || 'အကောင့်ဝင်ရောက်မှု မအောင်မြင်ပါ' };
      }
      setUser((prev) => ({ ...prev, ...data.user }));
      setIsLoggedIn(true);
      setCurrentViewState('main');
      setActiveTabState('home');
      persistNavState('home', 'main');
      await refreshUserData();
      void registerPushSubscription();
      return { success: true };
    } catch {
      return { success: false, error: 'ဆာဗာနှင့် ချိတ်ဆက်ရာတွင် အဆင်မပြေပါ' };
    }
  };

  const logout = async () => {
    try {
      await fetch('/api/auth/logout', { method: 'POST' });
    } catch {}
    try {
      localStorage.removeItem(NAV_STATE_KEY);
    } catch {}
    setUser(DEFAULT_USER);
    setTransactions([]);
    setBets([]);
    setIsLoggedIn(false);
    setCurrentViewState('login');
  };

  const register = async (
    name: string,
    phone: string,
    agentCode: string,
    password?: string
  ): Promise<{ success: boolean; error?: string }> => {
    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, phone, agentCode, password }),
      });
      const data = await res.json();
      if (!res.ok || !data.success) {
        return { success: false, error: data.error || 'အကောင့်ဖွင့်ခြင်း မအောင်မြင်ပါ' };
      }
      setUser((prev) => ({ ...prev, ...data.user }));
      setIsLoggedIn(true);
      setCurrentViewState('main');
      setActiveTabState('home');
      persistNavState('home', 'main');
      await refreshUserData();
      void registerPushSubscription();
      return { success: true };
    } catch {
      return { success: false, error: 'ဆာဗာနှင့် ချိတ်ဆက်ရာတွင် အဆင်မပြေပါ' };
    }
  };

  const deposit = async (amount: number, method: string, last6: string, slipImage?: string) => {
    const timestampStr = new Date().toLocaleString('en-US', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      weekday: 'short',
      hour: '2-digit',
      minute: '2-digit',
      hour12: true,
    });
    try {
      await fetch('/api/user/transactions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: 'deposit',
          amount,
          method,
          transactionNumber: last6,
          timestamp: timestampStr,
          slipImage: slipImage || '',
        }),
      });
    } catch {}
    await refreshUserData();
  };

  const withdraw = async (
    amount: number,
    method: string,
    accountName: string,
    accountPhone: string
  ): Promise<boolean> => {
    if (user.balance < amount) return false;
    const timestampStr = new Date().toLocaleString('en-US', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      weekday: 'short',
      hour: '2-digit',
      minute: '2-digit',
      hour12: true,
    });
    try {
      const res = await fetch('/api/user/transactions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type: 'withdraw',
          amount,
          method,
          transactionNumber: `${accountName} (${accountPhone})`,
          timestamp: timestampStr,
        }),
      });
      if (!res.ok) return false;
    } catch {
      return false;
    }
    await refreshUserData();
    return true;
  };

  const placeBet = async (
    type: '2D' | '3D',
    session: string,
    numbersOrItems: string[] | BetItem[],
    amountPerNumber?: number
  ): Promise<BetRecord | null> => {
    if (!numbersOrItems || numbersOrItems.length === 0) return null;

    let numbers: string[] = [];
    let items: BetItem[] = [];
    let totalCost = 0;

    if (typeof numbersOrItems[0] === 'string') {
      const rawNums = numbersOrItems as string[];
      const perUnit = amountPerNumber || 0;
      totalCost = rawNums.length * perUnit;
      items = rawNums.map((n) => ({
        number: n,
        amount: perUnit,
        subNumbers: [{ number: n, amount: perUnit }],
        subCount: 1,
        perItemAmount: perUnit,
      }));
      numbers = rawNums;
    } else {
      items = (numbersOrItems as BetItem[]).map((it) => {
        if (!it.subNumbers || it.subNumbers.length === 0) {
          return {
            ...it,
            subNumbers: [{ number: it.number, amount: it.amount }],
            subCount: 1,
            perItemAmount: it.amount,
          };
        }
        return it;
      });
      numbers = items.map((it) => it.number);
      totalCost = items.reduce((sum, it) => sum + it.amount, 0);
    }

    if (totalCost <= 0) return null;
    if (user.balance < totalCost) return null;

    const dateStr = new Date().toLocaleString('en-US', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      weekday: 'short',
      hour: '2-digit',
      minute: '2-digit',
      hour12: true,
    });

    try {
      const res = await fetch('/api/user/bets', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type, session, numbers, items, date: dateStr, amountPerNumber }),
      });
      const data = await res.json();
      if (!res.ok || !data.success) return null;
      await refreshUserData();
      return {
        id: data.bet.id,
        type,
        amount: data.bet.amount,
        session,
        date: dateStr,
        numbers,
        items,
        status: 'pending',
      };
    } catch {
      return null;
    }
  };

  const updateProfile = async (data: Partial<UserProfile>) => {
    try {
      await fetch('/api/user/profile', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: data.name, phone: data.phone }),
      });
    } catch {}
    await refreshUserData();
  };

  return (
    <AppContext.Provider
      value={{
        isHydrated,
        user,
        isLoggedIn,
        activeTab,
        currentView,
        transactions,
        bets,
        login,
        logout,
        register,
        setActiveTab,
        setCurrentView,
        deposit,
        withdraw,
        placeBet,
        updateProfile,
        refreshUserData,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within AppProvider');
  return context;
}
