'use client';

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { AppProvider, useApp } from '@/context/AppContext';
import { SplashScreen } from '@/components/SplashScreen';
import { AuthScreens } from '@/components/AuthScreens';
import { AppHeader } from '@/components/AppHeader';
import { BottomNav } from '@/components/BottomNav';
import { HomeView } from '@/components/HomeView';
import { WalletView } from '@/components/WalletView';
import { BetHistoryView } from '@/components/BetHistoryView';
import { ProfileView } from '@/components/ProfileView';
import { DepositView } from '@/components/DepositView';
import { WithdrawView } from '@/components/WithdrawView';
import { Live2DView } from '@/components/Live2DView';
import { Bet2DView } from '@/components/Bet2DView';
import { Bet3DView } from '@/components/Bet3DView';
import { ResultsHistoryModal } from '@/components/ResultsHistoryModal';
import { SupportSheet } from '@/components/SupportSheet';
import { NotificationModal } from '@/components/NotificationModal';
import { PWAInstallBanner } from '@/components/PWAInstallBanner';
import { OfflineIndicator } from '@/components/OfflineIndicator';
import { useNotifications } from '@/hooks/use-notifications';
import { fetchAppSettings, getCachedAppSettings } from '@/lib/appSettings';

const TAB_ORDER = ['home', 'wallet', 'record', 'profile'] as const;

function MainAppContent() {
  const { isHydrated, isLoggedIn, activeTab, currentView, setCurrentView, setActiveTab } = useApp();
  const {
    notifications,
    markRead,
    markAllRead,
    soundEnabled,
    setSoundEnabled,
  } = useNotifications();

  const [splashDone, setSplashDone] = useState(false);

  useEffect(() => {
    if (!isHydrated) return;
    const timer = setTimeout(() => {
      try {
        if (isLoggedIn) {
          setSplashDone(true);
          return;
        }
        const hasSeenSplash = sessionStorage.getItem('fast2d3d_splash_seen');
        if (hasSeenSplash) {
          setSplashDone(true);
        }
      } catch {
        setSplashDone(true);
      }
    }, 0);

    return () => clearTimeout(timer);
  }, [isHydrated, isLoggedIn]);

  const handleSplashComplete = () => {
    try {
      sessionStorage.setItem('fast2d3d_splash_seen', 'true');
    } catch {}
    setSplashDone(true);
  };

  const [notifOpen, setNotifOpen] = useState(false);
  const [resultsOpen, setResultsOpen] = useState(false);
  const [supportOpen, setSupportOpen] = useState(false);
  const [supportLinks, setSupportLinks] = useState<{ telegram: string; viber: string }>({
    telegram: '',
    viber: '',
  });
  const [showIOSInstallGuide, setShowIOSInstallGuide] = useState(false);

  useEffect(() => {
    void fetchAppSettings();
  }, []);

  const openSupport = () => {
    setSupportOpen(true);
    const cachedSupport = getCachedAppSettings()?.website?.support;
    if (cachedSupport) {
      setSupportLinks({ telegram: cachedSupport.telegram || '', viber: cachedSupport.viber || '' });
    }
    void (async () => {
      try {
        const res = await fetch('/api/settings', { cache: 'no-store' });
        if (res.ok) {
          const json = await res.json();
          const s = json?.data?.website?.support;
          setSupportLinks({ telegram: s?.telegram || '', viber: s?.viber || '' });
        }
      } catch {}
    })();
  };

  const [prevTab, setPrevTab] = useState(activeTab);
  const [direction, setDirection] = useState(1);

  if (activeTab !== prevTab) {
    const prevIndex = TAB_ORDER.indexOf(prevTab as (typeof TAB_ORDER)[number]);
    const currentIndex = TAB_ORDER.indexOf(activeTab as (typeof TAB_ORDER)[number]);
    setPrevTab(activeTab);
    setDirection(currentIndex >= prevIndex ? 1 : -1);
  }

  if (!isHydrated) {
    return (
      <div className="min-h-screen bg-[#050505] flex justify-center items-center">
        <div className="w-full max-w-md min-h-screen bg-black flex flex-col items-center justify-center p-6 text-center">
          <div className="w-10 h-10 rounded-full border-2 border-[#e6b325] border-t-transparent animate-spin mb-4" />
          <p className="text-[#ffd700] text-xs font-semibold tracking-wider uppercase">Loading Fast 2D3D...</p>
        </div>
      </div>
    );
  }

  if (!splashDone) {
    return <SplashScreen onComplete={handleSplashComplete} />;
  }

  if (!isLoggedIn || currentView === 'login' || currentView === 'register') {
    return (
      <div className="min-h-screen bg-[#050505] flex justify-center">
        <div className="w-full max-w-md min-h-screen bg-black relative flex flex-col">
          <AuthScreens onOpenSupport={openSupport} />
          <SupportSheet isOpen={supportOpen} links={supportLinks} onClose={() => setSupportOpen(false)} />
        </div>
      </div>
    );
  }

  if (currentView === 'deposit') {
    return (
      <div className="min-h-screen bg-[#050505] flex justify-center">
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          transition={{ duration: 0.22, ease: [0.25, 1, 0.5, 1] }}
          className="w-full max-w-md min-h-screen bg-black relative flex flex-col"
        >
          <DepositView onBack={() => setCurrentView('main')} />
        </motion.div>
      </div>
    );
  }

  if (currentView === 'withdraw') {
    return (
      <div className="min-h-screen bg-[#050505] flex justify-center">
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          transition={{ duration: 0.22, ease: [0.25, 1, 0.5, 1] }}
          className="w-full max-w-md min-h-screen bg-black relative flex flex-col"
        >
          <WithdrawView onBack={() => setCurrentView('main')} />
        </motion.div>
      </div>
    );
  }

  if (currentView === '2d_live') {
    return (
      <div className="min-h-screen bg-[#050505] flex justify-center">
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          transition={{ duration: 0.22, ease: [0.25, 1, 0.5, 1] }}
          className="w-full max-w-md min-h-screen bg-black relative flex flex-col"
        >
          <Live2DView onBack={() => setCurrentView('main')} />
        </motion.div>
      </div>
    );
  }

  if (currentView === '2d_bet') {
    return (
      <div className="min-h-screen bg-[#050505] flex justify-center">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 16 }}
          transition={{ duration: 0.22, ease: [0.25, 1, 0.5, 1] }}
          className="w-full max-w-md min-h-[100dvh] overflow-x-hidden bg-black relative flex flex-col"
        >
          <Bet2DView onBack={() => setCurrentView('main')} />
        </motion.div>
      </div>
    );
  }

  if (currentView === '3d_bet') {
    return (
      <div className="min-h-screen bg-[#050505] flex justify-center">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 16 }}
          transition={{ duration: 0.22, ease: [0.25, 1, 0.5, 1] }}
          className="w-full max-w-md min-h-[100dvh] overflow-x-hidden bg-black relative flex flex-col"
        >
          <Bet3DView onBack={() => setCurrentView('main')} />
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#050505] flex justify-center">
      <div className="w-full max-w-md min-h-screen bg-[#090909] relative flex flex-col overflow-hidden">
        <PWAInstallBanner
          forceShowIOSModal={showIOSInstallGuide}
          onCloseIOSModal={() => setShowIOSInstallGuide(false)}
        />

        <AppHeader
          onOpenSupport={openSupport}
          onOpenNotifications={() => setNotifOpen(true)}
          onOpenInstall={() => setShowIOSInstallGuide(true)}
        />

        <main className="flex-1 overflow-y-auto relative">
          <AnimatePresence mode="wait" initial={false}>
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, x: direction * 18 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: direction * -18 }}
              transition={{
                duration: 0.2,
                ease: [0.25, 1, 0.5, 1],
              }}
              className="w-full h-full"
            >
              {activeTab === 'home' && (
                <HomeView
                  onOpen2DBet={() => setCurrentView('2d_bet')}
                  onOpen3DBet={() => setCurrentView('3d_bet')}
                  onOpenLive2D={() => setCurrentView('2d_live')}
                  onOpenResultsHistory={() => setResultsOpen(true)}
                />
              )}

              {activeTab === 'wallet' && (
                <WalletView
                  onGoDeposit={() => setCurrentView('deposit')}
                  onGoWithdraw={() => setCurrentView('withdraw')}
                />
              )}

              {activeTab === 'record' && <BetHistoryView />}

              {activeTab === 'profile' && <ProfileView />}
            </motion.div>
          </AnimatePresence>
        </main>

        <BottomNav />

        <ResultsHistoryModal isOpen={resultsOpen} onClose={() => setResultsOpen(false)} />
        <SupportSheet isOpen={supportOpen} links={supportLinks} onClose={() => setSupportOpen(false)} />
        <NotificationModal
          isOpen={notifOpen}
          onClose={() => setNotifOpen(false)}
          notifications={notifications}
          onMarkRead={markRead}
          onMarkAllRead={markAllRead}
          soundEnabled={soundEnabled}
          onToggleSound={setSoundEnabled}
          onNavigate={(screen) => {
            if (screen === 'home' || screen === 'wallet' || screen === 'record' || screen === 'profile') {
              setActiveTab(screen);
            }
          }}
        />

        <OfflineIndicator />
      </div>
    </div>
  );
}

export default function Page() {
  return (
    <AppProvider>
      <MainAppContent />
    </AppProvider>
  );
}
