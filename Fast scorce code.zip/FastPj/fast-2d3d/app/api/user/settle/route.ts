import { NextRequest, NextResponse } from 'next/server';
import { sql, ensureTablesExist } from '@/lib/db';
import { getSession } from '@/lib/session';
import { createNotification } from '@/lib/notifications';
import { computeWin, type BetItemLike } from '@/lib/payout';
import { isTood, TOOD_MULTIPLIER, payoutTransactionId } from '@/lib/tood';
import { recordWinSettlement } from '@/lib/commission';

function parseJsonArray(value: unknown): unknown[] {
  if (Array.isArray(value)) return value;
  if (typeof value === 'string') {
    try {
      const parsed = JSON.parse(value);
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  }
  return [];
}

export async function POST(req: NextRequest) {
  try {
    await ensureTablesExist();
    const session = await getSession();
    if (!session || session.kind !== 'user' || !session.uid) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await req.json();
    const { betId } = body;
    if (!betId) {
      return NextResponse.json({ error: 'Missing parameters' }, { status: 400 });
    }

    const bets = await sql`
      SELECT id, uid, type, session, amount, numbers, items, status
      FROM bets
      WHERE id = ${betId} AND uid = ${session.uid}
      LIMIT 1;
    `;

    if (!bets || bets.length === 0) {
      return NextResponse.json({ error: 'Bet not found' }, { status: 404 });
    }

    const bet = bets[0] as {
      id: string;
      uid: string;
      type: string;
      session: string;
      amount: string | number;
      numbers: unknown;
      items: unknown;
      status: string;
    };

    if (bet.status === 'win' || bet.status === 'lose' || bet.status === 'TOOD_WIN') {
      return NextResponse.json({ error: 'Already settled' }, { status: 409 });
    }

    const resultRows = await sql`
      SELECT winning_number FROM results
      WHERE type = ${bet.type} AND session = ${bet.session}
      ORDER BY created_at DESC
      LIMIT 1;
    `;
    if (!resultRows || resultRows.length === 0) {
      return NextResponse.json(
        { error: 'တရားဝင် ရလဒ် မထုတ်ပြန်ရသေးပါ' },
        { status: 409 }
      );
    }
    const winningNumber = String((resultRows[0] as { winning_number: string }).winning_number);

    const isToodResult = bet.type === '3D' && isTood(winningNumber);
    const multiplier = isToodResult ? TOOD_MULTIPLIER : bet.type === '2D' ? 85 : 550;
    const winStatus = isToodResult ? 'TOOD_WIN' : 'win';
    const items = parseJsonArray(bet.items) as BetItemLike[];
    const numbers = parseJsonArray(bet.numbers) as string[];
    const { totalWin, details, matched } = computeWin(
      winningNumber,
      items,
      numbers,
      Number(bet.amount),
      multiplier
    );

    if (matched && totalWin > 0) {
      const txId = payoutTransactionId(betId, isToodResult);
      const credited = await sql`
        WITH updated AS (
          UPDATE bets
          SET status = ${winStatus}, winning_number = ${winningNumber},
              win_amount = ${totalWin}, win_details = ${details},
              payout_multiplier = ${multiplier}, is_tood = ${isToodResult}
          WHERE id = ${betId} AND status = 'pending'
          RETURNING uid, win_amount
        ),
        tx AS (
          INSERT INTO transactions
            (id, uid, type, amount, method, transaction_number, status, timestamp,
             bet_id, draw_id, bet_number, bet_amount, payout_multiplier)
          SELECT ${txId}, u.uid, ${isToodResult ? 'TOOD_WIN' : 'deposit'}, u.win_amount,
                 ${isToodResult ? 'TOOD_WIN' : bet.type + ' Win'},
                 ${winningNumber}, 'completed', ${new Date().toLocaleString()},
                 ${betId}, ${bet.session}, ${winningNumber}, ${Number(bet.amount)}, ${multiplier}
          FROM updated u
          ON CONFLICT (id) DO NOTHING
          RETURNING uid, amount
        )
        UPDATE users SET balance = balance + t.amount, updated_at = NOW()
        FROM tx t
        WHERE users.uid = t.uid
        RETURNING users.uid, users.balance;
      `;
      if (!credited || credited.length === 0) {
        return NextResponse.json({ error: 'Already settled' }, { status: 409 });
      }

      await recordWinSettlement({
        betId,
        winningNumber,
        multiplier,
        grossPayout: totalWin,
        isTood: isToodResult,
      });

      await createNotification({
        targetType: 'user',
        targetId: session.uid,
        type: 'win',
        title: isToodResult
          ? 'ဂုဏ်ယူပါသည်! TOOD ပေါက်ကြေးဆုငွေ ရရှိပါပြီ'
          : 'ဂုဏ်ယူပါသည်! ပေါက်ကြေးဆုငွေ ရရှိပါပြီ',
        message: isToodResult
          ? `${bet.type} TOOD ပေါက်ဂဏန်း (${winningNumber}) ဖြင့် ${totalWin.toLocaleString()} MMK ဆုငွေ (×${multiplier}) ရရှိပါပြီ။`
          : `${bet.type} ပေါက်ဂဏန်း (${winningNumber}) ဖြင့် ${totalWin.toLocaleString()} MMK ဆုငွေ ရရှိပါပြီ။`,
        data: { screen: 'record' },
      });

      return NextResponse.json({
        won: true,
        isTood: isToodResult,
        multiplier,
        winAmount: totalWin,
        details,
        newBalance: Number(
          (credited[0] as { balance: string | number } | undefined)?.balance || 0
        ),
      });
    } else {
      await sql`
        UPDATE bets
        SET status = 'lose', winning_number = ${winningNumber},
            win_amount = 0, payout_multiplier = 0, is_tood = false
        WHERE id = ${betId} AND status = 'pending';
      `;
      return NextResponse.json({ won: false, isTood: false, winAmount: 0, details: '' });
    }
  } catch (error: unknown) {
    console.error('Settlement failed:', error);
    return NextResponse.json({ error: 'Settlement failed' }, { status: 500 });
  }
}
