import { NextRequest, NextResponse } from 'next/server';
import { sql, ensureTablesExist, nextOrderNumber } from '@/lib/db';
import { getSession } from '@/lib/session';
import { createNotification } from '@/lib/notifications';

export async function GET() {
  try {
    await ensureTablesExist();
    const session = await getSession();
    if (!session || session.kind !== 'user' || !session.uid) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const txs = await sql`
      SELECT id, type, amount, method, transaction_number as "transactionNumber",
             order_number as "orderNumber", status, timestamp, slip_image as "slipImage"
      FROM transactions
      WHERE uid = ${session.uid}
      ORDER BY created_at DESC
      LIMIT 100;
    `;

    return NextResponse.json({
      transactions: (txs || []).map((t) => {
        const row = t as Record<string, unknown>;
        return {
          id: row.id,
          type: row.type,
          amount: Number(row.amount),
          method: row.method,
          transactionNumber: row.transactionNumber || '',
          orderNumber: row.orderNumber || '',
          status: row.status,
          timestamp: row.timestamp,
          slipImage: row.slipImage || '',
        };
      }),
    });
  } catch (error: unknown) {
    console.error('Fetch transactions failed:', error);
    return NextResponse.json({ error: 'Fetch transactions failed' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    await ensureTablesExist();
    const session = await getSession();
    if (!session || session.kind !== 'user' || !session.uid) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await req.json();
    const { type, amount, method, transactionNumber, timestamp, slipImage } = body;

    if (!type || (type !== 'deposit' && type !== 'withdraw')) {
      return NextResponse.json({ error: 'Invalid transaction type' }, { status: 400 });
    }
    const numAmount = Number(amount);
    if (!Number.isFinite(numAmount) || numAmount <= 0) {
      return NextResponse.json({ error: 'Invalid amount' }, { status: 400 });
    }

    if (type === 'withdraw') {
      const userRes = await sql`
        SELECT balance, status FROM users WHERE uid = ${session.uid} LIMIT 1;
      `;
      if (!userRes || userRes.length === 0) {
        return NextResponse.json({ error: 'User not found' }, { status: 404 });
      }
      const u = userRes[0] as { balance: string | number; status: string | null };
      if ((u.status || 'active') !== 'active') {
        return NextResponse.json({ error: 'အကောင့်ပိတ်ထားပါသည်' }, { status: 403 });
      }
      if (Number(u.balance) < numAmount) {
        return NextResponse.json({ error: 'လက်ကျန်ငွေ မလုံလောက်ပါ' }, { status: 400 });
      }
    }

    const txId = `tx-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
    const txStatus = 'pending';
    const orderNumber = await nextOrderNumber(type);

    await sql`
      INSERT INTO transactions (id, uid, type, amount, method, transaction_number, order_number, status, timestamp, slip_image)
      VALUES (${txId}, ${session.uid}, ${type}, ${numAmount}, ${method || 'Direct'},
              ${transactionNumber || ''}, ${orderNumber}, ${txStatus},
              ${timestamp || new Date().toLocaleString()},
              ${typeof slipImage === 'string' && slipImage ? slipImage : null});
    `;

    await createNotification({
      targetType: 'admin',
      targetId: null,
      type: 'transaction',
      title: type === 'deposit' ? 'ငွေသွင်းတောင်းဆိုမှုအသစ်' : 'ငွေထုတ်တောင်းဆိုမှုအသစ်',
      message: `${session.name || 'User'} မှ ${numAmount.toLocaleString()} MMK ${type === 'deposit' ? 'ငွေသွင်း' : 'ငွေထုတ်'} တောင်းဆိုထားပါသည်။`,
      data: { screen: 'transactions' },
    });
    await createNotification({
      targetType: 'user',
      targetId: session.uid,
      type: 'transaction',
      title: 'တောင်းဆိုမှု လက်ခံရရှိပါပြီ',
      message: `သင့် ${numAmount.toLocaleString()} MMK ${type === 'deposit' ? 'ငွေသွင်း' : 'ငွေထုတ်'} တောင်းဆိုမှုကို စစ်ဆေးနေပါသည်။`,
      data: { screen: 'wallet' },
    });

    return NextResponse.json({
      success: true,
      transaction: {
        id: txId,
        type,
        amount: numAmount,
        method: method || 'Direct',
        transactionNumber: transactionNumber || '',
        orderNumber,
        status: txStatus,
        timestamp,
      },
    });
  } catch (error: unknown) {
    console.error('Create transaction failed:', error);
    return NextResponse.json({ error: 'Create transaction failed' }, { status: 500 });
  }
}
