import { NextRequest, NextResponse } from 'next/server';
import { sql, ensureTablesExist } from '@/lib/db';
import { getSession } from '@/lib/session';
import { createNotification } from '@/lib/notifications';
import {
  DEFAULT_SCHEDULE,
  evaluateBetting,
  getMyanmarNow,
  type ScheduleConfig,
} from '@/lib/schedule';

interface BetItemInput {
  number?: string;
  amount?: number;
  subNumbers?: { number: string; amount: number }[];
}

function computeTotal(items: BetItemInput[], numbers: string[], amountPerNumber?: number): number {
  if (Array.isArray(items) && items.length > 0) {
    return items.reduce((sum, it) => sum + Number(it.amount || 0), 0);
  }
  return numbers.length * Number(amountPerNumber || 0);
}

export async function GET() {
  try {
    await ensureTablesExist();
    const session = await getSession();
    if (!session || session.kind !== 'user' || !session.uid) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const bets = await sql`
      SELECT id, type, session, amount, numbers, items, status,
             winning_number as "winningNumber", win_amount as "winAmount",
             win_details as "winDetails", payout_multiplier as "payoutMultiplier",
             is_tood as "isTood", date
      FROM bets
      WHERE uid = ${session.uid}
      ORDER BY created_at DESC
      LIMIT 100;
    `;

    return NextResponse.json({
      bets: (bets || []).map((b) => {
        const row = b as Record<string, unknown>;
        return {
          id: row.id,
          type: row.type,
          session: row.session,
          amount: Number(row.amount),
          numbers: row.numbers || [],
          items: row.items || [],
          status: row.status,
          winningNumber: row.winningNumber,
          winAmount: row.winAmount ? Number(row.winAmount) : undefined,
          winDetails: row.winDetails,
          payoutMultiplier: row.payoutMultiplier ? Number(row.payoutMultiplier) : undefined,
          isTood: Boolean(row.isTood),
          date: row.date,
        };
      }),
    });
  } catch (error: unknown) {
    console.error('Fetch bets failed:', error);
    return NextResponse.json({ error: 'Fetch bets failed' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    await ensureTablesExist();
    const session = await getSession();
    if (!session || session.kind !== 'user' || !session.uid) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await req.json();
    const { type, session: betSession, numbers, items, date, amountPerNumber } = body;

    if (!type || !betSession || !Array.isArray(numbers) || numbers.length === 0) {
      return NextResponse.json({ error: 'Invalid bet payload' }, { status: 400 });
    }

    const betType: '2D' | '3D' = type === '3D' ? '3D' : '2D';

    const scheduleRows = await sql`SELECT value FROM settings WHERE key = 'schedule' LIMIT 1;`;
    const storedSchedule = (scheduleRows?.[0] as { value?: Partial<ScheduleConfig> } | undefined)?.value;
    const schedule: ScheduleConfig = { ...DEFAULT_SCHEDULE, ...(storedSchedule || {}) };
    const evaluation = evaluateBetting(schedule, betType, getMyanmarNow());
    if (!evaluation.open || !evaluation.session) {
      return NextResponse.json(
        { error: 'ထိုးသွင်းချိန် မဟုတ်ပါ (ထိုးချိန် ပိတ်ထားပါသည်)' },
        { status: 403 }
      );
    }
    const canonicalSession = evaluation.session;

    const itemList: BetItemInput[] = Array.isArray(items) ? items : [];
    const total = computeTotal(itemList, numbers, amountPerNumber);
    if (!Number.isFinite(total) || total <= 0) {
      return NextResponse.json({ error: 'Invalid bet amount' }, { status: 400 });
    }

    {
      const width = betType === '2D' ? 2 : 3;
      const newCounts: Record<string, number> = {};
      for (const it of itemList) {
        const subs =
          it.subNumbers && it.subNumbers.length > 0
            ? it.subNumbers
            : [{ number: String(it.number || '') }];
        for (const s of subs) {
          const key = String(s.number || '').padStart(width, '0');
          if (key) newCounts[key] = (newCounts[key] || 0) + 1;
        }
      }

      const limitRows = await sql`
        SELECT number, max_bet_count, is_blocked FROM number_limits WHERE type = ${betType};
      `;
      const limitMap = new Map<string, { max: number; blocked: boolean }>();
      for (const r of limitRows || []) {
        const row = r as { number: string; max_bet_count: number; is_blocked: boolean };
        limitMap.set(String(row.number).padStart(width, '0'), {
          max: Number(row.max_bet_count),
          blocked: Boolean(row.is_blocked),
        });
      }

      const todayRows = await sql`
        SELECT items FROM bets WHERE type = ${betType} AND created_at >= CURRENT_DATE;
      `;
      const currentCounts: Record<string, number> = {};
      for (const r of todayRows || []) {
        let todayItems: unknown = (r as { items: unknown }).items;
        if (typeof todayItems === 'string') {
          try {
            todayItems = JSON.parse(todayItems);
          } catch {
            todayItems = [];
          }
        }
        if (!Array.isArray(todayItems)) continue;
        for (const it of todayItems as BetItemInput[]) {
          const subs =
            it.subNumbers && it.subNumbers.length > 0
              ? it.subNumbers
              : [{ number: String(it.number || '') }];
          for (const s of subs) {
            const key = String(s.number || '').padStart(width, '0');
            if (key) currentCounts[key] = (currentCounts[key] || 0) + 1;
          }
        }
      }

      for (const [num, count] of Object.entries(newCounts)) {
        const limit = limitMap.get(num);
        if (limit?.blocked) {
          return NextResponse.json({ error: `ဂဏန်း (${num}) ကို ပိတ်ထားပါသည်` }, { status: 400 });
        }
        const max = limit?.max ?? 100;
        if ((currentCounts[num] || 0) + count > max) {
          return NextResponse.json(
            { error: `ဂဏန်း (${num}) သည် သတ်မှတ်အကြိမ်ရေ ပြည့်သွားပါပြီ` },
            { status: 400 }
          );
        }
      }
    }

    const userRes = await sql`
      SELECT balance, status FROM users WHERE uid = ${session.uid} LIMIT 1;
    `;
    if (!userRes || userRes.length === 0) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }
    const u = userRes[0] as { balance: string | number; status: string | null };
    if ((u.status || 'active') !== 'active') {
      return NextResponse.json({ error: 'အကောင့်ပိတ်ထားပါသည်' }, { status: 403 });
    }
    if (Number(u.balance) < total) {
      return NextResponse.json({ error: 'လက်ကျန်ငွေ မလုံလောက်ပါ' }, { status: 400 });
    }

    const betId = `bet-${Date.now()}-${Math.floor(Math.random() * 1000)}`;

    const deductRes = await sql`
      UPDATE users SET balance = balance - ${total}, updated_at = NOW()
      WHERE uid = ${session.uid} AND balance >= ${total}
      RETURNING balance;
    `;
    if (!deductRes || deductRes.length === 0) {
      return NextResponse.json({ error: 'လက်ကျန်ငွေ မလုံလောက်ပါ' }, { status: 400 });
    }

    await sql`
      INSERT INTO bets (id, uid, type, session, amount, numbers, items, status, date)
      VALUES (${betId}, ${session.uid}, ${betType}, ${canonicalSession}, ${total},
              ${JSON.stringify(numbers)}, ${JSON.stringify(itemList)}, 'pending',
              ${date || new Date().toISOString()});
    `;

    await createNotification({
      targetType: 'user',
      targetId: session.uid,
      type: 'bet',
      title: 'ထိုးစာရင်း အတည်ပြုပြီးပါပြီ',
      message: `${betType} ထိုးစာရင်း ${total.toLocaleString()} MMK အောင်မြင်စွာ ထိုးပြီးပါပြီ။`,
      data: { screen: 'record' },
    });
    await createNotification({
      targetType: 'admin',
      targetId: null,
      type: 'bet',
      title: 'ထိုးစာရင်းအသစ် (New Bet)',
      message: `${session.name || 'User'} မှ ${betType} ${total.toLocaleString()} MMK ထိုးထားပါသည်။`,
      data: { screen: 'bet_records' },
    });

    return NextResponse.json({
      success: true,
      bet: {
        id: betId,
        type: betType,
        session: canonicalSession,
        amount: total,
        numbers,
        items: itemList,
        status: 'pending',
        date,
      },
      newBalance: Number((deductRes[0] as { balance: string | number }).balance),
    });
  } catch (error: unknown) {
    console.error('Create bet failed:', error);
    return NextResponse.json({ error: 'Create bet failed' }, { status: 500 });
  }
}
