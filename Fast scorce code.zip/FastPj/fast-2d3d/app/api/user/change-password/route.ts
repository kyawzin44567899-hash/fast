import { NextRequest, NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';
import { sql, ensureTablesExist } from '@/lib/db';
import { getSession } from '@/lib/session';

export async function POST(req: NextRequest) {
  try {
    await ensureTablesExist();
    const session = await getSession();
    if (!session || session.kind !== 'user' || !session.uid) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await req.json();
    const { currentPassword, newPassword } = body;

    if (!currentPassword || !newPassword) {
      return NextResponse.json(
        { error: 'လက်ရှိ လျှို့ဝှက်နံပါတ် နှင့် လျှို့ဝှက်နံပါတ် အသစ်တို့ကို ထည့်သွင်းပေးပါ' },
        { status: 400 }
      );
    }

    if (String(newPassword).length < 4) {
      return NextResponse.json(
        { error: 'လျှို့ဝှက်နံပါတ် အသစ်သည် အနည်းဆုံး ၄ လုံး ရှိရပါမည်' },
        { status: 400 }
      );
    }

    const users = await sql`
      SELECT id, uid, password_hash FROM users WHERE uid = ${session.uid} LIMIT 1;
    `;

    if (!users || users.length === 0) {
      return NextResponse.json({ error: 'အကောင့် ရှာမတွေ့ပါ' }, { status: 404 });
    }

    const user = users[0] as { password_hash: string | null };

    if (user.password_hash) {
      const isMatch = await bcrypt.compare(String(currentPassword), user.password_hash);
      if (!isMatch) {
        return NextResponse.json({ error: 'လက်ရှိ လျှို့ဝှက်နံပါတ် မှားယွင်းနေပါသည်' }, { status: 401 });
      }
    }

    const salt = await bcrypt.genSalt(10);
    const newPasswordHash = await bcrypt.hash(String(newPassword), salt);

    await sql`
      UPDATE users SET password_hash = ${newPasswordHash}, updated_at = NOW()
      WHERE uid = ${session.uid};
    `;

    return NextResponse.json({
      success: true,
      message: 'လျှို့ဝှက်နံပါတ် အောင်မြင်စွာ ပြောင်းလဲပြီးပါပြီ',
    });
  } catch (error: unknown) {
    console.error('Change password error:', error);
    return NextResponse.json({ error: 'Change password failed' }, { status: 500 });
  }
}
