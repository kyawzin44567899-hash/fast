import { NextRequest, NextResponse } from 'next/server';
import { sql, ensureTablesExist } from '@/lib/db';
import { getSession } from '@/lib/session';

export async function POST(req: NextRequest) {
  try {
    await ensureTablesExist();
    const session = await getSession();
    if (!session || session.kind !== 'user' || !session.uid) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await req.json();
    const { name, phone } = body;

    if (name !== undefined && (typeof name !== 'string' || name.trim().length === 0)) {
      return NextResponse.json({ error: 'Invalid name' }, { status: 400 });
    }

    if (phone !== undefined) {
      const cleanPhone = String(phone).trim();
      const dupe = await sql`
        SELECT uid FROM users WHERE phone = ${cleanPhone} AND uid <> ${session.uid} LIMIT 1;
      `;
      if (dupe && dupe.length > 0) {
        return NextResponse.json({ error: 'ဖုန်းနံပါတ် အသုံးပြုပြီးသား ဖြစ်ပါသည်' }, { status: 409 });
      }
    }

    const updates = await sql`
      UPDATE users
      SET name = COALESCE(${name ?? null}, name),
          phone = COALESCE(${phone ?? null}, phone),
          updated_at = NOW()
      WHERE uid = ${session.uid}
      RETURNING uid, name, phone, agent_code, balance, role, status;
    `;

    if (!updates || updates.length === 0) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    const u = updates[0] as {
      uid: string;
      name: string;
      phone: string;
      agent_code: string | null;
      balance: string | number;
      role: string | null;
      status: string | null;
    };

    return NextResponse.json({
      success: true,
      user: {
        uid: u.uid,
        name: u.name,
        phone: u.phone,
        agentCode: u.agent_code || '',
        balance: Number(u.balance),
        role: u.role || 'user',
        status: u.status || 'active',
      },
    });
  } catch (error: unknown) {
    console.error('Update profile failed:', error);
    return NextResponse.json({ error: 'Update failed' }, { status: 500 });
  }
}
