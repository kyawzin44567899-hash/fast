import { NextRequest, NextResponse } from 'next/server';
import { ensureTablesExist } from '@/lib/db';
import { runSettlement } from '@/lib/settlement';

async function handle(req: NextRequest) {
  const secret = process.env.CRON_SECRET;
  const provided =
    req.headers.get('x-cron-secret') ||
    new URL(req.url).searchParams.get('secret');

  if (!secret || provided !== secret) {
    return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
  }

  try {
    await ensureTablesExist();
    const result = await runSettlement();
    return NextResponse.json({ success: true, data: result });
  } catch (error) {
    console.error('Cron settlement failed:', error);
    return NextResponse.json({ success: false, error: 'Settlement failed' }, { status: 500 });
  }
}

export async function GET(req: NextRequest) {
  return handle(req);
}

export async function POST(req: NextRequest) {
  return handle(req);
}
