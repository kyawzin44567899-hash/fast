import { NextRequest, NextResponse } from 'next/server';
import { sql, ensureTablesExist } from '@/lib/db';
import { getSession } from '@/lib/session';

type NumberType = '2D' | '3D';

interface BetItemLike {
  number?: string;
  amount?: number;
  subNumbers?: { number: string; amount: number }[];
}

function normalizeType(value: string | null): NumberType {
  return value === '3D' ? '3D' : '2D';
}

function widthFor(type: NumberType): number {
  return type === '2D' ? 2 : 3;
}

async function computeTodayCounts(type: NumberType): Promise<Record<string, number>> {
  const counts: Record<string, number> = {};
  const width = widthFor(type);
  const rows = await sql`
    SELECT items FROM bets
    WHERE type = ${type} AND created_at >= CURRENT_DATE;
  `;
  for (const r of rows || []) {
    let items: unknown = (r as { items: unknown }).items;
    if (typeof items === 'string') {
      try {
        items = JSON.parse(items);
      } catch {
        items = [];
      }
    }
    if (!Array.isArray(items)) continue;
    for (const it of items as BetItemLike[]) {
      const subs = it.subNumbers && it.subNumbers.length > 0 ? it.subNumbers : [{ number: it.number }];
      for (const s of subs) {
        const key = String(s.number || '').padStart(width, '0');
        if (key) counts[key] = (counts[key] || 0) + 1;
      }
    }
  }
  return counts;
}

async function computeTodayAmounts(type: NumberType): Promise<Record<string, number>> {
  const amounts: Record<string, number> = {};
  const width = widthFor(type);
  const rows = await sql`
    SELECT items FROM bets
    WHERE type = ${type} AND created_at >= CURRENT_DATE;
  `;
  for (const r of rows || []) {
    let items: unknown = (r as { items: unknown }).items;
    if (typeof items === 'string') {
      try {
        items = JSON.parse(items);
      } catch {
        items = [];
      }
    }
    if (!Array.isArray(items)) continue;
    for (const it of items as BetItemLike[]) {
      const subs =
        it.subNumbers && it.subNumbers.length > 0
          ? it.subNumbers
          : [{ number: it.number, amount: it.amount }];
      for (const s of subs) {
        const key = String(s.number || '').padStart(width, '0');
        if (key) amounts[key] = (amounts[key] || 0) + Number(s.amount || 0);
      }
    }
  }
  return amounts;
}

export async function GET(req: NextRequest) {
  try {
    await ensureTablesExist();
    const session = await getSession();
    if (!session || session.kind !== 'user') {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const type = normalizeType(new URL(req.url).searchParams.get('type'));
    const width = widthFor(type);
    const total = type === '2D' ? 100 : 1000;

    const rows = await sql`
      SELECT number, max_bet_count, max_bet_amount, is_blocked FROM number_limits WHERE type = ${type};
    `;
    const configured = new Map<string, { max: number; maxAmount: number; blocked: boolean }>();
    for (const r of rows || []) {
      const row = r as {
        number: string;
        max_bet_count: number;
        max_bet_amount: string | number;
        is_blocked: boolean;
      };
      configured.set(String(row.number).padStart(width, '0'), {
        max: Number(row.max_bet_count),
        maxAmount: Number(row.max_bet_amount || 0),
        blocked: Boolean(row.is_blocked),
      });
    }

    const counts = await computeTodayCounts(type);
    const amounts = await computeTodayAmounts(type);

    const data = Array.from({ length: total }, (_, i) => {
      const number = String(i).padStart(width, '0');
      const conf = configured.get(number);
      return {
        number,
        maxBetCount: conf?.max ?? 100,
        maxBetAmount: conf?.maxAmount ?? 0,
        currentBetCount: counts[number] || 0,
        currentBetAmount: amounts[number] || 0,
        isBlocked: conf?.blocked ?? false,
      };
    });

    return NextResponse.json({ success: true, data });
  } catch (error) {
    console.error('Fetch number status failed:', error);
    return NextResponse.json({ success: false, error: 'Failed' }, { status: 500 });
  }
}
