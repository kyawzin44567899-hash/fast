import { NextResponse } from 'next/server';
import { sql, ensureTablesExist } from '@/lib/db';

export async function GET() {
  try {
    await ensureTablesExist();
    const rows = await sql`
      SELECT key, value FROM settings
      WHERE key IN ('website', 'ads', 'schedule', 'winningSlots');
    `;
    const map: Record<string, unknown> = {};
    for (const r of rows || []) {
      const row = r as { key: string; value: unknown };
      map[row.key] = row.value;
    }
    return NextResponse.json({ success: true, data: map });
  } catch (error) {
    console.error('Fetch public settings failed:', error);
    return NextResponse.json({ success: false, error: 'Failed' }, { status: 500 });
  }
}
