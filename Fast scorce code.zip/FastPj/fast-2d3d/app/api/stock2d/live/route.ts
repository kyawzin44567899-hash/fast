import { NextResponse } from 'next/server';
import { maybeRunSettlement } from '@/lib/settlement';

export async function GET() {

  maybeRunSettlement();

  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 4500);

    const res = await fetch('https://api.thaistock2d.com/live', {
      headers: {
        Accept: 'application/json',
        'User-Agent': 'Fast2D3D-App/1.0',
      },
      signal: controller.signal,
      cache: 'no-store',
    });

    clearTimeout(timeoutId);

    if (res.ok) {
      const data = await res.json();
      return NextResponse.json(data, {
        headers: {
          'Cache-Control': 'no-store, max-age=0',
        },
      });
    }
  } catch {

  }

  return NextResponse.json(
    { live: null, result: [], message: 'Live data currently unavailable' },
    {
      status: 503,
      headers: {
        'Cache-Control': 'no-store, max-age=0',
      },
    }
  );
}
