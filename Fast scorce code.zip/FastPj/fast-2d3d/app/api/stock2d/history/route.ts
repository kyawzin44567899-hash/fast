import { NextResponse } from 'next/server';

export async function GET() {
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 5000);

    const res = await fetch('https://api.thaistock2d.com/history', {
      headers: {
        Accept: 'application/json',
        'User-Agent': 'Fast2D3D-App/1.0',
      },
      signal: controller.signal,
      next: { revalidate: 30 },
    });

    clearTimeout(timeoutId);

    if (res.ok) {
      const data = await res.json();
      return NextResponse.json(data);
    }
  } catch {

  }

  return NextResponse.json([]);
}
