import { NextRequest, NextResponse } from 'next/server';
import { ensureTablesExist, sql } from '@/lib/db';
import { getSession } from '@/lib/session';

export async function POST(req: NextRequest) {
  try {
    await ensureTablesExist();
    const session = await getSession();
    if (!session || session.kind !== 'user' || !session.uid) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const body = await req.json();
    const endpoint = body?.endpoint;
    if (endpoint) {
      await sql`
        DELETE FROM push_subscriptions
        WHERE endpoint = ${endpoint} AND target_type = 'user' AND target_id = ${session.uid};
      `;
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Push unsubscribe failed:', error);
    return NextResponse.json({ success: false, error: 'Failed' }, { status: 500 });
  }
}
