import { NextRequest, NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';
import { sql, ensureTablesExist, generateRandom10DigitUID } from '@/lib/db';
import { setSession } from '@/lib/session';

export async function POST(req: NextRequest) {
  try {
    await ensureTablesExist();
    const body = await req.json();
    const { name, phone, password, agentCode } = body;

    if (!phone || !password) {
      return NextResponse.json({ error: 'Phone number and password are required' }, { status: 400 });
    }

    const cleanPhone = String(phone).trim();
    const cleanName = (name || 'User').trim();
    const cleanAgentCode =
      agentCode && String(agentCode).trim() ? String(agentCode).trim() : null;

    const existing = await sql`
      SELECT id, uid FROM users WHERE phone = ${cleanPhone} LIMIT 1;
    `;

    if (existing && existing.length > 0) {
      return NextResponse.json(
        { error: 'အကောင့်ရှိပြီးသားဖြစ်ပါသည်။ ကျေးဇူးပြု၍ Login ဝင်ပါ။' },
        { status: 409 }
      );
    }

    if (cleanAgentCode) {
      const agents = await sql`
        SELECT code FROM agents WHERE code = ${cleanAgentCode} AND status = 'active' LIMIT 1;
      `;
      if (!agents || agents.length === 0) {
        return NextResponse.json(
          { error: 'အေးဂျင့်ကုဒ် မမှန်ကန်ပါ သို့မဟုတ် ပိတ်ထားပါသည်' },
          { status: 400 }
        );
      }
    }

    let uid = generateRandom10DigitUID();
    let isUnique = false;
    let attempts = 0;
    while (!isUnique && attempts < 5) {
      const checkUid = await sql`SELECT id FROM users WHERE uid = ${uid} LIMIT 1;`;
      if (!checkUid || checkUid.length === 0) {
        isUnique = true;
      } else {
        uid = generateRandom10DigitUID();
        attempts++;
      }
    }

    const salt = await bcrypt.genSalt(10);
    const passwordHash = await bcrypt.hash(String(password), salt);

    const result = await sql`
      INSERT INTO users (uid, name, phone, password_hash, agent_code, role, status, balance)
      VALUES (${uid}, ${cleanName}, ${cleanPhone}, ${passwordHash}, ${cleanAgentCode}, 'user', 'active', 0.00)
      RETURNING id, uid, name, phone, agent_code, balance, role, status;
    `;

    const user = result[0] as {
      id: number;
      uid: string;
      name: string;
      phone: string;
      agent_code: string | null;
      balance: string | number;
      role: string | null;
      status: string | null;
    };

    await setSession({ kind: 'user', id: user.id, uid: user.uid, name: user.name });

    return NextResponse.json({
      success: true,
      user: {
        uid: user.uid,
        name: user.name,
        phone: user.phone,
        agentCode: user.agent_code || '',
        balance: Number(user.balance || 0),
        role: user.role || 'user',
        status: user.status || 'active',
      },
    });
  } catch (error: unknown) {
    console.error('Registration error:', error);
    return NextResponse.json({ error: 'Registration failed' }, { status: 500 });
  }
}
