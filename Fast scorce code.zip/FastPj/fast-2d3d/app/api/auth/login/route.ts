import { NextRequest, NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';
import { sql, ensureTablesExist } from '@/lib/db';
import { setSession } from '@/lib/session';

export async function POST(req: NextRequest) {
  try {
    await ensureTablesExist();
    const body = await req.json();
    const { phone, password } = body;

    if (!phone) {
      return NextResponse.json({ error: 'Phone number is required' }, { status: 400 });
    }

    const cleanPhone = String(phone).trim();

    const users = await sql`
      SELECT id, uid, name, phone, password_hash, agent_code, balance, status, role
      FROM users
      WHERE phone = ${cleanPhone}
      LIMIT 1;
    `;

    if (!users || users.length === 0) {
      return NextResponse.json(
        { error: 'အကောင့် မရှိသေးပါ။ ကျေးဇူးပြု၍ Register တွင် အကောင့်အရင်ဖွင့်ပါ။' },
        { status: 404 }
      );
    }

    const user = users[0] as {
      id: number;
      uid: string;
      name: string;
      phone: string;
      password_hash: string | null;
      agent_code: string | null;
      balance: string | number;
      status: string | null;
      role: string | null;
    };

    if (!password) {
      return NextResponse.json({ error: 'စကားဝှက် ထည့်သွင်းပေးပါ' }, { status: 400 });
    }

    if (user.password_hash) {
      const isMatch = await bcrypt.compare(String(password), user.password_hash);
      if (!isMatch) {
        return NextResponse.json({ error: 'စကားဝှက် မှားယွင်းနေပါသည်' }, { status: 401 });
      }
    }

    if ((user.status || 'active') !== 'active') {
      return NextResponse.json(
        { error: 'သင့်အကောင့်ကို ပိတ်ထားပါသည်။ ကျေးဇူးပြု၍ Support ကို ဆက်သွယ်ပါ။' },
        { status: 403 }
      );
    }

    await setSession({
      kind: 'user',
      id: user.id,
      uid: user.uid,
      name: user.name,
    });

    return NextResponse.json({
      success: true,
      user: {
        uid: user.uid,
        name: user.name,
        phone: user.phone,
        agentCode: user.agent_code || '',
        balance: Number(user.balance),
        role: user.role || 'user',
        status: user.status || 'active',
      },
    });
  } catch (error: unknown) {
    console.error('Login error:', error);
    return NextResponse.json({ error: 'Login failed' }, { status: 500 });
  }
}
