import { NextResponse } from 'next/server';
import { sql, ensureTablesExist } from '@/lib/db';
import { getSession } from '@/lib/session';

export async function GET() {
  try {
    await ensureTablesExist();
    const session = await getSession();
    if (!session || session.kind !== 'user' || !session.uid) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const users = await sql`
      SELECT uid, name, phone, agent_code, balance, role, status
      FROM users
      WHERE uid = ${session.uid}
      LIMIT 1;
    `;

    if (!users || users.length === 0) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    const u = users[0] as {
      uid: string;
      name: string;
      phone: string;
      agent_code: string | null;
      balance: string | number;
      role: string | null;
      status: string | null;
    };

    return NextResponse.json({
      user: {
        uid: u.uid,
        name: u.name,
        phone: u.phone,
        agentCode: u.agent_code || '',
        balance: Number(u.balance),
        role: u.role || 'user',
        status: u.status || 'active',
      },
    });
  } catch (error: unknown) {
    console.error('Me error:', error);
    return NextResponse.json({ error: 'Failed to fetch user' }, { status: 500 });
  }
}
