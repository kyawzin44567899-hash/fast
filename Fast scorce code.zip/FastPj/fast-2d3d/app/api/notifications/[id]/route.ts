import { NextRequest, NextResponse } from 'next/server';
import { ensureTablesExist } from '@/lib/db';
import { getSession } from '@/lib/session';
import { markNotificationRead } from '@/lib/notifications';

interface RouteContext {
  params: Promise<{ id: string }>;
}

export async function PATCH(_req: NextRequest, ctx: RouteContext) {
  try {
    await ensureTablesExist();
    const session = await getSession();
    if (!session || session.kind !== 'user' || !session.uid) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }
    const { id } = await ctx.params;
    const updated = await markNotificationRead(id, 'user', session.uid);
    if (!updated) {
      return NextResponse.json({ success: false, error: 'Notification not found' }, { status: 404 });
    }
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Mark notification read failed:', error);
    return NextResponse.json({ success: false, error: 'Failed' }, { status: 500 });
  }
}
