import { NextResponse } from 'next/server';
import { ensureTablesExist } from '@/lib/db';
import { getSession } from '@/lib/session';
import { markAllNotificationsRead } from '@/lib/notifications';

export async function POST() {
  try {
    await ensureTablesExist();
    const session = await getSession();
    if (!session || session.kind !== 'user' || !session.uid) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }
    await markAllNotificationsRead('user', session.uid);
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Mark all read failed:', error);
    return NextResponse.json({ success: false, error: 'Failed' }, { status: 500 });
  }
}
