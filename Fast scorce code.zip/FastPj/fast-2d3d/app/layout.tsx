import type {Metadata, Viewport} from 'next';
import './globals.css';

export const viewport: Viewport = {
  themeColor: '#0a0a0a',
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  viewportFit: 'cover',
};

export const metadata: Metadata = {
  title: 'Fast 2D3D',
  description: 'Official mobile PWA application for real-time 2D 3D lottery results, live numbers, and wallet management.',
  applicationName: 'Fast 2D3D',
  appleWebApp: {
    capable: true,
    statusBarStyle: 'black',
    title: 'Fast 2D3D',
  },
  icons: {
    icon: '/favicon.ico',
    apple: [
      { url: '/apple-touch-icon-iphone-60x60.png', sizes: '60x60', type: 'image/png' },
      { url: '/apple-touch-icon-iphone-retina-120x120.png', sizes: '120x120', type: 'image/png' },
      { url: '/apple-touch-icon-ipad-76x76.png', sizes: '76x76', type: 'image/png' },
      { url: '/apple-touch-icon-ipad-retina-152x152.png', sizes: '152x152', type: 'image/png' },
      { url: '/images/logo.png', sizes: '180x180', type: 'image/png' },
    ],
  },
  openGraph: {
    title: 'Fast 2D3D',
    description: 'Official mobile PWA application for real-time 2D 3D lottery results, live numbers, and wallet management.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Fast 2D3D',
    description: 'Official mobile PWA application for real-time 2D 3D lottery results, live numbers, and wallet management.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <head>
        <link rel="manifest" href="/manifest.webmanifest" />
        <meta name="mobile-web-app-capable" content="yes" />
      </head>
      <body suppressHydrationWarning className="bg-[#0a0a0a] text-white antialiased selection:bg-amber-500 selection:text-black min-h-screen">
        {children}
        <script
          dangerouslySetInnerHTML={{
            __html: `
              if ('serviceWorker' in navigator) {
                window.addEventListener('load', function() {
                  var isDev = window.location.hostname.includes('localhost') ||
                              window.location.hostname.includes('ais-dev') ||
                              window.location.port === '3000';
                  if (isDev) {
                    navigator.serviceWorker.getRegistrations().then(function(regs) {
                      for (var i = 0; i < regs.length; i++) {
                        regs[i].unregister();
                      }
                    });
                  } else {
                    navigator.serviceWorker.register('/sw.js').then(function(reg) {
                      reg.update();
                    }).catch(function(err) {
                      console.log('SW registration failed: ', err);
                    });
                  }
                });
              }
            `,
          }}
        />
      </body>
    </html>
  );
}
