'use client';

import { useState, useEffect, useCallback } from 'react';
import { getCachedAppSettings, fetchAppSettings } from '@/lib/appSettings';

export interface BannerConfig {
  id: string;
  title: string;
  imageUrl: string;
  link?: string;
  active: boolean;
}

export interface ClientAdsConfig {
  notice1: string;
  notice2: string;
  banners: BannerConfig[];
}

const DEFAULT_ADS: ClientAdsConfig = { notice1: '', notice2: '', banners: [] };

function mapAds(a: unknown): ClientAdsConfig {
  const raw = (a || {}) as {
    notice1?: string;
    tickerNotice?: string;
    notice2?: string;
    banners?: BannerConfig[];
  };
  return {
    notice1: raw.notice1 || raw.tickerNotice || '',
    notice2: raw.notice2 || '',
    banners: Array.isArray(raw.banners) ? raw.banners.filter((b) => b.active !== false) : [],
  };
}

export function useAds() {
  const [ads, setAds] = useState<ClientAdsConfig>(() => {
    const cached = getCachedAppSettings();
    return cached?.ads ? mapAds(cached.ads) : DEFAULT_ADS;
  });

  const refresh = useCallback(async () => {
    const data = await fetchAppSettings();
    if (data?.ads) setAds(mapAds(data.ads));
  }, []);

  useEffect(() => {
    const timer = setTimeout(() => {
      void refresh();
    }, 0);
    return () => clearTimeout(timer);
  }, [refresh]);

  return { ...ads, refresh };
}
