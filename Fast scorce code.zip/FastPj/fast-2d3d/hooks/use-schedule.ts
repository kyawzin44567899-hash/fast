'use client';

import { useState, useEffect, useCallback } from 'react';
import {
  DEFAULT_SCHEDULE,
  evaluateBetting,
  getMyanmarNow,
  type ScheduleConfig,
  type MyanmarNow,
  type BettingEvaluation,
} from '@/lib/schedule';
import { getCachedAppSettings, fetchAppSettings } from '@/lib/appSettings';

const CLOSED: BettingEvaluation = { open: false, session: null, reason: 'outside_window' };

export function useSchedule() {
  const [schedule, setSchedule] = useState<ScheduleConfig>(() => {
    const cached = getCachedAppSettings();
    return cached?.schedule
      ? { ...DEFAULT_SCHEDULE, ...(cached.schedule as Partial<ScheduleConfig>) }
      : DEFAULT_SCHEDULE;
  });
  const [now, setNow] = useState<MyanmarNow | null>(() => getMyanmarNow());
  const [isLoading] = useState(false);

  useEffect(() => {
    let isMounted = true;

    void (async () => {
      try {
        const data = await fetchAppSettings();
        if (isMounted && data?.schedule) {
          setSchedule({ ...DEFAULT_SCHEDULE, ...(data.schedule as Partial<ScheduleConfig>) });
        }
      } catch {}
    })();

    const timer = setInterval(() => setNow(getMyanmarNow()), 30000);

    return () => {
      isMounted = false;
      clearInterval(timer);
    };
  }, []);

  const evaluate = useCallback(
    (type: '2D' | '3D'): BettingEvaluation => (now ? evaluateBetting(schedule, type, now) : CLOSED),
    [schedule, now]
  );

  return { schedule, evaluate, isLoading };
}
