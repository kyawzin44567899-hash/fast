export interface CachedWebsite {
  payments?: unknown[];
  withdrawalPayments?: unknown[];
  support?: { telegram?: string; viber?: string };
  [key: string]: unknown;
}

export interface CachedAppSettings {
  website?: CachedWebsite;
  ads?: unknown;
  schedule?: unknown;
  winningSlots?: unknown;
}

const KEY = 'f2d3d_settings_cache';
let memory: CachedAppSettings | null = null;

export function getCachedAppSettings(): CachedAppSettings | null {
  if (memory) return memory;
  if (typeof window === 'undefined') return null;
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) {
      memory = JSON.parse(raw) as CachedAppSettings;
      return memory;
    }
  } catch {}
  return null;
}

export async function fetchAppSettings(): Promise<CachedAppSettings | null> {
  try {
    const res = await fetch('/api/settings', { cache: 'no-store' });
    if (!res.ok) return null;
    const json = await res.json();
    const data = (json?.data || {}) as CachedAppSettings;
    memory = data;
    if (typeof window !== 'undefined') {
      try {
        localStorage.setItem(KEY, JSON.stringify(data));
      } catch {}
    }
    return data;
  } catch {
    return null;
  }
}
