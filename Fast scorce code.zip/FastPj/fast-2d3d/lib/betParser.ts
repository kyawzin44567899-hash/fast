

export interface BetSubNumber {
  number: string;
  amount: number;
}

export interface BetItem {
  number: string;
  amount: number;
  subNumbers?: BetSubNumber[];
  subCount?: number;
  perItemAmount?: number;
  label?: string;
}

export type ParsedBetItem = BetItem;

export function normalizeMyanmarDigits(input: string): string {
  const myanmarDigits = ['၀', '၁', '၂', '၃', '၄', '၅', '၆', '၇', '၈', '၉'];
  let res = input;
  for (let i = 0; i < 10; i++) {
    res = res.replaceAll(myanmarDigits[i], String(i));
  }
  return res;
}

export function getPermutations(str: string): string[] {
  if (str.length <= 1) return [str];
  if (str.length === 2) {
    return str[0] === str[1] ? [str] : [str, str[1] + str[0]];
  }
  const results = new Set<string>();
  const permute = (arr: string[], m: string[] = []) => {
    if (arr.length === 0) {
      results.add(m.join(''));
    } else {
      for (let i = 0; i < arr.length; i++) {
        const curr = arr.slice();
        const next = curr.splice(i, 1);
        permute(curr.slice(), m.concat(next));
      }
    }
  };
  permute(str.split(''));
  return Array.from(results);
}

export function createRBetItem(number: string, totalAmount: number, type: '2D' | '3D'): BetItem {
  const perms = getPermutations(number);
  const count = perms.length;

  if (count <= 1) {
    return {
      number,
      amount: totalAmount,
      subNumbers: [{ number, amount: totalAmount }],
      subCount: 1,
      perItemAmount: totalAmount,
      label: '၁ ကွက်',
    };
  }

  const perItem = Math.floor(totalAmount / count);
  const remainder = totalAmount - perItem * count;

  const subNumbers: BetSubNumber[] = perms.map((num, idx) => ({
    number: num,
    amount: idx < remainder ? perItem + 1 : perItem,
  }));

  const label =
    type === '2D'
      ? `${perms.join(', ')} (${perItem.toLocaleString()} ကျပ်စီ)`
      : `${count} ကွက် (${perItem.toLocaleString()} ကျပ်စီ)`;

  return {
    number: `${number} (R)`,
    amount: totalAmount,
    subNumbers,
    subCount: count,
    perItemAmount: perItem,
    label,
  };
}

export function createPresetBetItem(name: string, numbers: string[], totalAmount: number): BetItem {
  const count = numbers.length;
  const numbersString = numbers.join(', ');

  if (count === 0) {
    return {
      number: numbersString || name,
      amount: totalAmount,
      subNumbers: [],
      subCount: 0,
      perItemAmount: 0,
      label: name,
    };
  }

  const perItem = Math.floor(totalAmount / count);
  const remainder = totalAmount - perItem * count;

  const subNumbers: BetSubNumber[] = numbers.map((num, idx) => ({
    number: num,
    amount: idx < remainder ? perItem + 1 : perItem,
  }));

  return {
    number: numbersString,
    amount: totalAmount,
    subNumbers,
    subCount: count,
    perItemAmount: perItem,
    label: name ? `${name} (${count} ကွက်)` : `${count} ကွက်`,
  };
}

export const PRESETS_2D = {
  doubles: () => ['00', '11', '22', '33', '44', '55', '66', '77', '88', '99'],
  power: () => ['05', '50', '16', '61', '27', '72', '38', '83', '49', '94'],
  natkhat: () => ['07', '70', '18', '81', '24', '42', '35', '53', '69', '96'],
  brothers: () => {
    const all = Array.from({ length: 100 }, (_, i) => String(i).padStart(2, '0'));
    return all.filter((n) => {
      const a = parseInt(n[0], 10);
      const b = parseInt(n[1], 10);
      return (a + 1) % 10 === b || (b + 1) % 10 === a;
    });
  },
  even_even: () => {
    const all = Array.from({ length: 100 }, (_, i) => String(i).padStart(2, '0'));
    return all.filter((n) => parseInt(n[0], 10) % 2 === 0 && parseInt(n[1], 10) % 2 === 0);
  },
  odd_odd: () => {
    const all = Array.from({ length: 100 }, (_, i) => String(i).padStart(2, '0'));
    return all.filter((n) => parseInt(n[0], 10) % 2 !== 0 && parseInt(n[1], 10) % 2 !== 0);
  },
  even_odd: () => {
    const all = Array.from({ length: 100 }, (_, i) => String(i).padStart(2, '0'));
    return all.filter((n) => parseInt(n[0], 10) % 2 === 0 && parseInt(n[1], 10) % 2 !== 0);
  },
  odd_even: () => {
    const all = Array.from({ length: 100 }, (_, i) => String(i).padStart(2, '0'));
    return all.filter((n) => parseInt(n[0], 10) % 2 !== 0 && parseInt(n[1], 10) % 2 === 0);
  },
  head: (digit: number) => {
    return Array.from({ length: 10 }, (_, i) => `${digit}${i}`);
  },
  tail: (digit: number) => {
    return Array.from({ length: 10 }, (_, i) => `${i}${digit}`);
  },
  break: (digit: number) => {
    const all = Array.from({ length: 100 }, (_, i) => String(i).padStart(2, '0'));
    return all.filter((n) => (parseInt(n[0], 10) + parseInt(n[1], 10)) % 10 === digit);
  },
  all: () => Array.from({ length: 100 }, (_, i) => String(i).padStart(2, '0')),
};

export const PRESETS_3D = {
  triples: () => Array.from({ length: 10 }, (_, i) => `${i}${i}${i}`),
  front_double: () => {
    const res: string[] = [];
    for (let i = 0; i < 10; i++) {
      for (let j = 0; j < 10; j++) {
        if (i !== j) res.push(`${i}${i}${j}`);
      }
    }
    return res;
  },
  back_double: () => {
    const res: string[] = [];
    for (let i = 0; i < 10; i++) {
      for (let j = 0; j < 10; j++) {
        if (i !== j) res.push(`${j}${i}${i}`);
      }
    }
    return res;
  },
};

export function parseBetPaste(
  rawText: string,
  type: '2D' | '3D',
  defaultAmount: number
): BetItem[] {
  if (!rawText || !rawText.trim()) return [];

  const targetLength = type === '2D' ? 2 : 3;
  let text = normalizeMyanmarDigits(rawText);

  text = text.replace(/ကျပ်|ks|k|kyats|kyat/gi, ' ');

  const resultItems: BetItem[] = [];

  const addItem = (item: BetItem) => {
    const existing = resultItems.find((b) => b.number === item.number);
    if (existing) {
      existing.amount += item.amount;

      if (existing.subNumbers && existing.subNumbers.length > 0) {
        const count = existing.subNumbers.length;
        const perItem = Math.floor(existing.amount / count);
        const rem = existing.amount - perItem * count;
        existing.subNumbers.forEach((sub, i) => {
          sub.amount = i < rem ? perItem + 1 : perItem;
        });
        existing.perItemAmount = perItem;
        if (existing.label) {
          existing.label = `${count} ကွက် (${perItem.toLocaleString()} ကျပ်စီ)`;
        }
      }
    } else {
      resultItems.push(item);
    }
  };

  const lines = text.split(/[\r\n]+/);

  for (const rawLine of lines) {
    const line = rawLine.trim();
    if (!line) continue;

    if (/^အပူး/i.test(line)) {
      const amtMatch = line.match(/\d+/);
      const amt = amtMatch ? parseInt(amtMatch[0], 10) : defaultAmount;
      const numbers = type === '2D' ? PRESETS_2D.doubles() : PRESETS_3D.triples();
      addItem(createPresetBetItem(type === '2D' ? 'အပူး' : '3D အပူး', numbers, amt));
      continue;
    }

    if (/^ပါဝါ/i.test(line)) {
      const amtMatch = line.match(/\d+/);
      const amt = amtMatch ? parseInt(amtMatch[0], 10) : defaultAmount;
      addItem(createPresetBetItem('ပါဝါ', PRESETS_2D.power(), amt));
      continue;
    }

    if (/^နက္ခတ်/i.test(line)) {
      const amtMatch = line.match(/\d+/);
      const amt = amtMatch ? parseInt(amtMatch[0], 10) : defaultAmount;
      addItem(createPresetBetItem('နက္ခတ်', PRESETS_2D.natkhat(), amt));
      continue;
    }

    if (/^ညီကို/i.test(line)) {
      const amtMatch = line.match(/\d+/);
      const amt = amtMatch ? parseInt(amtMatch[0], 10) : defaultAmount;
      addItem(createPresetBetItem('ညီကို', PRESETS_2D.brothers(), amt));
      continue;
    }

    if (/^စုံစုံ/i.test(line)) {
      const amtMatch = line.match(/\d+/);
      const amt = amtMatch ? parseInt(amtMatch[0], 10) : defaultAmount;
      addItem(createPresetBetItem('စုံစုံ', PRESETS_2D.even_even(), amt));
      continue;
    }

    if (/^မမ/i.test(line)) {
      const amtMatch = line.match(/\d+/);
      const amt = amtMatch ? parseInt(amtMatch[0], 10) : defaultAmount;
      addItem(createPresetBetItem('မမ', PRESETS_2D.odd_odd(), amt));
      continue;
    }

    if (/^စုံမ/i.test(line)) {
      const amtMatch = line.match(/\d+/);
      const amt = amtMatch ? parseInt(amtMatch[0], 10) : defaultAmount;
      addItem(createPresetBetItem('စုံမ', PRESETS_2D.even_odd(), amt));
      continue;
    }

    if (/^မစုံ/i.test(line)) {
      const amtMatch = line.match(/\d+/);
      const amt = amtMatch ? parseInt(amtMatch[0], 10) : defaultAmount;
      addItem(createPresetBetItem('မစုံ', PRESETS_2D.odd_even(), amt));
      continue;
    }

    const headMatch = line.match(/^(\d)\s*ထိပ်\s*([=:\/\-*\s])?\s*(\d*)/);
    if (headMatch) {
      const d = parseInt(headMatch[1], 10);
      const amt = headMatch[3] ? parseInt(headMatch[3], 10) : defaultAmount;
      addItem(createPresetBetItem(`${d} ထိပ်`, PRESETS_2D.head(d), amt));
      continue;
    }

    const tailMatch = line.match(/^(\d)\s*နောက်\s*([=:\/\-*\s])?\s*(\d*)/);
    if (tailMatch) {
      const d = parseInt(tailMatch[1], 10);
      const amt = tailMatch[3] ? parseInt(tailMatch[3], 10) : defaultAmount;
      addItem(createPresetBetItem(`${d} နောက်`, PRESETS_2D.tail(d), amt));
      continue;
    }

    const breakMatch = line.match(/^(\d)\s*ဘရိတ်\s*([=:\/\-*\s])?\s*(\d*)/);
    if (breakMatch) {
      const d = parseInt(breakMatch[1], 10);
      const amt = breakMatch[3] ? parseInt(breakMatch[3], 10) : defaultAmount;
      addItem(createPresetBetItem(`${d} ဘရိတ်`, PRESETS_2D.break(d), amt));
      continue;
    }

    const rSingleMatch = line.match(
      new RegExp(`^(\\d{${targetLength}})\\s*(?:\\(R\\)|R)?\\s*(?:=|:|-|\\/|\\*|\\s)\\s*(\\d+)\\s*(?:\\(R\\)|R)?$`, 'i')
    );
    if (rSingleMatch && (line.includes('r') || line.includes('R') || line.includes('(R)'))) {
      const num = rSingleMatch[1];
      const amt = parseInt(rSingleMatch[2], 10) || defaultAmount;
      addItem(createRBetItem(num, amt, type));
      continue;
    }

    const rDirectMatch = line.match(
      new RegExp(`^(\\d{${targetLength}})\\s+(?:r|R)\\s+(\\d+)$`, 'i')
    );
    if (rDirectMatch) {
      const num = rDirectMatch[1];
      const amt = parseInt(rDirectMatch[2], 10) || defaultAmount;
      addItem(createRBetItem(num, amt, type));
      continue;
    }

    const groupMatch = line.match(/^([0-9\s,.\-*+/]+?)\s*(=|:|\/|-|\*)\s*([0-9]+)\s*(r|R)?$/i);
    if (groupMatch) {
      const numbersPart = groupMatch[1];
      const parsedAmt = parseInt(groupMatch[3], 10);
      const amt = parsedAmt >= 50 ? parsedAmt : defaultAmount;
      const isR = Boolean(groupMatch[4]);

      const nums = numbersPart.match(/\b\d+\b/g) || [];
      for (const n of nums) {
        if (n.length === targetLength) {
          if (isR) {
            addItem(createRBetItem(n, amt, type));
          } else {
            addItem({
              number: n,
              amount: amt,
              subNumbers: [{ number: n, amount: amt }],
              subCount: 1,
              perItemAmount: amt,
            });
          }
        }
      }
      continue;
    }

    const segments = line.split(/[,;]+/).map((s) => s.trim()).filter(Boolean);
    if (segments.length > 1 || line.includes('=') || line.includes(':') || line.includes('-')) {
      for (const seg of segments) {
        const segRMatch = seg.match(
          new RegExp(`^(\\d{${targetLength}})\\s*(?:\\(R\\)|R)?\\s*(?:=|:|-|\\/|\\*|\\s)\\s*(\\d+)\\s*(?:\\(R\\)|R)?$`, 'i')
        );
        if (segRMatch) {
          const num = segRMatch[1];
          const amt = parseInt(segRMatch[2], 10) || defaultAmount;
          const hasR = seg.includes('r') || seg.includes('R');
          if (hasR) {
            addItem(createRBetItem(num, amt, type));
          } else {
            addItem({
              number: num,
              amount: amt,
              subNumbers: [{ number: num, amount: amt }],
              subCount: 1,
              perItemAmount: amt,
            });
          }
          continue;
        }

        const plainNumMatch = seg.match(new RegExp(`^(\\d{${targetLength}})$`));
        if (plainNumMatch) {
          const num = plainNumMatch[1];
          addItem({
            number: num,
            amount: defaultAmount,
            subNumbers: [{ number: num, amount: defaultAmount }],
            subCount: 1,
            perItemAmount: defaultAmount,
          });
        }
      }
      continue;
    }

    const tokens = line.split(/[\s]+/).filter(Boolean);
    if (tokens.length === 2 && tokens[0].length === targetLength && tokens[1].length >= 3 && parseInt(tokens[1], 10) >= 50) {
      const num = tokens[0];
      const amt = parseInt(tokens[1], 10);
      addItem({
        number: num,
        amount: amt,
        subNumbers: [{ number: num, amount: amt }],
        subCount: 1,
        perItemAmount: amt,
      });
      continue;
    }

    if (tokens.length >= 4 && tokens.length % 2 === 0) {
      let allPairs = true;
      for (let i = 0; i < tokens.length; i += 2) {
        if (tokens[i].length !== targetLength || tokens[i + 1].length < 3 || parseInt(tokens[i + 1], 10) < 50) {
          allPairs = false;
          break;
        }
      }
      if (allPairs) {
        for (let i = 0; i < tokens.length; i += 2) {
          const num = tokens[i];
          const amt = parseInt(tokens[i + 1], 10);
          addItem({
            number: num,
            amount: amt,
            subNumbers: [{ number: num, amount: amt }],
            subCount: 1,
            perItemAmount: amt,
          });
        }
        continue;
      }
    }

    for (const tok of tokens) {
      const digitsOnly = tok.replace(/\D/g, '');
      if (digitsOnly.length === targetLength) {
        addItem({
          number: digitsOnly,
          amount: defaultAmount,
          subNumbers: [{ number: digitsOnly, amount: defaultAmount }],
          subCount: 1,
          perItemAmount: defaultAmount,
        });
      }
    }
  }

  return resultItems;
}
