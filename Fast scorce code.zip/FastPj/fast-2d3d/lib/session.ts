import crypto from 'crypto';
import { cookies } from 'next/headers';
import { sql } from './db';

export type SessionKind = 'user' | 'admin' | 'agent';

export interface SessionPayload {
  kind: SessionKind;
  id: number;
  uid?: string;
  code?: string;
  name: string;
  email?: string;
  sid: string;
  exp: number;
}

export const SESSION_COOKIE = 'f2d3d_session';
const SESSION_TTL_MS = 30 * 24 * 60 * 60 * 1000;

function getSecret(): string {
  const secret = process.env.SESSION_SECRET;
  if (!secret) {
    if (process.env.NODE_ENV === 'production') {
      throw new Error('SESSION_SECRET is not configured');
    }
    return 'fast2d3d-dev-session-secret';
  }
  return secret;
}

function base64url(input: Buffer | string): string {
  return Buffer.from(input)
    .toString('base64')
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=+$/, '');
}

function fromBase64url(input: string): Buffer {
  return Buffer.from(input.replace(/-/g, '+').replace(/_/g, '/'), 'base64');
}

export function signSession(payload: Omit<SessionPayload, 'exp'> & { exp?: number }): string {
  const body: SessionPayload = {
    ...payload,
    exp: payload.exp ?? Date.now() + SESSION_TTL_MS,
  };
  const data = base64url(JSON.stringify(body));
  const sig = base64url(crypto.createHmac('sha256', getSecret()).update(data).digest());
  return `${data}.${sig}`;
}

export function verifySessionToken(token: string | undefined | null): SessionPayload | null {
  if (!token) return null;
  const parts = token.split('.');
  if (parts.length !== 2) return null;
  const [data, sig] = parts;
  const expected = base64url(crypto.createHmac('sha256', getSecret()).update(data).digest());
  const a = Buffer.from(sig);
  const b = Buffer.from(expected);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
  try {
    const payload = JSON.parse(fromBase64url(data).toString()) as SessionPayload;
    if (!payload.exp || payload.exp <= Date.now()) return null;
    return payload;
  } catch {
    return null;
  }
}

export async function getSession(): Promise<SessionPayload | null> {
  const store = await cookies();
  const payload = verifySessionToken(store.get(SESSION_COOKIE)?.value);
  if (!payload) return null;

  try {
    const rows = await sql`
      SELECT id FROM sessions WHERE id = ${payload.sid} AND expires_at > NOW() LIMIT 1;
    `;
    if (!rows || rows.length === 0) return null;
  } catch {
    return null;
  }
  return payload;
}

export async function setSession(payload: Omit<SessionPayload, 'exp' | 'sid'>): Promise<void> {
  const sid = `sess-${Date.now()}-${crypto.randomBytes(12).toString('hex')}`;
  const exp = Date.now() + SESSION_TTL_MS;
  const subjectId =
    payload.kind === 'user' ? payload.uid || '' : payload.kind === 'agent' ? payload.code || '' : String(payload.id);

  try {
    await sql`
      INSERT INTO sessions (id, kind, subject_id, expires_at)
      VALUES (${sid}, ${payload.kind}, ${subjectId}, ${new Date(exp).toISOString()});
    `;
  } catch (err) {
    console.error('Failed to persist session:', err);
  }

  const token = signSession({ ...payload, sid, exp });
  const store = await cookies();
  store.set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production',
    path: '/',
    maxAge: Math.floor(SESSION_TTL_MS / 1000),
  });
}

export async function clearSession(): Promise<void> {
  const store = await cookies();
  const payload = verifySessionToken(store.get(SESSION_COOKIE)?.value);
  if (payload?.sid) {
    try {
      await sql`DELETE FROM sessions WHERE id = ${payload.sid};`;
    } catch {

    }
  }
  store.set(SESSION_COOKIE, '', {
    httpOnly: true,
    sameSite: 'lax',
    secure: process.env.NODE_ENV === 'production',
    path: '/',
    maxAge: 0,
  });
}
