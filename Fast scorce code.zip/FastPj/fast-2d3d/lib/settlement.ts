import { sql } from './db';
import { createNotification } from './notifications';
import { openTimeToSession } from './schedule';
import { computeWin, countNumbers, type BetItemLike } from './payout';
import { isTood, TOOD_MULTIPLIER, payoutTransactionId } from './tood';
import { recordWinSettlement } from './commission';
import { normalizeResultDate, getMyanmarDate } from './date';

export const MULTIPLIER_2D = 85;
export const MULTIPLIER_3D = 550;

function parseArray(value: unknown): unknown[] {
  if (Array.isArray(value)) return value;
  if (typeof value === 'string') {
    try {
      const parsed = JSON.parse(value);
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  }
  return [];
}

export async function settlePendingBets(
  type: '2D' | '3D',
  session: string,
  winningNumber: string,
  resultDate: string | null
): Promise<number> {
  const rows = await sql`
    SELECT id, uid, amount, numbers, items
    FROM bets
    WHERE type = ${type} AND session = ${session} AND status = 'pending'
    LIMIT 1000;
  `;

  let settled = 0;

  const isToodResult = type === '3D' && isTood(winningNumber);
  const baseMultiplier = type === '2D' ? MULTIPLIER_2D : MULTIPLIER_3D;
  const multiplier = isToodResult ? TOOD_MULTIPLIER : baseMultiplier;
  const winStatus = isToodResult ? 'TOOD_WIN' : 'win';

  for (const raw of rows || []) {
    const bet = raw as {
      id: string;
      uid: string;
      amount: string | number;
      numbers: unknown;
      items: unknown;
    };

    const items = parseArray(bet.items) as BetItemLike[];
    const numbers = parseArray(bet.numbers) as string[];
    const { totalWin, details, matched } = computeWin(
      winningNumber,
      items,
      numbers,
      Number(bet.amount),
      multiplier
    );
    const totalNumbers = countNumbers(items, numbers);

    if (matched && totalWin > 0) {
      const txId = payoutTransactionId(bet.id, isToodResult);
      const credited = await sql`
        WITH updated AS (
          UPDATE bets
          SET status = ${winStatus}, winning_number = ${winningNumber},
              win_amount = ${totalWin}, win_details = ${details},
              payout_multiplier = ${multiplier}, is_tood = ${isToodResult}
          WHERE id = ${bet.id} AND status = 'pending'
          RETURNING uid, win_amount
        ),
        tx AS (
          INSERT INTO transactions
            (id, uid, type, amount, method, transaction_number, status, timestamp,
             bet_id, draw_id, bet_number, bet_amount, payout_multiplier)
          SELECT ${txId}, u.uid, ${isToodResult ? 'TOOD_WIN' : 'deposit'}, u.win_amount,
                 ${isToodResult ? 'TOOD_WIN' : type + ' Win'},
                 ${winningNumber}, 'completed', ${new Date().toLocaleString()},
                 ${bet.id}, ${session}, ${winningNumber}, ${Number(bet.amount)}, ${multiplier}
          FROM updated u
          ON CONFLICT (id) DO NOTHING
          RETURNING uid, amount
        )
        UPDATE users SET balance = balance + t.amount, updated_at = NOW()
        FROM tx t
        WHERE users.uid = t.uid
        RETURNING users.uid;
      `;
      if (!credited || credited.length === 0) continue;

      await recordWinSettlement({
        betId: bet.id,
        winningNumber,
        multiplier,
        grossPayout: totalWin,
        isTood: isToodResult,
      });

      await createNotification({
        targetType: 'user',
        targetId: bet.uid,
        type: 'win',
        title: isToodResult
          ? 'ဂုဏ်ယူပါသည်! TOOD ပေါက်ကြေးဆုငွေ ရရှိပါပြီ'
          : 'ဂုဏ်ယူပါသည်! ပေါက်ကြေးဆုငွေ ရရှိပါပြီ',
        message: isToodResult
          ? `${type} TOOD ပေါက်ဂဏန်း (${winningNumber}) ဖြင့် ${totalWin.toLocaleString()} MMK ဆုငွေ (×${multiplier}) ရရှိပါပြီ။`
          : `${type} ပေါက်ဂဏန်း (${winningNumber}) ဖြင့် ${totalWin.toLocaleString()} MMK ဆုငွေ ရရှိပါပြီ။`,
        data: { screen: 'record' },
      });

      await createNotification({
        targetType: 'admin',
        targetId: null,
        type: 'win',
        title: isToodResult
          ? `TOOD Win Bet ${type} - ${bet.uid}`
          : `Win Bet ${type} - ${bet.uid}`,
        message: `User ID: ${bet.uid} | Bet: ${Number(bet.amount).toLocaleString()} MMK | Win: ${totalWin.toLocaleString()} MMK | Type: ${isToodResult ? 'TOOD' : type} | Winning No: ${winningNumber} | Total Numbers: ${totalNumbers} | Won: ${details}`,
        data: {
          screen: 'win_bets',
          userId: bet.uid,
          betId: bet.id,
          type,
          winningNumber,
          winAmount: totalWin,
          isTood: isToodResult,
        },
      });

      settled++;
    } else {
      await sql`
        UPDATE bets
        SET status = 'lose', winning_number = ${winningNumber},
            win_amount = 0, payout_multiplier = 0, is_tood = false
        WHERE id = ${bet.id} AND status = 'pending';
      `;
    }
  }

  return settled;
}

async function upsertResult(type: '2D' | '3D', session: string, resultDate: string | null, winningNumber: string) {
  const date = normalizeResultDate(resultDate);
  await sql`
    INSERT INTO results (type, session, result_date, winning_number)
    VALUES (${type}, ${session}, ${date}, ${winningNumber})
    ON CONFLICT (type, session, COALESCE(result_date, ''))
    DO UPDATE SET winning_number = EXCLUDED.winning_number, created_at = NOW();
  `;
}

async function fetch2DResults(): Promise<{ twod: string; open_time: string; date: string }[]> {
  try {
    const res = await fetch('https://api.thaistock2d.com/live', {
      headers: { Accept: 'application/json', 'User-Agent': 'Fast2D3D-App/1.0' },
      cache: 'no-store',
      signal: AbortSignal.timeout(6000),
    });
    if (!res.ok) return [];
    const data = await res.json();
    const liveDate: string = data?.live?.date || getMyanmarDate();
    const list = Array.isArray(data?.result) ? data.result : [];
    return list
      .filter((r: { twod?: string }) => r?.twod && r.twod !== '--')
      .map((r: { twod: string; open_time: string; stock_date?: string }) => ({
        twod: r.twod,
        open_time: r.open_time,
        date: r.stock_date || liveDate,
      }));
  } catch {
    return [];
  }
}

async function fetchShwelamin2D(): Promise<{ session: string; twod: string; date: string }[]> {
  try {
    const res = await fetch('https://backend.shwelamin.com/api/lv/twod-result', {
      headers: { Accept: 'application/json', 'User-Agent': 'Fast2D3D-App/1.0' },
      cache: 'no-store',
      signal: AbortSignal.timeout(6000),
    });
    if (!res.ok) return [];
    const data = await res.json();
    const item = Array.isArray(data?.data) ? data.data[0] : null;
    if (!item) return [];
    const date: string = item.date || getMyanmarDate();
    const out: { session: string; twod: string; date: string }[] = [];
    if (item.result_1200 && item.result_1200 !== '--') {
      out.push({ session: '12:01 PM', twod: String(item.result_1200), date });
    }
    if (item.result_430 && item.result_430 !== '--') {
      out.push({ session: '04:30 PM', twod: String(item.result_430), date });
    }
    return out;
  } catch {
    return [];
  }
}

async function fetch3DResult(): Promise<{ result: string; date: string } | null> {
  try {
    const res = await fetch('https://api.2dboss.com/api/v2/v1/2dstock/threed-result', {
      headers: { Accept: 'application/json', 'User-Agent': 'Fast2D3D-App/1.0' },
      cache: 'no-store',
      signal: AbortSignal.timeout(6000),
    });
    if (!res.ok) return null;
    const data = await res.json();
    const item = Array.isArray(data?.data) ? data.data[0] : null;
    if (!item?.result) return null;
    return {
      result: String(item.result),
      date: item.datetime ? String(item.datetime).slice(0, 10) : getMyanmarDate(),
    };
  } catch {
    return null;
  }
}

export async function runSettlement(): Promise<{ twoD: number; threeD: number }> {
  let twoD = 0;
  let threeD = 0;

  const results2D = await fetch2DResults();
  const seenSessions = new Set<string>();
  for (const r of results2D) {
    const session = openTimeToSession(r.open_time);
    if (!session) continue;
    seenSessions.add(session);
    await upsertResult('2D', session, r.date, r.twod);
    twoD += await settlePendingBets('2D', session, r.twod, r.date);
  }

  const requiredSessions = ['12:01 PM', '04:30 PM'];
  if (requiredSessions.some((s) => !seenSessions.has(s))) {
    const fallbackResults = await fetchShwelamin2D();
    for (const r of fallbackResults) {
      if (seenSessions.has(r.session)) continue;
      seenSessions.add(r.session);
      await upsertResult('2D', r.session, r.date, r.twod);
      twoD += await settlePendingBets('2D', r.session, r.twod, r.date);
    }
  }

  const result3D = await fetch3DResult();
  if (result3D) {
    await upsertResult('3D', '03:30 PM', result3D.date, result3D.result);
    threeD += await settlePendingBets('3D', '03:30 PM', result3D.result, result3D.date);
  }

  return { twoD, threeD };
}

let lastRun = 0;
const THROTTLE_MS = 60 * 1000;

export function maybeRunSettlement(): void {
  const now = Date.now();
  if (now - lastRun < THROTTLE_MS) return;
  lastRun = now;
  void runSettlement().catch((err) => console.error('Settlement failed:', err));
}
