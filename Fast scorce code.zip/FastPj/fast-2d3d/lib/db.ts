import { neon, type NeonQueryFunction } from '@neondatabase/serverless';

export const getDatabaseUrl = (): string => {
  const url = process.env.DATABASE_URL;
  if (!url) {
    throw new Error('DATABASE_URL is not configured');
  }
  return url;
};

let _sql: NeonQueryFunction<false, false> | null = null;
export const getSql = (): NeonQueryFunction<false, false> => {
  if (!_sql) {
    _sql = neon(getDatabaseUrl());
  }
  return _sql;
};

export function sql(strings: TemplateStringsArray, ...values: unknown[]) {
  return getSql()(strings, ...values);
}

export function generateRandom10DigitUID(): string {
  return Math.floor(1000000000 + Math.random() * 9000000000).toString();
}

export async function nextOrderNumber(kind: 'deposit' | 'withdraw'): Promise<string> {
  const seqDate = new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Yangon' }).format(new Date());
  const db = getSql();
  const rows = await db`
    INSERT INTO order_sequences (type, seq_date, last_seq)
    VALUES (${kind}, ${seqDate}, 1)
    ON CONFLICT (type, seq_date) DO UPDATE SET last_seq = order_sequences.last_seq + 1
    RETURNING last_seq;
  `;
  const seq = Number(rows?.[0]?.last_seq || 1);
  const prefix = kind === 'deposit' ? 'DEP' : 'WD';
  return `${prefix}-${seqDate.replace(/-/g, '')}-${String(seq).padStart(4, '0')}`;
}

let isInitialized = false;
export async function ensureTablesExist() {
  if (isInitialized) return;
  const db = getSql();
  try {
    await db`
      CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        uid VARCHAR(10) UNIQUE NOT NULL,
        name VARCHAR(255) NOT NULL,
        phone VARCHAR(50) UNIQUE NOT NULL,
        password_hash VARCHAR(255) NOT NULL,
        agent_code VARCHAR(50),
        role VARCHAR(20) DEFAULT 'user',
        status VARCHAR(20) DEFAULT 'active',
        balance NUMERIC(15, 2) DEFAULT 0.00,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
      );
    `;

    await db`ALTER TABLE users ADD COLUMN IF NOT EXISTS role VARCHAR(20) DEFAULT 'user';`;
    await db`ALTER TABLE users ADD COLUMN IF NOT EXISTS status VARCHAR(20) DEFAULT 'active';`;

    await db`
      CREATE TABLE IF NOT EXISTS agents (
        id SERIAL PRIMARY KEY,
        code VARCHAR(50) UNIQUE NOT NULL,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) UNIQUE,
        phone VARCHAR(50),
        secret_key_hash VARCHAR(255) NOT NULL,
        commission NUMERIC(5, 2) DEFAULT 0.00,
        balance NUMERIC(15, 2) DEFAULT 0.00,
        status VARCHAR(20) DEFAULT 'active',
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
      );
    `;

    await db`
      CREATE TABLE IF NOT EXISTS admins (
        id SERIAL PRIMARY KEY,
        email VARCHAR(255) UNIQUE NOT NULL,
        name VARCHAR(255) NOT NULL,
        secret_key_hash VARCHAR(255) NOT NULL,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
      );
    `;

    await db`
      CREATE TABLE IF NOT EXISTS transactions (
        id VARCHAR(100) PRIMARY KEY,
        uid VARCHAR(10) NOT NULL,
        type VARCHAR(50) NOT NULL,
        amount NUMERIC(15, 2) NOT NULL,
        method VARCHAR(100) NOT NULL,
        transaction_number VARCHAR(255),
        status VARCHAR(50) DEFAULT 'pending',
        timestamp VARCHAR(100) NOT NULL,
        slip_image TEXT,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
      );
    `;
    await db`ALTER TABLE transactions ADD COLUMN IF NOT EXISTS slip_image TEXT;`;
    await db`ALTER TABLE transactions ADD COLUMN IF NOT EXISTS order_number VARCHAR(50);`;
    await db`ALTER TABLE transactions ADD COLUMN IF NOT EXISTS bet_id VARCHAR(100);`;
    await db`ALTER TABLE transactions ADD COLUMN IF NOT EXISTS draw_id VARCHAR(100);`;
    await db`ALTER TABLE transactions ADD COLUMN IF NOT EXISTS bet_number VARCHAR(20);`;
    await db`ALTER TABLE transactions ADD COLUMN IF NOT EXISTS bet_amount NUMERIC(15, 2);`;
    await db`ALTER TABLE transactions ADD COLUMN IF NOT EXISTS payout_multiplier NUMERIC(15, 2);`;
    await db`CREATE UNIQUE INDEX IF NOT EXISTS idx_transactions_order_number ON transactions (order_number) WHERE order_number IS NOT NULL;`;
    await db`CREATE INDEX IF NOT EXISTS idx_transactions_bet_id ON transactions (bet_id) WHERE bet_id IS NOT NULL;`;

    await db`
      CREATE TABLE IF NOT EXISTS order_sequences (
        type VARCHAR(20) NOT NULL,
        seq_date VARCHAR(20) NOT NULL,
        last_seq INTEGER NOT NULL DEFAULT 0,
        PRIMARY KEY (type, seq_date)
      );
    `;

    await db`
      CREATE TABLE IF NOT EXISTS bets (
        id VARCHAR(100) PRIMARY KEY,
        uid VARCHAR(10) NOT NULL,
        type VARCHAR(10) NOT NULL,
        session VARCHAR(50) NOT NULL,
        amount NUMERIC(15, 2) NOT NULL,
        numbers JSONB NOT NULL,
        items JSONB,
        status VARCHAR(50) DEFAULT 'pending',
        winning_number VARCHAR(50),
        win_amount NUMERIC(15, 2) DEFAULT 0,
        win_details TEXT,
        payout_multiplier NUMERIC(15, 2) DEFAULT 0,
        is_tood BOOLEAN DEFAULT FALSE,
        date VARCHAR(100) NOT NULL,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
      );
    `;
    await db`ALTER TABLE bets ADD COLUMN IF NOT EXISTS payout_multiplier NUMERIC(15, 2) DEFAULT 0;`;
    await db`ALTER TABLE bets ADD COLUMN IF NOT EXISTS is_tood BOOLEAN DEFAULT FALSE;`;
    await db`CREATE INDEX IF NOT EXISTS idx_bets_winning_number ON bets (type, winning_number);`;

    await db`
      CREATE TABLE IF NOT EXISTS settings (
        key VARCHAR(100) PRIMARY KEY,
        value JSONB NOT NULL,
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
      );
    `;

    await db`
      CREATE TABLE IF NOT EXISTS results (
        id SERIAL PRIMARY KEY,
        type VARCHAR(10) NOT NULL,
        session VARCHAR(100) NOT NULL,
        result_date VARCHAR(100),
        winning_number VARCHAR(50) NOT NULL,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
      );
    `;

    await db`CREATE UNIQUE INDEX IF NOT EXISTS idx_results_unique ON results (type, session, COALESCE(result_date, ''));`;

    await db`
      CREATE TABLE IF NOT EXISTS win_settlements (
        id VARCHAR(100) PRIMARY KEY,
        bet_id VARCHAR(100) UNIQUE NOT NULL,
        uid VARCHAR(10) NOT NULL,
        user_name VARCHAR(255),
        agent_code VARCHAR(50),
        agent_name VARCHAR(255),
        bet_type VARCHAR(10) NOT NULL,
        session VARCHAR(50),
        winning_number VARCHAR(20),
        bet_amount NUMERIC(15, 2) NOT NULL DEFAULT 0,
        multiplier NUMERIC(15, 2) NOT NULL DEFAULT 0,
        gross_payout NUMERIC(15, 2) NOT NULL DEFAULT 0,
        agent_percent NUMERIC(5, 2) NOT NULL DEFAULT 0,
        agent_share NUMERIC(15, 2) NOT NULL DEFAULT 0,
        admin_share NUMERIC(15, 2) NOT NULL DEFAULT 0,
        paid_amount NUMERIC(15, 2) NOT NULL DEFAULT 0,
        remaining_amount NUMERIC(15, 2) NOT NULL DEFAULT 0,
        payment_status VARCHAR(20) NOT NULL DEFAULT 'pending',
        payment_reference VARCHAR(255),
        operator VARCHAR(255),
        paid_at TIMESTAMP WITH TIME ZONE,
        is_tood BOOLEAN DEFAULT FALSE,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
      );
    `;
    await db`CREATE INDEX IF NOT EXISTS idx_win_settlements_agent ON win_settlements (agent_code);`;
    await db`CREATE INDEX IF NOT EXISTS idx_win_settlements_uid ON win_settlements (uid);`;
    await db`CREATE INDEX IF NOT EXISTS idx_win_settlements_status ON win_settlements (payment_status);`;

    await db`
      CREATE TABLE IF NOT EXISTS settlement_payments (
        id VARCHAR(100) PRIMARY KEY,
        settlement_id VARCHAR(100) NOT NULL,
        amount NUMERIC(15, 2) NOT NULL,
        reference VARCHAR(255),
        operator VARCHAR(255),
        note TEXT,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
      );
    `;
    await db`CREATE INDEX IF NOT EXISTS idx_settlement_payments_sid ON settlement_payments (settlement_id);`;

    await db`CREATE INDEX IF NOT EXISTS idx_users_agent_code ON users (agent_code);`;
    await db`CREATE INDEX IF NOT EXISTS idx_transactions_uid ON transactions (uid);`;
    await db`CREATE INDEX IF NOT EXISTS idx_bets_uid ON bets (uid);`;

    await db`CREATE INDEX IF NOT EXISTS idx_bets_created_at ON bets (created_at);`;
    await db`CREATE INDEX IF NOT EXISTS idx_transactions_created_at ON transactions (created_at);`;

    await db`
      CREATE TABLE IF NOT EXISTS notifications (
        id VARCHAR(100) PRIMARY KEY,
        target_type VARCHAR(20) NOT NULL,
        target_id VARCHAR(100),
        type VARCHAR(50) NOT NULL DEFAULT 'info',
        title VARCHAR(255) NOT NULL,
        message TEXT NOT NULL,
        data JSONB,
        is_read BOOLEAN DEFAULT FALSE,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        expires_at TIMESTAMP WITH TIME ZONE NOT NULL
      );
    `;
    await db`CREATE INDEX IF NOT EXISTS idx_notifications_target ON notifications (target_type, target_id);`;
    await db`CREATE INDEX IF NOT EXISTS idx_notifications_expires ON notifications (expires_at);`;

    await db`
      CREATE TABLE IF NOT EXISTS push_subscriptions (
        id VARCHAR(100) PRIMARY KEY,
        target_type VARCHAR(20) NOT NULL,
        target_id VARCHAR(100) NOT NULL,
        endpoint TEXT UNIQUE NOT NULL,
        p256dh TEXT NOT NULL,
        auth TEXT NOT NULL,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
      );
    `;
    await db`CREATE INDEX IF NOT EXISTS idx_push_target ON push_subscriptions (target_type, target_id);`;

    await db`
      CREATE TABLE IF NOT EXISTS otp_codes (
        id SERIAL PRIMARY KEY,
        target_type VARCHAR(20) NOT NULL,
        target_id VARCHAR(100) NOT NULL,
        email VARCHAR(255) NOT NULL,
        name VARCHAR(255),
        otp_hash VARCHAR(255) NOT NULL,
        expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
        attempt_count INTEGER DEFAULT 0,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
      );
    `;
    await db`CREATE INDEX IF NOT EXISTS idx_otp_codes_email ON otp_codes (email);`;
    await db`CREATE INDEX IF NOT EXISTS idx_otp_codes_expires ON otp_codes (expires_at);`;

    await db`
      CREATE TABLE IF NOT EXISTS sessions (
        id VARCHAR(100) PRIMARY KEY,
        kind VARCHAR(20) NOT NULL,
        subject_id VARCHAR(100) NOT NULL,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        expires_at TIMESTAMP WITH TIME ZONE NOT NULL
      );
    `;
    await db`CREATE INDEX IF NOT EXISTS idx_sessions_subject ON sessions (kind, subject_id);`;
    await db`CREATE INDEX IF NOT EXISTS idx_sessions_expires ON sessions (expires_at);`;

    await db`
      CREATE TABLE IF NOT EXISTS login_history (
        id SERIAL PRIMARY KEY,
        actor_type VARCHAR(20) NOT NULL,
        actor_id VARCHAR(100) NOT NULL,
        actor_name VARCHAR(255),
        device VARCHAR(255),
        user_agent TEXT,
        ip VARCHAR(100),
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
      );
    `;
    await db`CREATE INDEX IF NOT EXISTS idx_login_history_actor ON login_history (actor_type, actor_id);`;

    await db`
      CREATE TABLE IF NOT EXISTS number_limits (
        number VARCHAR(5) PRIMARY KEY,
        max_bet_count INTEGER NOT NULL DEFAULT 100,
        is_blocked BOOLEAN DEFAULT FALSE,
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
      );
    `;
    await db`ALTER TABLE number_limits ADD COLUMN IF NOT EXISTS type VARCHAR(10) DEFAULT '2D';`;
    await db`ALTER TABLE number_limits ADD COLUMN IF NOT EXISTS max_bet_amount NUMERIC(15, 2) DEFAULT 0;`;
    await db`CREATE INDEX IF NOT EXISTS idx_number_limits_type ON number_limits (type);`;

    isInitialized = true;
  } catch (err) {
    console.error('Failed to initialize DB tables:', err);
    throw err;
  }
}
