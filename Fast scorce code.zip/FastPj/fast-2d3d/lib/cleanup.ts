import { sql } from './db';

export interface CleanupResult {
  bets: number;
  transactions: number;
  notifications: number;
  otps: number;
  sessions: number;
}

export async function runCleanup(): Promise<CleanupResult> {
  const bets = await sql`
    DELETE FROM bets
    WHERE created_at < NOW() - INTERVAL '7 days'
    RETURNING id;
  `;

  const transactions = await sql`
    DELETE FROM transactions
    WHERE created_at < NOW() - INTERVAL '7 days'
    RETURNING id;
  `;

  const notifications = await sql`
    DELETE FROM notifications
    WHERE expires_at < NOW()
    RETURNING id;
  `;

  const otps = await sql`
    DELETE FROM otp_codes
    WHERE expires_at < NOW()
    RETURNING id;
  `;

  const sessions = await sql`
    DELETE FROM sessions
    WHERE expires_at < NOW()
    RETURNING id;
  `;

  return {
    bets: (bets || []).length,
    transactions: (transactions || []).length,
    notifications: (notifications || []).length,
    otps: (otps || []).length,
    sessions: (sessions || []).length,
  };
}

let lastRun = 0;
const THROTTLE_MS = 5 * 60 * 1000;

export function maybeRunCleanup(): void {
  const now = Date.now();
  if (now - lastRun < THROTTLE_MS) return;
  lastRun = now;
  void runCleanup().catch((err) => console.error('Cleanup failed:', err));
}
