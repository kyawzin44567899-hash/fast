import { NextResponse } from 'next/server';
import { getSession } from '@/lib/session';

export function ok<T>(data: T, status = 200) {
  return NextResponse.json({ success: true, data }, { status });
}

export function fail(error: string, status = 400) {
  return NextResponse.json({ success: false, error }, { status });
}

export async function requireUser() {
  const session = await getSession();
  if (!session || session.kind !== 'user') return null;
  return session;
}
