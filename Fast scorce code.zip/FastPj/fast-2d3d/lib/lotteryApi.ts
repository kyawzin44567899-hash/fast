

export interface Live2DData {
  server_time: string;
  live: {
    set: string;
    value: string;
    time: string;
    twod: string;
    date: string;
  };
  result: Array<{
    set: string;
    value: string;
    open_time: string;
    twod: string;
    stock_date?: string;
    stock_datetime?: string;
    history_id?: string | null;
  }>;
  holiday?: {
    status: string;
    date: string;
    name: string;
  };
}

export interface TwodHistoryDay {
  date: string;
  child: Array<{
    time: string;
    set: string;
    value: string;
    twod: string;
  }>;
}

export interface ThreedHistoryData {
  data: Array<{
    result: string;
    datetime: string;
  }>;
  result: number;
  message: string;
}

export interface ShwelaminTwodItem {
  id: string;
  date: string;
  set_1200: string;
  val_1200: string;
  set_430: string;
  val_430: string;
  result_1200: string;
  result_430: string;
  internet_930: string;
  modern_930: string;
  internet_200: string;
  modern_200: string;
  time_1200: string;
  time_430: string;
}

export interface ShwelaminTwodResponse {
  result: number;
  message: string;
  data: ShwelaminTwodItem[];
}

export interface SetLiveData {
  modern_930: string;
  internet_930: string;
  modern_200: string;
  internet_200: string;
}

const SETLIVE_KEYS = ['modern_930', 'internet_930', 'modern_200', 'internet_200'] as const;

function extractSetLiveFields(value: unknown, out: Record<string, string>, depth = 0): void {
  if (!value || typeof value !== 'object' || depth > 6) return;
  for (const [k, v] of Object.entries(value as Record<string, unknown>)) {
    if ((SETLIVE_KEYS as readonly string[]).includes(k)) {
      if (v !== null && v !== undefined) out[k] = String(v);
    } else if (v && typeof v === 'object') {
      extractSetLiveFields(v, out, depth + 1);
    }
  }
}

function parseSetLive(value: unknown): SetLiveData | null {
  if (!value) return null;
  const out: Record<string, string> = {};
  extractSetLiveFields(value, out);
  if (!SETLIVE_KEYS.some((k) => out[k])) return null;
  return {
    modern_930: out.modern_930 || '--',
    internet_930: out.internet_930 || '--',
    modern_200: out.modern_200 || '--',
    internet_200: out.internet_200 || '--',
  };
}

async function safeFetch<T>(url: string, timeoutMs = 3500): Promise<T | null> {
  try {
    const controller = new AbortController();
    const id = setTimeout(() => controller.abort(), timeoutMs);
    const res = await fetch(url, {
      signal: controller.signal,
      cache: 'no-store',
      headers: {
        Accept: 'application/json',
      },
    });
    clearTimeout(id);
    if (res.ok) {
      const text = await res.text();
      const trimmed = text.trim();
      if (trimmed.startsWith('{') || trimmed.startsWith('[')) {
        return JSON.parse(trimmed) as T;
      }
    }
  } catch {

  }
  return null;
}

export async function get2DLive(): Promise<Live2DData | null> {

  const directData = await safeFetch<Live2DData>('https://api.thaistock2d.com/live', 3000);
  if (directData?.live?.twod) return directData;

  if (typeof window !== 'undefined') {
    const proxyData = await safeFetch<Live2DData>('/api/stock2d/live', 3000);
    if (proxyData?.live?.twod) return proxyData;
  }

  return null;
}

export async function get2DHistory(): Promise<TwodHistoryDay[]> {
  const directData = await safeFetch<TwodHistoryDay[]>('https://api.thaistock2d.com/history', 3500);
  if (Array.isArray(directData) && directData.length > 0) return directData;

  if (typeof window !== 'undefined') {
    const proxyData = await safeFetch<TwodHistoryDay[]>('/api/stock2d/history', 3500);
    if (Array.isArray(proxyData) && proxyData.length > 0) return proxyData;
  }

  return [];
}

export async function get2DResult(): Promise<TwodHistoryDay[]> {
  const directData = await safeFetch<TwodHistoryDay[]>('https://api.thaistock2d.com/2d_result', 3500);
  if (Array.isArray(directData) && directData.length > 0) return directData;

  if (typeof window !== 'undefined') {
    const proxyData = await safeFetch<TwodHistoryDay[]>('/api/stock2d/2d_result', 3500);
    if (Array.isArray(proxyData) && proxyData.length > 0) return proxyData;
  }

  return [];
}

export async function getShwelaminTwod(): Promise<ShwelaminTwodResponse | null> {
  const directData = await safeFetch<ShwelaminTwodResponse>('https://backend.shwelamin.com/api/lv/twod-result', 5000);
  if (Array.isArray(directData?.data) && directData.data.length > 0) return directData;

  if (typeof window !== 'undefined') {
    const proxyData = await safeFetch<ShwelaminTwodResponse>('/api/stock2d/twod-result', 5000);
    if (Array.isArray(proxyData?.data) && proxyData.data.length > 0) return proxyData;
  }

  return null;
}

export async function getSetLiveModernInternet(): Promise<SetLiveData | null> {
  if (typeof window === 'undefined') return null;
  const proxyData = await safeFetch<unknown>('/api/stock2d/setlive', 6000);
  return parseSetLive(proxyData);
}

export async function get3DHistory(): Promise<ThreedHistoryData | null> {
  const directData = await safeFetch<ThreedHistoryData>('https://api.2dboss.com/api/v2/v1/2dstock/threed-result', 3000);
  if (Array.isArray(directData?.data) && directData.data.length > 0) return directData;

  if (typeof window !== 'undefined') {
    const proxyData = await safeFetch<ThreedHistoryData>('/api/stock3d/history', 3000);
    if (Array.isArray(proxyData?.data) && proxyData.data.length > 0) return proxyData;
  }

  return null;
}
