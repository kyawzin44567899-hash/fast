

export interface ScheduleConfig {
  isClosedToday: boolean;
  morningStart: string;
  morningEnd: string;
  eveningStart: string;
  eveningEnd: string;
  closedDates: string[];
  threeDEnabled: boolean;
  threeDCloseTime: string;
  threeDReopenTime: string;
  threeDClosedDates: string[];
}

export const DEFAULT_SCHEDULE: ScheduleConfig = {
  isClosedToday: false,
  morningStart: '09:30',
  morningEnd: '12:01',
  eveningStart: '14:00',
  eveningEnd: '16:30',
  closedDates: [],
  threeDEnabled: true,
  threeDCloseTime: '15:30',
  threeDReopenTime: '09:00',
  threeDClosedDates: [],
};

export interface MyanmarNow {
  date: string;
  minutes: number;
}

export function getMyanmarNow(): MyanmarNow {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Yangon',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  }).formatToParts(new Date());

  const get = (type: string) => parts.find((p) => p.type === type)?.value || '00';
  const year = get('year');
  const month = get('month');
  const day = get('day');
  let hour = parseInt(get('hour'), 10);
  if (hour === 24) hour = 0;
  const minute = parseInt(get('minute'), 10);

  return {
    date: `${year}-${month}-${day}`,
    minutes: hour * 60 + minute,
  };
}

export function toMinutes(hhmm: string): number | null {
  if (!hhmm || !hhmm.includes(':')) return null;
  const [h, m] = hhmm.split(':').map((v) => parseInt(v, 10));
  if (Number.isNaN(h) || Number.isNaN(m)) return null;
  return h * 60 + m;
}

export interface BettingEvaluation {
  open: boolean;
  session: string | null;
  reason: 'closed_today' | 'closed_date' | 'outside_window' | 'three_d_disabled' | 'ok';
}

export function evaluateBetting(
  schedule: ScheduleConfig,
  type: '2D' | '3D',
  now: MyanmarNow
): BettingEvaluation {
  if (schedule.isClosedToday) {
    return { open: false, session: null, reason: 'closed_today' };
  }
  if (schedule.closedDates?.includes(now.date)) {
    return { open: false, session: null, reason: 'closed_date' };
  }

  if (type === '2D') {
    const morningStart = toMinutes(schedule.morningStart);
    const morningEnd = toMinutes(schedule.morningEnd);
    const eveningStart = toMinutes(schedule.eveningStart);
    const eveningEnd = toMinutes(schedule.eveningEnd);

    if (morningStart !== null && morningEnd !== null && now.minutes >= morningStart && now.minutes < morningEnd) {
      return { open: true, session: '12:01 PM', reason: 'ok' };
    }
    if (eveningStart !== null && eveningEnd !== null && now.minutes >= eveningStart && now.minutes < eveningEnd) {
      return { open: true, session: '04:30 PM', reason: 'ok' };
    }
    return { open: false, session: null, reason: 'outside_window' };
  }

  if (!schedule.threeDEnabled) {
    return { open: false, session: null, reason: 'three_d_disabled' };
  }
  if (schedule.threeDClosedDates?.includes(now.date)) {
    return { open: false, session: null, reason: 'closed_date' };
  }

  const dayOfMonth = parseInt(now.date.slice(8, 10), 10);

  if (dayOfMonth === 1 || dayOfMonth === 16) {
    const closeMin = toMinutes(schedule.threeDCloseTime);
    if (closeMin !== null && now.minutes >= closeMin) {
      return { open: false, session: null, reason: 'outside_window' };
    }
    return { open: true, session: '03:30 PM', reason: 'ok' };
  }

  if (dayOfMonth === 2 || dayOfMonth === 17) {
    const reopenMin = toMinutes(schedule.threeDReopenTime);
    if (reopenMin !== null && now.minutes < reopenMin) {
      return { open: false, session: null, reason: 'outside_window' };
    }
    return { open: true, session: '03:30 PM', reason: 'ok' };
  }

  return { open: true, session: '03:30 PM', reason: 'ok' };
}

export function openTimeToSession(openTime: string | undefined): string | null {
  if (!openTime) return null;
  const t = openTime.trim();
  if (t.startsWith('12:01')) return '12:01 PM';
  if (t.startsWith('16:30')) return '04:30 PM';
  return null;
}
