'use client';

import React, { useState, useRef, useEffect } from 'react';
import {
  Clipboard,
  Trash2,
  Edit2,
  CheckCircle2,
  AlertCircle,
  Keyboard as KeyboardIcon,
  LayoutGrid,
} from 'lucide-react';
import { useApp, BetItem, BetRecord } from '@/context/AppContext';
import { useSchedule } from '@/hooks/use-schedule';
import { useAds } from '@/hooks/use-ads';
import { PasteBetModal } from './PasteBetModal';
import { QuickSelectModal } from './QuickSelectModal';
import { KhwayModal } from './KhwayModal';
import { FullNumbersModal } from './FullNumbersModal';
import { NumberStatusModal } from './NumberStatusModal';
import { ReceiptModal } from './ReceiptModal';
import { parseBetPaste, getPermutations, createRBetItem } from '@/lib/betParser';

interface Bet2DViewProps {
  onBack: () => void;
}

export const Bet2DView: React.FC<Bet2DViewProps> = ({ onBack }) => {
  const { user, placeBet } = useApp();
  const { evaluate, isLoading } = useSchedule();
  const betting = evaluate('2D');
  const ads = useAds();

  const [activeField, setActiveField] = useState<'number' | 'amount'>('number');
  const [numberInput, setNumberInput] = useState<string>('');
  const [amountInput, setAmountInput] = useState<string>('');
  const [isR, setIsR] = useState<boolean>(false);

  const [betList, setBetList] = useState<BetItem[]>([]);

  const [isPasteModalOpen, setIsPasteModalOpen] = useState<boolean>(false);
  const [isQuickModalOpen, setIsQuickModalOpen] = useState<boolean>(false);
  const [isKhwayModalOpen, setIsKhwayModalOpen] = useState<boolean>(false);
  const [isFullModalOpen, setIsFullModalOpen] = useState<boolean>(false);
  const [isStatusModalOpen, setIsStatusModalOpen] = useState<boolean>(false);
  const [isReceiptOpen, setIsReceiptOpen] = useState<boolean>(false);
  const [createdBet, setCreatedBet] = useState<BetRecord | null>(null);

  const [errorMsg, setErrorMsg] = useState<string>('');
  const [successToast, setSuccessToast] = useState<string>('');
  const [isSuccess, setIsSuccess] = useState<boolean>(false);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  const [isKeypadVisible, setIsKeypadVisible] = useState<boolean>(true);
  const [limitMap, setLimitMap] = useState<
    Record<
      string,
      {
        maxBetCount: number;
        maxBetAmount: number;
        currentBetCount: number;
        currentBetAmount: number;
        isBlocked: boolean;
      }
    >
  >({});

  const currentAmount = parseInt(amountInput, 10) || 0;

  useEffect(() => {
    let mounted = true;
    const load = async () => {
      try {
        const res = await fetch('/api/number-limits?type=2D', { cache: 'no-store' });
        const json = await res.json();
        if (mounted && json?.success && Array.isArray(json.data)) {
          const map: Record<
            string,
            {
              maxBetCount: number;
              maxBetAmount: number;
              currentBetCount: number;
              currentBetAmount: number;
              isBlocked: boolean;
            }
          > = {};
          for (const item of json.data) {
            map[item.number] = {
              maxBetCount: item.maxBetCount,
              maxBetAmount: item.maxBetAmount ?? 0,
              currentBetCount: item.currentBetCount,
              currentBetAmount: item.currentBetAmount ?? 0,
              isBlocked: item.isBlocked,
            };
          }
          setLimitMap(map);
        }
      } catch {}
    };
    void load();
    const interval = setInterval(load, 60000);
    return () => {
      mounted = false;
      clearInterval(interval);
    };
  }, []);

  const getNumberStatus = (num: string): 'blocked' | 'full' | 'ok' => {
    const clean = num.replace(/\D/g, '').padStart(2, '0');
    const info = limitMap[clean];
    if (!info) return 'ok';
    if (info.isBlocked) return 'blocked';
    if (info.currentBetCount >= info.maxBetCount) return 'full';
    return 'ok';
  };

  const isAmountLimitFull = (num: string): boolean => {
    const clean = num.replace(/\D/g, '').padStart(2, '0');
    const info = limitMap[clean];
    if (!info || !info.maxBetAmount) return false;
    return info.currentBetAmount >= info.maxBetAmount;
  };

  const currentNumberStatus = numberInput.length === 2 ? getNumberStatus(numberInput) : 'ok';
  const currentAmountLimitFull =
    numberInput.length === 2 ? isAmountLimitFull(numberInput) : false;

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {

      const target = e.target as HTMLElement | null;
      if (target && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA')) {
        return;
      }

      if (!e.ctrlKey && !e.metaKey && !e.altKey && e.key.length === 1) {
        e.preventDefault();
      }
    };

    window.addEventListener('keydown', handleKeyDown, { passive: false });
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const handleKeypadPress = (val: string) => {
    setErrorMsg('');

    if (activeField === 'number') {
      if (val === '00' || val === '000') {
        const next = (numberInput + val).slice(0, 2);
        setNumberInput(next);
      } else {
        if (numberInput.length < 2) {
          setNumberInput((prev) => prev + val);
        }
      }
    } else {

      if (amountInput.length < 7) {
        if (amountInput === '0' || amountInput === '') {
          setAmountInput(val === '00' || val === '000' ? '100' : val);
        } else {
          setAmountInput((prev) => (prev + val).slice(0, 7));
        }
      }
    }
  };

  const handleBackspace = () => {
    setErrorMsg('');
    if (activeField === 'number') {
      setNumberInput((prev) => prev.slice(0, -1));
    } else {
      setAmountInput((prev) => prev.slice(0, -1));
    }
  };

  const buildCurrentItem = (): BetItem | null => {
    const cleanNum = numberInput.replace(/\D/g, '');
    if (cleanNum.length !== 2) return null;
    if (currentAmount < 100) return null;
    if (isR) return createRBetItem(cleanNum, currentAmount, '2D');
    return {
      number: cleanNum,
      amount: currentAmount,
      subNumbers: [{ number: cleanNum, amount: currentAmount }],
      subCount: 1,
      perItemAmount: currentAmount,
    };
  };

  const applyAmountToPending = (amount: number): BetItem[] | null => {
    const hasPending = betList.some((it) => !it.amount || it.amount <= 0);
    if (!hasPending) return null;
    const newList = betList.map((it) => {
      if (it.amount && it.amount > 0) return it;
      const count = it.subNumbers && it.subNumbers.length > 0 ? it.subNumbers.length : 1;
      const per = Math.floor(amount / count);
      const rem = amount - per * count;
      const subNumbers =
        it.subNumbers && it.subNumbers.length > 0
          ? it.subNumbers.map((s, idx) => ({ ...s, amount: idx < rem ? per + 1 : per }))
          : [{ number: it.number, amount }];
      const baseLabel = (it.label || '').replace(/\s*\([^)]*ကျပ်စီ\)\s*$/, '');
      const label = baseLabel
        ? `${baseLabel} (${per.toLocaleString()} ကျပ်စီ)`
        : count > 1
        ? `${count} ကွက် (${per.toLocaleString()} ကျပ်စီ)`
        : it.label;
      return {
        ...it,
        amount,
        subNumbers,
        subCount: count,
        perItemAmount: per,
        label,
      };
    });
    setBetList(newList);
    return newList;
  };

  const handleEnter = () => {
    setErrorMsg('');
    const cleanNum = numberInput.replace(/\D/g, '');

    const hasPending = betList.some((it) => !it.amount || it.amount <= 0);
    if (hasPending && (activeField === 'amount' || cleanNum.length === 0)) {
      if (currentAmount < 100) {
        setErrorMsg('အနည်းဆုံး ၁၀၀ ကျပ် ဖြစ်ရပါမည်');
        setActiveField('amount');
        return;
      }
      applyAmountToPending(currentAmount);
      setSuccessToast('ပမာဏ ထည့်သွင်းပြီး');
      setAmountInput('');
      setActiveField('number');
      setTimeout(() => setSuccessToast(''), 1500);
      return;
    }

    if (cleanNum.length !== 2) {
      setErrorMsg('၂ လုံးဂဏန်း (ဥပမာ 12) အတိအကျ ထည့်ပါ');
      setActiveField('number');
      return;
    }

    if (currentAmount < 100) {
      setErrorMsg('အနည်းဆုံး ၁၀၀ ကျပ် ဖြစ်ရပါမည်');
      setActiveField('amount');
      return;
    }

    const status = getNumberStatus(cleanNum);
    if (status !== 'ok') {
      setErrorMsg(
        status === 'blocked'
          ? `ဂဏန်း (${cleanNum}) ကို ပိတ်ထားပါသည်`
          : `ဂဏန်း (${cleanNum}) သတ်မှတ်အကြိမ်ရေ ပြည့်သွားပါပြီ`
      );
      setActiveField('number');
      return;
    }

    const newItems = [...betList];

    if (isR) {
      const rItem = createRBetItem(cleanNum, currentAmount, '2D');
      const existingIdx = newItems.findIndex((it) => it.number === rItem.number);
      if (existingIdx >= 0) {
        newItems[existingIdx].amount += rItem.amount;
        if (newItems[existingIdx].subNumbers) {
          const count = newItems[existingIdx].subNumbers.length;
          const per = Math.floor(newItems[existingIdx].amount / count);
          const rem = newItems[existingIdx].amount - per * count;
          newItems[existingIdx].subNumbers.forEach((s, idx) => {
            s.amount = idx < rem ? per + 1 : per;
          });
          newItems[existingIdx].perItemAmount = per;
          newItems[existingIdx].label = `၈၅, ၅၈ (${per.toLocaleString()} ကျပ်စီ)`;
        }
      } else {
        newItems.push(rItem);
      }
      setSuccessToast(`${cleanNum} (R) ထည့်သွင်းပြီး`);
    } else {
      const existingIdx = newItems.findIndex((it) => it.number === cleanNum);
      if (existingIdx >= 0) {
        newItems[existingIdx].amount += currentAmount;
        if (newItems[existingIdx].subNumbers?.[0]) {
          newItems[existingIdx].subNumbers[0].amount = newItems[existingIdx].amount;
        }
      } else {
        newItems.push({
          number: cleanNum,
          amount: currentAmount,
          subNumbers: [{ number: cleanNum, amount: currentAmount }],
          subCount: 1,
          perItemAmount: currentAmount,
        });
      }
      setSuccessToast(`${cleanNum} ထည့်သွင်းပြီး`);
    }

    setBetList(newItems);
    setNumberInput('');
    setIsR(false);
    setActiveField('number');
    setTimeout(() => setSuccessToast(''), 1500);
  };

  const handleToggleR = () => {
    setIsR(!isR);
  };

  const handlePasteClick = async () => {
    setErrorMsg('');
    if (currentAmount < 100) {
      setErrorMsg('အနည်းဆုံး ၁၀၀ ကျပ် ပမာဏ ထည့်ပါ');
      setActiveField('amount');
      return;
    }
    try {
      if (navigator.clipboard && navigator.clipboard.readText) {
        const text = await navigator.clipboard.readText();
        if (text && text.trim()) {
          const parsed = parseBetPaste(text, '2D', currentAmount);
          if (parsed.length > 0) {
            handleParsedItems(parsed);
            return;
          }
        }
      }
    } catch {

    }
    setIsPasteModalOpen(true);
  };

  const handleParsedItems = (items: BetItem[]) => {
    if (items.length === 0) return;

    const newItems = [...betList];
    for (const it of items) {
      const existingIdx = newItems.findIndex((b) => b.number === it.number);
      if (existingIdx >= 0) {
        newItems[existingIdx].amount += it.amount;
        if (newItems[existingIdx].subNumbers && newItems[existingIdx].subNumbers.length > 0) {
          const count = newItems[existingIdx].subNumbers.length;
          const per = Math.floor(newItems[existingIdx].amount / count);
          const rem = newItems[existingIdx].amount - per * count;
          newItems[existingIdx].subNumbers.forEach((s, idx) => {
            s.amount = idx < rem ? per + 1 : per;
          });
          newItems[existingIdx].perItemAmount = per;
          newItems[existingIdx].label = `${count} ကွက် (${per.toLocaleString()} ကျပ်စီ)`;
        }
      } else {
        newItems.push(it);
      }
    }

    setBetList(newItems);
    setSuccessToast(`ဂဏန်း ${items.length} မျိုး ထည့်သွင်းပြီးပါပြီ`);
    setTimeout(() => setSuccessToast(''), 2500);
  };

  const handlePresetAdd = (item: BetItem) => {
    const newItems = [...betList];
    const existingIdx = newItems.findIndex((b) => b.number === item.number);
    if (existingIdx >= 0) {
      newItems[existingIdx].amount += item.amount;
      if (newItems[existingIdx].subNumbers && newItems[existingIdx].subNumbers.length > 0) {
        const count = newItems[existingIdx].subNumbers.length;
        const per = Math.floor(newItems[existingIdx].amount / count);
        const rem = newItems[existingIdx].amount - per * count;
        newItems[existingIdx].subNumbers.forEach((s, idx) => {
          s.amount = idx < rem ? per + 1 : per;
        });
        newItems[existingIdx].perItemAmount = per;
        newItems[existingIdx].label = `${count} ကွက် (${per.toLocaleString()} ကျပ်စီ)`;
      }
    } else {
      newItems.push(item);
    }
    setBetList(newItems);
    if (currentAmount < 100) {
      setActiveField('amount');
      setSuccessToast('ပမာဏ ထည့်သွင်းပြီး ENTER နှိပ်ပါ');
    } else {
      setSuccessToast(`${item.number} ထည့်သွင်းပြီး`);
    }
    setTimeout(() => setSuccessToast(''), 2500);
  };

  const handleBatchAdd = (numbers: string[]) => {
    if (numbers.length === 0) return;
    const newItems = [...betList];
    for (const num of numbers) {
      const existingIdx = newItems.findIndex((b) => b.number === num);
      if (existingIdx >= 0) {
        newItems[existingIdx].amount += currentAmount;
      } else {
        newItems.push({
          number: num,
          amount: currentAmount,
          subNumbers: [{ number: num, amount: currentAmount }],
          subCount: 1,
          perItemAmount: currentAmount,
        });
      }
    }
    setBetList(newItems);
    if (currentAmount < 100) {
      setActiveField('amount');
      setSuccessToast('ပမာဏ ထည့်သွင်းပြီး ENTER နှိပ်ပါ');
    } else {
      setSuccessToast(`${numbers.length} ကွက် ထည့်သွင်းပြီး`);
    }
    setTimeout(() => setSuccessToast(''), 2500);
  };

  const handleRemoveRow = (num: string) => {
    setBetList(betList.filter((it) => it.number !== num));
  };

  const handleEditRow = (num: string, amt: number) => {
    const isReverse = num.includes('(R)');
    const cleanNumber = num.replace(/\s*\(R\)/, '').trim();
    if (/^\d{2}$/.test(cleanNumber)) {
      setNumberInput(cleanNumber);
      setIsR(isReverse);
    } else {
      setNumberInput('');
      setIsR(false);
    }
    setAmountInput(amt.toString());
    setActiveField('number');
    setBetList(betList.filter((it) => it.number !== num));
  };

  const handleClearAll = () => {
    setBetList([]);
    setErrorMsg('');
  };

  const totalCost = betList.reduce((sum, it) => sum + it.amount, 0);

  const handleConfirmBet = async () => {
    if (!betting.open) {
      setErrorMsg('ထိုးသွင်းချိန် မဟုတ်ပါ (ထိုးချိန် ပိတ်ထားပါသည်)');
      return;
    }
    if (isSubmitting) return;
    setIsSubmitting(true);

    let workingList = betList;
    if (workingList.some((it) => !it.amount || it.amount <= 0)) {
      if (currentAmount < 100) {
        setErrorMsg('ထိုးရန် ပမာဏ ထည့်သွင်းပါ');
        setActiveField('amount');
        setIsSubmitting(false);
        return;
      }
      workingList = applyAmountToPending(currentAmount) || workingList;
    }

    let finalList = workingList;
    if (finalList.length === 0) {
      const item = buildCurrentItem();
      if (!item) {
        setErrorMsg('ဂဏန်းနှင့် ပမာဏ ဖြည့်သွင်းပါ');
        setIsSubmitting(false);
        return;
      }
      finalList = [item];
    }

    const finalTotal = finalList.reduce((sum, it) => sum + it.amount, 0);

    for (const it of finalList) {
      const nums =
        it.subNumbers && it.subNumbers.length > 0
          ? it.subNumbers.map((s) => s.number)
          : [it.number];
      for (const n of nums) {
        const st = getNumberStatus(n);
        if (st !== 'ok') {
          setErrorMsg(
            st === 'blocked'
              ? `ဂဏန်း (${n}) ကို ပိတ်ထားပါသည်`
              : `ဂဏန်း (${n}) သတ်မှတ်အကြိမ်ရေ ပြည့်သွားပါပြီ`
          );
          setIsSubmitting(false);
          return;
        }
      }
    }

    if (user.balance < finalTotal) {
      setErrorMsg(
        `လက်ကျန်ငွေ မလုံလောက်ပါ (လိုအပ်ငွေ: ${finalTotal.toLocaleString()} ks, လက်ကျန်: ${user.balance.toLocaleString()} ks)`
      );
      setIsSubmitting(false);
      return;
    }

    const newBet = await placeBet('2D', betting.session || '12:01 PM', finalList);
    if (newBet) {
      setCreatedBet(newBet);
      setIsSuccess(true);
      setSuccessToast('ထိုးတာအောင်မြင်ပါသည်');
      setBetList([]);
      setNumberInput('');
      setIsR(false);
      setErrorMsg('');
      setIsSubmitting(false);
      setTimeout(() => onBack(), 1600);
    } else {
      setErrorMsg('ထိုးခြင်းမအောင်မြင်ပါ');
      setIsSubmitting(false);
    }
  };

  return (
    <div
      className="w-full min-h-[100dvh] bg-black text-white flex flex-col justify-between select-none max-w-md mx-auto relative overflow-x-hidden pb-[env(safe-area-inset-bottom)]"
      id="bet-2d-screen"
    >
      <div className="flex items-center gap-2 px-3 pt-3 pb-2 bg-black z-20">
        <button
          type="button"
          onClick={onBack}
          className="p-1 shrink-0 text-[#eab308] hover:text-amber-300 transition cursor-pointer"
          id="bet-2d-back-btn"
          aria-label="Back"
        >
          <svg
            className="w-8 h-8 text-[#eab308]"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="3"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="M9 15L4 10m0 0l5-5M4 10h11a5 5 0 015 5v1" />
          </svg>
        </button>

        <h1 className="flex-1 text-center font-extrabold text-xl text-[#eab308] tracking-wide">
          2D ထိုးမည်
        </h1>

        <div className="w-8 shrink-0" />
      </div>

      {ads.notice2 && (
        <div className="bg-black overflow-hidden py-1 border-b border-zinc-900 flex items-center">
          <div className="animate-marquee text-[#eab308] text-xs font-semibold tracking-wide">
            {ads.notice2}
          </div>
        </div>
      )}

      <div className="flex-1 flex flex-col min-h-0 bg-black">
        <div className="grid grid-cols-12 px-3 py-2 text-[#eab308] text-xs font-bold border-b border-zinc-900 bg-black/90 sticky top-0 z-10">
          <span className="col-span-1 text-left pl-1">စဉ်</span>
          <span className="col-span-6 text-center">ဂဏန်း</span>
          <span className="col-span-3 text-center">ပမာဏ</span>
          <span className="col-span-2 text-right pr-1">ပြင်/ဖျက်</span>
        </div>

        <div className="flex-1 overflow-y-auto px-2 py-1 space-y-1">
          {betList.length === 0 ? (
            <div className="h-44 flex flex-col items-center justify-center text-zinc-600 text-xs text-center px-4">
              <p>ထိုးလိုသော ဂဏန်းများကို အောက်ပါ Keypad ဖြင့် ရိုက်ထည့်ပါ</p>
              <p className="text-zinc-700 text-[11px] mt-1">
                (လက်ကျန်ငွေ: {user.balance.toLocaleString()} ks)
              </p>
            </div>
          ) : (
            betList.map((item, idx) => (
              <div
                key={`${item.number}-${idx}`}
                className="grid grid-cols-12 items-center px-2 py-2 rounded-lg bg-[#111111] border border-zinc-800/80 text-xs hover:border-amber-500/30 transition gap-1"
              >
                <span className="col-span-1 text-zinc-400 font-mono pl-1">{idx + 1}</span>
                <div className="col-span-6 flex flex-col items-center justify-center px-1">
                  <span className="text-center font-black text-amber-300 text-xs sm:text-sm break-words max-w-full font-mono leading-snug">
                    {item.number}
                  </span>
                  {item.label && (
                    <span className="text-[10px] text-zinc-400 font-normal leading-tight text-center mt-0.5">
                      {item.label}
                    </span>
                  )}
                </div>
                <span className="col-span-3 text-center text-zinc-200 font-mono font-bold">
                  {item.amount.toLocaleString()}
                </span>
                <div className="col-span-2 flex items-center justify-end gap-1.5 pr-1">
                  <button
                    type="button"
                    onClick={() => handleEditRow(item.number, item.amount)}
                    className="p-1 text-zinc-400 hover:text-amber-400 transition"
                    title="ပြင်မည်"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    type="button"
                    onClick={() => handleRemoveRow(item.number)}
                    className="p-1 text-zinc-400 hover:text-red-400 transition"
                    title="ဖျက်မည်"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        {betList.length > 0 && (
          <div className="px-4 py-1.5 bg-[#0e0e0e] border-t border-zinc-800 flex items-center justify-between text-xs">
            <span className="text-zinc-300">
              စုစုပေါင်း: <strong className="text-amber-400">{betList.length} ကွက်</strong> ({totalCost.toLocaleString()} ks)
            </span>
            <button
              type="button"
              onClick={handleClearAll}
              className="text-red-400 hover:text-red-300 text-[11px] font-semibold"
            >
              အားလုံးဖျက်မည်
            </button>
          </div>
        )}

        {errorMsg && (
          <div className="mx-3 my-1 p-2.5 rounded-xl bg-red-950/80 border border-red-500/50 text-red-300 text-sm sm:text-base font-semibold text-center flex items-center justify-center gap-2">
            <AlertCircle className="w-5 h-5 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {successToast && (
          <div className="mx-3 my-1 p-2 rounded-xl bg-amber-950/80 border border-amber-500/50 text-amber-300 text-sm font-semibold text-center">
            {successToast}
          </div>
        )}

        {isSuccess && (
          <div className="mx-3 my-1 p-2 rounded-xl bg-green-950/80 border border-green-500/60 text-green-300 text-xs font-bold text-center flex items-center justify-center gap-1.5">
            <CheckCircle2 className="w-4 h-4 text-green-400" />
            <span>ထိုးကြေး အောင်မြင်စွာ တင်သွင်းပြီးပါပြီ။</span>
          </div>
        )}
      </div>

      {isKeypadVisible ? (
        <div className="bg-black px-3 pt-2 pb-3 space-y-2 border-t border-zinc-900 transition-all">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => setActiveField('number')}
              className={`flex-1 h-13 rounded-2xl border-2 transition flex items-center justify-center font-black text-lg cursor-pointer ${
                currentNumberStatus !== 'ok' || currentAmountLimitFull
                  ? 'border-red-500 bg-black text-red-500'
                  : activeField === 'number'
                  ? 'border-[#f5b300] bg-black text-[#f5b300] shadow-[0_0_12px_rgba(245,179,0,0.3)]'
                  : 'border-[#f5b300] bg-black text-[#f5b300]'
              }`}
              id="bet-2d-number-box"
            >
              {numberInput ? (
                <span className="tracking-widest">{numberInput}</span>
              ) : (
                <span className="text-[#f5b300]">ဂဏန်း</span>
              )}
              {activeField === 'number' && (
                <span className="caret-blink ml-0.5 inline-block w-[2px] h-6 bg-[#f5b300]" />
              )}
              {isR && <span className="ml-1 text-xs bg-white text-black px-1.5 py-0.5 rounded-full font-bold">R</span>}
            </button>

            <button
              type="button"
              onClick={() => setActiveField('amount')}
              className={`flex-1 h-13 rounded-2xl border-2 transition flex items-center justify-center font-black text-lg cursor-pointer ${
                activeField === 'amount'
                  ? 'border-[#f5b300] bg-black text-[#f5b300] shadow-[0_0_12px_rgba(245,179,0,0.3)]'
                  : 'border-[#f5b300] bg-black text-[#f5b300]'
              }`}
              id="bet-2d-amount-box"
            >
              {amountInput ? (
                <span className="font-mono">{amountInput}</span>
              ) : (
                <span className="text-[#f5b300]">ပမာဏ</span>
              )}
              {activeField === 'amount' && (
                <span className="caret-blink ml-0.5 inline-block w-[2px] h-6 bg-[#f5b300]" />
              )}
            </button>
          </div>

          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => setIsKhwayModalOpen(true)}
              className="flex-1 h-11 rounded-full bg-black border border-zinc-700/80 text-[#f5b300] font-bold text-base flex items-center justify-center hover:bg-zinc-900 active:scale-95 transition cursor-pointer"
              id="bet-2d-khway-btn"
            >
              ခွေ
            </button>

            <button
              type="button"
              onClick={() => setIsFullModalOpen(true)}
              className="flex-1 h-11 rounded-full bg-[#f5b300] text-black font-extrabold text-base flex items-center justify-center hover:bg-[#e0a200] active:scale-95 transition cursor-pointer"
              id="bet-2d-full-btn"
            >
              ပြည့်ဂဏန်း
            </button>

            <button
              type="button"
              onClick={() => setIsStatusModalOpen(true)}
              className="w-11 h-11 shrink-0 rounded-full bg-black border border-[#f5b300]/60 text-[#f5b300] flex items-center justify-center hover:bg-zinc-900 active:scale-95 transition cursor-pointer"
              id="bet-2d-status-btn"
              title="ဂဏန်းအခြေအနေ (Full / Blocked)"
            >
              <LayoutGrid className="w-5 h-5" />
            </button>
          </div>

          <div className="grid grid-cols-4 gap-2">
            <button
              type="button"
              onClick={() => setIsQuickModalOpen(true)}
              className="h-11 rounded-full bg-[#f5b300] text-black font-extrabold text-sm flex items-center justify-center hover:bg-[#e0a200] active:scale-95 transition cursor-pointer"
              id="bet-2d-quick-btn"
            >
              အမြန်
            </button>

            <button
              type="button"
              onClick={() => {
                setActiveField(activeField === 'number' ? 'amount' : 'number');
              }}
              className="h-11 rounded-full bg-[#161616] text-white font-bold text-xl flex items-center justify-center hover:bg-zinc-800 active:scale-95 transition cursor-pointer"
            >
              *
            </button>

            <button
              type="button"
              onClick={handlePasteClick}
              className="h-11 rounded-full bg-[#161616] text-[#f5b300] flex items-center justify-center hover:bg-zinc-800 active:scale-95 transition cursor-pointer"
              title="ကူးယူထားသော ဂဏန်းများ ထည့်ရန်"
              id="bet-2d-paste-btn"
            >
              <Clipboard className="w-5 h-5 stroke-[2.3] text-[#f5b300]" />
            </button>

            <button
              type="button"
              onClick={handleBackspace}
              className="h-11 rounded-full bg-[#161616] text-white flex items-center justify-center hover:bg-zinc-800 active:scale-95 transition cursor-pointer"
              title="ဖျက်မည်"
              id="bet-2d-backspace-btn"
            >
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src="/images/backspace.png"
                alt="backspace"
                className="w-6 h-6 object-contain"
              />
            </button>
          </div>

          <div className="grid grid-cols-4 gap-2">
            <button
              type="button"
              onClick={() => handleKeypadPress('7')}
              className="h-11 rounded-full bg-[#161616] text-white font-bold text-lg flex items-center justify-center hover:bg-zinc-800 active:scale-95 transition cursor-pointer"
            >
              7
            </button>
            <button
              type="button"
              onClick={() => handleKeypadPress('8')}
              className="h-11 rounded-full bg-[#161616] text-white font-bold text-lg flex items-center justify-center hover:bg-zinc-800 active:scale-95 transition cursor-pointer"
            >
              8
            </button>
            <button
              type="button"
              onClick={() => handleKeypadPress('9')}
              className="h-11 rounded-full bg-[#161616] text-white font-bold text-lg flex items-center justify-center hover:bg-zinc-800 active:scale-95 transition cursor-pointer"
            >
              9
            </button>
            <button
              type="button"
              onClick={handleToggleR}
              className={`h-11 rounded-full font-black text-lg flex items-center justify-center active:scale-95 transition cursor-pointer ${
                isR
                  ? 'bg-[#f5b300] text-black ring-2 ring-white shadow-md'
                  : 'bg-white text-black hover:bg-zinc-200'
              }`}
              title="ပတ်လည် (R)"
              id="bet-2d-r-btn"
            >
              R
            </button>

            <button
              type="button"
              onClick={() => handleKeypadPress('4')}
              className="h-11 rounded-full bg-[#161616] text-white font-bold text-lg flex items-center justify-center hover:bg-zinc-800 active:scale-95 transition cursor-pointer"
            >
              4
            </button>
            <button
              type="button"
              onClick={() => handleKeypadPress('5')}
              className="h-11 rounded-full bg-[#161616] text-white font-bold text-lg flex items-center justify-center hover:bg-zinc-800 active:scale-95 transition cursor-pointer"
            >
              5
            </button>
            <button
              type="button"
              onClick={() => handleKeypadPress('6')}
              className="h-11 rounded-full bg-[#161616] text-white font-bold text-lg flex items-center justify-center hover:bg-zinc-800 active:scale-95 transition cursor-pointer"
            >
              6
            </button>
            <button
              type="button"
              onClick={() => {
                setActiveField(activeField === 'number' ? 'amount' : 'number');
              }}
              className="h-11 rounded-full bg-[#161616] text-white font-bold text-lg flex items-center justify-center hover:bg-zinc-800 active:scale-95 transition cursor-pointer"
            >
              /
            </button>

            <button
              type="button"
              onClick={() => handleKeypadPress('1')}
              className="h-11 rounded-full bg-[#161616] text-white font-bold text-lg flex items-center justify-center hover:bg-zinc-800 active:scale-95 transition cursor-pointer"
            >
              1
            </button>
            <button
              type="button"
              onClick={() => handleKeypadPress('2')}
              className="h-11 rounded-full bg-[#161616] text-white font-bold text-lg flex items-center justify-center hover:bg-zinc-800 active:scale-95 transition cursor-pointer"
            >
              2
            </button>
            <button
              type="button"
              onClick={() => handleKeypadPress('3')}
              className="h-11 rounded-full bg-[#161616] text-white font-bold text-lg flex items-center justify-center hover:bg-zinc-800 active:scale-95 transition cursor-pointer"
            >
              3
            </button>
            <button
              type="button"
              onClick={handleEnter}
              className="h-11 rounded-full bg-[#161616] text-[#f5b300] font-black text-xs sm:text-sm tracking-wider flex items-center justify-center hover:bg-zinc-800 active:scale-95 transition cursor-pointer"
              id="bet-2d-enter-btn"
            >
              ENTER
            </button>

            <button
              type="button"
              onClick={() => handleKeypadPress('0')}
              className="h-11 rounded-full bg-[#161616] text-white font-bold text-lg flex items-center justify-center hover:bg-zinc-800 active:scale-95 transition cursor-pointer"
            >
              0
            </button>
            <button
              type="button"
              onClick={() => handleKeypadPress('00')}
              className="h-11 rounded-full bg-[#161616] text-white font-bold text-base flex items-center justify-center hover:bg-zinc-800 active:scale-95 transition cursor-pointer"
            >
              00
            </button>
            <button
              type="button"
              onClick={() => handleKeypadPress('000')}
              className="h-11 rounded-full bg-[#161616] text-white font-bold text-base flex items-center justify-center hover:bg-zinc-800 active:scale-95 transition cursor-pointer"
            >
              000
            </button>
            <button
              type="button"
              onClick={() => setIsKeypadVisible(false)}
              className="h-11 rounded-full bg-[#161616] border border-amber-500/30 flex items-center justify-center hover:bg-zinc-800 active:scale-95 transition cursor-pointer"
              title="ကီးဘုတ် ဖျောက်မည်"
              id="bet-2d-hide-keypad-btn"
            >
              <KeyboardIcon className="w-5 h-5 text-[#f5b300]" />
            </button>
          </div>

          <div className="pt-1 text-center">
            <button
              type="button"
              onClick={handleConfirmBet}
              disabled={isSuccess || isSubmitting || !betting.open}
              className="w-full py-2 text-center text-[#f5b300] font-extrabold text-xl hover:text-amber-300 active:scale-95 transition cursor-pointer disabled:opacity-50 flex items-center justify-center gap-2"
              id="bet-2d-submit-btn"
            >
              {isSubmitting ? (
                <>
                  <span className="w-5 h-5 border-2 border-[#f5b300] border-t-transparent rounded-full animate-spin" />
                  <span>ထိုးနေပါသည်...</span>
                </>
              ) : isSuccess ? (
                'အောင်မြင်ပါသည်...'
              ) : (
                'ထိုးမည်'
              )}
            </button>
          </div>
        </div>
      ) : (

        <div className="bg-black px-4 py-3 border-t border-zinc-900 flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={() => setIsKeypadVisible(true)}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-zinc-900 border border-amber-500/40 text-[#f5b300] text-xs font-bold hover:bg-zinc-800 active:scale-95 transition cursor-pointer"
          >
            <KeyboardIcon className="w-4 h-4" />
            <span>ကီးဘုတ် ဖွင့်မည်</span>
          </button>

          <button
            type="button"
            onClick={handleConfirmBet}
            disabled={isSuccess || isSubmitting || !betting.open || (betList.length === 0 && !buildCurrentItem())}
            className="flex-1 py-2.5 rounded-xl bg-[#f5b300] text-black font-extrabold text-base hover:bg-[#e0a200] active:scale-95 transition cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            {isSubmitting ? (
              <>
                <span className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin" />
                <span>ထိုးနေပါသည်...</span>
              </>
            ) : isSuccess ? (
              'အောင်မြင်ပါသည်...'
            ) : (
              'ထိုးမည်'
            )}
          </button>
        </div>
      )}

      {!isKeypadVisible && (
        <button
          type="button"
          onClick={() => setIsKeypadVisible(true)}
          className="fixed bottom-20 right-5 z-40 w-14 h-14 rounded-full bg-[#161616] border-2 border-[#f5b300] text-[#f5b300] shadow-[0_0_24px_rgba(245,179,0,0.5)] flex items-center justify-center hover:scale-110 active:scale-95 transition-all cursor-pointer group"
          title="ကီးဘုတ် ဖွင့်မည်"
          aria-label="Show number pad"
          id="bet-2d-floating-keypad-btn"
        >
          <KeyboardIcon className="w-7 h-7 group-hover:rotate-6 transition-transform" />
        </button>
      )}

      <PasteBetModal
        isOpen={isPasteModalOpen}
        type="2D"
        defaultAmount={currentAmount}
        onClose={() => setIsPasteModalOpen(false)}
        onAdd={handleParsedItems}
      />

      <QuickSelectModal
        isOpen={isQuickModalOpen}
        type="2D"
        amount={currentAmount}
        onClose={() => setIsQuickModalOpen(false)}
        onSelectPreset={handlePresetAdd}
        onSelectNumbers={handleBatchAdd}
      />

      <KhwayModal
        isOpen={isKhwayModalOpen}
        type="2D"
        amount={currentAmount}
        onClose={() => setIsKhwayModalOpen(false)}
        onSelectPreset={handlePresetAdd}
        onGenerate={handleBatchAdd}
      />

      <FullNumbersModal
        isOpen={isFullModalOpen}
        type="2D"
        amount={currentAmount}
        onClose={() => setIsFullModalOpen(false)}
        onSelectPreset={handlePresetAdd}
        onSelectNumbers={handleBatchAdd}
      />

      <NumberStatusModal
        isOpen={isStatusModalOpen}
        type="2D"
        onClose={() => setIsStatusModalOpen(false)}
      />

      <ReceiptModal
        bet={createdBet}
        isOpen={isReceiptOpen}
        onClose={() => setIsReceiptOpen(false)}
        onContinueBetting={() => setIsReceiptOpen(false)}
      />

      {isLoading && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center bg-black/90">
          <div className="flex flex-col items-center gap-3">
            <span className="w-9 h-9 border-2 border-[#f5b300] border-t-transparent rounded-full animate-spin" />
            <span className="text-[#f5b300] text-xs font-semibold">ထိုးချိန် စစ်ဆေးနေပါသည်...</span>
          </div>
        </div>
      )}

      {!isLoading && !betting.open && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center bg-black/90 backdrop-blur-sm p-4">
          <div className="w-full max-w-xs rounded-3xl bg-[#141416] border-2 border-amber-500/60 p-6 text-center shadow-2xl">
            <div className="w-14 h-14 rounded-full bg-amber-500/15 text-amber-400 flex items-center justify-center mx-auto mb-3">
              <AlertCircle className="w-7 h-7" />
            </div>
            <h3 className="text-base font-bold text-amber-400 mb-2">ထိုးသွင်းချိန် ပိတ်ထားပါသည်</h3>
            <p className="text-xs text-zinc-300 leading-relaxed">
              Admin သတ်မှတ်ထားသော အချိန်အတွင်းသာ ထိုးနိုင်ပါသည်။
            </p>
            <button
              type="button"
              onClick={onBack}
              className="mt-4 w-full py-2.5 rounded-xl bg-[#f5b300] text-black text-sm font-bold hover:bg-[#e0a200] transition"
            >
              နောက်သို့ ပြန်မည်
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
