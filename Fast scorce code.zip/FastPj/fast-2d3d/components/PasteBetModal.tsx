'use client';

import React, { useState, useMemo } from 'react';
import { X, Clipboard, CheckCircle2, AlertCircle } from 'lucide-react';
import { parseBetPaste, ParsedBetItem } from '@/lib/betParser';
import { ModalPortal } from './ModalPortal';

interface PasteBetModalProps {
  isOpen: boolean;
  onClose: () => void;
  type: '2D' | '3D';
  defaultAmount: number;
  onAdd: (items: ParsedBetItem[]) => void;
}

export const PasteBetModal: React.FC<PasteBetModalProps> = ({
  isOpen,
  onClose,
  type,
  defaultAmount,
  onAdd,
}) => {
  const [pasteText, setPasteText] = useState('');
  const [actionError, setActionError] = useState('');

  const { parsedPreview, parseError } = useMemo(() => {
    if (!pasteText.trim()) {
      return { parsedPreview: [], parseError: '' };
    }
    const items = parseBetPaste(pasteText, type, defaultAmount);
    let err = '';
    if (items.length === 0 && pasteText.trim().length > 1) {
      err =
        type === '2D'
          ? 'မှန်ကန်သော ၂ လုံးဂဏန်း မတွေ့ရှိပါ (ဥပမာ 12=1000 သို့မဟုတ် 12 34 56)'
          : 'မှန်ကန်သော ၃ လုံးဂဏန်း မတွေ့ရှိပါ (ဥပမာ 123=1000 သို့မဟုတ် 123 456)';
    }
    return { parsedPreview: items, parseError: err };
  }, [pasteText, type, defaultAmount]);

  if (!isOpen) return null;

  const displayError = actionError || parseError;

  const handleReadClipboard = async () => {
    try {
      if (navigator.clipboard && navigator.clipboard.readText) {
        const text = await navigator.clipboard.readText();
        if (text) {
          setPasteText(text);
          return;
        }
      }
    } catch {

    }
  };

  const handleConfirm = () => {
    if (parsedPreview.length === 0) {
      setActionError('ထည့်သွင်းရန် ဂဏန်း မရှိပါ');
      return;
    }
    onAdd(parsedPreview);
    setPasteText('');
    setActionError('');
    onClose();
  };

  const totalAmt = parsedPreview.reduce((sum, it) => sum + it.amount, 0);

  return (
    <ModalPortal>
    <div className="fixed inset-0 z-60 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 select-none animate-in fade-in duration-150">
      <div className="w-full max-w-sm max-h-[88dvh] bg-[#14120e] border border-amber-500/40 rounded-2xl overflow-hidden shadow-2xl flex flex-col">
        <div className="flex items-center justify-between px-4 py-3 border-b border-amber-500/20 bg-black/70">
          <div className="flex items-center gap-2">
            <Clipboard className="w-4 h-4 text-amber-400" />
            <h4 className="font-bold text-sm text-amber-400">
              {type} ဂဏန်းနှင့်ထိုးငွေ ကူးထည့်မည် (Paste)
            </h4>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-zinc-400 hover:text-white bg-zinc-900"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-4 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs text-zinc-400">ကူးယူထားသော စာသားကို ထည့်ပါ:</span>
            <button
              type="button"
              onClick={handleReadClipboard}
              className="text-[11px] px-2.5 py-1 rounded-md bg-amber-400/20 border border-amber-400/40 text-amber-300 font-bold hover:bg-amber-400/30 flex items-center gap-1"
            >
              <Clipboard className="w-3 h-3" />
              <span>Paste နှိပ်မည်</span>
            </button>
          </div>

          <textarea
            rows={5}
            value={pasteText}
            onChange={(e) => setPasteText(e.target.value)}
            placeholder={
              type === '2D'
                ? `ဥပမာ -\n85 R 100 (၈၅=၅၀, ၅၈=၅၀)\nအပူး 1000 (၁ ကွက် ၁၀၀)\n12=1000, 34=500\n12 34 56 78\n၁၂=၅၀၀`
                : `ဥပမာ -\n123 R 600\n3D အပူး 1000\n123=2000, 456=1000\n123 456 789\n၁၂၃=၁၀၀၀`
            }
            className="w-full p-3 rounded-xl bg-black border border-amber-500/30 text-amber-200 font-mono text-xs focus:outline-none focus:ring-1 focus:ring-amber-400 placeholder:text-zinc-600 resize-none"
            autoFocus
          />

          {displayError && (
            <div className="p-2 rounded-lg bg-red-950/70 border border-red-500/40 text-red-300 text-[11px] flex items-center gap-1.5">
              <AlertCircle className="w-3.5 h-3.5 flex-shrink-0" />
              <span>{displayError}</span>
            </div>
          )}

          {parsedPreview.length > 0 && (
            <div className="rounded-xl border border-amber-500/30 bg-black/60 p-2.5 max-h-36 overflow-y-auto space-y-1.5">
              <div className="flex items-center justify-between text-[11px] text-zinc-400 border-b border-zinc-800 pb-1">
                <span>
                  တွေ့ရှိသောဂဏန်း: <strong className="text-amber-300">{parsedPreview.length}</strong> ကွက်
                </span>
                <span className="text-amber-400 font-bold">
                  {totalAmt.toLocaleString()} ks
                </span>
              </div>
              <div className="flex flex-wrap gap-1.5 pt-1">
                {parsedPreview.map((item, idx) => (
                  <span
                    key={`${item.number}-${idx}`}
                    className="inline-flex flex-col items-center px-2 py-1 rounded-md bg-amber-400/15 border border-amber-400/30 text-[11px] font-bold text-amber-300"
                  >
                    <span>
                      {item.number} ({item.amount.toLocaleString()}ks)
                    </span>
                    {item.label && (
                      <span className="text-[9px] text-zinc-400 font-normal">
                        {item.label}
                      </span>
                    )}
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>

        <div className="p-3 border-t border-amber-500/20 bg-black/70 flex gap-2">
          <button
            type="button"
            onClick={onClose}
            className="flex-1 h-10 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-300 font-bold text-xs hover:bg-zinc-800 transition"
          >
            မလုပ်တော့ပါ
          </button>
          <button
            type="button"
            disabled={parsedPreview.length === 0}
            onClick={handleConfirm}
            className="flex-1 h-10 rounded-xl bg-gradient-to-b from-[#ffdc5e] via-[#f1b827] to-[#cb8f0b] text-black font-bold text-xs hover:brightness-105 transition disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center gap-1"
          >
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>စာရင်းထဲထည့်မည် ({parsedPreview.length})</span>
          </button>
        </div>
      </div>
    </div>
    </ModalPortal>
  );
};
