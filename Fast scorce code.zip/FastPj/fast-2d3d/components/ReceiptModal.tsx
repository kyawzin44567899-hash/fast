'use client';

import React, { useRef, useState } from 'react';
import {
  Download,
  Share2,
  Copy,
  Check,
  X,
  Trophy,
  CheckCircle2,
  Sparkles,
  ShieldCheck,
  Calendar,
  Clock,
  User,
  Hash,
  ArrowRight,
} from 'lucide-react';
import { BetRecord, useApp } from '@/context/AppContext';
import { toPng } from 'html-to-image';
import { ModalPortal } from './ModalPortal';

interface ReceiptModalProps {
  bet: BetRecord | null;
  isOpen: boolean;
  onClose: () => void;
  onContinueBetting?: () => void;
}

export const ReceiptModal: React.FC<ReceiptModalProps> = ({
  bet,
  isOpen,
  onClose,
  onContinueBetting,
}) => {
  const { user } = useApp();
  const receiptRef = useRef<HTMLDivElement>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [copied, setCopied] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  if (!isOpen || !bet) return null;

  const voucherId = bet.id.startsWith('bet-')
    ? `V${bet.type}-${bet.id.replace('bet-', '').slice(-8)}`
    : `#${bet.id}`;

  const totalSubCount = bet.items?.reduce((sum, it) => {
    return sum + (it.subCount || it.subNumbers?.length || 1);
  }, 0) || bet.numbers.length;

  const isToodWin = bet.status === 'TOOD_WIN' || Boolean(bet.isTood);
  const multiplier = isToodWin
    ? bet.payoutMultiplier || 10
    : bet.type === '2D'
    ? 85
    : 550;

  const handleSaveToDevice = async () => {
    if (!receiptRef.current) return;
    setIsGenerating(true);
    setErrorMessage(null);

    try {

      const node = receiptRef.current;
      const dataUrl = await toPng(node, {
        quality: 0.98,
        pixelRatio: 2.5,
        cacheBust: true,
        backgroundColor: '#0c0c0e',
        style: {
          borderRadius: '16px',
        },
      });

      const link = document.createElement('a');
      link.download = `Fast2D3D_Receipt_${voucherId}_${bet.type}.png`;
      link.href = dataUrl;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3000);
    } catch (err) {
      console.error('Failed to generate PNG receipt:', err);

      setErrorMessage('ပုံထုတ်ယူခြင်း မအောင်မြင်ပါ။ စာသားဖြင့် ကူးယူသိမ်းဆည်းနိုင်ပါသည်။');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleShare = async () => {
    if (!receiptRef.current) return;
    setErrorMessage(null);

    try {
      if (navigator.share) {
        setIsGenerating(true);
        const node = receiptRef.current;
        const dataUrl = await toPng(node, {
          quality: 0.95,
          pixelRatio: 2,
          backgroundColor: '#0c0c0e',
        });
        const res = await fetch(dataUrl);
        const blob = await res.blob();
        const file = new File([blob], `Fast2D3D_Receipt_${voucherId}.png`, {
          type: 'image/png',
        });

        if (navigator.canShare && navigator.canShare({ files: [file] })) {
          await navigator.share({
            title: `Fast 2D3D ဘောက်ချာ - ${voucherId}`,
            text: `Fast 2D/3D ထိုးကြေးပြေစာ | ${bet.type} (${bet.session}) | စုစုပေါင်း: ${bet.amount.toLocaleString()} ks`,
            files: [file],
          });
          setIsGenerating(false);
          return;
        }
      }

      handleCopyText();
    } catch {
      handleCopyText();
    } finally {
      setIsGenerating(false);
    }
  };

  const handleCopyText = () => {
    const lines = [
      `=== FAST 2D/3D LOTTERY RECEIPT ===`,
      `ပြေစာအမှတ်: ${voucherId}`,
      `အမျိုးအစား: ${bet.type} (${bet.session})`,
      `ရက်စွဲ: ${bet.date}`,
      `ဖုန်းနံပါတ်: ${user.phone}`,
      `ကိုယ်စားလှယ်ကုဒ်: ${user.agentCode}`,
      `---------------------------------`,
      `ထိုးထားသော ဂဏန်းများ:`,
      ...(bet.items && bet.items.length > 0
        ? bet.items.map(
            (it, i) =>
              `${i + 1}. ${it.number} = ${it.amount.toLocaleString()} ks ${
                it.label ? `(${it.label})` : ''
              }`
          )
        : bet.numbers.map((n, i) => `${i + 1}. ${n}`)),
      `---------------------------------`,
      `စုစုပေါင်း ကွက်ရေ: ${totalSubCount} ကွက်`,
      `စုစုပေါင်း ထိုးငွေ: ${bet.amount.toLocaleString()} ks`,
      `အလျော်ဆ: ${multiplier} ဆ`,
      `အခြေအနေ: ${
        bet.status === 'TOOD_WIN'
          ? 'TOOD ပေါက် (Tood Win)'
          : bet.status === 'win'
          ? 'ပေါက်ပါသည် (Won)'
          : 'အတည်ပြုပြီး (Confirmed)'
      }`,
      ...(bet.winAmount ? [`ပေါက်ငွေ: ${bet.winAmount.toLocaleString()} ks`] : []),
      `=================================`,
      `Fast 2D/3D Official Mobile App`,
    ];

    navigator.clipboard.writeText(lines.join('\n'));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <ModalPortal>
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-3 sm:p-4 overflow-y-auto animate-in fade-in select-none"
      id="receipt-modal-backdrop"
    >
      <div className="w-full max-w-sm rounded-3xl bg-zinc-950 border border-amber-500/50 text-white shadow-2xl overflow-hidden flex flex-col my-auto max-h-[88dvh]">
        <div className="flex items-center justify-between px-4 py-3 bg-gradient-to-r from-[#18150e] via-[#221c10] to-[#18150e] border-b border-amber-500/30">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-amber-400/20 border border-amber-400/50 flex items-center justify-center text-amber-400">
              <ShieldCheck className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-extrabold text-sm text-amber-400 leading-tight">
                ထိုးကြေး ပြေစာဘောက်ချာ
              </h3>
              <p className="text-[10px] text-zinc-400">Official Bet Slip</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-zinc-900 border border-zinc-700 text-zinc-400 hover:text-white flex items-center justify-center active:scale-95 transition"
            id="close-receipt-btn"
            aria-label="Close"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="overflow-y-auto px-3.5 py-3 flex-1 space-y-3">
          <div
            ref={receiptRef}
            id="capturable-receipt"
            className="relative bg-gradient-to-b from-[#161618] via-[#101012] to-[#0a0a0c] rounded-2xl border border-amber-500/40 p-4 text-zinc-100 shadow-xl overflow-hidden"
          >
            <div className="flex justify-between items-center opacity-40 mb-2 border-b border-dashed border-zinc-700/80 pb-2">
              <span className="font-mono text-[9px] tracking-widest text-amber-300">
                FAST 2D/3D LOTTERY
              </span>
              <span className="font-mono text-[9px] text-zinc-400">{voucherId}</span>
            </div>

            <div className="text-center space-y-1 mb-3">
              <div className="inline-flex items-center justify-center gap-1 px-3 py-0.5 rounded-full bg-amber-400/15 border border-amber-400/40 text-amber-400 text-xs font-black tracking-wider uppercase">
                <Sparkles className="w-3 h-3" />
                FAST 2D3D OFFICIAL
              </div>
              <h2 className="text-lg font-black text-amber-300 tracking-tight">
                {bet.type} LOTTERY RECEIPT
              </h2>
              <p className="text-[11px] text-zinc-400">
                အချိန် - {bet.session} | နေ့စွဲ - {bet.date}
              </p>
            </div>

            {(bet.status === 'win' || bet.status === 'TOOD_WIN') && (
              <div className="mb-3 p-2.5 rounded-xl bg-gradient-to-r from-emerald-950/90 to-emerald-900/60 border border-emerald-500/60 text-emerald-200 text-center space-y-0.5 shadow-md">
                <div className="flex items-center justify-center gap-1.5 text-xs font-black text-emerald-300">
                  <Trophy className="w-4 h-4 text-amber-400" />
                  {bet.status === 'TOOD_WIN'
                    ? 'TOOD ပေါက် / Tood Win'
                    : 'ဂုဏ်ယူပါသည်! ပေါက်ပါသည်'}
                </div>
                <div className="text-sm font-black text-emerald-400">
                  ပေါက်ငွေ: +{(bet.winAmount || 0).toLocaleString()} Ks
                </div>
                <div className="text-[10px] text-emerald-300/80">
                  Tood: ×{multiplier}
                  {bet.winningNumber ? ` | ပေါက်ဂဏန်း: ${bet.winningNumber}` : ''}
                </div>
              </div>
            )}

            <div className="grid grid-cols-2 gap-2 p-2.5 rounded-xl bg-black/60 border border-zinc-800 text-[11px] mb-3">
              <div>
                <span className="text-zinc-500 block text-[10px]">ဘောက်ချာနံပါတ်</span>
                <span className="font-mono font-bold text-amber-300">{voucherId}</span>
              </div>
              <div>
                <span className="text-zinc-500 block text-[10px]">အသုံးပြုသူ</span>
                <span className="font-medium text-zinc-200">{user.phone}</span>
              </div>
              <div>
                <span className="text-zinc-500 block text-[10px]">ကစားနည်း</span>
                <span className="font-bold text-amber-400">
                  {bet.type} ({bet.session})
                </span>
              </div>
              <div>
                <span className="text-zinc-500 block text-[10px]">အခြေအနေ</span>
                <span className="inline-flex items-center gap-1 font-bold text-emerald-400">
                  <CheckCircle2 className="w-3 h-3" />
                  {bet.status === 'TOOD_WIN'
                    ? 'TOOD ပေါက်ပြီး'
                    : bet.status === 'win'
                    ? 'ပေါက်ပြီး'
                    : 'ထိုးပြီးပါပြီ'}
                </span>
              </div>
            </div>

            <div className="space-y-1.5 mb-3">
              <div className="flex items-center justify-between text-[10px] font-bold text-zinc-400 px-1 border-b border-zinc-800 pb-1">
                <span>ဂဏန်း / အမျိုးအစား</span>
                <span>ကွက်ရေ / ထိုးကြေး</span>
              </div>

              <div className="space-y-1.5 max-h-56 overflow-y-auto pr-0.5">
                {bet.items && bet.items.length > 0 ? (
                  bet.items.map((item, idx) => (
                    <div
                      key={`${item.number}-${idx}`}
                      className="flex items-center justify-between p-2 rounded-lg bg-zinc-900/80 border border-zinc-800/80 text-xs"
                    >
                      <div className="flex items-start gap-2">
                        <span className="text-[10px] text-zinc-500 font-mono mt-0.5">
                          {idx + 1}.
                        </span>
                        <div>
                          <div className="font-black text-amber-300 text-sm tracking-wide">
                            {item.number}
                          </div>
                          {item.label && (
                            <div className="text-[10px] text-zinc-400 leading-tight">
                              {item.label}
                            </div>
                          )}
                        </div>
                      </div>

                      <div className="text-right">
                        <div className="font-extrabold text-zinc-100">
                          {item.amount.toLocaleString()}{' '}
                          <span className="text-[10px] text-zinc-400 font-normal">Ks</span>
                        </div>
                        {item.subCount && item.subCount > 1 && item.perItemAmount && (
                          <div className="text-[9px] text-amber-400/80">
                            (၁ ကွက် {item.perItemAmount.toLocaleString()} Ks)
                          </div>
                        )}
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="p-2 bg-zinc-900/60 rounded-lg text-xs font-mono text-amber-300">
                    {bet.numbers.join(', ')}
                  </div>
                )}
              </div>
            </div>

            <div className="relative my-3">
              <div className="border-t border-dashed border-zinc-600/70" />
            </div>

            <div className="space-y-1.5 bg-amber-950/20 border border-amber-500/30 rounded-xl p-2.5 text-xs">
              <div className="flex items-center justify-between text-zinc-300">
                <span>စုစုပေါင်း ကွက်ရေ</span>
                <span className="font-bold text-zinc-100">{totalSubCount} ကွက်</span>
              </div>

              <div className="flex items-center justify-between text-zinc-300">
                <span>အလျော်ဆ</span>
                <span className="font-bold text-amber-400">{multiplier} ဆ</span>
              </div>

              <div className="flex items-center justify-between pt-1 border-t border-amber-500/20 text-sm font-black">
                <span className="text-amber-300">စုစုပေါင်း ထိုးငွေ</span>
                <span className="text-amber-400 font-mono text-base">
                  {bet.amount.toLocaleString()} Ks
                </span>
              </div>
            </div>

            <div className="mt-3 pt-2 text-center border-t border-dashed border-zinc-800">
              <p className="text-[9px] text-zinc-500 font-mono tracking-wider">
                AUTHENTICATED DIGITAL BETTING TICKET • THANK YOU & GOOD LUCK
              </p>
            </div>
          </div>

          {saveSuccess && (
            <div className="p-2.5 rounded-xl bg-emerald-950 border border-emerald-500/50 text-emerald-300 text-xs font-bold text-center flex items-center justify-center gap-1.5 animate-in fade-in">
              <Check className="w-4 h-4" />
              ပြေစာပုံကို စက်ထဲသို့ သိမ်းဆည်းပြီးပါပြီ! (Saved PNG)
            </div>
          )}

          {copied && (
            <div className="p-2 rounded-xl bg-amber-950 border border-amber-500/50 text-amber-300 text-xs font-bold text-center flex items-center justify-center gap-1.5 animate-in fade-in">
              <Check className="w-3.5 h-3.5" />
              ပြေစာစာသား ကူးယူပြီးပါပြီ!
            </div>
          )}

          {errorMessage && (
            <div className="p-2 rounded-xl bg-red-950 border border-red-500/50 text-red-300 text-xs text-center">
              {errorMessage}
            </div>
          )}
        </div>

        <div className="p-3 bg-[#111113] border-t border-zinc-800/80 space-y-2">
          <button
            type="button"
            onClick={handleSaveToDevice}
            disabled={isGenerating}
            id="save-to-device-btn"
            className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-amber-400 via-amber-300 to-amber-400 text-black font-extrabold text-sm shadow-lg shadow-amber-400/20 hover:brightness-105 active:scale-[0.98] transition flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
          >
            <Download className="w-4 h-4 stroke-[2.5]" />
            <span>
              {isGenerating ? 'ပုံထုတ်ယူနေပါသည်...' : 'Save to Device (ပြေစာပုံ သိမ်းမည်)'}
            </span>
          </button>

          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={handleCopyText}
              className="py-2.5 px-3 rounded-xl bg-zinc-900 border border-zinc-700/80 text-zinc-200 text-xs font-bold hover:bg-zinc-800 active:scale-95 transition flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Copy className="w-3.5 h-3.5 text-amber-400" />
              <span>စာသား ကူးမည်</span>
            </button>

            <button
              type="button"
              onClick={handleShare}
              className="py-2.5 px-3 rounded-xl bg-zinc-900 border border-zinc-700/80 text-zinc-200 text-xs font-bold hover:bg-zinc-800 active:scale-95 transition flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Share2 className="w-3.5 h-3.5 text-amber-400" />
              <span>မျှဝေမည်</span>
            </button>
          </div>

          {onContinueBetting && (
            <button
              type="button"
              onClick={() => {
                onClose();
                onContinueBetting();
              }}
              className="w-full py-2 text-center text-xs font-bold text-amber-400 hover:text-amber-300 transition cursor-pointer flex items-center justify-center gap-1 pt-1"
            >
              <span>ဆက်လက်ထိုးမည်</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>
    </div>
    </ModalPortal>
  );
};
