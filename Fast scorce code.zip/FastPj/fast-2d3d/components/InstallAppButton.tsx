'use client';

import React, { useState } from 'react';
import { Download, X } from 'lucide-react';
import { usePWAInstall } from '@/hooks/use-pwa-install';

export const InstallAppButton: React.FC = () => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showHelp, setShowHelp] = useState(false);

  if (isInstalled) return null;

  const handleClick = async () => {
    if (isInstallable) {
      const ok = await install();
      if (ok) return;
    }
    setShowHelp(true);
  };

  return (
    <>
      <button
        type="button"
        onClick={handleClick}
        className="fixed bottom-20 right-4 z-40 flex items-center gap-1.5 px-3.5 py-2.5 rounded-full bg-gradient-to-r from-amber-400 to-yellow-500 text-black text-xs font-extrabold shadow-[0_6px_20px_rgba(245,158,11,0.45)] hover:brightness-105 active:scale-95 transition"
        aria-label="Install App"
        id="install-app-btn"
      >
        <Download className="w-4 h-4" />
        <span>Install App</span>
      </button>

      {showHelp && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/80 backdrop-blur-sm p-4">
          <div className="w-full max-w-sm rounded-3xl bg-[#14120c] border border-amber-500/40 p-5 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-amber-500/20">
              <h3 className="text-sm font-bold text-amber-300">App ကို Install လုပ်ရန်</h3>
              <button
                onClick={() => setShowHelp(false)}
                className="p-1 rounded-full text-zinc-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="pt-3 text-xs text-zinc-300 leading-relaxed space-y-2">
              {isIOS ? (
                <>
                  <p>1. Safari ရဲ့ အောက်ခြေ Share (□↑) ခလုတ်ကို နှိပ်ပါ။</p>
                  <p>2. “Add to Home Screen” ကို ရွေးပါ။</p>
                  <p>3. “Add” ကို နှိပ်လိုက်ပါ။</p>
                </>
              ) : (
                <>
                  <p>1. Browser ရဲ့ menu (⋮) ကို နှိပ်ပါ။</p>
                  <p>2. “Install app” သို့မဟုတ် “Add to Home screen” ကို ရွေးပါ။</p>
                  <p>3. အတည်ပြုလိုက်ပါ။</p>
                </>
              )}
            </div>
            <button
              type="button"
              onClick={() => setShowHelp(false)}
              className="mt-4 w-full py-2.5 rounded-xl bg-[#FFCC00] text-black text-xs font-bold hover:bg-amber-400 transition"
            >
              နားလည်ပါပြီ
            </button>
          </div>
        </div>
      )}
    </>
  );
};
