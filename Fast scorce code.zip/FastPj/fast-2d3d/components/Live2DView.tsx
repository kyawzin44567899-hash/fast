'use client';

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Undo2, RefreshCw, History, Radio, Calendar } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import {
  get2DLive,
  get2DResult,
  getShwelaminTwod,
  getSetLiveModernInternet,
  type TwodHistoryDay,
  type SetLiveData,
} from '@/lib/lotteryApi';

function getMyanmarToday(): string {
  return new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Yangon' }).format(new Date());
}

function isTodayDate(dateStr?: string | null): boolean {
  if (!dateStr) return false;
  return String(dateStr).slice(0, 10) === getMyanmarToday();
}

interface Live2DViewProps {
  onBack: () => void;
}

interface LiveSessionItem {
  set: string;
  value: string;
  open_time: string;
  twod: string;
  stock_date?: string;
}

interface ShwelaminHistoryItem {
  date: string;
  time1201: string;
  time430: string;
  result1201: string;
  result430: string;
  set1201: string;
  val1201: string;
  set430: string;
  val430: string;
}

interface CalendarCell {
  day: number;
  date: string;
  r1201?: string;
  r430?: string;
}

export const Live2DView: React.FC<Live2DViewProps> = ({ onBack }) => {

  const [liveTwod, setLiveTwod] = useState<string>('--');
  const [liveSet, setLiveSet] = useState<string>('--');
  const [liveValue, setLiveValue] = useState<string>('--');
  const [serverTime, setServerTime] = useState<string>('');
  const [sessions, setSessions] = useState<LiveSessionItem[]>([
    { open_time: '12:01:00', set: '--', value: '--', twod: '--' },
    { open_time: '16:30:00', set: '--', value: '--', twod: '--' },
  ]);

  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [numberHasChanged, setNumberHasChanged] = useState<boolean>(false);
  const [showHistoryModal, setShowHistoryModal] = useState<boolean>(false);
  const [historyItems, setHistoryItems] = useState<ShwelaminHistoryItem[]>([]);
  const [historyLoading, setHistoryLoading] = useState<boolean>(false);
  const [setlive, setSetlive] = useState<SetLiveData | null>(null);

  const [showCalendarModal, setShowCalendarModal] = useState<boolean>(false);
  const [calendarDays, setCalendarDays] = useState<TwodHistoryDay[]>([]);
  const [calendarLoading, setCalendarLoading] = useState<boolean>(false);
  const [calendarMonth, setCalendarMonth] = useState<{ year: number; month: number }>(() => {
    const now = new Date();
    return { year: now.getFullYear(), month: now.getMonth() };
  });
  const [selectedDate, setSelectedDate] = useState<string>('');

  const prevNumberRef = useRef<string>('--');
  const setliveBusyRef = useRef(false);

  const formatTimeHeader = (openTime: string): string => {
    if (!openTime || openTime === '--') return '--';
    const parts = openTime.split(':');
    if (parts.length >= 2) {
      let hour = parseInt(parts[0], 10);
      const minute = parts[1];
      const ampm = hour >= 12 ? 'PM' : 'AM';
      hour = hour % 12 || 12;
      return `${String(hour).padStart(2, '0')}:${minute} ${ampm}`;
    }
    return openTime;
  };

  const fetchLive = useCallback(async (showSpinner = false) => {
    if (showSpinner) setIsLoading(true);
    try {
      const data = await get2DLive();
      const liveDate = data?.live?.date;
      const liveIsToday = isTodayDate(liveDate);

      if (data?.live && liveIsToday) {
        const newTwod = String(data.live.twod || '--');
        if (newTwod !== prevNumberRef.current) {
          setNumberHasChanged(true);
          setTimeout(() => setNumberHasChanged(false), 800);
          prevNumberRef.current = newTwod;
        }
        setLiveTwod(newTwod);
        setLiveSet(data.live.set || '--');
        setLiveValue(data.live.value || '--');
      } else {
        setLiveTwod('--');
        setLiveSet('--');
        setLiveValue('--');
      }

      if (data?.server_time) {
        setServerTime(data.server_time);
      } else if (data?.live?.time && data?.live?.date) {
        setServerTime(`${data.live.date} ${data.live.time}`);
      }

      if (Array.isArray(data?.result)) {
        const findToday = (prefix: string) =>
          data.result.find(
            (s) =>
              isTodayDate(s.stock_date || liveDate) &&
              (s.open_time || '').trim().startsWith(prefix)
          );
        const item1201 = findToday('12:01');
        const item1630 = findToday('16:30') || findToday('04:30');
        const merged: LiveSessionItem[] = [
          {
            open_time: '12:01:00',
            set: item1201?.set || '--',
            value: item1201?.value || '--',
            twod: item1201?.twod && item1201.twod !== '--' ? item1201.twod : '--',
          },
          {
            open_time: '16:30:00',
            set: item1630?.set || '--',
            value: item1630?.value || '--',
            twod: item1630?.twod && item1630.twod !== '--' ? item1630.twod : '--',
          },
        ];
        setSessions(merged);
      }
    } finally {
      if (showSpinner) setIsLoading(false);
    }
  }, []);

  const fetchSetlive = useCallback(async () => {
    if (setliveBusyRef.current) return;
    setliveBusyRef.current = true;
    try {
      const data = await getSetLiveModernInternet();
      if (data) setSetlive(data);
    } finally {
      setliveBusyRef.current = false;
    }
  }, []);

  const fetchHistory = useCallback(async () => {
    setHistoryLoading(true);
    try {
      const data = await getShwelaminTwod();
      const list = Array.isArray(data?.data) ? data.data : [];
      setHistoryItems(
        list.map((item) => ({
          date: item.date || '',
          time1201: item.time_1200 || '',
          time430: item.time_430 || '',
          result1201: item.result_1200 || '--',
          result430: item.result_430 || '--',
          set1201: item.set_1200 || '',
          val1201: item.val_1200 || '',
          set430: item.set_430 || '',
          val430: item.val_430 || '',
        }))
      );
    } finally {
      setHistoryLoading(false);
    }
  }, []);

  const fetchCalendar = useCallback(async () => {
    setCalendarLoading(true);
    try {
      const data = await get2DResult();
      const list = Array.isArray(data) ? data : [];
      setCalendarDays(list);
      const available = new Set(list.map((d) => d.date));
      const today = getMyanmarToday();
      const pickDate = available.has(today) ? today : list[0]?.date;
      if (pickDate) {
        const [y, m] = pickDate.split('-').map(Number);
        if (y && m) setCalendarMonth({ year: y, month: m - 1 });
        setSelectedDate(pickDate);
      }
    } finally {
      setCalendarLoading(false);
    }
  }, []);

  useEffect(() => {

    const runInitialFetch = async () => {
      await fetchLive(false);
    };
    runInitialFetch();

    const interval = setInterval(() => {
      fetchLive(false);
    }, 3500);

    return () => clearInterval(interval);
  }, [fetchLive]);

  useEffect(() => {
    const initial = setTimeout(() => {
      void fetchSetlive();
    }, 0);
    const interval = setInterval(() => {
      if (typeof document !== 'undefined' && document.hidden) return;
      void fetchSetlive();
    }, 1000);
    return () => {
      clearTimeout(initial);
      clearInterval(interval);
    };
  }, [fetchSetlive]);

  const handleOpenHistory = () => {
    setShowHistoryModal(true);
    fetchHistory();
  };

  const handleOpenCalendar = () => {
    setShowCalendarModal(true);
    if (calendarDays.length === 0) void fetchCalendar();
  };

  const calendarMap: Record<string, { r1201?: string; r430?: string }> = {};
  for (const day of calendarDays) {
    const entry: { r1201?: string; r430?: string } = {};
    for (const c of day.child || []) {
      if (c.time?.startsWith('12:01')) entry.r1201 = c.twod;
      if (c.time?.startsWith('16:30') || c.time?.startsWith('04:30')) entry.r430 = c.twod;
    }
    if (day.date) calendarMap[day.date] = entry;
  }

  const calendarCells: CalendarCell[] = (() => {
    const { year, month } = calendarMonth;
    const startDow = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const cells: CalendarCell[] = [];
    for (let i = 0; i < startDow; i++) cells.push({ day: 0, date: '' });
    for (let d = 1; d <= daysInMonth; d++) {
      const date = `${year}-${String(month + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
      const e = calendarMap[date];
      cells.push({ day: d, date, r1201: e?.r1201, r430: e?.r430 });
    }
    return cells;
  })();

  const monthLabel = new Date(calendarMonth.year, calendarMonth.month, 1).toLocaleString('en-US', {
    month: 'long',
    year: 'numeric',
  });

  const selectedEntry = selectedDate ? calendarMap[selectedDate] : undefined;

  const shiftMonth = (delta: number) => {
    setCalendarMonth((prev) => {
      const d = new Date(prev.year, prev.month + delta, 1);
      return { year: d.getFullYear(), month: d.getMonth() };
    });
  };

  return (
    <div className="min-h-screen bg-[#000000] text-white select-none pb-24" id="live-2d-screen">
      <div className="sticky top-0 z-30 flex items-center justify-between px-4 py-3.5 bg-black/95 backdrop-blur-md border-b border-amber-500/20">
        <button
          type="button"
          onClick={onBack}
          className="p-1 -ml-1 text-[#f5bd29] hover:text-amber-300 active:scale-90 transition cursor-pointer"
          id="live-2d-back-btn"
          aria-label="Back"
        >
          <Undo2 className="w-7 h-7 stroke-[2.8]" />
        </button>

        <h1 className="font-bold text-lg text-[#f5bd29] tracking-wide">
          2D Live
        </h1>

        <div className="flex items-center gap-1.5">
          <button
            type="button"
            onClick={handleOpenCalendar}
            className="p-1.5 text-amber-400 hover:text-amber-300 active:scale-95 transition"
            title="ရက်စွဲအလိုက် ပေါက်ဂဏန်း (Calendar)"
            id="live-calendar-btn"
          >
            <Calendar className="w-5 h-5" />
          </button>
          <button
            type="button"
            onClick={handleOpenHistory}
            className="p-1.5 text-amber-400 hover:text-amber-300 active:scale-95 transition"
            title="အချိန်နှင့်အမျှ မှတ်တမ်း"
            id="live-history-btn"
          >
            <History className="w-5 h-5" />
          </button>
          <button
            type="button"
            onClick={() => fetchLive(true)}
            className={`p-1.5 text-amber-400 hover:text-amber-300 active:scale-95 transition ${
              isLoading ? 'animate-spin' : ''
            }`}
            title="Refresh Live Data"
            id="live-refresh-btn"
          >
            <RefreshCw className="w-5 h-5" />
          </button>
        </div>
      </div>

      <div className="p-4 space-y-6 max-w-md mx-auto">
        <div className="flex items-center justify-between px-4 py-2 rounded-xl bg-[#14120b] border border-amber-500/25 text-xs text-amber-200/90 shadow-inner">
          <div className="flex items-center gap-1.5">
            <Radio className="w-3.5 h-3.5 text-red-500 animate-pulse" />
            <span className="font-bold text-amber-400">SET Index:</span>
            <span className="font-mono font-bold text-white">{liveSet}</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="font-bold text-amber-400">Value:</span>
            <span className="font-mono font-bold text-white">{liveValue}</span>
          </div>
        </div>

        <div className="flex flex-col items-center justify-center pt-2 pb-2">
          <motion.div
            animate={{
              y: [-6, 6, -6],
              rotate: [0, 0.4, -0.4, 0],
            }}
            transition={{
              duration: 3.6,
              repeat: Infinity,
              ease: 'easeInOut',
            }}
            className="relative flex items-center justify-center min-h-[140px]"
          >
            <div className="absolute w-48 h-48 rounded-full bg-gradient-to-tr from-amber-500/25 via-yellow-400/20 to-transparent blur-2xl pointer-events-none -z-10 animate-pulse" />

            <AnimatePresence mode="wait">
              <motion.div
                key={liveTwod}
                initial={{ opacity: 0, scale: 0.6, y: -24, filter: 'blur(8px)' }}
                animate={{
                  opacity: 1,
                  scale: 1,
                  y: 0,
                  filter: 'blur(0px)',
                  textShadow: numberHasChanged
                    ? '0 0 45px rgba(255, 220, 50, 0.95), 0 0 85px rgba(245, 189, 41, 0.7)'
                    : '0 6px 28px rgba(245, 189, 41, 0.55)',
                }}
                exit={{
                  opacity: 0,
                  scale: 1.25,
                  y: 24,
                  filter: 'blur(8px)',
                  transition: { duration: 0.25, ease: 'easeIn' },
                }}
                transition={{
                  opacity: { duration: 0.35, ease: 'easeInOut' },
                  scale: { type: 'spring', stiffness: 350, damping: 22 },
                  y: { duration: 0.35, ease: 'easeOut' },
                }}
                className="text-8xl sm:text-9xl font-black text-[#f7c22e] tracking-tight leading-none select-none font-sans"
                id="live-main-number"
              >
                {liveTwod}
              </motion.div>
            </AnimatePresence>

            {numberHasChanged && (
              <motion.div
                initial={{ scale: 0.7, opacity: 0.9 }}
                animate={{ scale: 1.5, opacity: 0 }}
                transition={{ duration: 0.7, ease: 'easeOut' }}
                className="absolute inset-0 rounded-full border-2 border-amber-300 pointer-events-none"
              />
            )}
          </motion.div>

          <div className="mt-4 flex items-center justify-center gap-1.5 text-xs sm:text-sm text-[#f5bd29] font-bold tracking-wide">
            <span>Updated: {serverTime || '--'}</span>
          </div>
        </div>

        <div className="space-y-4 pt-1" id="live-session-cards">
          {sessions.map((session, idx) => {
            const timeLabel = formatTimeHeader(session.open_time);
            const isFinished = session.twod !== '--' && session.twod !== '';

            return (
              <div
                key={idx}
                className="relative overflow-hidden rounded-2xl border-2 border-[#d69f24] bg-gradient-to-b from-[#19150d] via-[#120f09] to-[#0a0907] p-3.5 shadow-[0_4px_16px_rgba(0,0,0,0.7)] space-y-2"
                id={`session-card-${idx}`}
              >
                <div className="text-center border-b border-[#d69f24]/30 pb-2">
                  <h3 className="text-sm font-bold text-[#f5bd29] tracking-wider">
                    {timeLabel}
                  </h3>
                </div>

                <div className="grid grid-cols-3 text-center items-center py-1">
                  <div>
                    <span className="block text-xs font-semibold text-zinc-300">
                      Set
                    </span>
                    <span className="block text-xs sm:text-sm font-bold text-white mt-1 font-mono">
                      {session.set || '--'}
                    </span>
                  </div>

                  <div>
                    <span className="block text-xs font-semibold text-zinc-300">
                      Value
                    </span>
                    <span className="block text-xs sm:text-sm font-bold text-white mt-1 font-mono">
                      {session.value || '--'}
                    </span>
                  </div>

                  <div>
                    <span className="block text-xs font-semibold text-zinc-300">
                      2D
                    </span>
                    <span
                      className={`block text-base sm:text-lg font-black mt-1 font-mono ${
                        isFinished ? 'text-[#f5bd29]' : 'text-zinc-500'
                      }`}
                    >
                      {session.twod || '--'}
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        <div
          className="rounded-2xl border-2 border-[#d69f24] bg-gradient-to-b from-[#19150d] via-[#120f09] to-[#0a0907] p-3.5 shadow-[0_4px_16px_rgba(0,0,0,0.7)] space-y-2"
          id="modern-internet-cards"
        >
          {[
            { label: '9:30 AM', modern: setlive?.modern_930, internet: setlive?.internet_930 },
            { label: '2:00 PM', modern: setlive?.modern_200, internet: setlive?.internet_200 },
          ].map((row) => (
            <div
              key={row.label}
              className="grid grid-cols-[auto_1fr_1fr] items-center gap-2 rounded-xl bg-black/50 border border-[#d69f24]/25 px-3 py-2"
            >
              <span className="text-xs font-bold text-[#f5bd29] w-14">{row.label}</span>
              <div className="text-center">
                <span className="block text-[10px] text-zinc-400">Modern</span>
                <span className="block text-lg font-black text-[#f5bd29] font-mono leading-tight">
                  {row.modern || '--'}
                </span>
              </div>
              <div className="text-center">
                <span className="block text-[10px] text-zinc-400">Internet</span>
                <span className="block text-lg font-black text-[#f5bd29] font-mono leading-tight">
                  {row.internet || '--'}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {showHistoryModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-sm p-4">
          <div className="w-full max-w-md bg-[#13100a] border border-amber-500/40 rounded-3xl max-h-[85vh] flex flex-col shadow-2xl overflow-hidden">
            <div className="flex items-center justify-between px-5 py-4 border-b border-amber-500/25 bg-black/60">
              <div className="flex items-center gap-2">
                <History className="w-5 h-5 text-amber-400" />
                <h3 className="font-bold text-sm sm:text-base text-amber-300">
                  2D History (12:01 PM / 4:30 PM)
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setShowHistoryModal(false)}
                className="w-8 h-8 rounded-full bg-zinc-900 flex items-center justify-center text-zinc-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <div className="p-4 overflow-y-auto space-y-3 flex-1">
              {historyLoading ? (
                <div className="py-12 text-center text-amber-400/70 text-xs flex flex-col items-center gap-2">
                  <RefreshCw className="w-6 h-6 animate-spin text-amber-400" />
                  <span>အချက်အလက်များ ရယူနေပါသည်...</span>
                </div>
              ) : historyItems.length === 0 ? (
                <div className="py-12 text-center text-zinc-500 text-xs">
                  မှတ်တမ်းမရှိသေးပါ
                </div>
              ) : (
                historyItems.map((item, i) => (
                  <div key={`${item.date}-${i}`} className="pb-3 border-b border-amber-400/10 last:border-b-0">
                    <div className="text-[11px] font-bold text-amber-300 mb-1.5">
                      {item.date}
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <div className="rounded-xl bg-black/60 border border-amber-500/20 p-2 text-center">
                        <div className="text-[10px] text-zinc-400">12:01 PM</div>
                        <div className="text-xl font-black text-[#f5bd29] font-mono">
                          {item.result1201 || '--'}
                        </div>
                        <div className="text-[9px] text-zinc-500 font-mono truncate">
                          {item.set1201} | {item.val1201}
                        </div>
                      </div>
                      <div className="rounded-xl bg-black/60 border border-amber-500/20 p-2 text-center">
                        <div className="text-[10px] text-zinc-400">4:30 PM</div>
                        <div className="text-xl font-black text-[#f5bd29] font-mono">
                          {item.result430 || '--'}
                        </div>
                        <div className="text-[9px] text-zinc-500 font-mono truncate">
                          {item.set430} | {item.val430}
                        </div>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {showCalendarModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-sm p-4">
          <div className="w-full max-w-md bg-[#13100a] border border-amber-500/40 rounded-3xl max-h-[88vh] flex flex-col shadow-2xl overflow-hidden">
            <div className="flex items-center justify-between px-5 py-4 border-b border-amber-500/25 bg-black/60">
              <div className="flex items-center gap-2">
                <Calendar className="w-5 h-5 text-amber-400" />
                <h3 className="font-bold text-sm sm:text-base text-amber-300">
                  2D Result Calendar
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setShowCalendarModal(false)}
                className="w-8 h-8 rounded-full bg-zinc-900 flex items-center justify-center text-zinc-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <div className="p-4 overflow-y-auto flex-1 space-y-3">
              {calendarLoading ? (
                <div className="py-12 text-center text-amber-400/70 text-xs flex flex-col items-center gap-2">
                  <RefreshCw className="w-6 h-6 animate-spin text-amber-400" />
                  <span>အချက်အလက်များ ရယူနေပါသည်...</span>
                </div>
              ) : (
                <>
                  <div className="flex items-center justify-between">
                    <button
                      type="button"
                      onClick={() => shiftMonth(-1)}
                      className="w-8 h-8 rounded-lg bg-zinc-900 text-amber-300 hover:bg-zinc-800 active:scale-95"
                    >
                      ‹
                    </button>
                    <span className="text-sm font-bold text-amber-300">{monthLabel}</span>
                    <button
                      type="button"
                      onClick={() => shiftMonth(1)}
                      className="w-8 h-8 rounded-lg bg-zinc-900 text-amber-300 hover:bg-zinc-800 active:scale-95"
                    >
                      ›
                    </button>
                  </div>

                  <div className="grid grid-cols-7 gap-1 text-center text-[10px] text-zinc-500">
                    {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((d) => (
                      <div key={d}>{d}</div>
                    ))}
                  </div>

                  <div className="grid grid-cols-7 gap-1">
                    {calendarCells.map((cell, i) =>
                      cell.day === 0 ? (
                        <div key={`empty-${i}`} />
                      ) : (
                        <button
                          key={cell.date}
                          type="button"
                          onClick={() => setSelectedDate(cell.date)}
                          className={`rounded-lg p-1 border text-center transition ${
                            selectedDate === cell.date
                              ? 'border-amber-400 bg-amber-500/15'
                              : 'border-zinc-800 bg-black/40 hover:border-amber-500/40'
                          }`}
                        >
                          <span className="block text-[10px] font-bold text-zinc-300">
                            {cell.day}
                          </span>
                          <span className="block text-[10px] font-mono text-emerald-300 leading-tight">
                            {cell.r1201 || '--'}
                          </span>
                          <span className="block text-[10px] font-mono text-amber-300 leading-tight">
                            {cell.r430 || '--'}
                          </span>
                        </button>
                      )
                    )}
                  </div>

                  <div className="flex items-center justify-center gap-4 text-[10px] text-zinc-400">
                    <span className="flex items-center gap-1">
                      <span className="text-emerald-300 font-bold">■</span> 12:01 PM
                    </span>
                    <span className="flex items-center gap-1">
                      <span className="text-amber-300 font-bold">■</span> 4:30 PM
                    </span>
                  </div>

                  {selectedDate && (
                    <div className="rounded-2xl bg-black/60 border border-amber-500/25 p-3">
                      <div className="text-[11px] font-bold text-amber-300 mb-2">
                        {selectedDate}
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        <div className="rounded-xl bg-zinc-950 border border-zinc-800 p-2 text-center">
                          <div className="text-[10px] text-zinc-400">12:01 PM</div>
                          <div className="text-xl font-black text-[#f5bd29] font-mono">
                            {selectedEntry?.r1201 || '--'}
                          </div>
                        </div>
                        <div className="rounded-xl bg-zinc-950 border border-zinc-800 p-2 text-center">
                          <div className="text-[10px] text-zinc-400">4:30 PM</div>
                          <div className="text-xl font-black text-[#f5bd29] font-mono">
                            {selectedEntry?.r430 || '--'}
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
