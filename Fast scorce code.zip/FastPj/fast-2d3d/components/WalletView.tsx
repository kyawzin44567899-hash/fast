'use client';

import React, { useState } from 'react';
import {
  ArrowDownToLine,
  ArrowUpFromLine,
  CreditCard,
  PlusCircle,
  MinusCircle,
  X,
} from 'lucide-react';
import { useApp, type Transaction } from '@/context/AppContext';

interface WalletViewProps {
  onGoDeposit: () => void;
  onGoWithdraw: () => void;
}

const DetailRow: React.FC<{ label: string; value: string; mono?: boolean; highlight?: boolean }> = ({
  label,
  value,
  mono,
  highlight,
}) => (
  <div className="flex items-start justify-between gap-3 border-b border-amber-500/10 pb-2">
    <span className="text-[11px] text-zinc-400">{label}</span>
    <span
      className={`text-right text-xs font-semibold break-all ${mono ? 'font-mono' : ''} ${
        highlight ? 'text-amber-300' : 'text-white'
      }`}
    >
      {value}
    </span>
  </div>
);

export const WalletView: React.FC<WalletViewProps> = ({
  onGoDeposit,
  onGoWithdraw,
}) => {
  const { user, transactions } = useApp();
  const [selectedTx, setSelectedTx] = useState<Transaction | null>(null);

  return (
    <div className="space-y-4 px-4 py-3 select-none pb-24" id="wallet-view">
      <div className="relative overflow-hidden rounded-2xl border-2 border-[#d69f24] bg-gradient-to-b from-[#18150f] via-[#12100b] to-[#0a0907] p-5 shadow-[0_4px_16px_rgba(0,0,0,0.6)]">
        <div className="flex items-center gap-4">
          <div className="relative w-16 h-16 rounded-full overflow-hidden bg-gradient-to-tr from-sky-600 to-sky-400 p-0.5 shadow-md flex items-center justify-center shrink-0">
            <div className="w-full h-full rounded-full bg-[#1b3a57] flex items-center justify-center">
              <svg
                className="w-10 h-10 text-sky-200 mt-1.5"
                fill="currentColor"
                viewBox="0 0 24 24"
              >
                <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z" />
              </svg>
            </div>
          </div>

          <div className="space-y-1">
            <h2 className="text-xl font-bold text-amber-400 leading-tight">
              {user.name}
            </h2>
            <p className="text-sm font-semibold text-amber-300/90 tracking-wide">
              {user.phone}
            </p>
          </div>
        </div>

        <div className="h-[1px] bg-amber-400/30 my-4" />

        <div>
          <p className="text-base font-bold text-amber-400">
            လက်ကျန်ငွေ - {user.balance.toLocaleString()} ks
          </p>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3 pt-1">
        <button
          type="button"
          onClick={onGoDeposit}
          className="h-12 rounded-full border-2 border-[#d69f24] bg-black text-amber-400 font-bold text-sm flex items-center justify-center shadow-md hover:bg-amber-500/10 active:scale-95 transition cursor-pointer"
          id="wallet-deposit-btn"
        >
          ငွေသွင်းမည်
        </button>

        <button
          type="button"
          onClick={onGoWithdraw}
          className="h-12 rounded-full border-2 border-[#d69f24] bg-black text-amber-400 font-bold text-sm flex items-center justify-center shadow-md hover:bg-amber-500/10 active:scale-95 transition cursor-pointer"
          id="wallet-withdraw-btn"
        >
          ငွေထုတ်မည်
        </button>
      </div>

      <div className="pt-2">
        <h3 className="text-xs font-semibold text-amber-400/90 tracking-wide">
          ငွေသွင်း/ထုတ် မှတ်တမ်း -
        </h3>
      </div>

      <div className="space-y-3">
        {transactions.map((tx) => {
          const isDeposit = tx.type === 'deposit' || tx.type === 'TOOD_WIN';

          return (
            <div
              key={tx.id}
              role="button"
              tabIndex={0}
              onClick={() => setSelectedTx(tx)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' || e.key === ' ') setSelectedTx(tx);
              }}
              className={`relative overflow-hidden rounded-2xl border-2 p-3.5 shadow-md flex items-center justify-between cursor-pointer active:scale-[0.99] transition ${
                isDeposit
                  ? 'border-emerald-500/60 bg-gradient-to-b from-emerald-950/40 to-[#0a0907]'
                  : 'border-rose-500/60 bg-gradient-to-b from-rose-950/40 to-[#0a0907]'
              }`}
            >
              <div className="flex items-center gap-3">
                <div
                  className={`w-11 h-11 rounded-xl border flex items-center justify-center shrink-0 ${
                    isDeposit
                      ? 'bg-emerald-500/10 border-emerald-400/40'
                      : 'bg-rose-500/10 border-rose-400/40'
                  }`}
                >
                  {isDeposit ? (
                    <ArrowDownToLine className="w-5 h-5 text-emerald-400 stroke-[2.2]" />
                  ) : (
                    <ArrowUpFromLine className="w-5 h-5 text-rose-400 stroke-[2.2]" />
                  )}
                </div>

                <div>
                  <div className="flex items-center gap-1.5">
                    <span
                      className={`text-sm font-black ${
                        isDeposit ? 'text-emerald-400' : 'text-rose-400'
                      }`}
                    >
                      {isDeposit ? `+ ${tx.amount.toLocaleString()} ks` : `- ${tx.amount.toLocaleString()} ks`}
                    </span>
                  </div>
                  <span className="block text-[11px] text-zinc-300 mt-0.5 font-medium">
                    {tx.timestamp}
                  </span>
                </div>
              </div>

              <div className="text-right">
                <span
                  className={`text-sm font-bold tracking-tight ${
                    isDeposit ? 'text-emerald-400' : 'text-rose-400'
                  }`}
                >
                  {tx.type === 'TOOD_WIN' ? 'TOOD ဆုငွေ' : isDeposit ? 'ငွေသွင်း' : 'ငွေထုတ်'}
                </span>
                {tx.method && (
                  <span className="block text-[10px] text-zinc-400">
                    {tx.method}
                  </span>
                )}
                <span
                  className={`inline-block mt-0.5 text-[9px] font-bold uppercase px-1.5 py-0.5 rounded ${
                    tx.status === 'pending'
                      ? 'bg-amber-500/20 text-amber-300'
                      : tx.status === 'approved'
                      ? 'bg-emerald-500/20 text-emerald-300'
                      : tx.status === 'rejected'
                      ? 'bg-rose-500/20 text-rose-300'
                      : 'bg-zinc-800 text-zinc-400'
                  }`}
                >
                  {tx.status}
                </span>
              </div>
            </div>
          );
        })}

        {transactions.length === 0 && (
          <div className="py-8 text-center text-xs text-zinc-500">
            မှတ်တမ်း မရှိသေးပါ
          </div>
        )}
      </div>

      {selectedTx && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-sm p-4">
          <div className="w-full max-w-md bg-[#13100a] border-2 border-[#d69f24] rounded-3xl max-h-[85vh] flex flex-col shadow-2xl overflow-hidden">
            <div className="flex items-center justify-between px-5 py-4 border-b border-amber-500/25 bg-black/60">
              <h3 className="font-bold text-sm text-amber-300">
                {selectedTx.type === 'TOOD_WIN'
                  ? 'TOOD ဆုငွေ အသေးစိတ်'
                  : selectedTx.type === 'deposit'
                  ? 'ငွေသွင်း အသေးစိတ်'
                  : 'ငွေထုတ် အသေးစိတ်'}
              </h3>
              <button
                type="button"
                onClick={() => setSelectedTx(null)}
                className="w-8 h-8 rounded-full bg-zinc-900 flex items-center justify-center text-zinc-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-5 overflow-y-auto space-y-3 text-sm">
              <DetailRow label="Order Number" value={selectedTx.orderNumber || '-'} mono highlight />
              <DetailRow
                label="Type"
                value={
                  selectedTx.type === 'TOOD_WIN'
                    ? 'TOOD ဆုငွေ'
                    : selectedTx.type === 'deposit'
                    ? 'ငွေသွင်း'
                    : 'ငွေထုတ်'
                }
              />
              <DetailRow label="Amount" value={`${selectedTx.amount.toLocaleString()} ks`} mono />
              <DetailRow label="Method" value={selectedTx.method || '-'} />
              <DetailRow
                label="Reference No"
                value={selectedTx.transactionNumber || '-'}
                mono
              />
              <DetailRow label="Date" value={selectedTx.timestamp} />
              <DetailRow label="Status" value={selectedTx.status} />
              {selectedTx.slipImage && (
                <div>
                  <span className="block text-[11px] text-zinc-400 mb-1">Slip</span>
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={selectedTx.slipImage}
                    alt="slip"
                    className="w-full rounded-xl border border-amber-500/30"
                  />
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
