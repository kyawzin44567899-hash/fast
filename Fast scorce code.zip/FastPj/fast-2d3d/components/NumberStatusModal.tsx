'use client';

import React, { useState, useEffect } from 'react';
import { X, Search, Ban, AlertCircle, Check } from 'lucide-react';
import { ModalPortal } from './ModalPortal';

interface NumberStatusModalProps {
  isOpen: boolean;
  type: '2D' | '3D';
  onClose: () => void;
}

interface NumberStatus {
  number: string;
  maxBetCount: number;
  currentBetCount: number;
  isBlocked: boolean;
}

export const NumberStatusModal: React.FC<NumberStatusModalProps> = ({ isOpen, type, onClose }) => {
  const width = type === '2D' ? 2 : 3;
  const total = type === '2D' ? 100 : 1000;

  const [statuses, setStatuses] = useState<NumberStatus[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [filter, setFilter] = useState<string>('all');

  useEffect(() => {
    if (!isOpen) return;
    let isMounted = true;
    const timer = setTimeout(async () => {
      setFilter(type === '2D' ? 'all' : '000-099');
      setSearchQuery('');
      setIsLoading(true);
      try {
        const res = await fetch(`/api/number-limits?type=${type}`, { cache: 'no-store' });
        const json = await res.json();
        if (isMounted && json.success && Array.isArray(json.data)) {
          setStatuses(json.data as NumberStatus[]);
        }
      } catch {

      } finally {
        if (isMounted) setIsLoading(false);
      }
    }, 0);
    return () => {
      isMounted = false;
      clearTimeout(timer);
    };
  }, [isOpen, type]);

  if (!isOpen) return null;

  const totalBlocked = statuses.filter((s) => s.isBlocked).length;
  const totalFull = statuses.filter((s) => !s.isBlocked && s.currentBetCount >= s.maxBetCount).length;
  const totalOpen = statuses.length - totalBlocked - totalFull;

  const filterTabs =
    type === '2D'
      ? [
          { id: 'all', label: 'All' },
          { id: '00-19', label: '00-19' },
          { id: '20-39', label: '20-39' },
          { id: '40-59', label: '40-59' },
          { id: '60-79', label: '60-79' },
          { id: '80-99', label: '80-99' },
        ]
      : [
          { id: 'all', label: 'All' },
          { id: '000-099', label: '000-099' },
          { id: '100-199', label: '100-199' },
          { id: '200-299', label: '200-299' },
          { id: '300-399', label: '300-399' },
          { id: '400-499', label: '400-499' },
          { id: '500-599', label: '500-599' },
          { id: '600-699', label: '600-699' },
          { id: '700-799', label: '700-799' },
          { id: '800-899', label: '800-899' },
          { id: '900-999', label: '900-999' },
        ];

  const filtered = statuses.filter((s) => {
    if (searchQuery.trim()) return s.number.includes(searchQuery.trim());
    if (filter === 'all') return true;
    const [start, end] = filter.split('-').map(Number);
    const n = parseInt(s.number, 10);
    return n >= start && n <= end;
  });

  return (
    <ModalPortal>
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-sm p-3">
      <div className="w-full max-w-md rounded-3xl bg-[#141414] border border-amber-500/40 shadow-2xl flex flex-col max-h-[88dvh] overflow-hidden">
        <div className="flex items-center justify-between px-4 py-3 border-b border-zinc-800 bg-black/50">
          <div>
            <h3 className="font-bold text-amber-400 text-sm">
              {type} ဂဏန်းအခြေအနေ (Full / Blocked Numbers)
            </h3>
            <p className="text-[10px] text-zinc-400 mt-0.5">
              {type === '2D' ? '00 မှ 99' : '000 မှ 999'} • စုစုပေါင်း {total} ကွက်
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-zinc-400 hover:text-white rounded-lg hover:bg-zinc-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex items-center justify-between px-4 py-2 text-[11px] border-b border-zinc-800 bg-black/30">
          <div className="flex items-center gap-1.5 text-zinc-400">
            <span className="w-2 h-2 rounded-full bg-emerald-400" />
            <span>ဖွင့်: <strong className="text-white">{totalOpen}</strong></span>
          </div>
          <div className="flex items-center gap-1.5 text-zinc-400">
            <span className="w-2 h-2 rounded-full bg-amber-400" />
            <span>အကြိမ်ပြည့်: <strong className="text-amber-300">{totalFull}</strong></span>
          </div>
          <div className="flex items-center gap-1.5 text-zinc-400">
            <span className="w-2 h-2 rounded-full bg-red-500" />
            <span>ပိတ်: <strong className="text-red-400">{totalBlocked}</strong></span>
          </div>
        </div>

        <div className="px-4 py-2 border-b border-zinc-800">
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-zinc-500 absolute left-2.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value.replace(/\D/g, '').slice(0, width))}
              placeholder={type === '2D' ? 'ဂဏန်းရှာပါ (00-99)...' : 'ဂဏန်းရှာပါ (000-999)...'}
              className="w-full h-8 pl-8 pr-2.5 rounded-lg bg-zinc-900 border border-zinc-800 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-[#FFCC00]"
            />
          </div>
        </div>

        <div className="flex gap-1 px-4 py-2 overflow-x-auto pretty-scrollbar border-b border-zinc-800">
          {filterTabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => {
                setFilter(tab.id);
                setSearchQuery('');
              }}
              className={`px-2.5 py-1 rounded-md text-[11px] font-semibold whitespace-nowrap transition ${
                filter === tab.id && !searchQuery
                  ? 'bg-[#FFCC00] text-black font-bold'
                  : 'bg-zinc-900 text-zinc-400 hover:text-white border border-zinc-800'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <div className="flex-1 overflow-y-auto pretty-scrollbar px-3 py-3">
          {isLoading ? (
            <div className="py-10 text-center text-xs text-zinc-500">ဂဏန်းအခြေအနေ ရယူနေပါသည်...</div>
          ) : filtered.length === 0 ? (
            <div className="py-10 text-center text-xs text-zinc-500">ဂဏန်း ရှာမတွေ့ပါ</div>
          ) : (
            <div className="grid grid-cols-5 gap-2">
              {filtered.map((s) => {
                const isFull = !s.isBlocked && s.currentBetCount >= s.maxBetCount;
                const pct = Math.min(100, Math.round((s.currentBetCount / s.maxBetCount) * 100));
                return (
                  <div
                    key={s.number}
                    className={`rounded-xl border p-1.5 flex flex-col items-center ${
                      s.isBlocked
                        ? 'bg-red-950/60 border-red-800/80'
                        : isFull
                        ? 'bg-amber-950/40 border-amber-600/60'
                        : 'bg-black border-zinc-800'
                    }`}
                  >
                    <div className="flex items-center gap-1">
                      {s.isBlocked ? (
                        <Ban className="w-3 h-3 text-red-400" />
                      ) : isFull ? (
                        <AlertCircle className="w-3 h-3 text-amber-300" />
                      ) : (
                        <Check className="w-3 h-3 text-emerald-400" />
                      )}
                      <span
                        className={`font-black text-sm ${
                          s.isBlocked ? 'text-red-400' : isFull ? 'text-amber-300' : 'text-[#FFCC00]'
                        }`}
                      >
                        {s.number}
                      </span>
                    </div>

                    <span className="text-[9px] text-zinc-400 leading-none mt-0.5">
                      {s.currentBetCount}/{s.maxBetCount}
                    </span>

                    <div className="w-full bg-zinc-800 rounded-full h-1 mt-1 overflow-hidden">
                      <div
                        className={`h-full rounded-full ${
                          s.isBlocked ? 'bg-red-500' : isFull ? 'bg-amber-400' : 'bg-emerald-400'
                        }`}
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        <div className="px-4 py-2 border-t border-zinc-800 bg-black/40 flex items-center justify-center gap-4 text-[10px] text-zinc-400">
          <span className="flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-emerald-400" /> ဖွင့်
          </span>
          <span className="flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-amber-400" /> အကြိမ်ပြည့်
          </span>
          <span className="flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-red-500" /> ပိတ်
          </span>
        </div>
      </div>
    </div>
    </ModalPortal>
  );
};
