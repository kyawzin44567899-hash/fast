'use client';

import React, { useState, useCallback } from 'react';
import { useApp, BetRecord } from '@/context/AppContext';
import { ChevronRight, Clock, ReceiptText } from 'lucide-react';
import { ReceiptModal } from './ReceiptModal';
import { PullToRefresh } from './PullToRefresh';

export const BetHistoryView: React.FC = () => {
  const { user, bets, refreshUserData } = useApp();
  const [filter, setFilter] = useState<'all' | '2D' | '3D'>('all');
  const [selectedReceiptBet, setSelectedReceiptBet] = useState<BetRecord | null>(null);
  const [isReceiptOpen, setIsReceiptOpen] = useState(false);

  const filteredBets = bets.filter((bet) => {
    if (filter === 'all') return true;
    return bet.type === filter;
  });

  const handleOpenSlip = (bet: BetRecord) => {
    setSelectedReceiptBet(bet);
    setIsReceiptOpen(true);
  };

  const handleRefreshBets = useCallback(async () => {
    if (user.uid) {
      try {
        await refreshUserData();
      } catch (err) {
        console.error('Refresh bets error:', err);
      }
    }
  }, [user.uid, refreshUserData]);

  const getBetNumbers = (bet: BetRecord): string => {
    const set = new Set<string>();
    if (bet.items && bet.items.length > 0) {
      for (const it of bet.items) {
        if (it.subNumbers && it.subNumbers.length > 0) {
          for (const s of it.subNumbers) set.add(s.number);
        } else if (it.number) {
          set.add(it.number);
        }
      }
    } else if (bet.numbers && bet.numbers.length > 0) {
      for (const n of bet.numbers) set.add(n);
    }
    return Array.from(set).join(', ');
  };

  return (
    <PullToRefresh onRefresh={handleRefreshBets} id="bet-history-pull-to-refresh">
      <div className="space-y-3 px-4 py-3 select-none pb-24" id="bet-history-view">
        <div className="flex items-center justify-between pb-1">
          <div className="flex items-center gap-2">
            {(['all', '2D', '3D'] as const).map((type) => (
              <button
                key={type}
                type="button"
                onClick={() => setFilter(type)}
                className={`px-4 py-1.5 rounded-full text-xs font-bold transition cursor-pointer ${
                  filter === type
                    ? 'bg-amber-400 text-black shadow-md'
                    : 'bg-zinc-900 border border-zinc-800 text-zinc-400 hover:text-amber-300'
                }`}
              >
                {type === 'all' ? 'အားလုံး' : type}
              </button>
            ))}
          </div>

          <div className="text-[11px] text-zinc-400 flex items-center gap-1 font-medium">
            <ReceiptText className="w-3.5 h-3.5 text-amber-400" />
            <span>စုစုပေါင်း ({filteredBets.length}) စောင်</span>
          </div>
        </div>

        <div className="space-y-2">
          {filteredBets.map((bet) => {
            const numbers = getBetNumbers(bet);
            return (
              <div
                key={bet.id}
                onClick={() => handleOpenSlip(bet)}
                id={`history-bet-item-${bet.id}`}
                className="group relative p-3.5 rounded-xl border border-zinc-800/90 bg-gradient-to-r from-zinc-950 via-[#14120e] to-zinc-950 hover:border-amber-500/60 hover:bg-[#1a1710] active:scale-[0.99] transition shadow-sm cursor-pointer"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="w-2 h-2 rounded-full bg-amber-400 group-hover:scale-125 transition-transform" />
                    <span className="text-sm sm:text-base font-extrabold text-amber-400 tracking-tight">
                      {bet.type} - {bet.amount.toLocaleString()} ks
                    </span>
                    {bet.status === 'TOOD_WIN' && (
                      <span className="text-[10px] font-black text-emerald-400 bg-emerald-500/10 border border-emerald-500/40 px-2 py-0.5 rounded-full">
                        TOOD ပေါက်
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-2 text-right">
                    <span className="text-xs text-zinc-400 font-medium group-hover:text-zinc-200 transition">
                      {bet.date}
                    </span>
                    <ChevronRight className="w-4 h-4 text-zinc-600 group-hover:text-amber-400 group-hover:translate-x-0.5 transition" />
                  </div>
                </div>

                {numbers && (
                  <div className="mt-1.5 pl-5 text-[11px] font-mono text-amber-200/90 break-words leading-relaxed">
                    {numbers}
                  </div>
                )}
              </div>
            );
          })}

          {filteredBets.length === 0 && (
            <div className="py-16 text-center text-xs text-zinc-500 space-y-2">
              <Clock className="w-6 h-6 mx-auto text-zinc-600" />
              <p>ထိုးမှတ်တမ်း မရှိသေးပါ</p>
            </div>
          )}
        </div>

        <ReceiptModal
          bet={selectedReceiptBet}
          isOpen={isReceiptOpen}
          onClose={() => setIsReceiptOpen(false)}
        />
      </div>
    </PullToRefresh>
  );
};
