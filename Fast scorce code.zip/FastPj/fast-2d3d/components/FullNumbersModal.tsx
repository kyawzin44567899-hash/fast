'use client';

import React, { useState } from 'react';
import { X } from 'lucide-react';
import { BetItem, createPresetBetItem, PRESETS_2D, PRESETS_3D } from '@/lib/betParser';
import { ModalPortal } from './ModalPortal';

interface FullNumbersModalProps {
  isOpen: boolean;
  type: '2D' | '3D';
  amount: number;
  onClose: () => void;
  onSelectPreset: (item: BetItem) => void;
  onSelectNumbers?: (numbers: string[]) => void;
}

export const FullNumbersModal: React.FC<FullNumbersModalProps> = ({
  isOpen,
  type,
  amount,
  onClose,
  onSelectPreset,
}) => {
  const [tab, setTab] = useState<'head' | 'tail' | 'break' | 'all'>('head');

  if (!isOpen) return null;

  const handleSelect = (category: string, digit: number) => {
    let name = '';
    let selected: string[] = [];

    if (category === 'head') {
      name = `${digit} ထိပ်`;
      selected = PRESETS_2D.head(digit);
    } else if (category === 'tail') {
      name = `${digit} နောက်`;
      selected = PRESETS_2D.tail(digit);
    } else if (category === 'break') {
      name = `${digit} ဘရိတ်`;
      selected = PRESETS_2D.break(digit);
    }

    const item = createPresetBetItem(name, selected, amount);
    onSelectPreset(item);
    onClose();
  };

  const handleSelectAll = () => {
    if (type === '2D') {
      const all = PRESETS_2D.all();
      const item = createPresetBetItem('ပြည့်ဂဏန်း (00-99)', all, amount);
      onSelectPreset(item);
    } else {
      const all = PRESETS_3D.triples();
      const item = createPresetBetItem('3D အပူး (000-999)', all, amount);
      onSelectPreset(item);
    }
    onClose();
  };

  const per10 = Math.floor(amount / 10);
  const per100 = Math.floor(amount / 100);

  return (
    <ModalPortal>
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
      <div className="w-full max-w-sm max-h-[88dvh] overflow-y-auto pretty-scrollbar rounded-2xl bg-[#141414] border border-amber-500/40 p-4 text-white shadow-2xl animate-in fade-in zoom-in-95">
        <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
          <div>
            <h3 className="font-bold text-amber-400 text-sm">ပြည့်ဂဏန်း ရွေးချယ်ရန်</h3>
            <p className="text-[11px] text-zinc-400 mt-0.5">
              စုစုပေါင်း ထိုးငွေ: <strong className="text-amber-300">{amount.toLocaleString()} ks</strong>
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-zinc-400 hover:text-white rounded-lg hover:bg-zinc-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex items-center gap-1 my-3 bg-zinc-900 p-1 rounded-xl">
          <button
            type="button"
            onClick={() => setTab('head')}
            className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition ${
              tab === 'head' ? 'bg-amber-400 text-black' : 'text-zinc-400'
            }`}
          >
            ထိပ်
          </button>
          <button
            type="button"
            onClick={() => setTab('tail')}
            className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition ${
              tab === 'tail' ? 'bg-amber-400 text-black' : 'text-zinc-400'
            }`}
          >
            နောက်
          </button>
          <button
            type="button"
            onClick={() => setTab('break')}
            className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition ${
              tab === 'break' ? 'bg-amber-400 text-black' : 'text-zinc-400'
            }`}
          >
            ဘရိတ်
          </button>
        </div>

        <div className="text-[11px] text-amber-300/90 mb-2 text-center">
          {tab === 'head' && `ထိပ်ဂဏန်းတစ်ခုစီတွင် ၁၀ ကွက်ပါဝင်သည် (၁ ကွက် ${per10.toLocaleString()} ကျပ်)`}
          {tab === 'tail' && `နောက်ဂဏန်းတစ်ခုစီတွင် ၁၀ ကွက်ပါဝင်သည် (၁ ကွက် ${per10.toLocaleString()} ကျပ်)`}
          {tab === 'break' && `ဘရိတ်တစ်ခုစီတွင် ၁၀ ကွက်ပါဝင်သည် (၁ ကွက် ${per10.toLocaleString()} ကျပ်)`}
        </div>

        <div className="grid grid-cols-5 gap-2 my-2">
          {Array.from({ length: 10 }, (_, i) => i).map((d) => (
            <button
              key={d}
              type="button"
              onClick={() => handleSelect(tab, d)}
              className="h-11 rounded-xl bg-zinc-900 border border-amber-500/30 font-black text-base text-amber-300 hover:bg-amber-400 hover:text-black active:scale-95 transition flex flex-col items-center justify-center"
            >
              <span>{d}</span>
            </button>
          ))}
        </div>

        <div className="mt-3 pt-3 border-t border-zinc-800 space-y-1">
          <button
            type="button"
            onClick={handleSelectAll}
            className="w-full py-2.5 rounded-xl bg-zinc-900 border border-amber-500/40 text-amber-400 font-extrabold text-xs hover:bg-amber-500/20 active:scale-95 transition flex flex-col items-center justify-center gap-0.5"
          >
            <span>{type === '2D' ? '00 မှ 99 အကုန်ထိုးမည် (၁၀၀ ကွက်)' : '000 မှ 999 အပူးအားလုံး (၁၀ ကွက်)'}</span>
            <span className="text-[10px] text-zinc-400 font-normal">
              {type === '2D' ? `၁ ကွက် ${per100.toLocaleString()} ကျပ်` : `၁ ကွက် ${per10.toLocaleString()} ကျပ်`}
            </span>
          </button>
        </div>
      </div>
    </div>
    </ModalPortal>
  );
};
