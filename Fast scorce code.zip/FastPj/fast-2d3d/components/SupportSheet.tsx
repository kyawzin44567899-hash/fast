'use client';

import React from 'react';
import { X, Headphones, Send, Smartphone } from 'lucide-react';

interface SupportLinks {
  telegram: string;
  viber: string;
}

interface SupportSheetProps {
  isOpen: boolean;
  links: SupportLinks;
  onClose: () => void;
}

function normalizeTelegram(value: string): string {
  const v = value.trim();
  if (!v) return '';
  if (/^https?:\/\//i.test(v)) return v;
  return `https://t.me/${v.replace(/^@/, '')}`;
}

function normalizeViber(value: string): string {
  const v = value.trim();
  if (!v) return '';
  if (/^viber:/i.test(v)) {
    return v.replace(/(number=)([^&]*)/i, (_, prefix: string, num: string) => {
      let decoded = num;
      try {
        decoded = decodeURIComponent(num);
      } catch {}
      if (!decoded) return prefix + num;
      const withPlus = decoded.startsWith('+') ? decoded : `+${decoded}`;
      return prefix + encodeURIComponent(withPlus);
    });
  }
  if (/^https?:\/\//i.test(v)) return v;
  const digits = v.replace(/[^\d+]/g, '');
  if (!digits) return 'https://www.viber.com/';
  const withPlus = digits.startsWith('+') ? digits : `+${digits}`;
  return `viber://chat?number=${encodeURIComponent(withPlus)}`;
}

export const SupportSheet: React.FC<SupportSheetProps> = ({ isOpen, links, onClose }) => {
  if (!isOpen) return null;

  const open = (url: string) => {
    if (!url) return;
    window.open(url, '_blank', 'noopener,noreferrer');
    onClose();
  };

  const openViber = (url: string) => {
    if (!url) return;
    onClose();
    if (/^viber:/i.test(url)) {
      const isIOS = /iPhone|iPad|iPod/i.test(navigator.userAgent);
      const store = isIOS
        ? 'https://apps.apple.com/app/viber-messenger/id382617920'
        : 'https://play.google.com/store/apps/details?id=com.viber.voip';
      const started = Date.now();
      window.location.href = url;
      setTimeout(() => {
        if (!document.hidden && Date.now() - started < 2500) {
          window.location.href = store;
        }
      }, 1500);
    } else {
      window.open(url, '_blank', 'noopener,noreferrer');
    }
  };

  const telegram = normalizeTelegram(links.telegram);
  const viber = normalizeViber(links.viber);

  return (
    <div className="fixed inset-0 z-[60] flex items-end sm:items-center justify-center bg-black/80 backdrop-blur-sm p-4 select-none">
      <div className="w-full max-w-sm rounded-3xl bg-[#11100c] border border-amber-500/40 shadow-2xl overflow-hidden">
        <div className="flex items-center justify-between px-5 py-4 border-b border-amber-500/20 bg-black/60">
          <div className="flex items-center gap-2">
            <Headphones className="w-5 h-5 text-amber-400" />
            <h3 className="font-bold text-base text-amber-400">Customer Support</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-zinc-400 hover:text-white bg-zinc-900"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-4 space-y-3">
          {telegram ? (
            <button
              type="button"
              onClick={() => open(telegram)}
              className="w-full flex items-center gap-3 p-3.5 rounded-2xl bg-sky-950/40 border border-sky-500/40 hover:border-sky-400 transition text-left active:scale-[0.98]"
            >
              <span className="w-10 h-10 rounded-full bg-sky-500/20 text-sky-300 flex items-center justify-center shrink-0">
                <Send className="w-5 h-5" />
              </span>
              <span className="flex-1 min-w-0">
                <span className="block text-sm font-bold text-white">Telegram</span>
                <span className="block text-[11px] text-sky-300/80 truncate">{links.telegram}</span>
              </span>
            </button>
          ) : null}

          {viber ? (
            <button
              type="button"
              onClick={() => openViber(viber)}
              className="w-full flex items-center gap-3 p-3.5 rounded-2xl bg-purple-950/40 border border-purple-500/40 hover:border-purple-400 transition text-left active:scale-[0.98]"
            >
              <span className="w-10 h-10 rounded-full bg-purple-500/20 text-purple-300 flex items-center justify-center shrink-0">
                <Smartphone className="w-5 h-5" />
              </span>
              <span className="flex-1 min-w-0">
                <span className="block text-sm font-bold text-white">Viber</span>
                <span className="block text-[11px] text-purple-300/80 truncate">{links.viber}</span>
              </span>
            </button>
          ) : null}

          {!telegram && !viber && (
            <div className="py-8 text-center text-sm text-zinc-500">
              Support link မရှိသေးပါ
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
