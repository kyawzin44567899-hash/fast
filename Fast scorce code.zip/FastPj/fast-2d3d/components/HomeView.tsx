'use client';

import React, { useState, useEffect, useCallback } from 'react';
import {
  Wallet,
  Megaphone,
  Radio,
  Coins,
  ChevronRight,
  Sparkles,
  RefreshCw,
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useApp } from '@/context/AppContext';
import { useAds } from '@/hooks/use-ads';
import { get2DLive, get3DHistory } from '@/lib/lotteryApi';
import { PullToRefresh } from './PullToRefresh';
import { InstallAppButton } from './InstallAppButton';

interface HomeViewProps {
  onOpen2DBet: () => void;
  onOpen3DBet: () => void;
  onOpenLive2D: () => void;
  onOpenResultsHistory: () => void;
}

export const HomeView: React.FC<HomeViewProps> = ({
  onOpen2DBet,
  onOpen3DBet,
  onOpenLive2D,
  onOpenResultsHistory,
}) => {
  const { user, setActiveTab, refreshUserData } = useApp();
  const ads = useAds();
  const [bannerIndex, setBannerIndex] = useState(0);
  const [isRefreshing, setIsRefreshing] = useState(false);

  useEffect(() => {
    if (ads.banners.length <= 1) return;
    const timer = setInterval(() => {
      setBannerIndex((i) => (i + 1) % ads.banners.length);
    }, 5000);
    return () => clearInterval(timer);
  }, [ads.banners.length]);

  const currentBanner = ads.banners.length > 0 ? ads.banners[bannerIndex % ads.banners.length] : null;

  const [latest2D, setLatest2D] = useState<{ number: string; date: string; time: string }>({
    number: '--',
    date: '--',
    time: '--',
  });

  const [latest3D, setLatest3D] = useState<{ number: string; date: string; time: string }>({
    number: '--',
    date: '--',
    time: '--',
  });

  const fetchLatestHomeData = useCallback(async () => {
    try {
      const [data2D, data3D] = await Promise.all([
        get2DLive().catch(() => null),
        get3DHistory().catch(() => null),
        refreshUserData().catch(() => null),
      ]);

      if (data2D?.live) {
        const isAllowed2DSession = (tStr: string) => {
          if (!tStr) return false;
          const t = tStr.trim().toLowerCase();
          if (t.includes('11:00') || t.includes('15:00') || t.includes('03:00') || t.startsWith('11:') || t.startsWith('15:')) return false;
          return t.includes('12:01') || t.includes('16:30') || t.includes('4:30') || t.includes('04:30');
        };

        const completedResults = data2D.result?.filter((r) => r.twod && r.twod !== '--' && isAllowed2DSession(r.open_time));
        if (completedResults && completedResults.length > 0) {
          const lastSession = completedResults[completedResults.length - 1];
          setLatest2D({
            number: lastSession.twod,
            date: lastSession.stock_date || data2D.live.date || '--',
            time: lastSession.open_time || '--',
          });
        } else if (data2D.live.twod) {
          setLatest2D({
            number: data2D.live.twod,
            date: data2D.live.date || '--',
            time: data2D.live.time || '--',
          });
        }
      }

      if (data3D?.data && Array.isArray(data3D.data) && data3D.data.length > 0) {
        const item = data3D.data[0];
        setLatest3D({
          number: item.result,
          date: item.datetime || '--',
          time: '03:30 PM',
        });
      }
    } catch (err) {
      console.error('Fetch home data error:', err);
    }
  }, [refreshUserData]);

  useEffect(() => {
    let isMounted = true;
    const load = async () => {
      await fetchLatestHomeData();
    };
    load();
    return () => {
      isMounted = false;
    };
  }, [fetchLatestHomeData]);

  const handleRefresh = useCallback(async () => {
    if (isRefreshing) return;
    setIsRefreshing(true);
    try {
      await Promise.all([fetchLatestHomeData(), ads.refresh()]);
    } finally {
      setIsRefreshing(false);
    }
  }, [isRefreshing, fetchLatestHomeData, ads]);

  return (
    <PullToRefresh onRefresh={fetchLatestHomeData} id="home-pull-to-refresh">
      <div className="space-y-4 px-4 py-3 select-none pb-24" id="home-view">
      <div
        className="relative overflow-hidden rounded-2xl border border-[#d69f24] bg-gradient-to-b from-[#18150f] via-[#12100b] to-[#0c0a07] p-3.5 shadow-[0_4px_16px_rgba(0,0,0,0.6)]"
        id="user-balance-card"
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={() => setActiveTab('profile')}
              className="relative w-12 h-12 rounded-full overflow-hidden bg-gradient-to-tr from-sky-600 to-sky-400 p-0.5 shadow-md flex items-center justify-center hover:scale-105 active:scale-95 transition cursor-pointer"
              title="အကောင့်ကြည့်ရှုရန်"
            >
              <div className="w-full h-full rounded-full bg-[#1b3a57] flex items-center justify-center">
                <svg
                  className="w-8 h-8 text-sky-200 mt-1"
                  fill="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z" />
                </svg>
              </div>
            </button>

            <div className="flex items-center gap-2.5">
              <button
                type="button"
                onClick={() => setActiveTab('profile')}
                className="border-r border-amber-400/30 pr-3 text-left hover:opacity-85 transition cursor-pointer"
              >
                <h2 className="text-amber-400 font-bold text-sm leading-tight">
                  {user.name}
                </h2>
                <span className="text-[10px] text-amber-300/70 font-medium">အကောင့် &gt;</span>
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('wallet')}
                className="text-left hover:opacity-85 transition cursor-pointer"
              >
                <p className="text-[#f1f1f1] font-semibold text-xs tracking-tight">
                  လက်ကျန်ငွေ: <span className="text-amber-300 font-bold">{user.balance.toLocaleString()} ks</span>
                </p>
              </button>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleRefresh}
              disabled={isRefreshing}
              className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-400/30 text-amber-400 flex items-center justify-center shadow-inner hover:bg-amber-500/20 active:scale-95 transition cursor-pointer disabled:opacity-60"
              id="home-refresh-btn"
              title="အသစ်ပြန်ရယူရန်"
            >
              <RefreshCw className={`w-6 h-6 stroke-[2.2] ${isRefreshing ? 'animate-spin' : ''}`} />
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('wallet')}
              className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-400/30 text-amber-400 flex items-center justify-center shadow-inner hover:bg-amber-500/20 active:scale-95 transition cursor-pointer"
              id="user-wallet-btn"
              title="ပိုက်ဆံအိတ်"
            >
              <Wallet className="w-6 h-6 stroke-[2.2]" />
            </button>
          </div>
        </div>
      </div>

      {ads.notice1 && (
        <div className="flex items-center gap-2 px-3 py-2 rounded-xl bg-[#14120c] border border-amber-500/20 text-xs text-amber-200 overflow-hidden">
          <Megaphone className="w-4 h-4 text-amber-400 shrink-0 animate-bounce" />
          <div className="overflow-hidden whitespace-nowrap w-full relative">
            <div className="inline-block animate-[marquee_18s_linear_infinite] hover:[animation-play-state:paused]">
              <span className="font-semibold text-amber-300">{ads.notice1}</span>
            </div>
          </div>
        </div>
      )}

      {currentBanner ? (
        <div className="relative" id="ads-banner">
          <a
            href={currentBanner.link || undefined}
            target={currentBanner.link ? '_blank' : undefined}
            rel="noopener noreferrer"
            className="block relative overflow-hidden rounded-2xl border border-zinc-800 hover:border-amber-500/40 transition group"
          >
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={currentBanner.imageUrl}
              alt={currentBanner.title}
              className="w-full aspect-video object-cover"
            />
            {currentBanner.title && (
              <div className="absolute bottom-0 inset-x-0 bg-black/60 backdrop-blur-sm px-3 py-1.5 text-xs text-amber-200 font-semibold">
                {currentBanner.title}
              </div>
            )}
          </a>

          {ads.banners.length > 1 && (
            <div className="absolute bottom-2 right-2 flex items-center gap-1.5">
              {ads.banners.map((banner, idx) => (
                <button
                  key={banner.id}
                  type="button"
                  onClick={() => setBannerIndex(idx)}
                  aria-label={`Banner ${idx + 1}`}
                  className={`w-1.5 h-1.5 rounded-full transition ${
                    idx === bannerIndex % ads.banners.length ? 'bg-amber-400 w-3' : 'bg-white/40'
                  }`}
                />
              ))}
            </div>
          )}
        </div>
      ) : (
        <div
          className="relative overflow-hidden rounded-2xl bg-[#141414] border border-zinc-800 aspect-video flex flex-col items-center justify-center text-center shadow-inner"
          id="ads-banner"
        >
          <div className="absolute inset-0 bg-gradient-to-r from-amber-500/5 via-transparent to-amber-500/5 pointer-events-none" />
          <span className="text-zinc-500 text-lg font-medium tracking-wide">Ads</span>
          <span className="text-[11px] text-zinc-600 mt-1 flex items-center gap-1">
            <Sparkles className="w-3 h-3 text-amber-400" />
            ကြော်ငြာ မရှိသေးပါ
          </span>
        </div>
      )}

      <div className="space-y-2">
        <button
          type="button"
          onClick={onOpenResultsHistory}
          className="w-full flex items-center justify-center gap-1 text-xs text-amber-300 font-semibold hover:text-amber-200 transition py-1"
          id="view-results-btn"
        >
          <span>ပေါက်စဉ်များ ကြည့်ရန်နှိပ်ပါ &gt;&gt;</span>
        </button>

        <div className="grid grid-cols-2 gap-3">
          <div
            onClick={onOpenLive2D}
            className="cursor-pointer rounded-2xl border border-[#d69f24] bg-gradient-to-b from-[#19150e] to-[#0c0a07] p-3 text-center flex flex-col items-center justify-center shadow-md hover:border-amber-300 transition"
            id="result-box-2d"
          >
            <motion.div
              animate={{
                y: [-2, 2, -2],
              }}
              transition={{
                duration: 2.8,
                repeat: Infinity,
                ease: 'easeInOut',
              }}
              className="relative flex items-center justify-center min-h-[40px]"
            >
              <AnimatePresence mode="wait">
                <motion.div
                  key={latest2D.number}
                  initial={{ opacity: 0, scale: 0.7, y: -6, filter: 'blur(4px)' }}
                  animate={{ opacity: 1, scale: 1, y: 0, filter: 'blur(0px)' }}
                  exit={{ opacity: 0, scale: 1.2, y: 6, filter: 'blur(4px)' }}
                  transition={{ duration: 0.3 }}
                  className="text-3xl font-black text-amber-400 tracking-tight drop-shadow-[0_2px_8px_rgba(245,158,11,0.5)] font-mono"
                >
                  {latest2D.number}
                </motion.div>
              </AnimatePresence>
            </motion.div>
            <div className="text-[11px] text-zinc-300 font-medium mt-1 truncate max-w-full">
              {latest2D.date}
            </div>
            <div className="text-[10px] text-zinc-400">
              {latest2D.time}
            </div>
          </div>

          <div
            onClick={onOpenResultsHistory}
            className="cursor-pointer rounded-2xl border border-[#d69f24] bg-gradient-to-b from-[#19150e] to-[#0c0a07] p-3 text-center flex flex-col items-center justify-center shadow-md hover:border-amber-300 transition"
            id="result-box-3d"
          >
            <motion.div
              animate={{
                y: [-2, 2, -2],
              }}
              transition={{
                duration: 3.2,
                repeat: Infinity,
                ease: 'easeInOut',
              }}
              className="relative flex items-center justify-center min-h-[40px]"
            >
              <AnimatePresence mode="wait">
                <motion.div
                  key={latest3D.number}
                  initial={{ opacity: 0, scale: 0.7, y: -6, filter: 'blur(4px)' }}
                  animate={{ opacity: 1, scale: 1, y: 0, filter: 'blur(0px)' }}
                  exit={{ opacity: 0, scale: 1.2, y: 6, filter: 'blur(4px)' }}
                  transition={{ duration: 0.3 }}
                  className="text-3xl font-black text-amber-400 tracking-tight drop-shadow-[0_2px_8px_rgba(245,158,11,0.5)] font-mono"
                >
                  {latest3D.number}
                </motion.div>
              </AnimatePresence>
            </motion.div>
            <div className="text-[11px] text-zinc-300 font-medium mt-1 truncate max-w-full">
              {latest3D.date}
            </div>
            <div className="text-[10px] text-zinc-400">
              {latest3D.time}
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3 pt-1">
        <button
          type="button"
          onClick={onOpen2DBet}
          className="relative overflow-hidden rounded-2xl border-2 border-[#d69f24] bg-gradient-to-b from-[#1a160e] via-[#120f09] to-[#0b0a07] p-4 flex items-center justify-between shadow-lg hover:brightness-110 active:scale-95 transition text-left cursor-pointer group"
          id="btn-bet-2d"
        >
          <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-amber-600 via-yellow-400 to-amber-200 p-0.5 shadow-md flex items-center justify-center shrink-0">
            <div className="w-full h-full rounded-full bg-black/80 flex items-center justify-center">
              <Coins className="w-6 h-6 text-amber-400" />
            </div>
          </div>

          <div className="text-right">
            <span className="block text-2xl font-black text-amber-400 leading-none">
              2D
            </span>
            <span className="block text-xs font-semibold text-zinc-200 mt-1">
              ထိုးမည်
            </span>
          </div>
        </button>

        <button
          type="button"
          onClick={onOpen3DBet}
          className="relative overflow-hidden rounded-2xl border-2 border-[#d69f24] bg-gradient-to-b from-[#1a160e] via-[#120f09] to-[#0b0a07] p-4 flex items-center justify-between shadow-lg hover:brightness-110 active:scale-95 transition text-left cursor-pointer group"
          id="btn-bet-3d"
        >
          <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-amber-600 via-yellow-400 to-amber-200 p-0.5 shadow-md flex items-center justify-center shrink-0">
            <div className="w-full h-full rounded-full bg-black/80 flex items-center justify-center">
              <Coins className="w-6 h-6 text-amber-400" />
            </div>
          </div>

          <div className="text-right">
            <span className="block text-2xl font-black text-amber-400 leading-none">
              3D
            </span>
            <span className="block text-xs font-semibold text-zinc-200 mt-1">
              ထိုးမည်
            </span>
          </div>
        </button>

        <button
          type="button"
          onClick={onOpenLive2D}
          className="relative overflow-hidden rounded-2xl border-2 border-[#d69f24] bg-gradient-to-b from-[#1a160e] via-[#120f09] to-[#0b0a07] p-4 flex items-center justify-between shadow-lg hover:brightness-110 active:scale-95 transition text-left cursor-pointer group"
          id="btn-2d-live"
        >
          <div className="w-12 h-12 rounded-full bg-amber-500/15 border border-amber-400/40 flex items-center justify-center shrink-0">
            <div className="relative">
              <Radio className="w-6 h-6 text-amber-400 animate-pulse" />
              <span className="absolute -top-1 -right-1 w-2 h-2 bg-red-500 rounded-full animate-ping" />
            </div>
          </div>

          <div className="text-right">
            <span className="block text-2xl font-black text-amber-400 leading-none">
              2D
            </span>
            <span className="block text-xs font-semibold text-zinc-200 mt-1 uppercase tracking-wider">
              LIVE
            </span>
          </div>
        </button>
      </div>
      <InstallAppButton />
    </div>
    </PullToRefresh>
  );
};
