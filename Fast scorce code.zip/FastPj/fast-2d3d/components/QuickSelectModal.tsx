'use client';

import React from 'react';
import { X } from 'lucide-react';
import { BetItem, createPresetBetItem, PRESETS_2D, PRESETS_3D } from '@/lib/betParser';
import { ModalPortal } from './ModalPortal';

interface QuickSelectModalProps {
  isOpen: boolean;
  type: '2D' | '3D';
  amount: number;
  onClose: () => void;
  onSelectPreset: (item: BetItem) => void;
  onSelectNumbers?: (numbers: string[]) => void;
}

export const QuickSelectModal: React.FC<QuickSelectModalProps> = ({
  isOpen,
  type,
  amount,
  onClose,
  onSelectPreset,
}) => {
  if (!isOpen) return null;

  const handle2DPreset = (name: string, numbers: string[]) => {
    const item = createPresetBetItem(name, numbers, amount);
    onSelectPreset(item);
    onClose();
  };

  const handle3DPreset = (name: string, numbers: string[]) => {
    const item = createPresetBetItem(name, numbers, amount);
    onSelectPreset(item);
    onClose();
  };

  const getPerItemText = (count: number) => {
    if (amount < 100) return 'ပမာဏ ထည့်ပါ';
    const per = Math.floor(amount / count);
    return `၁ ကွက် ${per.toLocaleString()} ကျပ်`;
  };

  return (
    <ModalPortal>
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-3 sm:p-4">
      <div className="w-full max-w-sm max-h-[88dvh] rounded-2xl bg-[#141414] border border-amber-500/40 p-4 text-white shadow-2xl animate-in fade-in zoom-in-95 flex flex-col overflow-hidden">
        <div className="flex items-center justify-between pb-3 border-b border-zinc-800 shrink-0">
          <div>
            <h3 className="font-bold text-amber-400 text-sm">
              {type === '2D' ? '2D အမြန်ရွေးချယ်ရန်' : '3D အမြန်ရွေးချယ်ရန်'}
            </h3>
            <p className="text-[11px] text-zinc-400 mt-0.5">
              စုစုပေါင်း ထိုးငွေ: <strong className="text-amber-300">{amount.toLocaleString()} ks</strong>
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-zinc-400 hover:text-white rounded-lg hover:bg-zinc-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="grid grid-cols-2 gap-2.5 py-4 flex-1 min-h-0 overflow-y-auto pretty-scrollbar">
          {type === '2D' ? (
            <>
              <button
                type="button"
                onClick={() => handle2DPreset('အပူး', PRESETS_2D.doubles())}
                className="p-2.5 rounded-xl bg-zinc-900 border border-amber-500/30 text-amber-300 font-semibold text-xs hover:bg-amber-500/20 active:scale-95 transition flex flex-col items-center justify-center text-center gap-1 cursor-pointer"
              >
                <span>အပူး (၁၀ ကွက်)</span>
                <span className="text-[10px] text-zinc-300 font-mono line-clamp-1">
                  {PRESETS_2D.doubles().join(', ')}
                </span>
                <span className="text-[10px] text-zinc-400 font-normal">
                  {getPerItemText(10)}
                </span>
              </button>

              <button
                type="button"
                onClick={() => handle2DPreset('ပါဝါ', PRESETS_2D.power())}
                className="p-2.5 rounded-xl bg-zinc-900 border border-amber-500/30 text-amber-300 font-semibold text-xs hover:bg-amber-500/20 active:scale-95 transition flex flex-col items-center justify-center text-center gap-1 cursor-pointer"
              >
                <span>ပါဝါ (၁၀ ကွက်)</span>
                <span className="text-[10px] text-zinc-300 font-mono line-clamp-1">
                  {PRESETS_2D.power().join(', ')}
                </span>
                <span className="text-[10px] text-zinc-400 font-normal">
                  {getPerItemText(10)}
                </span>
              </button>

              <button
                type="button"
                onClick={() => handle2DPreset('နက္ခတ်', PRESETS_2D.natkhat())}
                className="p-2.5 rounded-xl bg-zinc-900 border border-amber-500/30 text-amber-300 font-semibold text-xs hover:bg-amber-500/20 active:scale-95 transition flex flex-col items-center justify-center text-center gap-1 cursor-pointer"
              >
                <span>နက္ခတ် (၁၀ ကွက်)</span>
                <span className="text-[10px] text-zinc-300 font-mono line-clamp-1">
                  {PRESETS_2D.natkhat().join(', ')}
                </span>
                <span className="text-[10px] text-zinc-400 font-normal">
                  {getPerItemText(10)}
                </span>
              </button>

              <button
                type="button"
                onClick={() => handle2DPreset('ညီကို', PRESETS_2D.brothers())}
                className="p-2.5 rounded-xl bg-zinc-900 border border-amber-500/30 text-amber-300 font-semibold text-xs hover:bg-amber-500/20 active:scale-95 transition flex flex-col items-center justify-center text-center gap-1 cursor-pointer"
              >
                <span>ညီကို (၂၀ ကွက်)</span>
                <span className="text-[10px] text-zinc-300 font-mono line-clamp-1">
                  01, 12, 23, 34, 45...
                </span>
                <span className="text-[10px] text-zinc-400 font-normal">
                  {getPerItemText(20)}
                </span>
              </button>

              <button
                type="button"
                onClick={() => handle2DPreset('စုံစုံ', PRESETS_2D.even_even())}
                className="p-2.5 rounded-xl bg-zinc-900 border border-amber-500/30 text-amber-300 font-semibold text-xs hover:bg-amber-500/20 active:scale-95 transition flex flex-col items-center justify-center text-center gap-1 cursor-pointer"
              >
                <span>စုံစုံ (၂၅ ကွက်)</span>
                <span className="text-[10px] text-zinc-300 font-mono line-clamp-1">
                  00, 02, 04, 06, 08...
                </span>
                <span className="text-[10px] text-zinc-400 font-normal">
                  {getPerItemText(25)}
                </span>
              </button>

              <button
                type="button"
                onClick={() => handle2DPreset('မမ', PRESETS_2D.odd_odd())}
                className="p-2.5 rounded-xl bg-zinc-900 border border-amber-500/30 text-amber-300 font-semibold text-xs hover:bg-amber-500/20 active:scale-95 transition flex flex-col items-center justify-center text-center gap-1 cursor-pointer"
              >
                <span>မမ (၂၅ ကွက်)</span>
                <span className="text-[10px] text-zinc-300 font-mono line-clamp-1">
                  11, 13, 15, 17, 19...
                </span>
                <span className="text-[10px] text-zinc-400 font-normal">
                  {getPerItemText(25)}
                </span>
              </button>

              <button
                type="button"
                onClick={() => handle2DPreset('စုံမ', PRESETS_2D.even_odd())}
                className="p-2.5 rounded-xl bg-zinc-900 border border-amber-500/30 text-amber-300 font-semibold text-xs hover:bg-amber-500/20 active:scale-95 transition flex flex-col items-center justify-center text-center gap-1 cursor-pointer"
              >
                <span>စုံမ (၂၅ ကွက်)</span>
                <span className="text-[10px] text-zinc-300 font-mono line-clamp-1">
                  01, 03, 05, 07, 09...
                </span>
                <span className="text-[10px] text-zinc-400 font-normal">
                  {getPerItemText(25)}
                </span>
              </button>

              <button
                type="button"
                onClick={() => handle2DPreset('မစုံ', PRESETS_2D.odd_even())}
                className="p-2.5 rounded-xl bg-zinc-900 border border-amber-500/30 text-amber-300 font-semibold text-xs hover:bg-amber-500/20 active:scale-95 transition flex flex-col items-center justify-center text-center gap-1 cursor-pointer"
              >
                <span>မစုံ (၂၅ ကွက်)</span>
                <span className="text-[10px] text-zinc-300 font-mono line-clamp-1">
                  10, 12, 14, 16, 18...
                </span>
                <span className="text-[10px] text-zinc-400 font-normal">
                  {getPerItemText(25)}
                </span>
              </button>
            </>
          ) : (
            <>
              <button
                type="button"
                onClick={() => handle3DPreset('3D အပူး', PRESETS_3D.triples())}
                className="p-3 rounded-xl bg-zinc-900 border border-amber-500/30 text-amber-300 font-semibold text-xs hover:bg-amber-500/20 active:scale-95 transition flex flex-col items-center justify-center text-center gap-1 cursor-pointer"
              >
                <span>3D အပူး (၁၀ ကွက်)</span>
                <span className="text-[10px] text-zinc-300 font-mono line-clamp-1">
                  {PRESETS_3D.triples().join(', ')}
                </span>
                <span className="text-[10px] text-zinc-400 font-normal">
                  {getPerItemText(10)}
                </span>
              </button>

              <button
                type="button"
                onClick={() => handle3DPreset('ရှေ့ပူး', PRESETS_3D.front_double())}
                className="p-3 rounded-xl bg-zinc-900 border border-amber-500/30 text-amber-300 font-semibold text-xs hover:bg-amber-500/20 active:scale-95 transition flex flex-col items-center justify-center text-center gap-1 cursor-pointer"
              >
                <span>ရှေ့ပူး (၉၀ ကွက်)</span>
                <span className="text-[10px] text-zinc-300 font-mono line-clamp-1">
                  001, 002, 003...
                </span>
                <span className="text-[10px] text-zinc-400 font-normal">
                  {getPerItemText(90)}
                </span>
              </button>

              <button
                type="button"
                onClick={() => handle3DPreset('နောက်ပူး', PRESETS_3D.back_double())}
                className="col-span-2 p-3 rounded-xl bg-zinc-900 border border-amber-500/30 text-amber-300 font-semibold text-xs hover:bg-amber-500/20 active:scale-95 transition flex flex-col items-center justify-center text-center gap-1 cursor-pointer"
              >
                <span>နောက်ပူး (၉၀ ကွက်)</span>
                <span className="text-[10px] text-zinc-300 font-mono line-clamp-1">
                  100, 200, 300...
                </span>
                <span className="text-[10px] text-zinc-400 font-normal">
                  {getPerItemText(90)}
                </span>
              </button>
            </>
          )}
        </div>

        <button
          type="button"
          onClick={onClose}
          className="w-full mt-2 py-2 rounded-xl bg-zinc-900 text-zinc-300 text-xs font-bold hover:bg-zinc-800 transition shrink-0"
        >
          ပိတ်မည်
        </button>
      </div>
    </div>
    </ModalPortal>
  );
};
