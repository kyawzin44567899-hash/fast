'use client';

import React, { useState } from 'react';
import { X, Check } from 'lucide-react';
import { BetItem, createPresetBetItem } from '@/lib/betParser';
import { ModalPortal } from './ModalPortal';

interface KhwayModalProps {
  isOpen: boolean;
  type: '2D' | '3D';
  amount: number;
  onClose: () => void;
  onSelectPreset: (item: BetItem) => void;
  onGenerate?: (numbers: string[]) => void;
}

export const KhwayModal: React.FC<KhwayModalProps> = ({
  isOpen,
  type,
  amount,
  onClose,
  onSelectPreset,
}) => {
  const [selectedDigits, setSelectedDigits] = useState<string[]>([]);
  const [includeDoubles, setIncludeDoubles] = useState<boolean>(false);

  if (!isOpen) return null;

  const toggleDigit = (d: string) => {
    if (selectedDigits.includes(d)) {
      setSelectedDigits(selectedDigits.filter((x) => x !== d));
    } else {
      if (type === '2D' && selectedDigits.length >= 8) return;
      if (type === '3D' && selectedDigits.length >= 7) return;
      setSelectedDigits([...selectedDigits, d]);
    }
  };

  const getGenerated = (): string[] => {
    if (type === '2D') {
      if (selectedDigits.length < 2) return [];
      const res: string[] = [];
      for (let i = 0; i < selectedDigits.length; i++) {
        for (let j = 0; j < selectedDigits.length; j++) {
          if (i === j && !includeDoubles) continue;
          res.push(`${selectedDigits[i]}${selectedDigits[j]}`);
        }
      }
      return res;
    } else {
      if (selectedDigits.length < 3) return [];
      const res: string[] = [];
      for (let i = 0; i < selectedDigits.length; i++) {
        for (let j = 0; j < selectedDigits.length; j++) {
          for (let k = 0; k < selectedDigits.length; k++) {
            if (!includeDoubles && (i === j || j === k || i === k)) continue;
            res.push(`${selectedDigits[i]}${selectedDigits[j]}${selectedDigits[k]}`);
          }
        }
      }
      return res;
    }
  };

  const previewNumbers = getGenerated();
  const perItem = previewNumbers.length > 0 ? Math.floor(amount / previewNumbers.length) : 0;

  const handleConfirm = () => {
    if (previewNumbers.length === 0) return;
    const sortedDigits = [...selectedDigits].sort().join('');
    const name = `${sortedDigits} ခွေ`;
    const item = createPresetBetItem(name, previewNumbers, amount);
    onSelectPreset(item);
    onClose();
  };

  return (
    <ModalPortal>
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
      <div className="w-full max-w-sm max-h-[88dvh] overflow-y-auto pretty-scrollbar rounded-2xl bg-[#141414] border border-amber-500/40 p-4 text-white shadow-2xl animate-in fade-in zoom-in-95">
        <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
          <div>
            <h3 className="font-bold text-amber-400 text-sm">
              {type === '2D' ? '2D ဂဏန်းခွေမည်' : '3D ဂဏန်းခွေမည်'}
            </h3>
            <p className="text-[11px] text-zinc-400 mt-0.5">
              စုစုပေါင်း ထိုးငွေ: <strong className="text-amber-300">{amount.toLocaleString()} ks</strong>
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-zinc-400 hover:text-white rounded-lg hover:bg-zinc-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <p className="text-xs text-zinc-400 my-2">
          ခွေလိုသော ဂဏန်းများကို ရွေးချယ်ပါ (အနည်းဆုံး {type === '2D' ? '၂' : '၃'} လုံး)
        </p>

        <div className="grid grid-cols-5 gap-2 my-3">
          {Array.from({ length: 10 }, (_, i) => String(i)).map((d) => {
            const isSel = selectedDigits.includes(d);
            return (
              <button
                key={d}
                type="button"
                onClick={() => toggleDigit(d)}
                className={`h-11 rounded-xl text-base font-bold transition flex items-center justify-center ${
                  isSel
                    ? 'bg-amber-400 text-black shadow-md'
                    : 'bg-zinc-900 text-zinc-300 border border-zinc-700 hover:border-amber-400'
                }`}
              >
                {d}
              </button>
            );
          })}
        </div>

        <label className="flex items-center gap-2 text-xs text-zinc-300 my-3 cursor-pointer select-none">
          <input
            type="checkbox"
            checked={includeDoubles}
            onChange={(e) => setIncludeDoubles(e.target.checked)}
            className="w-4 h-4 rounded accent-amber-400"
          />
          <span>အပူးပါ ထည့်သွင်းမည် (ဥပမာ 11, 22)</span>
        </label>

        {previewNumbers.length > 0 && (
          <div className="p-2.5 rounded-xl bg-amber-950/40 border border-amber-500/30 text-xs text-amber-300 flex items-center justify-between mb-3">
            <span>
              ခွေဂဏန်း: <strong>{previewNumbers.length}</strong> ကွက်
            </span>
            <span>
              ၁ ကွက်: <strong>{perItem.toLocaleString()}</strong> ကျပ်
            </span>
          </div>
        )}

        <div className="flex items-center gap-2 pt-2 border-t border-zinc-800">
          <button
            type="button"
            onClick={() => setSelectedDigits([])}
            className="flex-1 py-2.5 rounded-xl bg-zinc-900 border border-zinc-800 text-xs font-bold text-zinc-400 hover:text-white transition"
          >
            ပြန်ရွေးမည်
          </button>
          <button
            type="button"
            disabled={previewNumbers.length === 0}
            onClick={handleConfirm}
            className="flex-1 py-2.5 rounded-xl bg-amber-400 text-black text-xs font-extrabold hover:bg-amber-300 transition disabled:opacity-40 disabled:cursor-not-allowed flex items-center justify-center gap-1"
          >
            <Check className="w-4 h-4" />
            <span>အတည်ပြုမည်</span>
          </button>
        </div>
      </div>
    </div>
    </ModalPortal>
  );
};
