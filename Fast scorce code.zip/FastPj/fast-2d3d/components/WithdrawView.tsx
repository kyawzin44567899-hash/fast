'use client';

import React, { useState, useEffect } from 'react';
import {
  ArrowLeft,
  Wallet,
  CheckCircle2,
} from 'lucide-react';
import { useApp } from '@/context/AppContext';
import { getCachedAppSettings, fetchAppSettings } from '@/lib/appSettings';

interface WithdrawViewProps {
  onBack: () => void;
}

interface PaymentOption {
  id: string;
  name: string;
  logoUrl?: string;
  active?: boolean;
}

export const WithdrawView: React.FC<WithdrawViewProps> = ({ onBack }) => {
  const { user, withdraw } = useApp();

  const [amount, setAmount] = useState('1000');
  const [selectedMethod, setSelectedMethod] = useState('');
  const [payments, setPayments] = useState<PaymentOption[]>([]);
  const [accountName, setAccountName] = useState(user.name);
  const [accountNumber, setAccountNumber] = useState(user.phone);
  const [isSuccess, setIsSuccess] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  useEffect(() => {
    const apply = (list: unknown) => {
      if (!Array.isArray(list)) return;
      const active = (list as PaymentOption[]).filter((p) => p.active !== false);
      setPayments(active);
      if (active.length > 0) setSelectedMethod((prev) => prev || active[0].id);
    };

    const cached = getCachedAppSettings();
    if (cached?.website?.withdrawalPayments) apply(cached.website.withdrawalPayments);

    const timer = setTimeout(async () => {
      const data = await fetchAppSettings();
      if (data?.website?.withdrawalPayments) apply(data.website.withdrawalPayments);
    }, 0);
    return () => clearTimeout(timer);
  }, []);

  const handleSelectPayment = (id: string) => {
    if (id !== selectedMethod) {
      setAccountName('');
      setAccountNumber('');
    }
    setSelectedMethod(id);
  };

  const currentPayment = payments.find((p) => p.id === selectedMethod) || null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const numAmount = parseInt(amount, 10);
    if (isNaN(numAmount) || numAmount < 1000) {
      setErrorMsg('အနည်းဆုံး ၁၀၀၀ ကျပ် ဖြစ်ရပါမည်');
      return;
    }
    if (user.balance < numAmount) {
      setErrorMsg('လက်ကျန်ငွေ မလုံလောက်ပါ');
      return;
    }
    if (!currentPayment) {
      setErrorMsg('ငွေပေးချေမှု နည်းလမ်း ရွေးချယ်ပါ');
      return;
    }
    if (!accountName.trim() || !accountNumber.trim()) {
      setErrorMsg('အကောင့် နာမည်နှင့် နံပါတ် ထည့်သွင်းပါ');
      return;
    }

    setIsSubmitting(true);
    const ok = await withdraw(numAmount, currentPayment.name, accountName, accountNumber);
    setIsSubmitting(false);
    if (ok) {
      setIsSuccess(true);
      setTimeout(() => {
        onBack();
      }, 1800);
    } else {
      setErrorMsg('ငွေထုတ်ယူမှု မအောင်မြင်ပါ');
    }
  };

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white select-none pb-16" id="withdraw-screen">
      <div className="sticky top-0 z-30 flex items-center px-4 py-3 bg-[#0a0a0a]/95 backdrop-blur-md border-b border-amber-500/15">
        <button
          type="button"
          onClick={onBack}
          className="p-1 -ml-1 text-amber-400 hover:text-amber-300"
          id="withdraw-back-btn"
        >
          <ArrowLeft className="w-6 h-6 stroke-[2.5]" />
        </button>
        <h1 className="flex-1 text-center font-bold text-base text-amber-400 -mr-6">
          ငွေထုတ်မည်
        </h1>
      </div>

      <div className="p-4 space-y-4 max-w-md mx-auto">
        <div className="relative overflow-hidden rounded-2xl border-2 border-[#d69f24] bg-gradient-to-b from-[#18150f] via-[#12100b] to-[#0a0907] p-3.5 shadow-md">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-full overflow-hidden bg-gradient-to-tr from-sky-600 to-sky-400 p-0.5 shadow-md flex items-center justify-center">
                <div className="w-full h-full rounded-full bg-[#1b3a57] flex items-center justify-center">
                  <svg className="w-8 h-8 text-sky-200 mt-1" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z" />
                  </svg>
                </div>
              </div>

              <div className="flex items-center gap-2.5">
                <div className="border-r border-amber-400/30 pr-3">
                  <h2 className="text-amber-400 font-bold text-sm leading-tight">
                    {user.name}
                  </h2>
                </div>
                <div>
                  <p className="text-[#f1f1f1] font-semibold text-xs tracking-tight">
                    လက်ကျန်ငွေ: <span className="text-amber-300 font-bold">{user.balance.toLocaleString()} ks</span>
                  </p>
                </div>
              </div>
            </div>

            <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-400/30 text-amber-400 flex items-center justify-center">
              <Wallet className="w-6 h-6 stroke-[2.2]" />
            </div>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <div className="flex justify-between items-center mb-1.5 px-1">
              <span className="text-amber-400 text-xs font-bold">
                ငွေပမာဏ
              </span>
              <span className="text-amber-300/80 text-[11px]">
                အနည်းဆုံးပမာဏ: 1000 ks
              </span>
            </div>

            <input
              type="number"
              min="1000"
              max={user.balance}
              step="500"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="1000"
              className="w-full h-12 px-4 rounded-full bg-black border-2 border-[#dca326] text-white font-bold text-sm focus:outline-none focus:ring-2 focus:ring-amber-400/50"
              id="withdraw-amount-input"
              required
            />
          </div>

          <div>
            <label className="block text-amber-400 text-xs font-bold mb-2 px-1">
              ငွေပေးချေမှု ရွေးချယ်ပါ
            </label>

            {payments.length === 0 ? (
              <div className="rounded-2xl border border-zinc-800 bg-[#121212] p-4 text-center text-xs text-zinc-400">
                ငွေပေးချေမှု နည်းလမ်း မရှိသေးပါ။
              </div>
            ) : (
              <div className="grid grid-cols-3 gap-3">
                {payments.map((pay) => (
                  <button
                    key={pay.id}
                    type="button"
                    onClick={() => handleSelectPayment(pay.id)}
                    className={`relative rounded-2xl p-2.5 flex flex-col items-center justify-center border-2 transition ${
                      selectedMethod === pay.id
                        ? 'border-amber-400 bg-amber-950/20 ring-2 ring-amber-400/40'
                        : 'border-zinc-800 bg-[#121212] opacity-75 hover:opacity-100'
                    }`}
                  >
                    <div className="w-14 h-14 rounded-xl bg-white flex items-center justify-center shadow-md p-1 overflow-hidden">
                      {pay.logoUrl ? (
                        // eslint-disable-next-line @next/next/no-img-element
                        <img src={pay.logoUrl} alt={pay.name} className="w-full h-full object-contain" />
                      ) : (
                        <span className="text-black font-black text-[10px] leading-none text-center px-0.5 break-all">
                          {pay.name}
                        </span>
                      )}
                    </div>
                    <span className="mt-1.5 text-[10px] font-bold text-amber-200 truncate w-full text-center">
                      {pay.name}
                    </span>
                  </button>
                ))}
              </div>
            )}
          </div>

          <div className="space-y-3 pt-1">
            <h3 className="text-amber-400 text-xs font-bold px-1">
              ငွေပေးချေမှု အချက်အလက်များ
            </h3>

            <div>
              <label className="block text-amber-400 text-xs font-medium mb-1.5 px-1">
                နာမည်
              </label>
              <input
                type="text"
                value={accountName}
                onChange={(e) => setAccountName(e.target.value)}
                placeholder="အကောင့်နာမည်"
                className="w-full h-12 px-4 rounded-full bg-black border-2 border-[#dca326] text-white font-bold text-sm focus:outline-none focus:ring-2 focus:ring-amber-400/50"
                id="withdraw-name-input"
                required
              />
            </div>

            <div>
              <label className="block text-amber-400 text-xs font-medium mb-1.5 px-1">
                နံပါတ်
              </label>
              <input
                type="tel"
                value={accountNumber}
                onChange={(e) => setAccountNumber(e.target.value)}
                placeholder="09..."
                className="w-full h-12 px-4 rounded-full bg-black border-2 border-[#dca326] text-white font-bold text-sm focus:outline-none focus:ring-2 focus:ring-amber-400/50"
                id="withdraw-phone-input"
                required
              />
            </div>
          </div>

          {errorMsg && (
            <div className="p-2.5 rounded-xl bg-red-950/60 border border-red-500/50 text-red-300 text-xs text-center">
              {errorMsg}
            </div>
          )}

          {isSuccess && (
            <div className="p-3 rounded-xl bg-green-950/80 border border-green-500/60 text-green-300 text-xs font-bold text-center flex items-center justify-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-green-400" />
              <span>ငွေထုတ်ရန် တင်သွင်းပြီးပါပြီ</span>
            </div>
          )}

          <div className="pt-2">
            <button
              type="submit"
              disabled={isSuccess || isSubmitting}
              className="w-full h-12 rounded-full bg-gradient-to-b from-[#ffdc5e] via-[#f1b827] to-[#cb8f0b] text-black font-bold text-sm shadow-[0_4px_16px_rgba(241,184,39,0.4)] hover:brightness-105 active:scale-95 transition cursor-pointer flex items-center justify-center gap-2 disabled:opacity-70 disabled:cursor-not-allowed"
              id="withdraw-submit-btn"
            >
              {isSubmitting ? (
                <>
                  <span className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin" />
                  <span>ခေတ္တစောင့်ပါ...</span>
                </>
              ) : isSuccess ? (
                'အောင်မြင်ပါသည်...'
              ) : (
                'ပြုလုပ်မည်'
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
