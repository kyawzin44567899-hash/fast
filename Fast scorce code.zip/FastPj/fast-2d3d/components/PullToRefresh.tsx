'use client';

import React, { useState, useRef, useCallback } from 'react';
import { RefreshCw, ArrowDown } from 'lucide-react';

interface PullToRefreshProps {
  onRefresh: () => Promise<void> | void;
  children: React.ReactNode;
  className?: string;
  id?: string;
}

const PULL_THRESHOLD = 65;
const MAX_PULL = 90;

export const PullToRefresh: React.FC<PullToRefreshProps> = ({
  onRefresh,
  children,
  className = '',
  id,
}) => {
  const [pullY, setPullY] = useState(0);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [isPulling, setIsPulling] = useState(false);

  const startYRef = useRef(0);
  const currentYRef = useRef(0);
  const containerRef = useRef<HTMLDivElement>(null);

  const handleTouchStart = (e: React.TouchEvent) => {
    if (isRefreshing) return;
    const scrollTop = containerRef.current ? containerRef.current.scrollTop : window.scrollY;
    if (scrollTop <= 2) {
      startYRef.current = e.touches[0].clientY;
      currentYRef.current = e.touches[0].clientY;
      setIsPulling(true);
    }
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!isPulling || isRefreshing) return;
    const scrollTop = containerRef.current ? containerRef.current.scrollTop : window.scrollY;
    if (scrollTop > 5) {
      setIsPulling(false);
      setPullY(0);
      return;
    }

    currentYRef.current = e.touches[0].clientY;
    const diff = currentYRef.current - startYRef.current;

    if (diff > 0) {

      const damped = Math.min(diff * 0.45, MAX_PULL);
      setPullY(damped);
    } else {
      setPullY(0);
    }
  };

  const handleTouchEnd = async () => {
    if (!isPulling || isRefreshing) return;
    setIsPulling(false);

    if (pullY >= PULL_THRESHOLD) {
      setIsRefreshing(true);
      setPullY(50);
      try {
        await Promise.resolve(onRefresh());
      } catch (err) {
        console.error('Refresh error:', err);
      } finally {
        setTimeout(() => {
          setIsRefreshing(false);
          setPullY(0);
        }, 500);
      }
    } else {
      setPullY(0);
    }
  };

  const triggerManualRefresh = useCallback(async () => {
    if (isRefreshing) return;
    setIsRefreshing(true);
    setPullY(50);
    try {
      await Promise.resolve(onRefresh());
    } finally {
      setTimeout(() => {
        setIsRefreshing(false);
        setPullY(0);
      }, 500);
    }
  }, [isRefreshing, onRefresh]);

  const progress = Math.min(pullY / PULL_THRESHOLD, 1);
  const isReadyToRelease = pullY >= PULL_THRESHOLD;

  return (
    <div
      ref={containerRef}
      id={id}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
      className={`relative overflow-hidden ${className}`}
    >
      <div
        className="flex items-center justify-center overflow-hidden transition-all duration-200"
        style={{
          height: `${pullY}px`,
          opacity: pullY > 5 ? 1 : 0,
        }}
      >
        <div className="flex items-center gap-2 py-2 px-3.5 rounded-full bg-[#16140e] border border-amber-400/40 shadow-lg text-amber-300 text-xs font-semibold select-none">
          {isRefreshing ? (
            <>
              <RefreshCw className="w-4 h-4 text-amber-400 animate-spin" />
              <span>အချက်အလက်များ အသစ်ရယူနေသည်...</span>
            </>
          ) : isReadyToRelease ? (
            <>
              <RefreshCw
                className="w-4 h-4 text-amber-400 transition-transform duration-200"
                style={{ transform: `rotate(${progress * 180}deg)` }}
              />
              <span className="text-amber-300">လွှတ်၍ အသစ်ရယူပါ</span>
            </>
          ) : (
            <>
              <ArrowDown
                className="w-4 h-4 text-amber-400/80 transition-transform duration-200"
                style={{ transform: `scale(${0.8 + progress * 0.4}) translateY(${progress * 2}px)` }}
              />
              <span className="text-amber-400/80 text-[11px]">ဆွဲချ၍ အချက်အလက် အသစ်ယူပါ</span>
            </>
          )}
        </div>
      </div>

      <div
        style={{
          transform: pullY > 0 ? `translateY(${Math.min(pullY * 0.2, 15)}px)` : 'none',
          transition: isPulling ? 'none' : 'transform 0.25s cubic-bezier(0.25, 1, 0.5, 1)',
        }}
      >
        {children}
      </div>
    </div>
  );
};
