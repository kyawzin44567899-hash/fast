'use client';

import React, { useState, useEffect } from 'react';
import { X, Calendar, RefreshCw, Clock } from 'lucide-react';
import {
  get2DResult,
  get2DLive,
  get3DHistory,
  TwodHistoryDay,
  ThreedHistoryData,
  Live2DData,
} from '@/lib/lotteryApi';

interface ResultsHistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ResultsHistoryModal: React.FC<ResultsHistoryModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [activeType, setActiveType] = useState<'2D' | '3D'>('2D');

  const [twodList, setTwodList] = useState<TwodHistoryDay[]>([]);
  const [liveData, setLiveData] = useState<Live2DData | null>(null);
  const [loading2D, setLoading2D] = useState(false);

  const [threedList, setThreedList] = useState<ThreedHistoryData['data']>([]);
  const [loading3D, setLoading3D] = useState(false);

  useEffect(() => {
    if (!isOpen) return;

    let isMounted = true;

    const fetchData = async () => {
      setLoading2D(true);
      setLoading3D(true);
      try {
        const [history, live, threed] = await Promise.all([
          get2DResult(),
          get2DLive(),
          get3DHistory(),
        ]);
        if (!isMounted) return;
        if (Array.isArray(history)) setTwodList(history);
        if (live) setLiveData(live);
        if (Array.isArray(threed?.data)) setThreedList(threed.data);
      } catch {

      } finally {
        if (isMounted) {
          setLoading2D(false);
          setLoading3D(false);
        }
      }
    };

    fetchData();

    return () => {
      isMounted = false;
    };
  }, [isOpen]);

  const handleManualRefresh = async () => {
    setLoading2D(true);
    setLoading3D(true);
    try {
      const [history, live, threed] = await Promise.all([
        get2DResult(),
        get2DLive(),
        get3DHistory(),
      ]);
      if (Array.isArray(history)) setTwodList(history);
      if (live) setLiveData(live);
      if (Array.isArray(threed?.data)) setThreedList(threed.data);
    } catch {

    } finally {
      setLoading2D(false);
      setLoading3D(false);
    }
  };

  if (!isOpen) return null;

  const isAllowed2DSession = (openTime: string): boolean => {
    if (!openTime) return false;
    const t = openTime.trim().toLowerCase();
    if (t.includes('11:00') || t.includes('15:00') || t.includes('03:00') || t.startsWith('11:') || t.startsWith('15:')) {
      return false;
    }
    return (
      t.includes('12:01') ||
      t.includes('16:30') ||
      t.includes('4:30') ||
      t.includes('04:30') ||
      t.startsWith('12:01') ||
      t.startsWith('16:30')
    );
  };

  const isAllowed2DTick = (timeStr: string): boolean => {
    if (!timeStr) return false;
    const t = timeStr.trim().toLowerCase();
    if (t.startsWith('11:') || t.includes('11:00') || t.startsWith('15:') || t.includes('15:00') || t.includes('03:') || t.includes('3:00')) {
      return false;
    }
    return true;
  };

  const formatSessionTime = (openTime: string) => {
    if (!openTime) return '';
    const [h, m] = openTime.split(':');
    const hour = parseInt(h, 10);
    if (isNaN(hour)) return openTime;
    const ampm = hour >= 12 ? 'PM' : 'AM';
    const displayHour = hour > 12 ? hour - 12 : hour === 0 ? 12 : hour;
    return `${displayHour.toString().padStart(2, '0')}:${m || '00'} ${ampm}`;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-sm p-4 select-none animate-in fade-in duration-200">
      <div className="w-full max-w-md bg-[#110f0a] border-2 border-[#d69f24] rounded-3xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
        <div className="flex items-center justify-between px-5 py-4 border-b border-amber-500/25 bg-black/70">
          <div className="flex items-center gap-2">
            <Calendar className="w-5 h-5 text-amber-400" />
            <h3 className="font-bold text-base text-amber-400">
              ပေါက်စဉ်များ မှတ်တမ်း
            </h3>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handleManualRefresh}
              disabled={loading2D || loading3D}
              className="p-1.5 rounded-full text-zinc-400 hover:text-amber-300 bg-zinc-900 active:scale-95 transition cursor-pointer disabled:opacity-50"
              title="ပြန်လည်ရယူမည်"
            >
              <RefreshCw
                className={`w-4 h-4 ${loading2D || loading3D ? 'animate-spin text-amber-400' : ''}`}
              />
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-full text-zinc-400 hover:text-white bg-zinc-900 active:scale-95 transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div className="px-5 pt-3 pb-1 flex gap-2">
          {(['2D', '3D'] as const).map((t) => (
            <button
              key={t}
              onClick={() => setActiveType(t)}
              className={`flex-1 py-2 rounded-xl text-xs font-black transition cursor-pointer ${
                activeType === t
                  ? 'bg-gradient-to-r from-amber-400 to-amber-500 text-black shadow-md'
                  : 'bg-zinc-900/80 text-zinc-400 border border-amber-500/20 hover:text-white'
              }`}
            >
              {t} ပေါက်စဉ်
            </button>
          ))}
        </div>

        <div className="p-4 overflow-y-auto space-y-3.5 flex-1">
          {activeType === '2D' ? (
            loading2D && twodList.length === 0 && !liveData ? (
              <div className="py-12 flex flex-col items-center justify-center text-xs text-amber-400 gap-2">
                <RefreshCw className="w-6 h-6 animate-spin text-amber-400" />
                <span>2D အချက်အလက်များ API မှ ရယူနေပါသည်...</span>
              </div>
            ) : twodList.length === 0 && (!liveData || !liveData.result?.length) ? (
              <div className="text-center py-12 text-zinc-500 text-xs">
                2D ပေါက်စဉ်မှတ်တမ်း မရှိသေးပါ
              </div>
            ) : (
              <div className="space-y-4">
                {liveData?.result && liveData.result.filter((item) => isAllowed2DSession(item.open_time)).length > 0 && (
                  <div className="space-y-2">
                    <div className="flex items-center gap-1.5 px-2 text-xs font-bold text-amber-400">
                      <Clock className="w-3.5 h-3.5 text-amber-400" />
                      <span>
                        ယနေ့ အချိန်အလိုက် ပေါက်စဉ်များ ({liveData.live?.date || liveData.result[0]?.stock_date || 'Today'})
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-2.5">
                      {liveData.result
                        .filter((item) => isAllowed2DSession(item.open_time))
                        .map((item, idx) => (
                          <div
                            key={idx}
                            className="p-3 rounded-2xl bg-gradient-to-b from-[#19150e] to-[#0c0a07] border border-[#d69f24]/60 flex flex-col justify-between shadow-md"
                          >
                            <div className="flex items-center justify-between">
                              <span className="text-[11px] font-bold text-amber-300">
                                {formatSessionTime(item.open_time)}
                              </span>
                              <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-400/20 text-amber-300 font-mono">
                                2D
                              </span>
                            </div>

                            <div className="my-1.5 text-center">
                              <span className="text-3xl font-black text-amber-400 font-mono tracking-tight drop-shadow-[0_2px_8px_rgba(245,158,11,0.3)]">
                                {item.twod || '--'}
                              </span>
                            </div>

                            <div className="text-[10px] text-zinc-400 flex items-center justify-between border-t border-amber-500/20 pt-1">
                              <span>SET: <span className="font-mono text-zinc-200">{item.set || '-'}</span></span>
                              <span>Val: <span className="font-mono text-zinc-200">{item.value ? Math.round(Number(item.value.replace(/,/g, '')) / 1000) + 'k' : '-'}</span></span>
                            </div>
                          </div>
                        ))}
                    </div>
                  </div>
                )}

                {twodList.map((dayGroup, i) => {
                  const filteredChild = dayGroup.child?.filter((item) => isAllowed2DTick(item.time)) || [];
                  if (filteredChild.length === 0) return null;

                  return (
                    <div key={i} className="space-y-2">
                      <div className="sticky top-0 bg-[#110f0a] px-2 py-1.5 text-xs font-bold text-amber-400 border-b border-amber-500/25 flex items-center justify-between">
                        <span>ရက်စွဲ: {dayGroup.date}</span>
                        <span className="text-[10px] text-zinc-400 font-normal">
                          {filteredChild.length} မှတ်တမ်း
                        </span>
                      </div>

                      <div className="space-y-2">
                        {filteredChild.slice(0, 40).map((item, j) => (
                          <div
                            key={j}
                            className="p-3 rounded-2xl bg-zinc-950/90 border border-amber-500/25 flex items-center justify-between hover:border-amber-400/50 transition"
                          >
                            <div>
                              <span className="text-xs font-bold text-zinc-200 flex items-center gap-1.5">
                                <span className="w-1.5 h-1.5 rounded-full bg-amber-400 inline-block"></span>
                                {item.time}
                              </span>
                              <span className="block text-[11px] text-zinc-400 mt-0.5 ml-3">
                                SET: <span className="font-mono text-zinc-200">{item.set}</span> | Value: <span className="font-mono text-zinc-200">{item.value}</span>
                              </span>
                            </div>
                            <div className="text-right pl-3">
                              <span className="text-2xl font-black text-amber-400 font-mono">
                                {item.twod}
                              </span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  );
                })}
              </div>
            )
          ) : (
            loading3D && threedList.length === 0 ? (
              <div className="py-12 flex flex-col items-center justify-center text-xs text-amber-400 gap-2">
                <RefreshCw className="w-6 h-6 animate-spin text-amber-400" />
                <span>3D အချက်အလက်များ API မှ ရယူနေပါသည်...</span>
              </div>
            ) : threedList.length === 0 ? (
              <div className="text-center py-12 text-zinc-500 text-xs">
                3D ပေါက်စဉ်မှတ်တမ်း မရှိသေးပါ
              </div>
            ) : (
              threedList.map((item, i) => (
                <div
                  key={i}
                  className="p-4 rounded-2xl bg-zinc-950/90 border border-amber-500/30 flex items-center justify-between shadow-sm"
                >
                  <div>
                    <span className="text-xs font-bold text-zinc-200 block">ရက်စွဲ: {item.datetime}</span>
                    <span className="text-[11px] text-amber-400/80 block mt-0.5">
                      ထိုင်းထီ (3D) ပေါက်ဂဏန်း
                    </span>
                  </div>
                  <div className="text-right">
                    <span className="text-3xl font-black text-amber-400 tracking-wider font-mono">
                      {item.result}
                    </span>
                  </div>
                </div>
              ))
            )
          )}
        </div>
      </div>
    </div>
  );
};
