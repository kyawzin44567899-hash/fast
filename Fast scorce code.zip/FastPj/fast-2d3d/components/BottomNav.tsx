'use client';

import React from 'react';
import { Home, Wallet, ClipboardList, User } from 'lucide-react';
import { useApp } from '@/context/AppContext';

export const BottomNav: React.FC = () => {
  const { activeTab, setActiveTab, currentView, setCurrentView } = useApp();

  const handleTabClick = (tab: 'home' | 'wallet' | 'record' | 'profile') => {
    setActiveTab(tab);
    if (currentView !== 'main') {
      setCurrentView('main');
    }
  };

  const tabs = [
    {
      id: 'home',
      label: 'ပင်မ',
      icon: Home,
    },
    {
      id: 'wallet',
      label: 'ပိုက်ဆံအိတ်',
      icon: Wallet,
    },
    {
      id: 'record',
      label: 'စာရင်းချုပ်',
      icon: ClipboardList,
    },
    {
      id: 'profile',
      label: 'ကျွန်ုပ်',
      icon: User,
    },
  ] as const;

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 max-w-md mx-auto bg-[#0d0d0d]/95 backdrop-blur-lg border-t border-amber-500/20 px-2 pb-safe">
      <div className="flex items-center justify-around h-16">
        {tabs.map((tab) => {
          const isActive = activeTab === tab.id && currentView === 'main';
          const Icon = tab.icon;

          return (
            <button
              key={tab.id}
              onClick={() => handleTabClick(tab.id)}
              className={`flex-1 flex flex-col items-center justify-center py-1 transition-all duration-200 select-none ${
                isActive ? 'text-amber-400 scale-105' : 'text-[#8a8068] hover:text-amber-300/80'
              }`}
              id={`nav-tab-${tab.id}`}
            >
              <div className="relative">
                <Icon
                  className={`w-6 h-6 transition-transform ${
                    isActive ? 'stroke-[2.5] drop-shadow-[0_0_8px_rgba(245,158,11,0.5)]' : 'stroke-[1.75]'
                  }`}
                />
                {isActive && (
                  <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-1 h-1 bg-amber-400 rounded-full" />
                )}
              </div>
              <span
                className={`text-[11px] mt-1 font-medium tracking-tight ${
                  isActive ? 'font-bold text-amber-400' : 'text-[#8a8068]'
                }`}
              >
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
