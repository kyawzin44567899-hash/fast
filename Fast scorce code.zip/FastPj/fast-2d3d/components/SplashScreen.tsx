'use client';

import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { GoldEmblem } from './GoldEmblem';

interface SplashScreenProps {
  onComplete: () => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onComplete }) => {
  const [progress, setProgress] = useState(15);

  useEffect(() => {
    const timer = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(timer);
          setTimeout(onComplete, 350);
          return 100;
        }
        return prev + Math.floor(Math.random() * 20) + 10;
      });
    }, 250);

    return () => clearInterval(timer);
  }, [onComplete]);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.4 }}
      className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-black select-none cursor-pointer"
      onClick={onComplete}
      id="splash-screen"
    >
      <div className="flex flex-col items-center max-w-xs w-full px-6">
        <motion.div
          initial={{ scale: 0.85, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.8, ease: 'easeOut' }}
        >
          <GoldEmblem size="xl" showText={true} />
        </motion.div>

        <div className="mt-14 w-52 h-4 rounded-full border-2 border-[#e6b325] p-0.5 relative overflow-hidden bg-black/70 shadow-[0_0_12px_rgba(230,179,37,0.35)]">
          <motion.div
            className="h-full bg-gradient-to-r from-[#d89e18] via-[#ffd700] to-[#fff490] rounded-full relative"
            style={{ width: `${progress}%` }}
            transition={{ type: 'spring', damping: 20 }}
          >
            <div className="absolute right-0 top-1/2 -translate-y-1/2 w-3 h-3 bg-white rounded-full shadow-[0_0_8px_#ffffff]" />
          </motion.div>
        </div>

        <p className="mt-4 text-xs text-amber-300/60 font-medium tracking-wider uppercase">
          Loading Fast 2D3D...
        </p>
      </div>
    </motion.div>
  );
};
