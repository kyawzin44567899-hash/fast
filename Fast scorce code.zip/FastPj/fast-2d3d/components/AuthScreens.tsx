'use client';

import React, { useState } from 'react';
import { User, UserPlus, Headphones, Eye, EyeOff } from 'lucide-react';
import { GoldEmblem } from './GoldEmblem';
import { useApp } from '@/context/AppContext';

interface AuthScreensProps {
  onOpenSupport: () => void;
}

export const AuthScreens: React.FC<AuthScreensProps> = ({ onOpenSupport }) => {
  const { currentView, setCurrentView, login, register } = useApp();
  const isRegister = currentView === 'register';

  const [loginPhone, setLoginPhone] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  const [regName, setRegName] = useState('');
  const [regPhone, setRegPhone] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regAgentCode, setRegAgentCode] = useState('');
  const [showRegPassword, setShowRegPassword] = useState(false);

  const [errorMsg, setErrorMsg] = useState('');
  const [loading, setLoading] = useState(false);

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!loginPhone.trim()) {
      setErrorMsg('ဖုန်းနံပါတ် ထည့်သွင်းပါ');
      return;
    }
    setErrorMsg('');
    setLoading(true);
    try {
      const res = await login(loginPhone, loginPassword);
      if (!res.success) {
        setErrorMsg(res.error || 'အကောင့်ဝင်ရောက်မှု မအောင်မြင်ပါ');
      }
    } catch {
      setErrorMsg('ဆာဗာနှင့် ချိတ်ဆက်ရာတွင် အဆင်မပြေပါ');
    } finally {
      setLoading(false);
    }
  };

  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!regName.trim() || !regPhone.trim()) {
      setErrorMsg('အချက်အလက်များ အပြည့်အစုံ ဖြည့်စွက်ပါ');
      return;
    }
    setErrorMsg('');
    setLoading(true);
    try {
      const res = await register(regName, regPhone, regAgentCode, regPassword);
      if (!res.success) {
        setErrorMsg(res.error || 'အကောင့်ဖွင့်ခြင်း မအောင်မြင်ပါ');
      }
    } catch {
      setErrorMsg('ဆာဗာနှင့် ချိတ်ဆက်ရာတွင် အဆင်မပြေပါ');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#000000] text-white flex flex-col justify-between p-6 max-w-md mx-auto relative select-none" id="auth-screen-container">
      <div className="relative z-30 flex justify-end items-center pt-2">
        <button
          type="button"
          onClick={onOpenSupport}
          className="p-2.5 -mr-1 rounded-full text-amber-400 hover:bg-amber-400/10 active:scale-95 transition flex items-center gap-1 cursor-pointer touch-manipulation"
          aria-label="Customer Support"
          id="auth-support-btn"
        >
          <div className="relative">
            <Headphones className="w-6 h-6 text-amber-400 fill-amber-400/20" />
            <span className="absolute -top-0.5 -right-0.5 w-2 h-2 bg-amber-400 rounded-full animate-ping" />
          </div>
        </button>
      </div>

      <div className="flex flex-col items-center w-full my-auto pb-6">
        <div className="mb-5">
          <GoldEmblem size="lg" showText={true} />
        </div>

        <div className="w-full mb-6 max-w-xs">
          <div className="flex items-center p-1 rounded-full border border-[#e5a924]/80 bg-black/60 shadow-[0_0_12px_rgba(229,169,36,0.25)]">
            <button
              type="button"
              onClick={() => {
                setErrorMsg('');
                setCurrentView('login');
              }}
              className={`flex-1 flex items-center justify-center gap-1.5 py-2 px-3 rounded-full text-xs font-bold transition-all ${
                !isRegister
                  ? 'bg-gradient-to-r from-amber-400 via-amber-300 to-yellow-500 text-black shadow-[0_2px_8px_rgba(245,158,11,0.4)]'
                  : 'text-amber-300 hover:text-amber-200'
              }`}
              id="switch-login-tab"
            >
              <User className="w-3.5 h-3.5" />
              <span>အကောင့်ဝင်ရန်</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setErrorMsg('');
                setCurrentView('register');
              }}
              className={`flex-1 flex items-center justify-center gap-1.5 py-2 px-3 rounded-full text-xs font-bold transition-all ${
                isRegister
                  ? 'bg-gradient-to-r from-amber-400 via-amber-300 to-yellow-500 text-black shadow-[0_2px_8px_rgba(245,158,11,0.4)]'
                  : 'text-amber-300 hover:text-amber-200'
              }`}
              id="switch-register-tab"
            >
              <UserPlus className="w-3.5 h-3.5" />
              <span>အကောင့်ဖွင့်ရန်</span>
            </button>
          </div>
        </div>

        {errorMsg && (
          <div className="w-full mb-4 px-4 py-2 bg-red-950/70 border border-red-500/50 rounded-xl text-red-300 text-xs text-center">
            {errorMsg}
          </div>
        )}

        {!isRegister ? (
          <form onSubmit={handleLoginSubmit} className="w-full space-y-4" id="login-form">
            <div>
              <label className="block text-amber-400 text-xs font-medium mb-1.5 ml-1">
                ဖုန်းနံပါတ်
              </label>
              <div className="relative">
                <input
                  type="tel"
                  value={loginPhone}
                  onChange={(e) => setLoginPhone(e.target.value)}
                  placeholder="09..."
                  className="w-full h-12 px-4 rounded-full bg-black border-2 border-[#dca326] text-white text-sm focus:outline-none focus:ring-2 focus:ring-amber-400/50 focus:border-amber-400 transition"
                  id="login-phone-input"
                  required
                />
              </div>
            </div>

            <div>
              <div className="flex justify-between items-center mb-1.5 ml-1 mr-1">
                <label className="text-amber-400 text-xs font-medium">
                  လျှို့ဝှက်နံပါတ်
                </label>
                <button
                  type="button"
                  onClick={() => alert('ကျေးဇူးပြု၍ Customer Support အား ဆက်သွယ်ပြီး လျှို့ဝှက်နံပါတ် ပြန်လည်ရယူပါ')}
                  className="text-amber-200/90 text-xs hover:underline hover:text-amber-300"
                >
                  မေ့နေသည်
                </button>
              </div>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={loginPassword}
                  onChange={(e) => setLoginPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full h-12 px-4 pr-11 rounded-full bg-black border-2 border-[#dca326] text-white text-sm focus:outline-none focus:ring-2 focus:ring-amber-400/50 focus:border-amber-400 transition"
                  id="login-password-input"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-amber-400/70 hover:text-amber-400"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div className="pt-2">
              <button
                type="submit"
                disabled={loading}
                className="w-full h-12 rounded-full bg-gradient-to-b from-[#ffdc5e] via-[#f1b827] to-[#cb8f0b] text-black font-bold text-sm tracking-wide shadow-[0_4px_16px_rgba(241,184,39,0.35)] hover:brightness-105 active:scale-[0.98] transition cursor-pointer flex items-center justify-center gap-2 disabled:opacity-60 disabled:cursor-not-allowed"
                id="login-submit-btn"
              >
                {loading ? (
                  <span className="flex items-center gap-2">
                    <span className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin" />
                    <span>ခေတ္တစောင့်ပါ...</span>
                  </span>
                ) : (
                  <span>ဝင်မည်</span>
                )}
              </button>
            </div>

            <div className="text-center pt-2">
              <button
                type="button"
                onClick={() => {
                  setErrorMsg('');
                  setCurrentView('register');
                }}
                className="text-amber-300 text-xs tracking-wide hover:underline cursor-pointer"
                id="go-to-register-btn"
              >
                အကောင့်မရှိသေးပါက <span className="font-bold underline">အကောင့်အသစ်ပြုလုပ်မည်</span>
              </button>
            </div>
          </form>
        ) : (

          <form onSubmit={handleRegisterSubmit} className="w-full space-y-3" id="register-form">
            <div>
              <label className="block text-amber-400 text-xs font-medium mb-1 ml-1">
                နာမည်အပြည့်အစုံ
              </label>
              <input
                type="text"
                value={regName}
                onChange={(e) => setRegName(e.target.value)}
                placeholder="Aung Aung"
                className="w-full h-11 px-4 rounded-full bg-black border-2 border-[#dca326] text-white text-sm focus:outline-none focus:ring-2 focus:ring-amber-400/50 focus:border-amber-400 transition"
                id="register-name-input"
                required
              />
            </div>

            <div>
              <label className="block text-amber-400 text-xs font-medium mb-1 ml-1">
                ဖုန်းနံပါတ်
              </label>
              <input
                type="tel"
                value={regPhone}
                onChange={(e) => setRegPhone(e.target.value)}
                placeholder="09..."
                className="w-full h-11 px-4 rounded-full bg-black border-2 border-[#dca326] text-white text-sm focus:outline-none focus:ring-2 focus:ring-amber-400/50 focus:border-amber-400 transition"
                id="register-phone-input"
                required
              />
            </div>

            <div>
              <label className="block text-amber-400 text-xs font-medium mb-1 ml-1">
                လျှို့ဝှက်နံပါတ်
              </label>
              <div className="relative">
                <input
                  type={showRegPassword ? 'text' : 'password'}
                  value={regPassword}
                  onChange={(e) => setRegPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full h-11 px-4 pr-11 rounded-full bg-black border-2 border-[#dca326] text-white text-sm focus:outline-none focus:ring-2 focus:ring-amber-400/50 focus:border-amber-400 transition"
                  id="register-password-input"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowRegPassword(!showRegPassword)}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-amber-400/70 hover:text-amber-400"
                  aria-label={showRegPassword ? 'Hide password' : 'Show password'}
                >
                  {showRegPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div>
              <label className="block text-amber-400 text-xs font-medium mb-1 ml-1">
                အေးဂျင့်ကုဒ် (ရွေးချယ်ရန်)
              </label>
              <input
                type="text"
                value={regAgentCode}
                onChange={(e) => setRegAgentCode(e.target.value)}
                placeholder="အေးဂျင့်ကုဒ်ရှိပါက ထည့်သွင်းပါ"
                className="w-full h-11 px-4 rounded-full bg-black border-2 border-[#dca326] text-white text-sm focus:outline-none focus:ring-2 focus:ring-amber-400/50 focus:border-amber-400 transition"
                id="register-agent-input"
              />
            </div>

            <div className="pt-2">
              <button
                type="submit"
                disabled={loading}
                className="w-full h-12 rounded-full bg-gradient-to-b from-[#ffdc5e] via-[#f1b827] to-[#cb8f0b] text-black font-bold text-sm tracking-wide shadow-[0_4px_16px_rgba(241,184,39,0.35)] hover:brightness-105 active:scale-[0.98] transition cursor-pointer flex items-center justify-center gap-2 disabled:opacity-60 disabled:cursor-not-allowed"
                id="register-submit-btn"
              >
                {loading ? (
                  <span className="flex items-center gap-2">
                    <span className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin" />
                    <span>ခေတ္တစောင့်ပါ...</span>
                  </span>
                ) : (
                  <span>အကောင့်ပြုလုပ်မည်</span>
                )}
              </button>
            </div>

            <div className="text-center pt-2">
              <button
                type="button"
                onClick={() => {
                  setErrorMsg('');
                  setCurrentView('login');
                }}
                className="text-amber-300 text-xs tracking-wide hover:underline cursor-pointer"
                id="back-to-login-btn"
              >
                အကောင့်ရှိပြီးသားဖြစ်ပါက <span className="font-bold underline">အကောင့်ဝင်မည်</span>
              </button>
            </div>
          </form>
        )}
      </div>

      <div className="text-center text-[10px] text-zinc-500 pb-1">
        Fast 2D3D Official PWA Web App • Safe & Secure
      </div>
    </div>
  );
};
