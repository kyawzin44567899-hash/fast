'use client';

import React from 'react';
import Image from 'next/image';
import { Headphones, Bell, Download, RefreshCw } from 'lucide-react';
import { usePWAInstall } from '@/hooks/use-pwa-install';

interface AppHeaderProps {
  onOpenSupport: () => void;
  onOpenNotifications: () => void;
  onOpenInstall?: () => void;
}

export const AppHeader: React.FC<AppHeaderProps> = ({
  onOpenSupport,
  onOpenNotifications,
  onOpenInstall,
}) => {
  const { isInstallable, isIOS, isInstalled } = usePWAInstall();

  return (
    <header className="sticky top-0 z-30 flex items-center justify-between px-4 py-3 bg-[#0a0a0a]/95 backdrop-blur-md border-b border-amber-500/15">
      <div className="flex items-center gap-2">
        <div className="relative w-8 h-8 rounded-full overflow-hidden border border-amber-400/50 bg-black">
          <Image
            src="/images/logo.png"
            alt="2D3D"
            width={32}
            height={32}
            className="w-full h-full object-cover"
          />
        </div>
        <span className="text-xs font-black tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-amber-200 via-amber-400 to-yellow-500">
          2D3D
        </span>
      </div>

      <div className="text-center">
        <h1 className="text-base sm:text-lg font-bold tracking-wide text-transparent bg-clip-text bg-gradient-to-r from-[#ffd966] via-[#f1c232] to-[#e69138]">
          Fast 2D3D
        </h1>
      </div>

      <div className="flex items-center gap-2.5">
        {!isInstalled && (isInstallable || isIOS) && onOpenInstall && (
          <button
            onClick={onOpenInstall}
            className="p-1.5 rounded-full bg-amber-400/10 border border-amber-400/40 text-amber-300 hover:bg-amber-400/20 active:scale-95 transition"
            title="Install App"
            id="header-install-btn"
          >
            <Download className="w-4 h-4 text-amber-300" />
          </button>
        )}

        <button
          onClick={onOpenSupport}
          className="relative p-1.5 rounded-full text-amber-400 hover:bg-amber-400/10 active:scale-95 transition"
          aria-label="Customer Support"
          id="header-support-btn"
        >
          <div className="relative">
            <Headphones className="w-5 h-5 text-amber-400 fill-amber-400/20" />
            <span className="absolute -top-1 -right-1 flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75" />
              <span className="relative inline-flex rounded-full h-2 w-2 bg-amber-500" />
            </span>
          </div>
        </button>

        <button
          onClick={() => {
            if (typeof window !== 'undefined') window.location.reload();
          }}
          className="p-1.5 rounded-full text-amber-400 hover:bg-amber-400/10 active:scale-95 transition"
          aria-label="Refresh"
          title="Refresh"
          id="header-refresh-btn"
        >
          <RefreshCw className="w-5 h-5 text-amber-400" />
        </button>

        <button
          onClick={onOpenNotifications}
          className="relative p-1.5 rounded-full text-amber-400 hover:bg-amber-400/10 active:scale-95 transition"
          aria-label="Notifications"
          id="header-notifications-btn"
        >
          <Bell className="w-5 h-5 text-amber-400 fill-amber-400" />
          <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full ring-2 ring-black" />
        </button>
      </div>
    </header>
  );
};
