'use client';

import React from 'react';
import { useOnlineStatus } from '@/hooks/use-online-status';
import { WifiOff } from 'lucide-react';

export const OfflineIndicator: React.FC = () => {
  const isOnline = useOnlineStatus();

  if (isOnline) return null;

  return (
    <div className="fixed bottom-20 left-4 right-4 z-50 max-w-md mx-auto flex items-center justify-center gap-2 rounded-xl bg-amber-600/95 border border-amber-400 px-3.5 py-2 text-xs font-bold text-black shadow-xl backdrop-blur-sm animate-pulse">
      <WifiOff className="w-4 h-4 text-black" />
      <span>အင်တာနက် လိုင်းပြတ်တောက်နေပါသည်။ ဒေတာများကို သိုလှောင်ထားပါသည် (Offline Mode)</span>
    </div>
  );
};
