'use client';

import React from 'react';
import { X, Bell, CheckCheck, Volume2, VolumeX } from 'lucide-react';
import { AppNotification } from '@/hooks/use-notifications';

interface NotificationModalProps {
  isOpen: boolean;
  onClose: () => void;
  notifications?: AppNotification[];
  onMarkRead?: (id: string) => void;
  onMarkAllRead?: () => void;
  soundEnabled?: boolean;
  onToggleSound?: (enabled: boolean) => void;
  onNavigate?: (screen: string) => void;
}

function formatTime(value: string): string {
  if (!value) return '';
  try {
    return new Date(value).toLocaleString('en-US', {
      day: '2-digit',
      month: 'short',
      hour: '2-digit',
      minute: '2-digit',
      hour12: true,
    });
  } catch {
    return '';
  }
}

export const NotificationModal: React.FC<NotificationModalProps> = ({
  isOpen,
  onClose,
  notifications = [],
  onMarkRead,
  onMarkAllRead,
  soundEnabled = true,
  onToggleSound,
  onNavigate,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-sm p-4 select-none">
      <div className="w-full max-w-md bg-[#11100c] border border-amber-500/40 rounded-3xl max-h-[85vh] flex flex-col shadow-2xl overflow-hidden animate-in zoom-in-95 duration-200">
        <div className="flex items-center justify-between px-5 py-4 border-b border-amber-500/20 bg-black/60">
          <div className="flex items-center gap-2">
            <Bell className="w-5 h-5 text-amber-400" />
            <h3 className="font-bold text-base text-amber-400">
              အသိပေးချက်များ (Notifications)
            </h3>
          </div>
          <div className="flex items-center gap-1.5">
            {onToggleSound && (
              <button
                onClick={() => onToggleSound(!soundEnabled)}
                className="p-1.5 rounded-full text-amber-400 hover:bg-amber-400/10"
                title={soundEnabled ? 'Mute sound' : 'Unmute sound'}
              >
                {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
              </button>
            )}
            {onMarkAllRead && notifications.some((n) => !n.isRead) && (
              <button
                onClick={onMarkAllRead}
                className="p-1.5 rounded-full text-amber-400 hover:bg-amber-400/10"
                title="Mark all read"
              >
                <CheckCheck className="w-4 h-4" />
              </button>
            )}
            <button
              onClick={onClose}
              className="p-1.5 rounded-full text-zinc-400 hover:text-white bg-zinc-900"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div className="p-4 overflow-y-auto space-y-2.5 flex-1">
          {notifications.length === 0 && (
            <div className="text-center py-10 text-zinc-500 text-sm">
              အသိပေးချက် မရှိသေးပါ
            </div>
          )}
          {notifications.map((n) => (
            <button
              key={n.id}
              onClick={() => {
                if (!n.isRead && onMarkRead) onMarkRead(n.id);
                const screen = typeof n.data?.screen === 'string' ? (n.data.screen as string) : '';
                if (screen && onNavigate) {
                  onNavigate(screen);
                  onClose();
                }
              }}
              className={`w-full text-left p-3.5 rounded-2xl border transition ${
                !n.isRead
                  ? 'bg-amber-500/10 border-amber-400/40'
                  : 'bg-zinc-950/80 border-zinc-800 text-zinc-300'
              }`}
            >
              <div className="flex items-start justify-between gap-2">
                <h4 className="text-xs font-bold text-amber-300">{n.title}</h4>
                <span className="text-[10px] text-zinc-500 whitespace-nowrap">
                  {formatTime(n.createdAt)}
                </span>
              </div>
              <p className="text-[11px] text-zinc-300 mt-1 leading-relaxed">{n.message}</p>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
