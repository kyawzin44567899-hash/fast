'use client';

import React, { useState } from 'react';
import { Download, Share2, X, Smartphone, Check } from 'lucide-react';
import { usePWAInstall } from '@/hooks/use-pwa-install';

interface PWAInstallBannerProps {
  forceShowIOSModal?: boolean;
  onCloseIOSModal?: () => void;
}

export const PWAInstallBanner: React.FC<PWAInstallBannerProps> = ({
  forceShowIOSModal = false,
  onCloseIOSModal,
}) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);
  const [isDismissed, setIsDismissed] = useState(false);

  if (isInstalled && !forceShowIOSModal) {
    return null;
  }

  const isModalOpen = showIOSGuide || forceShowIOSModal;
  const handleCloseModal = () => {
    setShowIOSGuide(false);
    if (onCloseIOSModal) onCloseIOSModal();
  };

  return (
    <>
      {!isDismissed && isInstallable && (
        <div className="bg-gradient-to-r from-amber-600 via-yellow-500 to-amber-500 text-black px-4 py-2 flex items-center justify-between shadow-lg text-xs font-bold">
          <div className="flex items-center gap-2">
            <Smartphone className="w-4 h-4 text-black" />
            <span>Fast 2D3D အက်ပ်ကို ဖုန်းထဲတွင် ထည့်သွင်းပါ</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={install}
              className="bg-black text-amber-400 px-3 py-1 rounded-full text-xs font-black shadow-md hover:bg-zinc-900 active:scale-95 transition flex items-center gap-1"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Install</span>
            </button>
            <button
              onClick={() => setIsDismissed(true)}
              className="p-1 text-black/70 hover:text-black"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-4 backdrop-blur-sm select-none">
          <div className="w-full max-w-sm rounded-3xl bg-[#14120c] border border-amber-500/40 p-6 shadow-2xl text-white space-y-4">
            <div className="flex items-center justify-between border-b border-amber-500/20 pb-3">
              <div className="flex items-center gap-2">
                <Smartphone className="w-5 h-5 text-amber-400" />
                <h3 className="text-base font-bold text-amber-400">
                  iPhone / iPad တွင် ထည့်သွင်းရန်
                </h3>
              </div>
              <button
                onClick={handleCloseModal}
                className="p-1 rounded-full text-zinc-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-xs text-zinc-200">
              <div className="flex items-start gap-3 p-3 rounded-xl bg-zinc-950 border border-zinc-800">
                <span className="w-5 h-5 rounded-full bg-amber-400 text-black font-black flex items-center justify-center shrink-0">
                  1
                </span>
                <p className="leading-relaxed">
                  Safari browser အောက်ခြေရှိ <strong className="text-amber-300">Share</strong> (မြှားအပေါ်ထောင် အိုင်ကွန်) ကို နှိပ်ပါ။
                </p>
              </div>

              <div className="flex items-start gap-3 p-3 rounded-xl bg-zinc-950 border border-zinc-800">
                <span className="w-5 h-5 rounded-full bg-amber-400 text-black font-black flex items-center justify-center shrink-0">
                  2
                </span>
                <p className="leading-relaxed">
                  အောက်သို့ အနည်းငယ်ဆွဲချပြီး <strong className="text-amber-300">Add to Home Screen</strong> (ပင်မစာမျက်နှာသို့ ထည့်ပါ) ကို ရွေးချယ်ပါ။
                </p>
              </div>

              <div className="flex items-start gap-3 p-3 rounded-xl bg-zinc-950 border border-zinc-800">
                <span className="w-5 h-5 rounded-full bg-amber-400 text-black font-black flex items-center justify-center shrink-0">
                  3
                </span>
                <p className="leading-relaxed">
                  ညာဘက်အပေါ်ထောင့်ရှိ <strong className="text-amber-300">Add</strong> ကို နှိပ်ပြီး အက်ပ်ကို အလွယ်တကူ အသုံးပြုနိုင်ပါပြီ။
                </p>
              </div>
            </div>

            <button
              onClick={handleCloseModal}
              className="w-full py-2.5 rounded-full bg-amber-400 text-black font-bold text-xs hover:bg-amber-300 transition"
            >
              နားလည်ပါပြီ
            </button>
          </div>
        </div>
      )}
    </>
  );
};
