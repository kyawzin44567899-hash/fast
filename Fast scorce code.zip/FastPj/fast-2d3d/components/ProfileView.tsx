'use client';

import React, { useState } from 'react';
import { Pencil, User, Phone, Key, Shield, LogOut, Check, Copy, Eye, EyeOff, Lock } from 'lucide-react';
import { useApp } from '@/context/AppContext';

export const ProfileView: React.FC = () => {
  const { user, updateProfile, logout } = useApp();

  const [editingField, setEditingField] = useState<string | null>(null);
  const [editValue, setEditValue] = useState('');
  const [copiedUid, setCopiedUid] = useState(false);

  const [isPasswordModalOpen, setIsPasswordModalOpen] = useState(false);
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showCurrentPass, setShowCurrentPass] = useState(false);
  const [showNewPass, setShowNewPass] = useState(false);
  const [showConfirmPass, setShowConfirmPass] = useState(false);
  const [pwdError, setPwdError] = useState('');
  const [pwdSuccess, setPwdSuccess] = useState('');
  const [pwdLoading, setPwdLoading] = useState(false);

  const displayUid = user.uid || '';

  const handleCopyUid = () => {
    if (!displayUid) return;
    try {
      navigator.clipboard.writeText(displayUid);
      setCopiedUid(true);
      setTimeout(() => setCopiedUid(false), 2000);
    } catch {}
  };

  const startEdit = (field: string, currentVal: string) => {
    setEditingField(field);
    setEditValue(currentVal);
  };

  const saveEdit = () => {
    if (!editingField) return;
    if (editingField === 'name') updateProfile({ name: editValue });
    if (editingField === 'phone') updateProfile({ phone: editValue });
    if (editingField === 'agentCode') updateProfile({ agentCode: editValue });
    setEditingField(null);
  };

  const openPasswordModal = () => {
    setCurrentPassword('');
    setNewPassword('');
    setConfirmPassword('');
    setShowCurrentPass(false);
    setShowNewPass(false);
    setShowConfirmPass(false);
    setPwdError('');
    setPwdSuccess('');
    setIsPasswordModalOpen(true);
  };

  const handlePasswordChangeSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setPwdError('');
    setPwdSuccess('');

    if (!currentPassword.trim()) {
      setPwdError('လက်ရှိ လျှို့ဝှက်နံပါတ် ထည့်သွင်းပေးပါ');
      return;
    }

    if (!newPassword.trim()) {
      setPwdError('လျှို့ဝှက်နံပါတ် အသစ် ထည့်သွင်းပေးပါ');
      return;
    }

    if (newPassword.length < 4) {
      setPwdError('လျှို့ဝှက်နံပါတ် အသစ်သည် အနည်းဆုံး ၄ လုံး ရှိရပါမည်');
      return;
    }

    if (newPassword !== confirmPassword) {
      setPwdError('လျှို့ဝှက်နံပါတ် အသစ်နှစ်ခု ကိုက်ညီမှု မရှိပါ');
      return;
    }

    setPwdLoading(true);
    try {
      const res = await fetch('/api/user/change-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          uid: user.uid,
          currentPassword,
          newPassword,
        }),
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        setPwdError(data.error || 'လျှို့ဝှက်နံပါတ် ပြောင်းလဲမှု မအောင်မြင်ပါ');
      } else {
        setPwdSuccess('လျှို့ဝှက်နံပါတ် အောင်မြင်စွာ ပြောင်းလဲပြီးပါပြီ');
        setTimeout(() => {
          setIsPasswordModalOpen(false);
        }, 1500);
      }
    } catch {
      setPwdError('ဆာဗာနှင့် ချိတ်ဆက်ရာတွင် အဆင်မပြေပါ');
    } finally {
      setPwdLoading(false);
    }
  };

  return (
    <div className="space-y-6 px-4 py-3 select-none pb-24" id="profile-view">
      <div className="flex flex-col items-center pt-2">
        <div className="relative">
          <div className="w-24 h-24 rounded-full overflow-hidden bg-gradient-to-tr from-sky-600 to-sky-400 p-1 shadow-xl flex items-center justify-center">
            <div className="w-full h-full rounded-full bg-[#1b3a57] flex items-center justify-center">
              <svg
                className="w-16 h-16 text-sky-200 mt-2"
                fill="currentColor"
                viewBox="0 0 24 24"
              >
                <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z" />
              </svg>
            </div>
          </div>

          <button
            type="button"
            onClick={() => startEdit('name', user.name)}
            className="absolute bottom-0 right-0 p-2 rounded-full bg-gradient-to-b from-amber-300 to-amber-500 text-black shadow-lg hover:brightness-110 active:scale-95 transition cursor-pointer"
            title="Edit Profile"
          >
            <Pencil className="w-4 h-4 fill-black stroke-black" />
          </button>
        </div>

        <div className="mt-3 flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-[#161616] border border-amber-400/40 shadow-[0_2px_8px_rgba(0,0,0,0.5)]">
          <span className="text-[11px] font-bold text-amber-400/90 tracking-wider">UID:</span>
          <span className="font-mono text-xs font-black text-white tracking-widest" id="profile-uid-display">
            {displayUid}
          </span>
          <button
            type="button"
            onClick={handleCopyUid}
            className="ml-1 p-1 rounded-md text-amber-400/80 hover:text-amber-300 hover:bg-amber-400/10 active:scale-90 transition cursor-pointer"
            title="UID ကူးယူမည်"
            aria-label="Copy UID"
            id="copy-uid-btn"
          >
            {copiedUid ? (
              <Check className="w-3.5 h-3.5 text-emerald-400" />
            ) : (
              <Copy className="w-3.5 h-3.5 text-amber-400" />
            )}
          </button>
        </div>

        {copiedUid && (
          <span className="text-[10px] text-emerald-400 mt-1 font-semibold animate-pulse">
            UID ကူးယူပြီးပါပြီ
          </span>
        )}

        <h2 className="mt-3 text-base font-bold text-amber-400 tracking-wide">
          ကိုယ်ရေးအချက်အလက်များ
        </h2>
      </div>

      <div className="relative overflow-hidden rounded-2xl border-2 border-[#d69f24] bg-gradient-to-b from-[#18150f] via-[#120f09] to-[#0a0907] p-4 shadow-lg divide-y divide-amber-400/20">
        <div className="py-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-xs sm:text-sm font-bold text-amber-300">
              နာမည်အပြည့်အစုံ:
            </span>
            <span className="text-xs sm:text-sm font-semibold text-zinc-100">
              {user.name}
            </span>
          </div>
          <button
            type="button"
            onClick={() => startEdit('name', user.name)}
            className="p-1.5 text-amber-400 hover:text-amber-300"
          >
            <Pencil className="w-4 h-4" />
          </button>
        </div>

        <div className="py-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-xs sm:text-sm font-bold text-amber-300">
              ဖုန်းနံပါတ်:
            </span>
            <span className="text-xs sm:text-sm font-semibold text-zinc-100">
              {user.phone}
            </span>
          </div>
          <button
            type="button"
            onClick={() => startEdit('phone', user.phone)}
            className="p-1.5 text-amber-400 hover:text-amber-300"
          >
            <Pencil className="w-4 h-4" />
          </button>
        </div>

        <div className="py-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-xs sm:text-sm font-bold text-amber-300">
              အေးဂျင့်ကုဒ်:
            </span>
            <span className="text-xs sm:text-sm font-semibold text-zinc-300">
              {user.agentCode ? user.agentCode : '-'}
            </span>
          </div>
          <span className="text-[10px] text-zinc-500">Admin only</span>
        </div>

        <div className="py-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-xs sm:text-sm font-bold text-amber-300">
              လျှို့ဝှက်နံပါတ်
            </span>
            <span className="text-xs sm:text-sm font-semibold text-zinc-400">
              ••••••••
            </span>
          </div>
          <button
            type="button"
            onClick={openPasswordModal}
            className="p-1.5 text-amber-400 hover:text-amber-300 cursor-pointer"
            id="open-change-password-btn"
            title="လျှို့ဝှက်နံပါတ် ပြောင်းမည်"
          >
            <Pencil className="w-4 h-4" />
          </button>
        </div>
      </div>

      {isPasswordModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm" id="change-password-modal">
          <div className="w-full max-w-sm rounded-2xl border-2 border-amber-400/60 bg-gradient-to-b from-[#18150f] via-[#120f09] to-[#0a0907] p-5 shadow-2xl space-y-4">
            <div className="flex items-center gap-2 border-b border-amber-400/20 pb-3">
              <div className="p-2 rounded-full bg-amber-400/10 text-amber-400">
                <Lock className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-amber-300">
                  လျှို့ဝှက်နံပါတ် ပြောင်းလဲရန်
                </h4>
                <p className="text-[11px] text-zinc-400">
                  စကားဝှက်အသစ်ဖြင့် အောင်မြင်စွာ လဲလှယ်ပါ
                </p>
              </div>
            </div>

            {pwdError && (
              <div className="p-2.5 rounded-xl bg-red-950/80 border border-red-500/50 text-red-300 text-xs text-center">
                {pwdError}
              </div>
            )}

            {pwdSuccess && (
              <div className="p-2.5 rounded-xl bg-emerald-950/80 border border-emerald-500/50 text-emerald-300 text-xs text-center font-semibold">
                {pwdSuccess}
              </div>
            )}

            <form onSubmit={handlePasswordChangeSubmit} className="space-y-3" id="change-password-form">
              <div>
                <label className="block text-amber-400 text-xs font-medium mb-1">
                  လက်ရှိ လျှို့ဝှက်နံပါတ် (Current Password)
                </label>
                <div className="relative">
                  <input
                    type={showCurrentPass ? 'text' : 'password'}
                    value={currentPassword}
                    onChange={(e) => setCurrentPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full h-10 px-3 pr-10 rounded-xl bg-black border border-amber-400/50 text-white text-sm focus:outline-none focus:ring-1 focus:ring-amber-400"
                    id="current-password-input"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowCurrentPass(!showCurrentPass)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-amber-400/70 hover:text-amber-300"
                  >
                    {showCurrentPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-amber-400 text-xs font-medium mb-1">
                  လျှို့ဝှက်နံပါတ် အသစ် (New Password)
                </label>
                <div className="relative">
                  <input
                    type={showNewPass ? 'text' : 'password'}
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full h-10 px-3 pr-10 rounded-xl bg-black border border-amber-400/50 text-white text-sm focus:outline-none focus:ring-1 focus:ring-amber-400"
                    id="new-password-input"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowNewPass(!showNewPass)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-amber-400/70 hover:text-amber-300"
                  >
                    {showNewPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-amber-400 text-xs font-medium mb-1">
                  လျှို့ဝှက်နံပါတ် အသစ် အတည်ပြုပါ (Confirm New Password)
                </label>
                <div className="relative">
                  <input
                    type={showConfirmPass ? 'text' : 'password'}
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full h-10 px-3 pr-10 rounded-xl bg-black border border-amber-400/50 text-white text-sm focus:outline-none focus:ring-1 focus:ring-amber-400"
                    id="confirm-password-input"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowConfirmPass(!showConfirmPass)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-amber-400/70 hover:text-amber-300"
                  >
                    {showConfirmPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsPasswordModalOpen(false)}
                  disabled={pwdLoading}
                  className="flex-1 py-2.5 rounded-xl bg-zinc-800 text-xs font-semibold text-zinc-300 hover:bg-zinc-700 transition"
                >
                  မလုပ်တော့ပါ
                </button>
                <button
                  type="submit"
                  disabled={pwdLoading}
                  className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 text-xs font-bold text-black shadow-lg hover:brightness-105 active:scale-95 transition disabled:opacity-60 flex items-center justify-center gap-1.5"
                  id="confirm-change-password-btn"
                >
                  {pwdLoading ? (
                    <>
                      <span className="w-3.5 h-3.5 border-2 border-black border-t-transparent rounded-full animate-spin" />
                      <span>စောင့်ပါ...</span>
                    </>
                  ) : (
                    <span>ပြောင်းလဲမည်</span>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {editingField && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-sm">
          <div className="w-full max-w-xs rounded-2xl border border-amber-400/50 bg-[#14120c] p-5 shadow-2xl space-y-4">
            <h4 className="text-sm font-bold text-amber-300">
              {editingField === 'name' ? 'နာမည် ပြင်ဆင်ရန်' : editingField === 'phone' ? 'ဖုန်းနံပါတ် ပြင်ဆင်ရန်' : 'အေးဂျင့်ကုဒ်'}
            </h4>
            <input
              type="text"
              value={editValue}
              onChange={(e) => setEditValue(e.target.value)}
              className="w-full h-10 px-3 rounded-xl bg-black border border-amber-400/50 text-white text-sm focus:outline-none focus:ring-1 focus:ring-amber-400"
              autoFocus
            />
            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => setEditingField(null)}
                className="flex-1 py-2 rounded-xl bg-zinc-800 text-xs font-semibold text-zinc-300 hover:bg-zinc-700"
              >
                မလုပ်တော့ပါ
              </button>
              <button
                type="button"
                onClick={saveEdit}
                className="flex-1 py-2 rounded-xl bg-amber-400 text-xs font-bold text-black hover:bg-amber-300"
              >
                သိမ်းမည်
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="pt-2 flex flex-col items-center gap-3">
        <button
          type="button"
          onClick={logout}
          className="w-48 h-11 rounded-full bg-gradient-to-r from-red-600 via-red-500 to-rose-600 text-white font-bold text-sm shadow-[0_4px_16px_rgba(239,68,68,0.4)] hover:brightness-110 active:scale-95 transition flex items-center justify-center gap-2 cursor-pointer"
          id="profile-logout-btn"
        >
          <LogOut className="w-4 h-4" />
          <span>အကောင့်ထွက်မည်</span>
        </button>
      </div>
    </div>
  );
};
