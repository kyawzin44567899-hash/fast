'use client';

import React from 'react';
import Image from 'next/image';

interface GoldEmblemProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showText?: boolean;
  className?: string;
}

export const GoldEmblem: React.FC<GoldEmblemProps> = ({
  size = 'md',
  showText = true,
  className = '',
}) => {
  const dimensionMap = {
    sm: 48,
    md: 96,
    lg: 140,
    xl: 190,
  };

  const dim = dimensionMap[size];

  return (
    <div className={`flex flex-col items-center justify-center select-none ${className}`}>
      <div className="relative flex items-center justify-center">
        <div
          className="absolute rounded-full filter blur-xl opacity-40 bg-gradient-to-tr from-amber-600 via-yellow-400 to-amber-200 pointer-events-none"
          style={{ width: dim * 0.9, height: dim * 0.9 }}
        />

        <div
          className="relative overflow-hidden rounded-full border border-amber-400/40 shadow-2xl bg-black"
          style={{ width: dim, height: dim }}
        >
          <Image
            src="/images/logo.png"
            alt="Fast 2D3D Logo"
            width={dim}
            height={dim}
            className="w-full h-full object-cover"
            priority
            onError={(e) => {
              (e.currentTarget as HTMLElement).style.display = 'none';
            }}
          />
        </div>
      </div>

      {showText && (
        <div className="mt-2 text-center">
          <span
            className="font-black tracking-wider text-transparent bg-clip-text bg-gradient-to-b from-[#ffea75] via-[#e5b22b] to-[#99650b] drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)]"
            style={{
              fontSize: size === 'sm' ? '1.1rem' : size === 'md' ? '1.75rem' : size === 'lg' ? '2.4rem' : '3.2rem',
              letterSpacing: '0.05em',
            }}
          >
            2D3D
          </span>
        </div>
      )}
    </div>
  );
};
