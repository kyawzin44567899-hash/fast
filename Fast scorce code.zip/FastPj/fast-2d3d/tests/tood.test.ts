import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  TOOD_MULTIPLIER,
  isTood,
  normalize3D,
  getPayoutMultiplier,
  payoutTransactionId,
} from '../lib/tood.js';
import { computeWin, splitShares, computeAgentTotals } from '../lib/payout.js';
import { normalizeResultDate, getMyanmarDate } from '../lib/date.js';

const TOOD_CASES = ['112', '121', '211', '011', '100', '232', '322'];
const NOT_TOOD_CASES = ['123', '456', '111', '000', '999', '0010'];

test('isTood detects exactly two identical digits', () => {
  for (const n of TOOD_CASES) {
    assert.equal(isTood(n), true, `${n} should be Tood`);
  }
});

test('isTood rejects non-Tood and triple numbers', () => {
  for (const n of NOT_TOOD_CASES) {
    assert.equal(isTood(n), false, `${n} should NOT be Tood`);
  }
});

test('normalize3D preserves leading zero as a 3-digit string', () => {
  assert.equal(normalize3D('011'), '011');
  assert.equal(normalize3D('11'), '011');
  assert.equal(normalize3D(11), '011');
  assert.equal(isTood('011'), true);
});

test('getPayoutMultiplier uses x10 for Tood results and keeps base otherwise', () => {
  assert.deepEqual(getPayoutMultiplier('3D', '122', 550), {
    multiplier: TOOD_MULTIPLIER,
    isToodResult: true,
  });
  assert.deepEqual(getPayoutMultiplier('3D', '111', 550), {
    multiplier: 550,
    isToodResult: false,
  });
  assert.deepEqual(getPayoutMultiplier('3D', '123', 550), {
    multiplier: 550,
    isToodResult: false,
  });
  assert.deepEqual(getPayoutMultiplier('2D', '122', 85), {
    multiplier: 85,
    isToodResult: false,
  });
});

test('Tood payout is bet_amount x 10', () => {
  const win = computeWin(
    '122',
    [{ number: '122', amount: 100, subNumbers: [{ number: '122', amount: 100 }] }],
    [],
    100,
    TOOD_MULTIPLIER
  );
  assert.equal(win.matched, true);
  assert.equal(win.totalWin, 1000);

  const win500 = computeWin(
    '122',
    [{ number: '122', amount: 500, subNumbers: [{ number: '122', amount: 500 }] }],
    [],
    500,
    TOOD_MULTIPLIER
  );
  assert.equal(win500.totalWin, 5000);

  const win1000 = computeWin(
    '122',
    [{ number: '122', amount: 1000, subNumbers: [{ number: '122', amount: 1000 }] }],
    [],
    1000,
    TOOD_MULTIPLIER
  );
  assert.equal(win1000.totalWin, 10000);
});

test('non-matching numbers do not win', () => {
  const items = [
    { number: '121', amount: 100, subNumbers: [{ number: '121', amount: 100 }] },
    { number: '123', amount: 100, subNumbers: [{ number: '123', amount: 100 }] },
  ];
  const win = computeWin('122', items, [], 200, TOOD_MULTIPLIER);
  assert.equal(win.matched, false);
  assert.equal(win.totalWin, 0);
});

test('multiple qualifying subNumbers are summed independently', () => {
  const items = [
    {
      number: '122 (R)',
      amount: 300,
      subNumbers: [
        { number: '122', amount: 100 },
        { number: '212', amount: 100 },
        { number: '221', amount: 100 },
      ],
    },
  ];
  const win = computeWin('122', items, [], 300, TOOD_MULTIPLIER);
  assert.equal(win.matched, true);
  assert.equal(win.totalWin, 1000);
});

test('agent commission split applies to winning and losing', () => {
  const lose = computeAgentTotals({ totalBet: 100000, totalWin: 0, totalLoss: 100000, agentPercent: 40 });
  assert.equal(lose.netBalance, 100000);
  assert.equal(lose.agentShare, 40000);
  assert.equal(lose.adminShare, 60000);
  assert.equal(lose.settlementAmount, 40000);

  const win = computeAgentTotals({ totalBet: 100000, totalWin: 100000, totalLoss: 0, agentPercent: 40 });
  assert.equal(win.netBalance, -100000);
  assert.equal(win.agentShare, -40000);
  assert.equal(win.adminShare, -60000);

  const mixed = computeAgentTotals({ totalBet: 200000, totalWin: 50000, totalLoss: 150000, agentPercent: 40 });
  assert.equal(mixed.netBalance, 100000);
  assert.equal(mixed.agentShare, 40000);
  assert.equal(mixed.adminShare, 60000);
});

test('agent percentage is configurable (30/70 and 20/80)', () => {
  const t30 = computeAgentTotals({ totalBet: 100000, totalWin: 0, totalLoss: 100000, agentPercent: 30 });
  assert.equal(t30.agentShare, 30000);
  assert.equal(t30.adminShare, 70000);

  const t20 = computeAgentTotals({ totalBet: 100000, totalWin: 0, totalLoss: 100000, agentPercent: 20 });
  assert.equal(t20.agentShare, 20000);
  assert.equal(t20.adminShare, 80000);

  const clamp = computeAgentTotals({ totalBet: 0, totalWin: 0, totalLoss: 100, agentPercent: 150 });
  assert.equal(clamp.agentPercent, 100);
  assert.equal(clamp.agentShare, 100);
  assert.equal(clamp.adminShare, 0);
});

test('splitShares splits a single payout by configured percentage', () => {
  assert.deepEqual(splitShares(1000, 40), { agentPercent: 40, agentShare: 400, adminShare: 600 });
  assert.deepEqual(splitShares(0, 40), { agentPercent: 40, agentShare: 0, adminShare: 0 });
});

test('result dates are normalized so different days do not collide', () => {
  assert.equal(normalizeResultDate('2026-09-17'), '2026-09-17');
  assert.equal(normalizeResultDate('2026-09-18T12:00:00Z'), '2026-09-18');
  assert.equal(normalizeResultDate(''), getMyanmarDate());
  assert.equal(normalizeResultDate(null), getMyanmarDate());
  assert.notEqual(normalizeResultDate('2026-09-17'), normalizeResultDate('2026-09-18'));
});

test('payout transaction id is stable per bet for idempotency', () => {
  assert.equal(payoutTransactionId('bet-1', true), 'tx-tood-bet-1');
  assert.equal(payoutTransactionId('bet-1', true), payoutTransactionId('bet-1', true));
  assert.notEqual(payoutTransactionId('bet-1', true), payoutTransactionId('bet-2', true));
  assert.equal(payoutTransactionId('bet-1', false), 'tx-win-bet-1');
});
