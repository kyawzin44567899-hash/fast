'use client';

import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import {
  Zap,
  ShieldCheck,
  Headphones,
  TrendingUp,
  ArrowRight,
  CheckCircle2,
} from 'lucide-react';

export default function Fast2D3DLandingPage() {
  const [myanmarTime, setMyanmarTime] = useState<string>('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      // Format to Myanmar time (UTC+6:30) or local formatted time
      const timeStr = new Intl.DateTimeFormat('en-US', {
        timeZone: 'Asia/Yangon',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: true,
      }).format(now);
      setMyanmarTime(timeStr);
    };

    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <main
      id="fast2d3d-landing-container"
      className="relative min-h-screen w-full flex flex-col justify-between items-center px-4 sm:px-6 lg:px-8 py-6 sm:py-8 overflow-hidden bg-[#070A12]"
    >
      {/* Background Ambient Glow & Subtle Pattern */}
      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        {/* Radial Top Glow (Warm Amber & Emerald Gold) */}
        <div className="absolute -top-40 left-1/2 -translate-x-1/2 w-[700px] sm:w-[900px] h-[450px] bg-gradient-to-b from-amber-500/15 via-amber-600/5 to-transparent rounded-full blur-3xl opacity-70" />
        
        {/* Secondary subtle glow */}
        <div className="absolute -bottom-40 left-1/2 -translate-x-1/2 w-[600px] h-[350px] bg-gradient-to-t from-emerald-500/10 via-emerald-600/5 to-transparent rounded-full blur-3xl opacity-60" />

        {/* Subtle geometric dot grid overlay */}
        <div
          className="absolute inset-0 opacity-[0.04]"
          style={{
            backgroundImage:
              'radial-gradient(circle at 1px 1px, #f59e0b 1px, transparent 0)',
            backgroundSize: '32px 32px',
          }}
        />
      </div>

      {/* Header bar within the single section */}
      <header
        id="landing-header"
        className="relative z-10 w-full max-w-5xl flex items-center justify-between py-2 border-b border-white/5"
      >
        {/* Brand Logo & Name */}
        <div id="brand-logo-container" className="flex items-center gap-3">
          <div
            id="brand-icon-box"
            className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-400 via-amber-500 to-yellow-600 p-[1px] shadow-lg shadow-amber-500/20"
          >
            <div className="w-full h-full bg-slate-950/85 backdrop-blur-sm rounded-[11px] flex items-center justify-center overflow-hidden">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src="/images/logo.png"
                alt="Fast 2D3D"
                className="w-full h-full object-contain"
              />
            </div>
          </div>
          <div className="flex flex-col">
            <span
              id="brand-name"
              className="text-lg sm:text-xl font-extrabold tracking-tight text-white flex items-center gap-1.5"
            >
              FAST <span className="text-amber-400 font-black">2D3D</span>
            </span>
            <span className="text-[10px] text-amber-300/80 font-medium tracking-wider uppercase">
              Official Platform
            </span>
          </div>
        </div>

        {/* Live Status Pill */}
        <div
          id="live-status-indicator"
          className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-amber-950/40 border border-amber-500/20 backdrop-blur-md text-xs text-amber-300 shadow-sm"
        >
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
          </span>
          <span className="font-semibold text-white/90">LIVE 2D/3D</span>
          {myanmarTime && (
            <span className="hidden sm:inline-block text-slate-400 border-l border-white/10 pl-2">
              {myanmarTime} (MMT)
            </span>
          )}
        </div>
      </header>

      {/* Main Single Section Body / Hero Section */}
      <section
        id="hero-main-section"
        className="relative z-10 w-full max-w-4xl flex-1 flex flex-col items-center justify-center text-center my-auto py-8 sm:py-12"
      >
        <motion.div
          initial={{ opacity: 0, y: 18 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: 'easeOut' }}
          className="flex flex-col items-center w-full"
        >
          {/* Main Display Headline */}
          <h1
            id="hero-headline"
            className="text-4xl sm:text-6xl md:text-7xl font-black tracking-tight text-white leading-[1.1] max-w-3xl mb-4"
          >
            FAST{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-amber-300 via-amber-400 to-yellow-500">
              2D3D
            </span>
          </h1>

          {/* Subtitle / Tagline */}
          <p
            id="hero-subheading"
            className="text-slate-300 text-base sm:text-xl font-normal max-w-2xl leading-relaxed mb-8 px-2"
          >
            တိကျမြန်ဆန်သော ထိုင်းစတော့ခ် 2D / 3D တိုက်ရိုက်ပေါက်ဂဏန်းများနှင့်
            ယုံကြည်စိတ်ချရဆုံး အလျော်အစားများကို တစ်နေရာတည်းတွင် ရယူလိုက်ပါ။
          </p>

          {/* THE CTA BUTTON: 'ကစားမည်' to 'app.fast2d3d.com' */}
          <motion.div
            whileHover={{ scale: 1.04 }}
            whileTap={{ scale: 0.97 }}
            className="w-full sm:w-auto flex justify-center mb-10"
          >
            <a
              id="play-now-cta-btn"
              href="https://app.fast2d3d.com"
              target="_blank"
              rel="noopener noreferrer"
              className="group relative inline-flex items-center justify-center gap-3 px-10 sm:px-14 py-4 sm:py-5 w-full sm:w-auto text-xl sm:text-2xl font-extrabold text-slate-950 bg-gradient-to-r from-amber-400 via-amber-300 to-yellow-400 hover:from-amber-300 hover:to-yellow-300 rounded-2xl shadow-[0_0_35px_rgba(245,158,11,0.4)] hover:shadow-[0_0_55px_rgba(245,158,11,0.65)] transition-all duration-300 focus:outline-none focus:ring-4 focus:ring-amber-400/40"
            >
              {/* Shimmer light effect inside button */}
              <span className="absolute inset-0 w-full h-full rounded-2xl bg-white/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none" />
              
              <span className="relative tracking-wide font-black drop-shadow-sm">
                ကစားမည်
              </span>
              <ArrowRight className="relative w-6 h-6 text-slate-950 transition-transform duration-300 group-hover:translate-x-1.5" />
            </a>
          </motion.div>

          {/* Target link preview pill */}
          <div
            id="domain-indicator"
            className="inline-flex items-center gap-2 text-xs sm:text-sm text-slate-400 bg-white/[0.03] border border-white/10 px-4 py-1.5 rounded-full mb-10"
          >
            <span className="text-amber-400 font-medium">Link:</span>
            <span className="text-slate-200 font-mono">app.fast2d3d.com</span>
          </div>

          {/* Trust Highlights Grid - Compact within single section */}
          <div
            id="features-highlights"
            className="w-full max-w-3xl grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4 text-left"
          >
            <div
              id="feature-instant-payout"
              className="p-3.5 sm:p-4 rounded-xl bg-white/[0.03] border border-white/5 backdrop-blur-sm hover:border-amber-500/20 transition-colors"
            >
              <div className="flex items-center gap-2 mb-1.5">
                <Zap className="w-4 h-4 text-amber-400 shrink-0" />
                <span className="text-xs sm:text-sm font-bold text-white">လျင်မြန်မှု</span>
              </div>
              <p className="text-[11px] sm:text-xs text-slate-400 leading-snug">
                ငွေသွင်း/ငွေထုတ် စက္ကန့်ပိုင်းအတွင်း
              </p>
            </div>

            <div
              id="feature-live-results"
              className="p-3.5 sm:p-4 rounded-xl bg-white/[0.03] border border-white/5 backdrop-blur-sm hover:border-amber-500/20 transition-colors"
            >
              <div className="flex items-center gap-2 mb-1.5">
                <TrendingUp className="w-4 h-4 text-emerald-400 shrink-0" />
                <span className="text-xs sm:text-sm font-bold text-white">တိုက်ရိုက်ပေါက်</span>
              </div>
              <p className="text-[11px] sm:text-xs text-slate-400 leading-snug">
                ထိုင်း SET Index တိကျမှန်ကန်
              </p>
            </div>

            <div
              id="feature-secure-platform"
              className="p-3.5 sm:p-4 rounded-xl bg-white/[0.03] border border-white/5 backdrop-blur-sm hover:border-amber-500/20 transition-colors"
            >
              <div className="flex items-center gap-2 mb-1.5">
                <ShieldCheck className="w-4 h-4 text-blue-400 shrink-0" />
                <span className="text-xs sm:text-sm font-bold text-white">၁၀၀% စိတ်ချရ</span>
              </div>
              <p className="text-[11px] sm:text-xs text-slate-400 leading-snug">
                လုံခြုံစိတ်ချရသော စနစ်
              </p>
            </div>

            <div
              id="feature-support-24-7"
              className="p-3.5 sm:p-4 rounded-xl bg-white/[0.03] border border-white/5 backdrop-blur-sm hover:border-amber-500/20 transition-colors"
            >
              <div className="flex items-center gap-2 mb-1.5">
                <Headphones className="w-4 h-4 text-purple-400 shrink-0" />
                <span className="text-xs sm:text-sm font-bold text-white">၂၄ နာရီ</span>
              </div>
              <p className="text-[11px] sm:text-xs text-slate-400 leading-snug">
                အဆင်သင့် အကူအညီ ဝန်ဆောင်မှု
              </p>
            </div>
          </div>
        </motion.div>
      </section>

      {/* Footer bar within the single section */}
      <footer
        id="landing-footer"
        className="relative z-10 w-full max-w-5xl flex flex-col sm:flex-row items-center justify-between gap-3 pt-4 border-t border-white/5 text-xs text-slate-500"
      >
        <div id="footer-copyright" className="flex items-center gap-1.5">
          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
          <span>© 2026 Fast 2D3D Official. All rights reserved.</span>
        </div>

        <div id="footer-direct-action" className="flex items-center gap-2">
          <span className="text-slate-400">တိုက်ရိုက်အက်ပ်လိပ်စာ:</span>
          <a
            id="footer-domain-link"
            href="https://app.fast2d3d.com"
            target="_blank"
            rel="noopener noreferrer"
            className="text-amber-400 hover:text-amber-300 underline underline-offset-4 font-mono transition-colors"
          >
            app.fast2d3d.com
          </a>
        </div>
      </footer>
    </main>
  );
}
