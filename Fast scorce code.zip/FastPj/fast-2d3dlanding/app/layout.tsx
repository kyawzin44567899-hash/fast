import type {Metadata} from 'next';
import { Plus_Jakarta_Sans } from 'next/font/google';
import './globals.css';

const plusJakartaSans = Plus_Jakarta_Sans({
  subsets: ['latin'],
  display: 'swap',
  variable: '--font-sans',
});

export const metadata: Metadata = {
  title: 'Fast 2D3D',
  description: 'Fast 2D3D official landing page with instant access to 2D and 3D live results and gaming.',
  icons: {
    icon: '/favicon.ico',
    apple: '/images/logo.png',
  },
  openGraph: {
    title: 'Fast 2D3D',
    description: 'Fast 2D3D official landing page with instant access to 2D and 3D live results and gaming.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Fast 2D3D',
    description: 'Fast 2D3D official landing page with instant access to 2D and 3D live results and gaming.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="my" className={plusJakartaSans.variable}>
      <body
        className="antialiased font-sans bg-[#080B12] text-slate-100 selection:bg-amber-500 selection:text-black overflow-x-hidden min-h-screen"
        suppressHydrationWarning
      >
        {children}
      </body>
    </html>
  );
}
