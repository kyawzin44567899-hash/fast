import { NextRequest } from 'next/server';
import { sql } from './db';

export function getClientIp(req: NextRequest): string {
  const xff = req.headers.get('x-forwarded-for');
  if (xff) return xff.split(',')[0].trim();
  return (
    req.headers.get('x-real-ip') ||
    req.headers.get('cf-connecting-ip') ||
    'unknown'
  );
}

export function parseDevice(userAgent: string): string {
  const ua = (userAgent || '').toLowerCase();
  let os = 'Unknown OS';
  if (ua.includes('android')) os = 'Android';
  else if (ua.includes('iphone') || ua.includes('ipad') || ua.includes('ipod')) os = 'iOS';
  else if (ua.includes('windows')) os = 'Windows';
  else if (ua.includes('mac os') || ua.includes('macintosh')) os = 'macOS';
  else if (ua.includes('linux')) os = 'Linux';

  let browser = 'Browser';
  if (ua.includes('edg/')) browser = 'Edge';
  else if (ua.includes('opr/') || ua.includes('opera')) browser = 'Opera';
  else if (ua.includes('chrome') && !ua.includes('edg')) browser = 'Chrome';
  else if (ua.includes('firefox')) browser = 'Firefox';
  else if (ua.includes('safari')) browser = 'Safari';

  const mobile = ua.includes('mobile') || ua.includes('android') || ua.includes('iphone');
  return `${browser} on ${os}${mobile ? ' (Mobile)' : ''}`;
}

export async function recordLogin(
  req: NextRequest,
  actorType: 'admin' | 'agent',
  actorId: string,
  actorName: string
): Promise<void> {
  const userAgent = req.headers.get('user-agent') || '';
  const ip = getClientIp(req);
  const device = parseDevice(userAgent);
  try {
    await sql`
      INSERT INTO login_history (actor_type, actor_id, actor_name, device, user_agent, ip)
      VALUES (${actorType}, ${actorId}, ${actorName}, ${device}, ${userAgent}, ${ip});
    `;
  } catch (err) {
    console.error('Failed to record login history:', err);
  }
}
