import webpush from 'web-push';
import { sql } from './db';

let configured = false;

function ensureConfigured(): boolean {
  if (configured) return true;
  const publicKey = process.env.NEXT_PUBLIC_VAPID_PUBLIC_KEY;
  const privateKey = process.env.VAPID_PRIVATE_KEY;
  const subject = process.env.VAPID_SUBJECT || 'mailto:admin@fast2d3d.com';
  if (!publicKey || !privateKey) return false;
  webpush.setVapidDetails(subject, publicKey, privateKey);
  configured = true;
  return true;
}

export interface PushPayload {
  title: string;
  body: string;
  url?: string;
  data?: Record<string, unknown>;
}

export async function sendPushToTarget(
  targetType: string,
  targetId: string | null,
  payload: PushPayload
): Promise<void> {
  if (!ensureConfigured()) return;
  try {
    const subs = targetId
      ? await sql`
          SELECT endpoint, p256dh, auth FROM push_subscriptions
          WHERE target_type = ${targetType} AND target_id = ${targetId};
        `
      : await sql`
          SELECT endpoint, p256dh, auth FROM push_subscriptions
          WHERE target_type = ${targetType};
        `;

    await Promise.all(
      (subs || []).map(async (row) => {
        const sub = row as { endpoint: string; p256dh: string; auth: string };
        try {
          await webpush.sendNotification(
            { endpoint: sub.endpoint, keys: { p256dh: sub.p256dh, auth: sub.auth } },
            JSON.stringify(payload)
          );
        } catch (err: unknown) {
          const statusCode = (err as { statusCode?: number }).statusCode;
          if (statusCode === 404 || statusCode === 410) {
            await sql`DELETE FROM push_subscriptions WHERE endpoint = ${sub.endpoint};`;
          }
        }
      })
    );
  } catch (err) {
    console.error('Push send failed:', err);
  }
}
