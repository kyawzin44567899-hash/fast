import { sql } from './db';
import { sendPushToTarget } from './push';

export type NotificationTarget = 'user' | 'agent' | 'admin' | 'all';

export interface NotificationInput {
  targetType: NotificationTarget;
  targetId?: string | null;
  type?: string;
  title: string;
  message: string;
  data?: Record<string, unknown>;
  ttlHours?: number;
}

export interface NotificationRow {
  id: string;
  target_type: string;
  target_id: string | null;
  type: string;
  title: string;
  message: string;
  data: Record<string, unknown> | null;
  is_read: boolean;
  created_at: string;
  expires_at: string;
}

export async function createNotification(input: NotificationInput): Promise<NotificationRow | null> {
  try {
    const id = `ntf-${Date.now()}-${Math.floor(Math.random() * 100000)}`;
    const ttlHours = input.ttlHours ?? 48;
    const expiresAt = new Date(Date.now() + ttlHours * 60 * 60 * 1000).toISOString();

    const rows = await sql`
      INSERT INTO notifications (id, target_type, target_id, type, title, message, data, expires_at)
      VALUES (${id}, ${input.targetType}, ${input.targetId ?? null}, ${input.type ?? 'info'},
              ${input.title}, ${input.message}, ${JSON.stringify(input.data ?? {})}, ${expiresAt})
      RETURNING id, target_type, target_id, type, title, message, data, is_read, created_at, expires_at;
    `;

    const row = rows?.[0] as NotificationRow | undefined;

    void sendPushToTarget(input.targetType, input.targetId ?? null, {
      title: input.title,
      body: input.message,
      url: typeof input.data?.url === 'string' ? (input.data.url as string) : undefined,
      data: input.data ?? {},
    });

    return row ?? null;
  } catch (err) {
    console.error('createNotification failed:', err);
    return null;
  }
}

export async function listNotifications(
  targetType: NotificationTarget,
  targetId: string | null
): Promise<NotificationRow[]> {
  const rows = await sql`
    SELECT id, target_type, target_id, type, title, message, data, is_read, created_at, expires_at
    FROM notifications
    WHERE expires_at > NOW()
      AND (
        target_type = 'all'
        OR (target_type = ${targetType} AND target_id = ${targetId})
        OR (target_type = ${targetType} AND target_id IS NULL)
      )
    ORDER BY created_at DESC
    LIMIT 50;
  `;
  return (rows || []) as unknown as NotificationRow[];
}

export async function markNotificationRead(
  id: string,
  targetType: NotificationTarget,
  targetId: string | null
): Promise<boolean> {
  const rows = await sql`
    UPDATE notifications SET is_read = TRUE
    WHERE id = ${id}
      AND (
        target_type = 'all'
        OR (target_type = ${targetType} AND (target_id = ${targetId} OR target_id IS NULL))
      )
    RETURNING id;
  `;
  return Boolean(rows && rows.length > 0);
}

export async function markAllNotificationsRead(
  targetType: NotificationTarget,
  targetId: string | null
): Promise<void> {
  await sql`
    UPDATE notifications SET is_read = TRUE
    WHERE is_read = FALSE
      AND expires_at > NOW()
      AND (
        target_type = 'all'
        OR (target_type = ${targetType} AND (target_id = ${targetId} OR target_id IS NULL))
      );
  `;
}
