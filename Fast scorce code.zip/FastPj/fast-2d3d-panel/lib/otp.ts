import crypto from 'crypto';
import bcrypt from 'bcryptjs';
import { sql } from './db';

const OTP_TTL_MS = 10 * 60 * 1000;
const MAX_ATTEMPTS = 5;
const REQUEST_COOLDOWN_MS = 60 * 1000;
const MAX_REQUESTS_PER_HOUR = 5;

export function generateOtp(): string {
  return String(crypto.randomInt(0, 1_000_000)).padStart(6, '0');
}

export interface OtpRequestResult {
  ok: boolean;
  error?: 'cooldown' | 'rate_limited';
  otp?: string;
  expiresInMinutes?: number;
}

export async function createOtp(
  targetType: string,
  targetId: string,
  email: string,
  name: string
): Promise<OtpRequestResult> {
  const recent = await sql`
    SELECT created_at FROM otp_codes
    WHERE email = ${email}
    ORDER BY created_at DESC
    LIMIT 1;
  `;

  if (recent && recent.length > 0) {
    const last = new Date((recent[0] as { created_at: string }).created_at).getTime();
    if (Date.now() - last < REQUEST_COOLDOWN_MS) {
      return { ok: false, error: 'cooldown' };
    }
  }

  const hourly = await sql`
    SELECT COUNT(*)::int AS c FROM otp_codes
    WHERE email = ${email} AND created_at > NOW() - INTERVAL '1 hour';
  `;
  if (Number((hourly[0] as { c: number }).c) >= MAX_REQUESTS_PER_HOUR) {
    return { ok: false, error: 'rate_limited' };
  }

  const otp = generateOtp();
  const otpHash = await bcrypt.hash(otp, 10);
  const expiresAt = new Date(Date.now() + OTP_TTL_MS).toISOString();

  await sql`
    INSERT INTO otp_codes (target_type, target_id, email, name, otp_hash, expires_at)
    VALUES (${targetType}, ${targetId}, ${email}, ${name}, ${otpHash}, ${expiresAt});
  `;

  return { ok: true, otp, expiresInMinutes: Math.round(OTP_TTL_MS / 60000) };
}

export async function createAgentOtp(
  agentId: number,
  email: string,
  name: string
): Promise<OtpRequestResult> {
  return createOtp('agent', String(agentId), email, name);
}

export type OtpVerifyError = 'not_found' | 'expired' | 'locked' | 'invalid';

export async function verifyAgentOtp(
  email: string,
  otp: string
): Promise<{ ok: boolean; error?: OtpVerifyError; agentId?: number }> {
  const rows = await sql`
    SELECT id, target_id, otp_hash, expires_at, attempt_count
    FROM otp_codes
    WHERE email = ${email} AND target_type = 'agent'
    ORDER BY created_at DESC
    LIMIT 1;
  `;

  if (!rows || rows.length === 0) return { ok: false, error: 'not_found' };

  const row = rows[0] as {
    id: number;
    target_id: string;
    otp_hash: string;
    expires_at: string;
    attempt_count: number;
  };

  if (new Date(row.expires_at).getTime() < Date.now()) {
    await sql`DELETE FROM otp_codes WHERE id = ${row.id};`;
    return { ok: false, error: 'expired' };
  }

  if (Number(row.attempt_count) >= MAX_ATTEMPTS) {
    await sql`DELETE FROM otp_codes WHERE id = ${row.id};`;
    return { ok: false, error: 'locked' };
  }

  const match = await bcrypt.compare(otp, row.otp_hash);
  if (!match) {
    await sql`UPDATE otp_codes SET attempt_count = attempt_count + 1 WHERE id = ${row.id};`;
    return { ok: false, error: 'invalid' };
  }

  await sql`DELETE FROM otp_codes WHERE email = ${email};`;
  return { ok: true, agentId: Number(row.target_id) };
}
