export const TOOD_MULTIPLIER = 10;

export function normalize3D(value: unknown): string {
  const digits = String(value ?? '').replace(/\D/g, '');
  if (digits.length === 0 || digits.length > 3) return '';
  return digits.padStart(3, '0');
}

export function isTood(value: unknown): boolean {
  const num = normalize3D(value);
  if (num.length !== 3) return false;
  const [a, b, c] = num;
  if (a === b && b === c) return false;
  return a === b || b === c || a === c;
}

export function payoutTransactionId(betId: string, isToodResult: boolean): string {
  return isToodResult ? `tx-tood-${betId}` : `tx-win-${betId}`;
}
