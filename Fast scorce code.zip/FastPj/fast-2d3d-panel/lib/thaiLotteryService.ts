import { Thai2DLiveResponse, Thai3DResponse, Thai2DHistoryItem, ShwelaminTwodResponse, SetLiveData } from './types';

function cleanJsonText(raw: string): string {
  const jsonStart = raw.search(/[{\[]/);
  if (jsonStart !== -1) {
    return raw.slice(jsonStart);
  }
  return raw;
}

export async function fetchThai2DLive(): Promise<Thai2DLiveResponse | null> {

  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 5000);
    const directRes = await fetch('https://api.thaistock2d.com/live', {
      cache: 'no-store',
      signal: controller.signal,
    });
    clearTimeout(timeoutId);
    if (directRes.ok) {
      const rawText = await directRes.text();
      const cleaned = cleanJsonText(rawText);
      return JSON.parse(cleaned);
    }
  } catch {

  }

  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 5000);
    const res = await fetch('/api/thai2d/live', {
      cache: 'no-store',
      signal: controller.signal,
    });
    clearTimeout(timeoutId);
    if (res.ok) {
      return await res.json();
    }
  } catch {

  }

  return null;
}

export async function fetchThai2DResults(date?: string): Promise<any> {

  try {
    const directUrl = date
      ? `https://api.thaistock2d.com/2d_result?date=${encodeURIComponent(date)}`
      : 'https://api.thaistock2d.com/2d_result';
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 6000);
    const directRes = await fetch(directUrl, {
      cache: 'no-store',
      signal: controller.signal,
    });
    clearTimeout(timeoutId);
    if (directRes.ok) {
      const rawText = await directRes.text();
      const cleaned = cleanJsonText(rawText);
      return JSON.parse(cleaned);
    }
  } catch {

  }

  try {
    const url = date ? `/api/thai2d/results?date=${encodeURIComponent(date)}` : '/api/thai2d/results';
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 6000);
    const res = await fetch(url, {
      cache: 'no-store',
      signal: controller.signal,
    });
    clearTimeout(timeoutId);
    if (res.ok) {
      return await res.json();
    }
  } catch {

  }

  return null;
}

export async function fetchThai2DHistory(date?: string, twod?: string): Promise<Thai2DHistoryItem[] | null> {

  try {
    let directUrl = 'https://api.thaistock2d.com/history';
    if (twod && date) {
      directUrl = `https://api.thaistock2d.com/2d_history?twod=${encodeURIComponent(twod)}&date=${encodeURIComponent(date)}`;
    } else if (date) {
      directUrl = `https://api.thaistock2d.com/history?date=${encodeURIComponent(date)}`;
    }
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 6000);
    const directRes = await fetch(directUrl, {
      cache: 'no-store',
      signal: controller.signal,
    });
    clearTimeout(timeoutId);
    if (directRes.ok) {
      const rawText = await directRes.text();
      const cleaned = cleanJsonText(rawText);
      return JSON.parse(cleaned);
    }
  } catch {

  }

  try {
    const params = new URLSearchParams();
    if (date) params.set('date', date);
    if (twod) params.set('twod', twod);
    const queryString = params.toString();
    const url = queryString ? `/api/thai2d/history?${queryString}` : '/api/thai2d/history';
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 6000);
    const res = await fetch(url, {
      cache: 'no-store',
      signal: controller.signal,
    });
    clearTimeout(timeoutId);
    if (res.ok) {
      return await res.json();
    }
  } catch {

  }

  return null;
}

export async function fetchThai3DResults(): Promise<Thai3DResponse | null> {

  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 5000);
    const directRes = await fetch('https://api.2dboss.com/api/v2/v1/2dstock/threed-result', {
      cache: 'no-store',
      signal: controller.signal,
    });
    clearTimeout(timeoutId);
    if (directRes.ok) {
      const rawText = await directRes.text();
      const cleaned = cleanJsonText(rawText);
      return JSON.parse(cleaned);
    }
  } catch {

  }

  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 5000);
    const res = await fetch('/api/thai3d/results', {
      cache: 'no-store',
      signal: controller.signal,
    });
    clearTimeout(timeoutId);
    if (res.ok) {
      return await res.json();
    }
  } catch {

  }

  return null;
}

export async function fetchShwelaminTwod(): Promise<ShwelaminTwodResponse | null> {
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 6000);
    const directRes = await fetch('https://backend.shwelamin.com/api/lv/twod-result', {
      cache: 'no-store',
      signal: controller.signal,
    });
    clearTimeout(timeoutId);
    if (directRes.ok) {
      const rawText = await directRes.text();
      const cleaned = cleanJsonText(rawText);
      return JSON.parse(cleaned);
    }
  } catch {

  }

  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 6000);
    const res = await fetch('/api/thai2d/twod-result', {
      cache: 'no-store',
      signal: controller.signal,
    });
    clearTimeout(timeoutId);
    if (res.ok) {
      return await res.json();
    }
  } catch {

  }

  return null;
}

const SETLIVE_KEYS = ['modern_930', 'internet_930', 'modern_200', 'internet_200'] as const;

function extractSetLiveFields(value: unknown, out: Record<string, string>, depth = 0): void {
  if (!value || typeof value !== 'object' || depth > 6) return;
  for (const [k, v] of Object.entries(value as Record<string, unknown>)) {
    if ((SETLIVE_KEYS as readonly string[]).includes(k)) {
      if (v !== null && v !== undefined) out[k] = String(v);
    } else if (v && typeof v === 'object') {
      extractSetLiveFields(v, out, depth + 1);
    }
  }
}

function parseSetLive(value: unknown): SetLiveData | null {
  if (!value) return null;
  const out: Record<string, string> = {};
  extractSetLiveFields(value, out);
  if (!SETLIVE_KEYS.some((k) => out[k])) return null;
  return {
    modern_930: out.modern_930 || '--',
    internet_930: out.internet_930 || '--',
    modern_200: out.modern_200 || '--',
    internet_200: out.internet_200 || '--',
  };
}

export async function fetchSetLiveModernInternet(): Promise<SetLiveData | null> {
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 6000);
    const res = await fetch('/api/thai2d/setlive', { cache: 'no-store', signal: controller.signal });
    clearTimeout(timeoutId);
    if (res.ok) {
      return parseSetLive(await res.json());
    }
  } catch {}

  return null;
}

