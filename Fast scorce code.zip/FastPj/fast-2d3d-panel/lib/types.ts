export type ScreenType =
  | 'welcome'
  | 'admin_login'
  | 'agent_login'
  | 'dashboard'
  | 'user_list'
  | 'agents_list'
  | 'transactions'
  | 'numbers_manage'
  | 'schedule'
  | 'ads'
  | 'winning_numbers'
  | 'live_feed'
  | 'bet_records'
  | 'win_bets'
  | 'agent_balance'
  | 'results_history';

export type BottomTabType = 'home' | 'website' | 'profile';

export type UserRole = 'admin' | 'agent';

export interface BetItem {
  number: string;
  amount: number;
  subNumbers?: { number: string; amount: number }[];
}

export interface BetRecord {
  id: string;
  voucherNo: string;
  userId: string;
  userName: string;
  userPhone: string;
  userUid: string;
  agentCode?: string;
  category: '2D' | '3D';
  timeSlot: string;
  dateFormatted: string;
  items: BetItem[];
  totalNumbers: number;
  multiplier: number;
  totalAmount: number;
  status: 'confirmed' | 'won' | 'lost' | 'pending';
  isTood?: boolean;
  winningNumber?: string;
  winAmount?: number;
  winDetails?: string;
  createdAt: string;
}

export interface AppUser {
  id: string;
  uid: string;
  name: string;
  phone: string;
  agentCode?: string;
  password?: string;
  balance: number;
  totalBets: number;
  status: 'active' | 'suspended';
  createdAt: string;
}

export interface AppAgent {
  id: string;
  name: string;
  code: string;
  email: string;
  phone: string;
  secretKey: string;
  commission: number;
  membersCount: number;
  balance: number;
  status: 'active' | 'suspended';
  createdAt: string;
}

export interface Transaction {
  id: string;
  userId?: string;
  userUid?: string;
  agentCode?: string;
  userName: string;
  userPhone: string;
  type: 'deposit' | 'withdraw';
  amount: number;
  method: 'KBZPay' | 'WavePay' | 'CB Pay' | 'AYA Pay';
  refNumber: string;
  orderNumber?: string;
  dateTime: string;
  status: 'pending' | 'approved' | 'rejected';
  slipUrl?: string;
}

export interface WinningSlot {
  id: string;
  timeSlot: string;
  dateTime: string;
  luckyNumber: string;
  modern?: string;
  internet?: string;
  isConfirmed: boolean;
}

export interface NumberLimit {
  number: string;
  maxBetCount: number;
  maxBetAmount: number;
  currentBetCount: number;
  currentBetAmount: number;
  isBlocked: boolean;
}

export interface ScheduleConfig {
  isClosedToday: boolean;
  morningStart: string;
  morningEnd: string;
  eveningStart: string;
  eveningEnd: string;
  closedDates: string[];
  threeDEnabled: boolean;
  threeDCloseTime: string;
  threeDReopenTime: string;
  threeDClosedDates: string[];
}

export interface AdsConfig {
  tickerNotice?: string;
  notice1: string;
  notice2: string;
  banners: {
    id: string;
    title: string;
    imageUrl: string;
    link?: string;
    active: boolean;
  }[];
}

export interface PaymentMethod {
  id: string;
  name: string;
  mode?: 'number' | 'qr';
  accountName: string;
  accountNumber?: string;
  qrImageUrl?: string;
  logoUrl?: string;
  minDeposit: number;
  maxDeposit: number;
  active: boolean;
  type?: 'mobile_banking' | 'bank_transfer';
}

export interface SupportLinkConfig {
  telegram: string;
  viber: string;
}

export interface WebsiteSettings {
  siteStatus: 'online' | 'maintenance' | 'closed';
  support: SupportLinkConfig;
  payments: PaymentMethod[];
  withdrawalPayments: PaymentMethod[];
  appDownloadUrl: string;
  minBet: number;
  maxBet: number;
  maintenanceMessage: string;
}

export interface Thai2DLiveResultItem {
  set: string;
  value: string;
  open_time: string;
  twod: string;
  stock_date?: string;
  stock_datetime?: string;
  history_id?: string;
}

export interface Thai2DLiveResponse {
  server_time?: string;
  live: {
    set: string;
    value: string;
    time: string;
    twod: string;
    date?: string;
  };
  result: Thai2DLiveResultItem[];
  holiday?: {
    status: string;
    date: string;
    name: string;
  };
}

export interface Thai3DResultItem {
  result: string;
  datetime: string;
}

export interface Thai3DResponse {
  data: Thai3DResultItem[];
  result: number;
  message: string;
}

export interface Thai2DHistoryItem {
  date: string;
  child: {
    time: string;
    set: string;
    value: string;
    twod: string;
    is_result?: string;
  }[];
}

export interface ShwelaminTwodItem {
  id: string;
  date: string;
  set_1200: string;
  val_1200: string;
  set_430: string;
  val_430: string;
  result_1200: string;
  result_430: string;
  internet_930: string;
  modern_930: string;
  internet_200: string;
  modern_200: string;
  time_1200: string;
  time_430: string;
}

export interface ShwelaminTwodResponse {
  result: number;
  message: string;
  data: ShwelaminTwodItem[];
}

export interface SetLiveData {
  modern_930: string;
  internet_930: string;
  modern_200: string;
  internet_200: string;
}

