import { WinningSlot, ScheduleConfig, AdsConfig, WebsiteSettings } from './types';

export const DEFAULT_WINNING_SLOTS: WinningSlot[] = [
  { id: 'slot-1201', timeSlot: '12:01 PM', dateTime: '', luckyNumber: '--', isConfirmed: false },
  { id: 'slot-1630', timeSlot: '04:30 PM', dateTime: '', luckyNumber: '--', isConfirmed: false },
];

export const DEFAULT_SCHEDULE: ScheduleConfig = {
  isClosedToday: false,
  morningStart: '09:30',
  morningEnd: '12:01',
  eveningStart: '14:00',
  eveningEnd: '16:30',
  closedDates: [],
  threeDEnabled: true,
  threeDCloseTime: '15:30',
  threeDReopenTime: '09:00',
  threeDClosedDates: [],
};

export const DEFAULT_ADS: AdsConfig = {
  tickerNotice: '',
  notice1: '',
  notice2: '',
  banners: [],
};

export const DEFAULT_WEBSITE_SETTINGS: WebsiteSettings = {
  siteStatus: 'online',
  support: {
    telegram: '',
    viber: '',
  },
  payments: [],
  withdrawalPayments: [],
  appDownloadUrl: '',
  minBet: 100,
  maxBet: 100000,
  maintenanceMessage: '',
};
