import { sql } from './db';
import { createNotification } from './notifications';
import { computeWin, countNumbers, type BetItemLike } from './payout';
import { isTood, TOOD_MULTIPLIER, payoutTransactionId } from './tood';
import { recordWinSettlement } from './commission';

function parseArray(value: unknown): unknown[] {
  if (Array.isArray(value)) return value;
  if (typeof value === 'string') {
    try {
      const parsed = JSON.parse(value);
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  }
  return [];
}

export interface ToodSettlementResult {
  isToodResult: boolean;
  winners: number;
  totalPayout: number;
}

export async function settleToodBets(
  session: string,
  winningNumber: string
): Promise<ToodSettlementResult> {
  if (!isTood(winningNumber)) {
    return { isToodResult: false, winners: 0, totalPayout: 0 };
  }

  const rows = await sql`
    SELECT id, uid, amount, numbers, items
    FROM bets
    WHERE type = '3D' AND session = ${session} AND status = 'pending'
    LIMIT 1000;
  `;

  let winners = 0;
  let totalPayout = 0;

  for (const raw of rows || []) {
    const bet = raw as {
      id: string;
      uid: string;
      amount: string | number;
      numbers: unknown;
      items: unknown;
    };

    const items = parseArray(bet.items) as BetItemLike[];
    const numbers = parseArray(bet.numbers) as string[];
    const { totalWin, details, matched } = computeWin(
      winningNumber,
      items,
      numbers,
      Number(bet.amount),
      TOOD_MULTIPLIER
    );
    const totalNumbers = countNumbers(items, numbers);

    if (!matched || totalWin <= 0) continue;

    const txId = payoutTransactionId(bet.id, true);
    const credited = await sql`
      WITH updated AS (
        UPDATE bets
        SET status = 'TOOD_WIN', winning_number = ${winningNumber},
            win_amount = ${totalWin}, win_details = ${details},
            payout_multiplier = ${TOOD_MULTIPLIER}, is_tood = true
        WHERE id = ${bet.id} AND status = 'pending'
        RETURNING uid, win_amount
      ),
      tx AS (
        INSERT INTO transactions
          (id, uid, type, amount, method, transaction_number, status, timestamp,
           bet_id, draw_id, bet_number, bet_amount, payout_multiplier)
        SELECT ${txId}, u.uid, 'TOOD_WIN', u.win_amount,
               'TOOD_WIN', ${winningNumber}, 'completed', ${new Date().toLocaleString()},
               ${bet.id}, ${session}, ${winningNumber}, ${Number(bet.amount)}, ${TOOD_MULTIPLIER}
        FROM updated u
        ON CONFLICT (id) DO NOTHING
        RETURNING uid, amount
      )
      UPDATE users SET balance = balance + t.amount, updated_at = NOW()
      FROM tx t
      WHERE users.uid = t.uid
      RETURNING users.uid;
    `;
    if (!credited || credited.length === 0) continue;

    await recordWinSettlement({
      betId: bet.id,
      winningNumber,
      multiplier: TOOD_MULTIPLIER,
      grossPayout: totalWin,
      isTood: true,
    });

    winners++;
    totalPayout += totalWin;

    await createNotification({
      targetType: 'user',
      targetId: bet.uid,
      type: 'win',
      title: 'ဂုဏ်ယူပါသည်! TOOD ပေါက်ကြေးဆုငွေ ရရှိပါပြီ',
      message: `3D TOOD ပေါက်ဂဏန်း (${winningNumber}) ဖြင့် ${totalWin.toLocaleString()} MMK ဆုငွေ (×${TOOD_MULTIPLIER}) ရရှိပါပြီ။`,
      data: { screen: 'record' },
    });

    await createNotification({
      targetType: 'admin',
      targetId: null,
      type: 'win',
      title: `TOOD Win Bet 3D - ${bet.uid}`,
      message: `User ID: ${bet.uid} | Bet: ${Number(bet.amount).toLocaleString()} MMK | Win: ${totalWin.toLocaleString()} MMK | Type: TOOD | Winning No: ${winningNumber} | Total Numbers: ${totalNumbers} | Won: ${details}`,
      data: {
        screen: 'win_bets',
        userId: bet.uid,
        betId: bet.id,
        type: '3D',
        winningNumber,
        winAmount: totalWin,
        isTood: true,
      },
    });
  }

  return { isToodResult: true, winners, totalPayout };
}
