export async function sendAgentOtpEmail(
  email: string,
  otp: string,
  name: string,
  expiryMinutes = 10
): Promise<boolean> {
  const serviceId = process.env.EMAILJS_SERVICE_ID;
  const templateId = process.env.EMAILJS_TEMPLATE_ID;
  const publicKey = process.env.EMAILJS_PUBLIC_KEY;
  const privateKey = process.env.EMAILJS_PRIVATE_KEY;
  const origin = process.env.APP_URL || 'https://panel.fast2d3d.com';

  if (!serviceId || !templateId || !publicKey) {
    console.warn('[email] EmailJS is not configured (EMAILJS_SERVICE_ID/TEMPLATE_ID/PUBLIC_KEY).');
    return false;
  }

  try {
    const res = await fetch('https://api.emailjs.com/api/v1.0/email/send', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'User-Agent':
          'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36',
        Origin: origin,
        Referer: `${origin}/`,
      },
      body: JSON.stringify({
        service_id: serviceId,
        template_id: templateId,
        user_id: publicKey,
        accessToken: privateKey,
        template_params: {
          email,
          to_email: email,
          to_name: name || email,
          otp,
          app_name: 'Fast2D3D Panel',
          expiry_minutes: String(expiryMinutes),
        },
      }),
    });

    if (!res.ok) {
      const body = await res.text().catch(() => '');
      console.error('[email] EmailJS send failed:', res.status, body);
      return false;
    }
    return true;
  } catch (err) {
    console.error('[email] EmailJS request error:', err);
    return false;
  }
}
