import { NextResponse } from 'next/server';
import { getSession, SessionPayload } from '@/lib/session';

export function ok<T>(data: T, status = 200) {
  return NextResponse.json({ success: true, data }, { status });
}

export function fail(error: string, status = 400) {
  return NextResponse.json({ success: false, error }, { status });
}

export async function requireAdmin(): Promise<SessionPayload | null> {
  const session = await getSession();
  if (!session || session.kind !== 'admin') return null;
  return session;
}

export async function requireStaff(): Promise<SessionPayload | null> {
  const session = await getSession();
  if (!session || (session.kind !== 'admin' && session.kind !== 'agent')) return null;
  return session;
}

export function agentScope(session: SessionPayload): string | null {
  return session.kind === 'agent' ? session.code || null : null;
}
