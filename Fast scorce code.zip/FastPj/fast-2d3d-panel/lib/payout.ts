export interface BetItemLike {
  number?: string;
  amount?: number;
  subNumbers?: { number: string; amount: number }[];
}

export interface WinComputation {
  totalWin: number;
  details: string;
  matched: boolean;
}

export function computeWin(
  winningNumber: string,
  items: BetItemLike[],
  numbers: string[],
  betAmount: number,
  multiplier: number
): WinComputation {
  let totalWin = 0;
  let matched = false;
  const matchDetails: string[] = [];

  if (items.length > 0) {
    for (const item of items) {
      if (item.subNumbers && item.subNumbers.length > 0) {
        for (const sub of item.subNumbers) {
          if (sub.number === winningNumber) {
            const won = Number(sub.amount) * multiplier;
            totalWin += won;
            matched = true;
            matchDetails.push(
              `${item.number} ➔ ${sub.number} (${Number(sub.amount).toLocaleString()}ks × ${multiplier}ဆ = ${won.toLocaleString()}ks)`
            );
          }
        }
      } else if (item.number === winningNumber) {
        const won = Number(item.amount) * multiplier;
        totalWin += won;
        matched = true;
        matchDetails.push(
          `${item.number} (${Number(item.amount).toLocaleString()}ks × ${multiplier}ဆ = ${won.toLocaleString()}ks)`
        );
      }
    }
  } else if (numbers.includes(winningNumber)) {
    const perUnit = Math.floor(betAmount / numbers.length);
    const won = perUnit * multiplier;
    totalWin += won;
    matched = true;
    matchDetails.push(
      `${winningNumber} (${perUnit.toLocaleString()}ks × ${multiplier}ဆ = ${won.toLocaleString()}ks)`
    );
  }

  return { totalWin, details: matchDetails.join(', '), matched };
}

export interface AgentTotalsInput {
  totalBet: number;
  totalWin: number;
  totalLoss: number;
  agentPercent: number;
}

export interface AgentTotals {
  totalBet: number;
  totalWin: number;
  totalLoss: number;
  agentPercent: number;
  netBalance: number;
  agentShare: number;
  adminShare: number;
  settlementAmount: number;
}

function round2(value: number): number {
  return Math.round((Number(value) || 0) * 100) / 100;
}

export function splitShares(baseAmount: number, agentPercent: number): {
  agentPercent: number;
  agentShare: number;
  adminShare: number;
} {
  const pct = Math.max(0, Math.min(100, Number(agentPercent) || 0));
  const base = Number(baseAmount) || 0;
  const agentShare = round2((base * pct) / 100);
  const adminShare = round2(base - agentShare);
  return { agentPercent: pct, agentShare, adminShare };
}

export function computeAgentTotals(input: AgentTotalsInput): AgentTotals {
  const totalBet = Number(input.totalBet) || 0;
  const totalWin = Number(input.totalWin) || 0;
  const totalLoss = Number(input.totalLoss) || 0;
  const pct = Math.max(0, Math.min(100, Number(input.agentPercent) || 0));
  const netBalance = round2(totalLoss - totalWin);
  const agentShare = round2((netBalance * pct) / 100);
  const adminShare = round2(netBalance - agentShare);
  return {
    totalBet,
    totalWin,
    totalLoss,
    agentPercent: pct,
    netBalance,
    agentShare,
    adminShare,
    settlementAmount: agentShare,
  };
}

export function countNumbers(items: BetItemLike[], numbers: string[]): number {
  if (items.length > 0) {
    let total = 0;
    for (const item of items) {
      total += item.subNumbers && item.subNumbers.length > 0 ? item.subNumbers.length : 1;
    }
    return total;
  }
  return numbers.length;
}
