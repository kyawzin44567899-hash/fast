export function getMyanmarDate(date: Date = new Date()): string {
  return new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Yangon' }).format(date);
}

export function normalizeResultDate(value: unknown): string {
  const raw = value === null || value === undefined ? '' : String(value).trim();
  if (!raw) return getMyanmarDate();
  const match = raw.match(/^\d{4}-\d{2}-\d{2}/);
  return match ? match[0] : getMyanmarDate();
}
