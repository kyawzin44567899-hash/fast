import { sql } from './db';

export { splitShares, computeAgentTotals } from './payout';

export async function backfillWinSettlements(): Promise<void> {
  try {
    await sql`
      INSERT INTO win_settlements
        (id, bet_id, uid, user_name, agent_code, agent_name, bet_type, session,
         winning_number, bet_amount, multiplier, gross_payout, agent_percent,
         agent_share, admin_share, paid_amount, remaining_amount, payment_status, is_tood, created_at)
      SELECT 'stl-' || b.id, b.id, b.uid, u.name, u.agent_code, a.name, b.type, b.session,
             b.winning_number, b.amount,
             COALESCE(NULLIF(b.payout_multiplier, 0),
                      CASE WHEN b.type = '2D' THEN 85 WHEN b.is_tood THEN 10 ELSE 550 END),
             b.win_amount,
             COALESCE(a.commission, 0),
             ROUND(b.win_amount * COALESCE(a.commission, 0) / 100, 2),
             ROUND(b.win_amount - ROUND(b.win_amount * COALESCE(a.commission, 0) / 100, 2), 2),
             0, b.win_amount, 'pending', COALESCE(b.is_tood, false), b.created_at
      FROM bets b
      JOIN users u ON u.uid = b.uid
      LEFT JOIN agents a ON a.code = u.agent_code
      WHERE b.status IN ('win', 'TOOD_WIN') AND b.win_amount > 0
        AND NOT EXISTS (SELECT 1 FROM win_settlements w WHERE w.bet_id = b.id)
      ON CONFLICT (bet_id) DO NOTHING;
    `;
  } catch (err) {
    console.error('backfillWinSettlements failed:', err);
  }
}

export interface WinSettlementInput {
  betId: string;
  winningNumber: string;
  multiplier: number;
  grossPayout: number;
  isTood: boolean;
}

export async function recordWinSettlement(input: WinSettlementInput): Promise<void> {
  const id = `stl-${input.betId}`;
  try {
    await sql`
      INSERT INTO win_settlements
        (id, bet_id, uid, user_name, agent_code, agent_name, bet_type, session,
         winning_number, bet_amount, multiplier, gross_payout, agent_percent,
         agent_share, admin_share, paid_amount, remaining_amount, payment_status, is_tood)
      SELECT ${id}, b.id, b.uid, u.name, u.agent_code, a.name, b.type, b.session,
             ${input.winningNumber}, b.amount, ${input.multiplier}, ${input.grossPayout},
             COALESCE(a.commission, 0),
             ROUND(${input.grossPayout} * COALESCE(a.commission, 0) / 100, 2),
             ROUND(${input.grossPayout} - ROUND(${input.grossPayout} * COALESCE(a.commission, 0) / 100, 2), 2),
             0, ${input.grossPayout}, 'pending', ${input.isTood}
      FROM bets b
      JOIN users u ON u.uid = b.uid
      LEFT JOIN agents a ON a.code = u.agent_code
      WHERE b.id = ${input.betId}
      ON CONFLICT (bet_id) DO NOTHING;
    `;
  } catch (err) {
    console.error('recordWinSettlement failed:', err);
  }
}
