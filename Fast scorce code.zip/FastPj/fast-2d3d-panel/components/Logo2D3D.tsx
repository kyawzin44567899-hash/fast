'use client';

import React from 'react';

interface LogoProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showText?: boolean;
  className?: string;
}

export function Logo2D3D({ size = 'lg', showText = true, className = '' }: LogoProps) {
  const sizeMap = {
    sm: { w: 40, h: 40, fontSize: 16 },
    md: { w: 72, h: 72, fontSize: 24 },
    lg: { w: 120, h: 120, fontSize: 44 },
    xl: { w: 160, h: 160, fontSize: 58 },
  };

  const current = sizeMap[size];

  return (
    <div className={`flex flex-col items-center justify-center ${className}`}>
      <div
        className="relative flex items-center justify-center filter drop-shadow-[0_0_15px_rgba(234,179,8,0.4)]"
        style={{ width: current.w, height: current.h }}
      >
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src="/images/logo.png"
          alt="Fast 2D3D"
          className="w-full h-full object-contain"
        />
      </div>

      {showText && (
        <div className="mt-2 text-center select-none">
          <div
            className="font-black tracking-widest text-transparent bg-clip-text bg-gradient-to-b from-[#FFFDF0] via-[#FACC15] to-[#B45309] filter drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)]"
            style={{ fontSize: current.fontSize, lineHeight: 1.1 }}
          >
            2D3D
          </div>
        </div>
      )}
    </div>
  );
}
