import React from 'react';

export function UsersIcon({ className = 'w-14 h-14 text-black' }: { className?: string }) {
  return (
    <svg viewBox="0 0 100 100" fill="currentColor" className={className}>
      <circle cx="50" cy="30" r="16" />
      <path d="M24 78 C24 60, 36 50, 50 50 C64 50, 76 60, 76 78 Z" />
      <circle cx="26" cy="36" r="12" />
      <path d="M8 78 C8 65, 17 56, 28 56 C33 56, 38 58, 42 61 C37 66, 34 72, 34 78 Z" />
      <circle cx="74" cy="36" r="12" />
      <path d="M92 78 C92 65, 83 56, 72 56 C67 56, 62 58, 58 61 C63 66, 66 72, 66 78 Z" />
    </svg>
  );
}

export function AgentsIcon({ className = 'w-14 h-14 text-black' }: { className?: string }) {
  return (
    <svg viewBox="0 0 100 100" fill="currentColor" className={className}>
      <circle cx="50" cy="22" r="12" />
      <path d="M34 52 C34 40, 42 36, 50 36 C58 36, 66 40, 66 52 Z" />
      <polygon points="50,42 46,50 50,54 54,50" fill="#FFCC00" />
      <line x1="50" y1="52" x2="22" y2="68" stroke="currentColor" strokeWidth="4" />
      <line x1="50" y1="52" x2="50" y2="68" stroke="currentColor" strokeWidth="4" />
      <line x1="50" y1="52" x2="78" y2="68" stroke="currentColor" strokeWidth="4" />
      <circle cx="22" cy="74" r="8" />
      <path d="M12 92 C12 84, 16 82, 22 82 C28 82, 32 84, 32 92 Z" />
      <circle cx="50" cy="74" r="8" />
      <path d="M40 92 C40 84, 44 82, 50 82 C56 82, 60 84, 60 92 Z" />
      <circle cx="78" cy="74" r="8" />
      <path d="M68 92 C68 84, 72 82, 78 82 C84 82, 88 84, 88 92 Z" />
    </svg>
  );
}

export function CashInOutIcon({ className = 'w-14 h-14 text-black' }: { className?: string }) {
  return (
    <svg viewBox="0 0 100 100" fill="none" stroke="currentColor" strokeWidth="5" className={className}>
      <g transform="rotate(-12 40 45)">
        <rect x="18" y="28" width="58" height="34" rx="4" fill="#FFCC00" stroke="currentColor" strokeWidth="5" />
        <circle cx="47" cy="45" r="8" stroke="currentColor" strokeWidth="4" fill="none" />
        <line x1="24" y1="36" x2="24" y2="54" stroke="currentColor" strokeWidth="3" />
        <line x1="70" y1="36" x2="70" y2="54" stroke="currentColor" strokeWidth="3" />
      </g>
      <rect x="24" y="44" width="60" height="36" rx="4" fill="#FFCC00" stroke="currentColor" strokeWidth="5" />
      <circle cx="54" cy="62" r="9" stroke="currentColor" strokeWidth="4" fill="none" />
      <line x1="30" y1="52" x2="30" y2="72" stroke="currentColor" strokeWidth="3" />
      <line x1="78" y1="52" x2="78" y2="72" stroke="currentColor" strokeWidth="3" />
      <path d="M12 28 L24 22 M16 16 L24 22 L20 32" stroke="currentColor" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M86 74 L74 80 M80 86 L74 80 L78 70" stroke="currentColor" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

export function NumbersGridIcon({ className = 'w-14 h-14 text-black' }: { className?: string }) {
  return (
    <svg viewBox="0 0 100 100" fill="none" className={className}>
      <g transform="rotate(-6 50 50)">
        <rect x="22" y="20" width="16" height="16" rx="3" stroke="currentColor" strokeWidth="4" fill="none" />
        <text x="30" y="32" fill="currentColor" fontSize="12" fontWeight="bold" textAnchor="middle" dominantBaseline="middle">5</text>
        <rect x="42" y="20" width="16" height="16" rx="3" stroke="currentColor" strokeWidth="4" fill="none" />
        <text x="50" y="32" fill="currentColor" fontSize="12" fontWeight="bold" textAnchor="middle" dominantBaseline="middle">4</text>
        <rect x="62" y="20" width="16" height="16" rx="3" stroke="currentColor" strokeWidth="4" fill="none" />
        <text x="70" y="32" fill="currentColor" fontSize="12" fontWeight="bold" textAnchor="middle" dominantBaseline="middle">2</text>

        <rect x="22" y="40" width="16" height="16" rx="3" stroke="currentColor" strokeWidth="4" fill="none" />
        <text x="30" y="52" fill="currentColor" fontSize="12" fontWeight="bold" textAnchor="middle" dominantBaseline="middle">1</text>
        <rect x="42" y="40" width="16" height="16" rx="3" stroke="currentColor" strokeWidth="4" fill="none" />
        <text x="50" y="52" fill="currentColor" fontSize="12" fontWeight="bold" textAnchor="middle" dominantBaseline="middle">8</text>

        <rect x="32" y="60" width="16" height="16" rx="3" stroke="currentColor" strokeWidth="4" fill="none" />
        <text x="40" y="72" fill="currentColor" fontSize="12" fontWeight="bold" textAnchor="middle" dominantBaseline="middle">9</text>
        <rect x="52" y="60" width="16" height="16" rx="3" stroke="currentColor" strokeWidth="4" fill="none" />
        <text x="60" y="72" fill="currentColor" fontSize="12" fontWeight="bold" textAnchor="middle" dominantBaseline="middle">6</text>
        <rect x="72" y="60" width="16" height="16" rx="3" stroke="currentColor" strokeWidth="4" fill="none" />
        <text x="80" y="72" fill="currentColor" fontSize="12" fontWeight="bold" textAnchor="middle" dominantBaseline="middle">3</text>
      </g>
    </svg>
  );
}

export function CalendarIconCustom({ className = 'w-14 h-14 text-black' }: { className?: string }) {
  return (
    <svg viewBox="0 0 100 100" fill="none" stroke="currentColor" strokeWidth="5" className={className}>
      <line x1="28" y1="18" x2="28" y2="28" stroke="currentColor" strokeWidth="5" strokeLinecap="round" />
      <line x1="42" y1="18" x2="42" y2="28" stroke="currentColor" strokeWidth="5" strokeLinecap="round" />
      <line x1="58" y1="18" x2="58" y2="28" stroke="currentColor" strokeWidth="5" strokeLinecap="round" />
      <line x1="72" y1="18" x2="72" y2="28" stroke="currentColor" strokeWidth="5" strokeLinecap="round" />

      <rect x="18" y="24" width="64" height="60" rx="8" stroke="currentColor" strokeWidth="5" fill="none" />

      <g fill="currentColor" stroke="none">
        <rect x="28" y="40" width="8" height="8" rx="1.5" />
        <rect x="46" y="40" width="8" height="8" rx="1.5" />
        <rect x="64" y="40" width="8" height="8" rx="1.5" />

        <rect x="28" y="52" width="8" height="8" rx="1.5" />
        <rect x="46" y="52" width="8" height="8" rx="1.5" />
        <rect x="64" y="52" width="8" height="8" rx="1.5" />

        <rect x="28" y="64" width="8" height="8" rx="1.5" />
        <rect x="46" y="64" width="8" height="8" rx="1.5" />
        <rect x="64" y="64" width="8" height="8" rx="1.5" />
      </g>
    </svg>
  );
}

export function AdsWindowIcon({ className = 'w-14 h-14 text-black' }: { className?: string }) {
  return (
    <svg viewBox="0 0 100 100" fill="none" stroke="currentColor" strokeWidth="5" className={className}>
      <rect x="16" y="22" width="68" height="56" rx="8" stroke="currentColor" strokeWidth="5" fill="none" />
      <line x1="16" y1="36" x2="84" y2="36" stroke="currentColor" strokeWidth="5" />
      <circle cx="26" cy="29" r="3" fill="currentColor" stroke="none" />
      <circle cx="34" cy="29" r="3" fill="currentColor" stroke="none" />
      <circle cx="42" cy="29" r="3" fill="currentColor" stroke="none" />
      <text
        x="50"
        y="62"
        fill="currentColor"
        stroke="none"
        fontSize="22"
        fontWeight="900"
        letterSpacing="2"
        textAnchor="middle"
        dominantBaseline="middle"
      >
        ADS
      </text>
    </svg>
  );
}

export function Lucky777Icon({ className = 'w-14 h-14 text-black' }: { className?: string }) {
  return (
    <svg viewBox="0 0 100 100" className={className}>
      <g fill="currentColor">
        <polygon points="20,24 22,29 27,29 23,32 25,37 20,34 15,37 17,32 13,29 18,29" />
        <polygon points="80,24 82,29 87,29 83,32 85,37 80,34 75,37 77,32 73,29 78,29" />
        <polygon points="12,48 13,51 16,51 14,53 15,56 12,54 9,56 10,53 8,51 11,51" />
        <polygon points="88,48 89,51 92,51 90,53 91,56 88,54 85,56 86,53 84,51 87,51" />
      </g>
      <text
        x="50"
        y="62"
        fill="currentColor"
        fontFamily="Impact, system-ui, sans-serif"
        fontSize="36"
        fontWeight="900"
        letterSpacing="1"
        textAnchor="middle"
        dominantBaseline="middle"
      >
        777
      </text>
    </svg>
  );
}

export function LiveAntennaIcon({ className = 'w-14 h-14 text-black' }: { className?: string }) {
  return (
    <svg viewBox="0 0 100 100" fill="none" stroke="currentColor" strokeWidth="5" className={className}>
      <circle cx="50" cy="50" r="8" fill="currentColor" stroke="none" />

      <path d="M36 34 A 20 20 0 0 0 36 66" stroke="currentColor" strokeWidth="6" strokeLinecap="round" />
      <path d="M64 34 A 20 20 0 0 1 64 66" stroke="currentColor" strokeWidth="6" strokeLinecap="round" />

      <path d="M24 24 A 36 36 0 0 0 24 76" stroke="currentColor" strokeWidth="6" strokeLinecap="round" />
      <path d="M76 24 A 36 36 0 0 1 76 76" stroke="currentColor" strokeWidth="6" strokeLinecap="round" />
    </svg>
  );
}
