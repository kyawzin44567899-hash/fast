'use client';

import React from 'react';
import { Logo2D3D } from '../Logo2D3D';
import { Crown, Headphones, ShieldCheck } from 'lucide-react';

interface WelcomeViewProps {
  onSelectRole: (role: 'admin' | 'agent') => void;
}

export function WelcomeView({ onSelectRole }: WelcomeViewProps) {
  return (
    <div className="flex flex-col items-center justify-between min-h-screen px-6 py-12 bg-black text-white selection:bg-amber-400 selection:text-black">
      <div className="w-full pt-6 flex flex-col items-center">
        <Logo2D3D size="xl" showText={true} />

        <h1 className="mt-8 text-center text-lg sm:text-xl font-bold tracking-wide text-[#FFCC00]">
          Wealcome to Fast2D3D Panel!
        </h1>
      </div>

      <div className="w-full max-w-xs space-y-4 my-auto">
        <button
          id="btn-login-admin"
          onClick={() => onSelectRole('admin')}
          className="w-full py-3.5 px-6 rounded-full bg-[#FFCC00] hover:bg-[#ffbe00] active:scale-[0.98] text-black font-bold text-base flex items-center justify-center gap-3 shadow-[0_4px_20px_rgba(255,204,0,0.3)] transition cursor-pointer"
        >
          <Crown className="w-6 h-6 stroke-[2.2] fill-black text-black" />
          <span>Login as Admin</span>
        </button>

        <button
          id="btn-login-agent"
          onClick={() => onSelectRole('agent')}
          className="w-full py-3.5 px-6 rounded-full bg-[#FFCC00] hover:bg-[#ffbe00] active:scale-[0.98] text-black font-bold text-base flex items-center justify-center gap-3 shadow-[0_4px_20px_rgba(255,204,0,0.3)] transition cursor-pointer"
        >
          <Headphones className="w-6 h-6 stroke-[2.2] text-black" />
          <span>Login as Agent</span>
        </button>
      </div>

      <div className="pb-4 flex items-center gap-2 text-[#FFCC00] font-semibold text-sm">
        <ShieldCheck className="w-5 h-5 text-[#FFCC00]" />
        <span className="tracking-wide">Secured Panel!</span>
      </div>
    </div>
  );
}
