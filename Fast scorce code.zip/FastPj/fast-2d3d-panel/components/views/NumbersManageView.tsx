'use client';

import React, { useState, useRef, useEffect } from 'react';
import {
  ArrowLeft,
  Ban,
  Check,
  LayoutGrid,
  Search,
  CheckCheck,
  AlertCircle,
  Hash,
  ChevronLeft,
  ChevronRight,
  Lock,
  Banknote,
} from 'lucide-react';
import { NumberLimit, UserRole } from '@/lib/types';

interface NumbersManageViewProps {
  onBack: () => void;
  role?: UserRole;
}

type NumberType = '2D' | '3D';

export function NumbersManageView({ onBack, role = 'admin' }: NumbersManageViewProps) {
  const [type, setType] = useState<NumberType>('2D');

  const allNumbers =
    type === '2D'
      ? Array.from({ length: 100 }, (_, i) => i.toString().padStart(2, '0'))
      : Array.from({ length: 1000 }, (_, i) => i.toString().padStart(3, '0'));

  const [limits, setLimits] = useState<Record<string, NumberLimit>>({});
  const [selectedNumber, setSelectedNumber] = useState<string>('01');
  const [viewMode, setViewMode] = useState<'pills' | 'grid'>('pills');
  const [filter, setFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [isLoading, setIsLoading] = useState(false);

  const activePillRef = useRef<HTMLButtonElement | null>(null);
  const scrollContainerRef = useRef<HTMLDivElement | null>(null);

  const [inputLimit, setInputLimit] = useState('100');
  const [inputAmountLimit, setInputAmountLimit] = useState('0');
  const [toastMessage, setToastMessage] = useState('');

  useEffect(() => {
    let isMounted = true;
    const timer = setTimeout(async () => {
      setIsLoading(true);
      try {
        const res = await fetch(`/api/number-limits?type=${type}`, { cache: 'no-store' });
        const json = await res.json();
        if (isMounted && json.success && Array.isArray(json.data)) {
          const map: Record<string, NumberLimit> = {};
          for (const item of json.data as NumberLimit[]) map[item.number] = item;
          setLimits(map);
        }
      } catch {

      } finally {
        if (isMounted) setIsLoading(false);
      }
    }, 0);
    return () => {
      isMounted = false;
      clearTimeout(timer);
    };
  }, [type]);

  useEffect(() => {
    const timer = setTimeout(() => {
      if (type === '2D') {
        setSelectedNumber('01');
        setFilter('all');
      } else {
        setSelectedNumber('001');
        setFilter('000-099');
      }
      setSearchQuery('');
      setViewMode('pills');
    }, 0);
    return () => clearTimeout(timer);
  }, [type]);

  useEffect(() => {
    if (activePillRef.current && scrollContainerRef.current && viewMode === 'pills') {
      const container = scrollContainerRef.current;
      const element = activePillRef.current;
      const left = element.offsetLeft - container.offsetWidth / 2 + element.offsetWidth / 2;
      container.scrollTo({ left, behavior: 'smooth' });
    }
  }, [selectedNumber, viewMode, type]);

  useEffect(() => {
    const timer = setTimeout(() => {
      setInputLimit((limits[selectedNumber]?.maxBetCount || 100).toString());
      setInputAmountLimit((limits[selectedNumber]?.maxBetAmount || 0).toString());
    }, 0);
    return () => clearTimeout(timer);
  }, [selectedNumber, limits]);

  const handleScrollLeft = () => scrollContainerRef.current?.scrollBy({ left: -240, behavior: 'smooth' });
  const handleScrollRight = () => scrollContainerRef.current?.scrollBy({ left: 240, behavior: 'smooth' });

  const defaultWidth = type === '2D' ? 2 : 3;

  const currentInfo: NumberLimit = limits[selectedNumber] || {
    number: selectedNumber,
    maxBetCount: 100,
    maxBetAmount: 0,
    currentBetCount: 0,
    currentBetAmount: 0,
    isBlocked: false,
  };

  const isLimitReached = currentInfo.currentBetCount >= currentInfo.maxBetCount;
  const remainingCount = Math.max(0, currentInfo.maxBetCount - currentInfo.currentBetCount);
  const isAmountReached =
    currentInfo.maxBetAmount > 0 && currentInfo.currentBetAmount >= currentInfo.maxBetAmount;

  const persistLimit = async (number: string, maxBetCount: number) => {
    try {
      await fetch('/api/number-limits', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type, number, maxBetCount }),
      });
    } catch {}
  };

  const persistAmountLimit = async (number: string, maxBetAmount: number) => {
    try {
      await fetch('/api/number-limits', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type, number, maxBetAmount }),
      });
    } catch {}
  };

  const persistBlock = async (number: string, isBlocked: boolean) => {
    try {
      await fetch('/api/number-limits', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type, number, isBlocked }),
      });
    } catch {}
  };

  const handleSaveLimit = () => {
    const parsed = parseInt(inputLimit, 10);
    if (isNaN(parsed) || parsed <= 0) {
      setToastMessage('ကျေးဇူးပြု၍ မှန်ကန်သော အကြိမ်ရေ ထည့်သွင်းပါ');
      setTimeout(() => setToastMessage(''), 2500);
      return;
    }
    setLimits((prev) => ({
      ...prev,
      [selectedNumber]: {
        ...(prev[selectedNumber] || {
          number: selectedNumber,
          maxBetAmount: 0,
          currentBetCount: 0,
          currentBetAmount: 0,
          isBlocked: false,
        }),
        number: selectedNumber,
        maxBetCount: parsed,
      },
    }));
    void persistLimit(selectedNumber, parsed);
    setToastMessage(`ဂဏန်း (${selectedNumber}) ၏ အများဆုံးထိုးနိုင်သည့် အကြိမ်ရေကို [${parsed} ကြိမ်] သတ်မှတ်ပြီးပါပြီ`);
    setTimeout(() => setToastMessage(''), 3000);
  };

  const handleSaveAmountLimit = () => {
    const parsed = parseInt(inputAmountLimit, 10);
    if (isNaN(parsed) || parsed < 0) {
      setToastMessage('ကျေးဇူးပြု၍ မှန်ကန်သော ပမာဏ ထည့်သွင်းပါ');
      setTimeout(() => setToastMessage(''), 2500);
      return;
    }
    setLimits((prev) => ({
      ...prev,
      [selectedNumber]: {
        ...(prev[selectedNumber] || {
          number: selectedNumber,
          maxBetCount: 100,
          currentBetCount: 0,
          currentBetAmount: 0,
          isBlocked: false,
        }),
        number: selectedNumber,
        maxBetAmount: parsed,
      },
    }));
    void persistAmountLimit(selectedNumber, parsed);
    setToastMessage(
      `ဂဏန်း (${selectedNumber}) ၏ နေ့စဉ် ငွေပမာဏ ကန့်သတ်ချက်ကို [${parsed.toLocaleString()} ကျပ်] သတ်မှတ်ပြီးပါပြီ (ပြည့်လျှင် အနီရောင်ပြမည်၊ ထိုးနိုင်ဆဲ)`
    );
    setTimeout(() => setToastMessage(''), 3500);
  };

  const handleApplyAmountToAll = async () => {
    const parsed = parseInt(inputAmountLimit, 10);
    if (isNaN(parsed) || parsed < 0) return;
    try {
      await fetch('/api/number-limits', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type, applyAllAmount: parsed }),
      });
    } catch {}
    setLimits((prev) => {
      const updated: Record<string, NumberLimit> = {};
      for (const [num, info] of Object.entries(prev)) {
        updated[num] = { ...info, maxBetAmount: parsed };
      }
      return updated;
    });
    const rangeLabel = type === '2D' ? '00 မှ 99' : '000 မှ 999';
    setToastMessage(`ဂဏန်းအားလုံး (${rangeLabel}) ၏ နေ့စဉ် ငွေပမာဏ ကန့်သတ်ချက်ကို [${parsed.toLocaleString()} ကျပ်] စီ သတ်မှတ်ပြီးပါပြီ`);
    setTimeout(() => setToastMessage(''), 3500);
  };

  const handleApplyToAll = async () => {
    const parsed = parseInt(inputLimit, 10);
    if (isNaN(parsed) || parsed <= 0) return;
    try {
      await fetch('/api/number-limits', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type, applyAll: parsed }),
      });
    } catch {}
    setLimits((prev) => {
      const updated: Record<string, NumberLimit> = {};
      for (const [num, info] of Object.entries(prev)) {
        updated[num] = { ...info, maxBetCount: parsed };
      }
      return updated;
    });
    const rangeLabel = type === '2D' ? '00 မှ 99' : '000 မှ 999';
    setToastMessage(`ဂဏန်းအားလုံး (${rangeLabel}) ၏ အများဆုံးထိုးနိုင်သည့် အကြိမ်ရေကို [${parsed} ကြိမ်] စီ သတ်မှတ်ပြီးပါပြီ`);
    setTimeout(() => setToastMessage(''), 3500);
  };

  const handleToggleBlock = () => {
    const nextBlocked = !currentInfo.isBlocked;
    setLimits((prev) => ({
      ...prev,
      [selectedNumber]: {
        ...(prev[selectedNumber] || {
          number: selectedNumber,
          maxBetCount: 100,
          maxBetAmount: 0,
          currentBetCount: 0,
          currentBetAmount: 0,
        }),
        number: selectedNumber,
        isBlocked: nextBlocked,
      },
    }));
    void persistBlock(selectedNumber, nextBlocked);
    setToastMessage(nextBlocked ? `ဂဏန်း (${selectedNumber}) ကို ပိတ်လိုက်ပါပြီ (Blocked)` : `ဂဏန်း (${selectedNumber}) ကို ပြန်ဖွင့်လိုက်ပါပြီ (Unblocked)`);
    setTimeout(() => setToastMessage(''), 3000);
  };

  const filteredNumbers = allNumbers.filter((num) => {
    if (searchQuery.trim()) return num.includes(searchQuery.trim());
    if (filter === 'all') return true;
    const [start, end] = filter.split('-').map(Number);
    const n = parseInt(num, 10);
    return n >= start && n <= end;
  });

  const totalBlocked = Object.values(limits).filter((l) => l.isBlocked).length;
  const totalFull = Object.values(limits).filter((l) => !l.isBlocked && l.currentBetCount >= l.maxBetCount).length;
  const totalAll = type === '2D' ? 100 : 1000;
  const totalOpen = totalAll - totalBlocked - totalFull;

  const filterTabs =
    type === '2D'
      ? [
          { id: 'all', label: 'All' },
          { id: '00-19', label: '00-19' },
          { id: '20-39', label: '20-39' },
          { id: '40-59', label: '40-59' },
          { id: '60-79', label: '60-79' },
          { id: '80-99', label: '80-99' },
        ]
      : [
          { id: 'all', label: 'All' },
          { id: '000-099', label: '000-099' },
          { id: '100-199', label: '100-199' },
          { id: '200-299', label: '200-299' },
          { id: '300-399', label: '300-399' },
          { id: '400-499', label: '400-499' },
          { id: '500-599', label: '500-599' },
          { id: '600-699', label: '600-699' },
          { id: '700-799', label: '700-799' },
          { id: '800-899', label: '800-899' },
          { id: '900-999', label: '900-999' },
        ];

  return (
    <div className="flex flex-col min-h-screen bg-[#101012] text-white selection:bg-amber-400 selection:text-black">
      <div className="sticky top-0 z-30 flex items-center justify-between px-4 py-3 bg-[#101012]/95 backdrop-blur-md border-b border-zinc-900">
        <button
          onClick={onBack}
          className="w-10 h-10 rounded-full flex items-center justify-center text-[#FFCC00] hover:bg-zinc-800 transition active:scale-95"
          aria-label="Back"
        >
          <ArrowLeft className="w-7 h-7 stroke-[2.5]" />
        </button>

        <div className="text-center">
          <h1 className="text-xl font-bold tracking-wide text-[#FFCC00]">ဂဏန်းဆိုင်ရာ</h1>
          <span className="text-[11px] text-zinc-400">
            {type === '2D' ? '00 မှ 99 အကြိမ်ရေ ကန့်သတ်ချက်' : '000 မှ 999 အကြိမ်ရေ ကန့်သတ်ချက်'}
          </span>
        </div>

        <button
          onClick={() => setViewMode(viewMode === 'pills' ? 'grid' : 'pills')}
          className={`w-10 h-10 rounded-xl flex items-center justify-center transition border ${
            viewMode === 'grid'
              ? 'bg-[#FFCC00] text-black border-[#FFCC00]'
              : 'bg-zinc-900 text-[#FFCC00] border-zinc-800 hover:bg-zinc-800'
          }`}
          title={viewMode === 'pills' ? 'အကွက်ဇယားဖြင့် ကြည့်မည်' : 'အလျားလိုက် စာရင်းဖြင့် ကြည့်မည်'}
        >
          <LayoutGrid className="w-5 h-5" />
        </button>
      </div>

      <div className="px-4 pt-3">
        <div className="grid grid-cols-2 p-1 bg-zinc-900 rounded-2xl border border-zinc-800">
          {(['2D', '3D'] as NumberType[]).map((t) => (
            <button
              key={t}
              onClick={() => setType(t)}
              className={`py-2 text-sm font-bold rounded-xl transition ${
                type === t ? 'bg-[#FFCC00] text-black shadow' : 'text-zinc-400 hover:text-white'
              }`}
            >
              {t} {t === '2D' ? '(00-99)' : '(000-999)'}
            </button>
          ))}
        </div>
      </div>

      <div className="px-4 pt-3 pb-1 flex items-center justify-between text-xs border-b border-zinc-900 bg-black/40">
        <div className="flex items-center gap-1.5 text-zinc-400">
          <span className="w-2 h-2 rounded-full bg-emerald-400" />
          <span>ဖွင့်ထား: <strong className="text-white">{totalOpen}</strong></span>
        </div>
        <div className="flex items-center gap-1.5 text-zinc-400">
          <span className="w-2 h-2 rounded-full bg-amber-400" />
          <span>အကြိမ်ပြည့်: <strong className="text-[#FFCC00]">{totalFull}</strong></span>
        </div>
        <div className="flex items-center gap-1.5 text-zinc-400">
          <span className="w-2 h-2 rounded-full bg-red-500" />
          <span>ပိတ်ဂဏန်း: <strong className="text-red-400">{totalBlocked}</strong></span>
        </div>
        <div className="text-zinc-500 text-[11px]">စုစုပေါင်း: {totalAll} ကွက်</div>
      </div>

      <div className="px-4 py-2 bg-zinc-950/60 border-b border-zinc-900 flex items-center gap-2">
        <div className="relative flex-1">
          <Search className="w-3.5 h-3.5 text-zinc-500 absolute left-2.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value.replace(/\D/g, '').slice(0, defaultWidth))}
            placeholder={type === '2D' ? 'ဂဏန်းရှာပါ (00-99)...' : 'ဂဏန်းရှာပါ (000-999)...'}
            className="w-full h-8 pl-8 pr-2.5 rounded-lg bg-zinc-900 border border-zinc-800 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-[#FFCC00]"
          />
        </div>

        <div className="flex gap-1 overflow-x-auto pretty-scrollbar py-1">
          {filterTabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => {
                setFilter(tab.id);
                setSearchQuery('');
              }}
              className={`px-2.5 py-1 rounded-md text-[11px] font-semibold whitespace-nowrap transition ${
                filter === tab.id && !searchQuery
                  ? 'bg-[#FFCC00] text-black font-bold'
                  : 'bg-zinc-900 text-zinc-400 hover:text-white border border-zinc-800'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {isLoading && (
        <div className="px-4 py-1.5 text-center text-[11px] text-zinc-500">ဂဏန်းအခြေအနေ ရယူနေပါသည်...</div>
      )}

      {viewMode === 'pills' && (
        <div className="relative border-b border-zinc-900 bg-black/30">
          <button
            onClick={handleScrollLeft}
            className="absolute left-1 top-7 -translate-y-1/2 z-10 w-7 h-7 rounded-full bg-black/90 border border-zinc-700 text-zinc-300 hover:text-[#FFCC00] hover:border-[#FFCC00] flex items-center justify-center backdrop-blur-md shadow-lg active:scale-95 transition"
            aria-label="Scroll left"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>

          <button
            onClick={handleScrollRight}
            className="absolute right-1 top-7 -translate-y-1/2 z-10 w-7 h-7 rounded-full bg-black/90 border border-zinc-700 text-zinc-300 hover:text-[#FFCC00] hover:border-[#FFCC00] flex items-center justify-center backdrop-blur-md shadow-lg active:scale-95 transition"
            aria-label="Scroll right"
          >
            <ChevronRight className="w-4 h-4" />
          </button>

          <div ref={scrollContainerRef} className="px-9 pt-3 pb-3.5 overflow-x-auto numbers-scrollbar">
            <div className="flex items-center gap-2.5 w-max">
              {filteredNumbers.map((num) => {
                const isSelected = selectedNumber === num;
                const limitInfo = limits[num];
                const isBlocked = limitInfo?.isBlocked;
                const isFull = !isBlocked && (limitInfo?.currentBetCount || 0) >= (limitInfo?.maxBetCount || 100);
                const isAmountFull =
                  !isBlocked &&
                  !isFull &&
                  (limitInfo?.maxBetAmount || 0) > 0 &&
                  (limitInfo?.currentBetAmount || 0) >= (limitInfo?.maxBetAmount || 0);

                return (
                  <button
                    key={num}
                    ref={isSelected ? activePillRef : null}
                    onClick={() => {
                      setSelectedNumber(num);
                      setInputLimit((limits[num]?.maxBetCount || 100).toString());
                      setInputAmountLimit((limits[num]?.maxBetAmount || 0).toString());
                    }}
                    className={`w-13 h-13 rounded-2xl flex flex-col items-center justify-center font-bold text-base transition-all cursor-pointer relative shrink-0 ${
                      isSelected
                        ? 'bg-[#FFCC00] text-black ring-2 ring-[#FFCC00] scale-105 shadow-[0_0_15px_rgba(255,204,0,0.4)]'
                        : isBlocked
                        ? 'bg-red-950/60 text-red-400 border border-red-800/80'
                        : isFull
                        ? 'bg-amber-950/40 text-amber-300 border border-amber-600/60'
                        : isAmountFull
                        ? 'bg-red-900/40 text-red-300 border border-red-700/60'
                        : 'bg-black text-[#FFCC00] border border-[#FFCC00] hover:bg-[#FFCC00]/10 active:scale-95'
                    }`}
                  >
                    <span>{num}</span>
                    <span
                      className={`text-[9px] font-medium leading-none mt-0.5 ${
                        isSelected ? 'text-black/80 font-bold' : 'text-zinc-400'
                      }`}
                    >
                      {limitInfo ? `${limitInfo.currentBetCount}ကြိမ်` : '0ကြိမ်'}
                    </span>

                    {isBlocked && (
                      <span
                        title="ပိတ်ဂဏန်း"
                        className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-red-600 rounded-full border border-black flex items-center justify-center text-[8px] text-white"
                      >
                        ✕
                      </span>
                    )}
                    {isFull && (
                      <span
                        title="အကြိမ်ရေပြည့်ပြီ"
                        className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-amber-500 rounded-full border border-black flex items-center justify-center text-[7px] text-black font-black"
                      >
                        ●
                      </span>
                    )}
                    {isAmountFull && (
                      <span
                        title="ငွေပမာဏပြည့်ပြီ (ထိုးနိုင်ဆဲ)"
                        className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-red-500 rounded-full border border-black flex items-center justify-center text-[7px] text-white font-black"
                      >
                        ¥
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {viewMode === 'grid' && (
        <div className="px-3 pt-3 pb-4 border-b border-zinc-900 bg-zinc-950/80 max-h-80 overflow-y-auto pretty-scrollbar">
          <div className="grid grid-cols-10 gap-1.5 pb-2">
            {filteredNumbers.map((num) => {
              const isSelected = selectedNumber === num;
              const limitInfo = limits[num];
              const isBlocked = limitInfo?.isBlocked;
              const isFull = !isBlocked && (limitInfo?.currentBetCount || 0) >= (limitInfo?.maxBetCount || 100);
              const isAmountFull =
                !isBlocked &&
                !isFull &&
                (limitInfo?.maxBetAmount || 0) > 0 &&
                (limitInfo?.currentBetAmount || 0) >= (limitInfo?.maxBetAmount || 0);

              return (
                <button
                  key={num}
                  onClick={() => {
                    setSelectedNumber(num);
                    setInputLimit((limits[num]?.maxBetCount || 100).toString());
                    setInputAmountLimit((limits[num]?.maxBetAmount || 0).toString());
                  }}
                  className={`aspect-square rounded-xl flex flex-col items-center justify-center text-[10px] font-bold transition relative ${
                    isSelected
                      ? 'bg-[#FFCC00] text-black ring-2 ring-white shadow-md'
                      : isBlocked
                      ? 'bg-red-950/60 text-red-400 border border-red-800/80'
                      : isFull
                      ? 'bg-amber-950/40 text-amber-300 border border-amber-600/60'
                      : isAmountFull
                      ? 'bg-red-900/40 text-red-300 border border-red-700/60'
                      : 'bg-black text-[#FFCC00] border border-zinc-800 hover:border-[#FFCC00]/50'
                  }`}
                >
                  <span>{num}</span>
                  <span className="text-[8px] opacity-75 font-normal leading-none">
                    {limitInfo?.currentBetCount || 0}
                  </span>
                  {isBlocked && <span className="absolute top-0.5 right-0.5 w-1.5 h-1.5 rounded-full bg-red-500" />}
                  {isFull && <span className="absolute top-0.5 right-0.5 w-1.5 h-1.5 rounded-full bg-amber-400" />}
                  {isAmountFull && <span className="absolute top-0.5 right-0.5 w-1.5 h-1.5 rounded-full bg-red-500" />}
                </button>
              );
            })}
          </div>
        </div>
      )}

      {toastMessage && (
        <div className="mx-4 mt-3 p-2.5 rounded-xl bg-emerald-950/90 border border-emerald-500/60 text-emerald-300 text-xs text-center flex items-center justify-center gap-2 shadow-lg animate-in fade-in">
          <Check className="w-4 h-4 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      <div className="flex-1 px-4 pt-4 pb-32 max-w-sm mx-auto w-full space-y-4">
        <div className="p-5 rounded-3xl bg-black border border-[#FFCC00] text-center shadow-lg">
          <div className="flex items-center justify-between text-zinc-400 text-xs font-semibold px-2">
            <span>SELECTED {type}</span>
            <span className="text-zinc-500 font-mono">{type === '2D' ? '00-99 MATRIX' : '000-999 MATRIX'}</span>
          </div>

          <div className="text-6xl font-black text-[#FFCC00] my-2 tracking-widest drop-shadow-[0_4px_10px_rgba(255,204,0,0.2)]">
            {selectedNumber}
          </div>

          <div className="flex items-center justify-center gap-2">
            {currentInfo.isBlocked ? (
              <span className="px-3.5 py-1 rounded-full text-xs font-bold bg-red-500/20 text-red-400 border border-red-500/40 flex items-center gap-1.5">
                <Ban className="w-3.5 h-3.5" />
                ပိတ်ဂဏန်း (Blocked)
              </span>
            ) : isLimitReached ? (
              <span className="px-3.5 py-1 rounded-full text-xs font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40 flex items-center gap-1.5">
                <AlertCircle className="w-3.5 h-3.5" />
                အကြိမ်ရေပြည့်ပြီ (Limit Full)
              </span>
            ) : (
              <span className="px-3.5 py-1 rounded-full text-xs font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 flex items-center gap-1.5">
                <Check className="w-3.5 h-3.5" />
                ဖွင့်လှစ်ထားသည် (Open for Bets)
              </span>
            )}
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="p-3.5 rounded-2xl bg-zinc-950 border border-zinc-800 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between text-zinc-400 text-xs">
                <span>ထိုးပြီးသည့် အကြိမ်ရေ</span>
              </div>
              <div className="text-white font-extrabold text-xl mt-1.5 flex items-baseline gap-1">
                <span>{currentInfo.currentBetCount}</span>
                <span className="text-xs text-zinc-400 font-normal">ကြိမ်</span>
              </div>
            </div>

            <div className="mt-3">
              <div className="flex justify-between text-[10px] text-zinc-400 mb-1">
                <span>ပြည့်မီမှု</span>
                <span>
                  {Math.min(100, Math.round((currentInfo.currentBetCount / currentInfo.maxBetCount) * 100))}%
                </span>
              </div>
              <div className="w-full bg-zinc-800 rounded-full h-1.5 overflow-hidden">
                <div
                  className={`h-full rounded-full transition-all ${isLimitReached ? 'bg-amber-400' : 'bg-[#FFCC00]'}`}
                  style={{
                    width: `${Math.min(100, (currentInfo.currentBetCount / currentInfo.maxBetCount) * 100)}%`,
                  }}
                />
              </div>
            </div>
          </div>

          <div className="p-3.5 rounded-2xl bg-zinc-950 border border-zinc-800 flex flex-col justify-between">
            <div>
              <div className="text-zinc-400 text-xs">အများဆုံး ကန့်သတ်အကြိမ်ရေ</div>
              <div className="text-[#FFCC00] font-extrabold text-xl mt-1.5 flex items-baseline gap-1">
                <span>{currentInfo.maxBetCount}</span>
                <span className="text-xs text-zinc-400 font-normal">ကြိမ်</span>
              </div>
            </div>

            <div className="mt-3 pt-1 border-t border-zinc-900 flex items-center justify-between text-[11px]">
              <span className="text-zinc-400">ကျန်ရှိသည့် အကြိမ်:</span>
              <span className={`font-bold ${remainingCount === 0 ? 'text-red-400' : 'text-emerald-400'}`}>
                {remainingCount} ကြိမ်
              </span>
            </div>
          </div>
        </div>

        {role === 'admin' ? (
          <>
            <div className="p-4 rounded-2xl bg-black border border-zinc-800 space-y-3">
              <div className="flex items-center justify-between">
                <label className="block text-zinc-300 text-xs font-semibold">
                  အကြိမ်ရေ ကန့်သတ်ချက် သတ်မှတ်ရန် (Set Max Bet Times Limit)
                </label>
                <span className="text-[10px] text-zinc-500 font-mono">Bet Times Only</span>
              </div>

              <div className="flex items-center gap-1.5">
                {[50, 100, 200, 500, 1000].map((preset) => (
                  <button
                    key={preset}
                    type="button"
                    onClick={() => setInputLimit(preset.toString())}
                    className={`flex-1 py-1 rounded-lg text-xs font-bold transition border ${
                      inputLimit === preset.toString()
                        ? 'bg-[#FFCC00] text-black border-[#FFCC00]'
                        : 'bg-zinc-900 text-zinc-300 border-zinc-800 hover:border-zinc-700'
                    }`}
                  >
                    {preset}
                  </button>
                ))}
              </div>

              <div className="flex gap-2">
                <div className="relative flex-1">
                  <Hash className="w-4 h-4 text-zinc-500 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="number"
                    min="1"
                    step="1"
                    value={inputLimit}
                    onChange={(e) => setInputLimit(e.target.value)}
                    placeholder="ဥပမာ - 100 (အကြိမ်ရေ)"
                    className="w-full h-11 pl-9 pr-3 rounded-xl bg-zinc-900 border border-zinc-700 text-sm text-white font-semibold focus:outline-none focus:border-[#FFCC00]"
                  />
                </div>

                <button
                  onClick={handleSaveLimit}
                  className="px-4 h-11 rounded-xl bg-[#FFCC00] text-black font-bold text-xs hover:bg-[#ffbe00] active:scale-95 transition whitespace-nowrap shadow-[0_0_10px_rgba(255,204,0,0.2)]"
                >
                  သတ်မှတ်မည်
                </button>
              </div>

              <button
                onClick={handleApplyToAll}
                className="w-full py-2 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-300 hover:text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition active:scale-95"
              >
                <CheckCheck className="w-3.5 h-3.5 text-[#FFCC00]" />
                <span>
                  ဂဏန်းအားလုံး ({type === '2D' ? '00-99' : '000-999'}) ကို [{inputLimit} ကြိမ်] စီ တစ်ပြိုင်နက် သတ်မှတ်မည်
                </span>
              </button>
            </div>

            <div className="p-4 rounded-2xl bg-black border border-zinc-800 space-y-3">
              <div className="flex items-center justify-between">
                <label className="block text-zinc-300 text-xs font-semibold">
                  နေ့စဉ် ငွေပမာဏ ကန့်သတ်ချက် (Daily Amount Limit)
                </label>
                <span className="text-[10px] text-zinc-500 font-mono">Soft · ပြည့်လျှင် အနီရောင် · ထိုးနိုင်ဆဲ</span>
              </div>

              <div className="grid grid-cols-4 gap-1.5">
                {[0, 10000, 30000, 50000, 100000, 300000, 500000].map((preset) => (
                  <button
                    key={preset}
                    type="button"
                    onClick={() => setInputAmountLimit(preset.toString())}
                    className={`py-1 rounded-lg text-xs font-bold transition border ${
                      inputAmountLimit === preset.toString()
                        ? 'bg-[#FFCC00] text-black border-[#FFCC00]'
                        : 'bg-zinc-900 text-zinc-300 border-zinc-800 hover:border-zinc-700'
                    }`}
                  >
                    {preset === 0 ? 'Off' : `${preset / 1000}k`}
                  </button>
                ))}
              </div>

              <div className="flex gap-2">
                <div className="relative flex-1">
                  <Banknote className="w-4 h-4 text-zinc-500 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="number"
                    min="0"
                    step="1000"
                    value={inputAmountLimit}
                    onChange={(e) => setInputAmountLimit(e.target.value)}
                    placeholder="0 = ကန့်သတ်မရှိ (ကျပ်)"
                    className="w-full h-11 pl-9 pr-3 rounded-xl bg-zinc-900 border border-zinc-700 text-sm text-white font-semibold focus:outline-none focus:border-[#FFCC00]"
                  />
                </div>

                <button
                  onClick={handleSaveAmountLimit}
                  className="px-4 h-11 rounded-xl bg-[#FFCC00] text-black font-bold text-xs hover:bg-[#ffbe00] active:scale-95 transition whitespace-nowrap shadow-[0_0_10px_rgba(255,204,0,0.2)]"
                >
                  သတ်မှတ်မည်
                </button>
              </div>

              <button
                onClick={handleApplyAmountToAll}
                className="w-full py-2 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 text-zinc-300 hover:text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition active:scale-95"
              >
                <CheckCheck className="w-3.5 h-3.5 text-[#FFCC00]" />
                <span>
                  ဂဏန်းအားလုံး ({type === '2D' ? '00-99' : '000-999'}) ကို [{inputAmountLimit} ကျပ်] စီ တစ်ပြိုင်နက် သတ်မှတ်မည်
                </span>
              </button>

              <div className="text-[10px] text-zinc-500">
                လက်ရှိ ထိုးငွေစုစုပေါင်း:{' '}
                <span className={isAmountReached ? 'text-red-400 font-bold' : 'text-emerald-400 font-bold'}>
                  {currentInfo.currentBetAmount.toLocaleString()} ကျပ်
                </span>{' '}
                / {currentInfo.maxBetAmount > 0 ? `${currentInfo.maxBetAmount.toLocaleString()} ကျပ်` : 'ကန့်သတ်မရှိ'}
              </div>
            </div>

            <div>
              <button
                onClick={handleToggleBlock}
                className={`w-full py-3.5 rounded-2xl font-bold text-sm flex items-center justify-center gap-2 transition active:scale-[0.98] shadow-md ${
                  currentInfo.isBlocked
                    ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-950'
                    : 'bg-red-600 hover:bg-red-500 text-white shadow-red-950'
                }`}
              >
                {currentInfo.isBlocked ? (
                  <>
                    <Check className="w-4 h-4" />
                    <span>ဂဏန်း ပြန်ဖွင့်မည် (Unblock Number {selectedNumber})</span>
                  </>
                ) : (
                  <>
                    <Ban className="w-4 h-4" />
                    <span>ဂဏန်း ပိတ်မည် (Block Number {selectedNumber})</span>
                  </>
                )}
              </button>
            </div>
          </>
        ) : (
          <div className="p-3.5 rounded-2xl bg-zinc-900/80 border border-zinc-800 flex items-start gap-2.5 text-xs text-zinc-400">
            <Lock className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <div>
              <strong className="text-zinc-200">Agent View:</strong> ဂဏန်းပိတ်ခြင်း၊ အကြိမ်ရေကန့်သတ်ခြင်းများကို Master Admin သာ စီမံခွင့်ရှိပါသည်။
            </div>
          </div>
        )}

        <div className="p-3 rounded-xl bg-black/40 border border-zinc-900 text-[11px] text-zinc-400 space-y-1">
          <div className="text-zinc-300 font-semibold flex items-center gap-1">
            <span className="text-[#FFCC00]">★</span>
            <span>ထိုးနိုင်သည့် အကြိမ်ရေ ကန့်သတ်ချက် စနစ်:</span>
          </div>
          <p className="leading-relaxed">
            Admin မှ ကန့်သတ်ချက်ကို ၁၀၀ ကြိမ် သတ်မှတ်ထားပါက အဆိုပါဂဏန်းကို ထိုးပြီးပါက အကြိမ်ရေ တိုးသွားပြီး ၁၀၀ ပြည့်ပါက မည်သူမျှ ထပ်မံထိုး၍ မရတော့ပါ။
          </p>
        </div>
      </div>
    </div>
  );
}
