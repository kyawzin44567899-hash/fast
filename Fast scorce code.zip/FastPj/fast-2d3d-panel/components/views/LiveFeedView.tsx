'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  ArrowLeft,
  Radio,
  RefreshCw,
  TrendingUp,
  Clock,
  Calendar,
  Search,
  Sparkles,
  Trophy,
  AlertCircle,
  ChevronRight,
  Filter,
  CheckCircle2,
  Zap
} from 'lucide-react';
import {
  Thai2DLiveResponse,
  Thai3DResponse,
  Thai2DHistoryItem,
  ShwelaminTwodItem,
  SetLiveData,
} from '@/lib/types';
import {
  fetchThai2DLive,
  fetchThai2DResults,
  fetchThai2DHistory,
  fetchThai3DResults,
  fetchShwelaminTwod,
  fetchSetLiveModernInternet,
} from '@/lib/thaiLotteryService';

interface LiveFeedViewProps {
  onBack: () => void;
  liveData?: Thai2DLiveResponse | null;
  threeDData?: Thai3DResponse | null;
  onRefreshAll?: () => void;
}

type TabType = 'live' | 'results_history' | 'stock_ticks' | 'threed';

function getMyanmarToday(): string {
  return new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Yangon' }).format(new Date());
}

function isTodayDate(dateStr?: string | null): boolean {
  if (!dateStr) return false;
  return String(dateStr).slice(0, 10) === getMyanmarToday();
}

export function LiveFeedView({ onBack, liveData: initialLive, threeDData: initial3D, onRefreshAll }: LiveFeedViewProps) {
  const [activeTab, setActiveTab] = useState<TabType>('live');

  const [live, setLive] = useState<Thai2DLiveResponse | null>(initialLive || null);
  const [isLoadingLive, setIsLoadingLive] = useState(false);
  const [lastSyncTime, setLastSyncTime] = useState<string>('');

  const [resultsList, setResultsList] = useState<any[]>([]);
  const [isLoadingResults, setIsLoadingResults] = useState(false);
  const [selectedResultDate, setSelectedResultDate] = useState<string>('');

  const [ticksList, setTicksList] = useState<Thai2DHistoryItem[]>([]);
  const [isLoadingTicks, setIsLoadingTicks] = useState(false);
  const [tickDate, setTickDate] = useState<string>('');
  const [filterTwod, setFilterTwod] = useState<string>('');

  const [threeD, setThreeD] = useState<Thai3DResponse | null>(initial3D || null);
  const [isLoading3D, setIsLoading3D] = useState(false);

  const [shwelamin, setShwelamin] = useState<ShwelaminTwodItem | null>(null);
  const [setlive, setSetlive] = useState<SetLiveData | null>(null);

  const [statusNotice, setStatusNotice] = useState<string>('');

  const loadLive = useCallback(async (showLoading = false) => {
    if (showLoading) setIsLoadingLive(true);
    try {
      const data = await fetchThai2DLive();
      if (data) {
        setLive(data);
        setLastSyncTime(new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
      }
    } finally {
      if (showLoading) setIsLoadingLive(false);
    }
  }, []);

  const loadResults = useCallback(async (dateFilter?: string, withLoading = true) => {
    if (withLoading) setIsLoadingResults(true);
    try {
      const data = await fetchThai2DResults(dateFilter);
      if (Array.isArray(data)) {
        setResultsList(data);
      } else if (data && Array.isArray(data.data)) {
        setResultsList(data.data);
      } else {
        setResultsList([]);
      }
    } finally {
      if (withLoading) setIsLoadingResults(false);
    }
  }, []);

  const loadTicks = useCallback(async (date?: string, twod?: string, withLoading = true) => {
    if (withLoading) setIsLoadingTicks(true);
    try {
      const data = await fetchThai2DHistory(date || undefined, twod || undefined);
      if (data && Array.isArray(data)) {
        setTicksList(data);
      } else {
        setTicksList([]);
      }
    } finally {
      if (withLoading) setIsLoadingTicks(false);
    }
  }, []);

  const load3D = useCallback(async (withLoading = true) => {
    if (withLoading) setIsLoading3D(true);
    try {
      const data = await fetchThai3DResults();
      if (data) {
        setThreeD(data);
      }
    } finally {
      if (withLoading) setIsLoading3D(false);
    }
  }, []);

  useEffect(() => {
    let ignore = false;
    let setliveBusy = false;

    async function initialFetch() {
      const liveData = await fetchThai2DLive();
      if (!ignore && liveData) {
        setLive(liveData);
        setLastSyncTime(new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
      }
      const d3 = await fetchThai3DResults();
      if (!ignore && d3) {
        setThreeD(d3);
      }
      const sw = await fetchShwelaminTwod();
      if (!ignore && sw?.data?.[0]) {
        setShwelamin(sw.data[0]);
      }
      const sl = await fetchSetLiveModernInternet();
      if (!ignore && sl) {
        setSetlive(sl);
      }
    }

    initialFetch();

    const liveInterval = setInterval(async () => {
      if (typeof document !== 'undefined' && document.hidden) return;
      const liveData = await fetchThai2DLive();
      if (!ignore && liveData) {
        setLive(liveData);
        setLastSyncTime(new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
      }
    }, 1500);

    const shwelaminInterval = setInterval(async () => {
      if (typeof document !== 'undefined' && document.hidden) return;
      const sw = await fetchShwelaminTwod();
      if (!ignore && sw?.data?.[0]) {
        setShwelamin(sw.data[0]);
      }
    }, 30000);

    const setliveInterval = setInterval(async () => {
      if (typeof document !== 'undefined' && document.hidden) return;
      if (setliveBusy) return;
      setliveBusy = true;
      try {
        const sl = await fetchSetLiveModernInternet();
        if (!ignore && sl) {
          setSetlive(sl);
        }
      } finally {
        setliveBusy = false;
      }
    }, 1000);

    return () => {
      ignore = true;
      clearInterval(liveInterval);
      clearInterval(shwelaminInterval);
      clearInterval(setliveInterval);
    };
  }, []);

  const handleTabChange = (newTab: TabType) => {
    setActiveTab(newTab);
    if (newTab === 'results_history' && resultsList.length === 0) {
      loadResults();
    } else if (newTab === 'stock_ticks' && ticksList.length === 0) {
      const today = new Date().toISOString().slice(0, 10);
      setTickDate(today);
      loadTicks(today);
    } else if (newTab === 'threed' && !threeD) {
      load3D();
    }
  };

  const handleManualRefresh = () => {
    if (onRefreshAll) onRefreshAll();
    if (activeTab === 'live') loadLive(true);
    if (activeTab === 'results_history') loadResults(selectedResultDate);
    if (activeTab === 'stock_ticks') loadTicks(tickDate, filterTwod);
    if (activeTab === 'threed') load3D();

    setStatusNotice('ဒေတာများကို အသစ်ရယူပြီးပါပြီ (Updated)');
    setTimeout(() => setStatusNotice(''), 3000);
  };

  const liveObj = live?.live;
  const isMarketOpen = liveObj && liveObj.set !== '--' && liveObj.twod !== '--';
  const isHoliday = !!live?.holiday;

  const currentSet = liveObj?.set && liveObj.set !== '--' ? liveObj.set : '--';
  const currentVal = liveObj?.value && liveObj.value !== '--' ? liveObj.value : '--';
  const live2D = liveObj?.twod && liveObj.twod !== '--' ? liveObj.twod : '--';

  const setDigits = currentSet.replace(/,/g, '');
  const valDigits = currentVal.replace(/,/g, '');
  const lastSet = setDigits.includes('.') ? setDigits.split('.')[0].slice(-1) : setDigits.slice(-1);
  const firstValDecimal = valDigits.includes('.') ? valDigits.split('.')[1].charAt(0) : '0';

  const todayResults = (live?.result || []).filter((r) =>
    isTodayDate(r.stock_date || live?.live?.date)
  );

  return (
    <div className="flex flex-col min-h-screen bg-[#101012] text-white selection:bg-amber-400 selection:text-black">
      <div className="sticky top-0 z-30 flex items-center justify-between px-4 py-3 bg-[#101012]/95 backdrop-blur-md border-b border-zinc-900">
        <button
          onClick={onBack}
          className="w-10 h-10 rounded-full flex items-center justify-center text-[#FFCC00] hover:bg-zinc-800 transition active:scale-95"
          aria-label="Back"
        >
          <ArrowLeft className="w-7 h-7 stroke-[2.5]" />
        </button>

        <h1 className="text-xl font-bold tracking-wide text-[#FFCC00] flex items-center gap-2">
          <span className={`w-2.5 h-2.5 rounded-full ${isMarketOpen ? 'bg-emerald-400 animate-pulse' : 'bg-red-500'}`} />
          <span>2D 3D Live Feed</span>
        </h1>

        <button
          onClick={handleManualRefresh}
          className="w-10 h-10 rounded-full flex items-center justify-center text-[#FFCC00] hover:bg-zinc-800 transition active:scale-90"
          title="Refresh Data"
        >
          <RefreshCw className={`w-5 h-5 ${isLoadingLive || isLoadingResults || isLoadingTicks || isLoading3D ? 'animate-spin' : ''}`} />
        </button>
      </div>

      {statusNotice && (
        <div className="mx-4 mt-2 p-2 rounded-xl bg-emerald-950/80 border border-emerald-500/50 text-emerald-300 text-xs text-center flex items-center justify-center gap-1.5 animate-in fade-in">
          <CheckCircle2 className="w-3.5 h-3.5" />
          <span>{statusNotice}</span>
        </div>
      )}

      <div className="px-4 pt-3 pb-1">
        <div className="flex p-1 bg-black rounded-2xl border border-zinc-850 gap-1 overflow-x-auto no-scrollbar">
          <button
            onClick={() => handleTabChange('live')}
            className={`flex-1 min-w-[75px] py-2 px-2.5 rounded-xl text-xs font-bold transition whitespace-nowrap text-center ${
              activeTab === 'live'
                ? 'bg-[#FFCC00] text-black shadow-md'
                : 'text-zinc-400 hover:text-white'
            }`}
          >
            Live 2D
          </button>
          <button
            onClick={() => handleTabChange('results_history')}
            className={`flex-1 min-w-[85px] py-2 px-2.5 rounded-xl text-xs font-bold transition whitespace-nowrap text-center ${
              activeTab === 'results_history'
                ? 'bg-[#FFCC00] text-black shadow-md'
                : 'text-zinc-400 hover:text-white'
            }`}
          >
            2D ရလဒ်များ
          </button>
          <button
            onClick={() => handleTabChange('stock_ticks')}
            className={`flex-1 min-w-[85px] py-2 px-2.5 rounded-xl text-xs font-bold transition whitespace-nowrap text-center ${
              activeTab === 'stock_ticks'
                ? 'bg-[#FFCC00] text-black shadow-md'
                : 'text-zinc-400 hover:text-white'
            }`}
          >
            မိနစ်လိုက်
          </button>
          <button
            onClick={() => handleTabChange('threed')}
            className={`flex-1 min-w-[75px] py-2 px-2.5 rounded-xl text-xs font-bold transition whitespace-nowrap text-center ${
              activeTab === 'threed'
                ? 'bg-[#FFCC00] text-black shadow-md'
                : 'text-zinc-400 hover:text-white'
            }`}
          >
            3D ထွက်ဂဏန်း
          </button>
        </div>
      </div>

      <div className="flex-1 px-4 pt-3 pb-32 max-w-sm mx-auto w-full space-y-4">
        {activeTab === 'live' && (
          <div className="space-y-4 animate-in fade-in">
            <div className="p-5 rounded-3xl bg-black border border-[#FFCC00] text-center shadow-[0_0_25px_rgba(255,204,0,0.18)]">
              <div className="flex items-center justify-between text-xs text-zinc-400 pb-3 border-b border-zinc-900">
                <span className="flex items-center gap-1.5 font-bold">
                  {isMarketOpen ? (
                    <span className="flex items-center gap-1.5 text-emerald-400">
                      <Radio className="w-3.5 h-3.5 animate-pulse" /> LIVE STREAMING
                    </span>
                  ) : (
                    <span className="flex items-center gap-1.5 text-amber-400">
                      <Clock className="w-3.5 h-3.5" /> MARKET CLOSED
                    </span>
                  )}
                </span>
                <span className="flex items-center gap-1 font-mono text-[#FFCC00] text-[11px]">
                  {live?.server_time ? live.server_time.split(' ')[1] : lastSyncTime || 'Auto-Sync'}
                </span>
              </div>

              <div className="py-6 relative overflow-hidden flex flex-col items-center justify-center">
                <motion.div
                  animate={{
                    scale: [0.95, 1.12, 0.95],
                    opacity: [0.25, 0.5, 0.25],
                  }}
                  transition={{
                    duration: 3,
                    repeat: Infinity,
                    ease: 'easeInOut',
                  }}
                  className="absolute w-44 h-44 rounded-full bg-[#FFCC00]/20 blur-2xl pointer-events-none -z-0"
                />

                <div className="relative z-10 flex flex-col items-center">
                  <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-zinc-900/90 border border-zinc-700/60 text-[11px] text-zinc-300 font-medium mb-2 shadow-inner">
                    <Zap className="w-3 h-3 text-[#FFCC00] animate-pulse" />
                    <span className="uppercase tracking-wider">Thai SET Live 2D</span>
                  </div>

                  <motion.div
                    animate={{
                      y: [-5, 5, -5],
                      rotate: [-0.5, 0.5, -0.5],
                    }}
                    transition={{
                      duration: 3.2,
                      repeat: Infinity,
                      ease: 'easeInOut',
                    }}
                    className="relative my-2 py-1 px-4 cursor-default select-none"
                  >
                    <AnimatePresence mode="popLayout">
                      <motion.div
                        key={live2D}
                        initial={{ scale: 0.85, opacity: 0.5, y: -4 }}
                        animate={{ scale: 1, opacity: 1, y: 0 }}
                        exit={{ scale: 1.15, opacity: 0, y: 4 }}
                        transition={{
                          type: 'spring',
                          stiffness: 500,
                          damping: 24,
                          mass: 0.8,
                        }}
                        className="text-8xl font-black text-[#FFCC00] font-mono tracking-widest drop-shadow-[0_0_25px_rgba(255,204,0,0.6)] flex items-center justify-center"
                      >
                        {live2D}
                      </motion.div>
                    </AnimatePresence>
                  </motion.div>

                  <div className="text-xs text-emerald-400 font-medium mt-1 bg-emerald-950/40 border border-emerald-800/40 px-3 py-1 rounded-xl">
                    တွက်ချက်နည်း: SET ({lastSet}) + VALUE ({firstValDecimal}) = <span className="font-bold text-[#FFCC00]">{live2D}</span>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3 pt-3 border-t border-zinc-900 text-left">
                <div className="p-3 rounded-2xl bg-zinc-950 border border-zinc-800">
                  <div className="text-[11px] text-zinc-400">SET Index</div>
                  <div className="text-[#FFCC00] font-bold text-base mt-0.5 font-mono">{currentSet}</div>
                  <div className="text-[10px] text-zinc-500">Official Stock Exchange</div>
                </div>
                <div className="p-3 rounded-2xl bg-zinc-950 border border-zinc-800">
                  <div className="text-[11px] text-zinc-400">Value (M. Baht)</div>
                  <div className="text-white font-bold text-base mt-0.5 font-mono">{currentVal}</div>
                  <div className="text-[10px] text-emerald-400 font-semibold">Live Volume</div>
                </div>
              </div>

              <div className="mt-3 pt-2 border-t border-zinc-900 flex items-center justify-between text-[10px] text-zinc-500">
                <span className="flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                  API Instant Update Active
                </span>
                <span>သတင်းအချက်အလက် တိုက်ရိုက်ချိတ်ဆက်ထားသည်</span>
              </div>
            </div>

            <div className="p-4 rounded-3xl bg-black border border-zinc-800 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm font-bold text-[#FFCC00] flex items-center gap-1.5">
                  <Trophy className="w-4 h-4" /> ယနေ့ ပေါက်ဂဏန်း အချိန်ဇယား (12:01 PM / 04:30 PM)
                </span>
                <span className="text-[11px] text-zinc-400 font-mono">
                  {todayResults[0]?.stock_date || new Date().toISOString().slice(0, 10)}
                </span>
              </div>

              <div className="space-y-2.5">
                {[
                  { key: '12:01:00', label: '12:01 PM', name: 'မနက်ပိုင်း / နေ့လယ် (Morning Final)' },
                  { key: '16:30:00', label: '04:30 PM', name: 'ညနေပိုင်း (Evening Final)' },
                ].map((item) => {
                  const match = todayResults.find((r) => r.open_time?.startsWith(item.key.slice(0, 5)));
                  const is1201 = item.key.startsWith('12:01');
                  const swNum = is1201 ? shwelamin?.result_1200 : shwelamin?.result_430;
                  const swSet = is1201 ? shwelamin?.set_1200 : shwelamin?.set_430;
                  const swVal = is1201 ? shwelamin?.val_1200 : shwelamin?.val_430;
                  const num = match?.twod && match.twod !== '--' ? match.twod : swNum || '--';
                  const setVal = match ? match.set : swSet || '--';
                  const valVal = match ? match.value : swVal || '--';

                  return (
                    <div
                      key={item.key}
                      className="flex items-center justify-between p-3.5 rounded-2xl bg-zinc-950 border border-zinc-850 hover:border-zinc-700 transition"
                    >
                      <div className="flex flex-col">
                        <div className="flex items-center gap-2">
                          <span className="text-white font-bold text-base">{item.label}</span>
                          <span className="text-xs text-zinc-400">{item.name}</span>
                        </div>
                        <div className="text-[11px] text-zinc-400 font-mono mt-1">
                          SET: {setVal} | VAL: {valVal}
                        </div>
                      </div>
                      <div className="w-14 h-14 rounded-2xl bg-black border-2 border-[#FFCC00] flex items-center justify-center text-3xl font-black text-[#FFCC00] font-mono shadow-md">
                        {num}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="rounded-3xl bg-black border border-zinc-800 p-3.5 space-y-2">
              {[
                { label: '9:30 AM', modern: setlive?.modern_930, internet: setlive?.internet_930 },
                { label: '2:00 PM', modern: setlive?.modern_200, internet: setlive?.internet_200 },
              ].map((row) => (
                <div
                  key={row.label}
                  className="grid grid-cols-[auto_1fr_1fr] items-center gap-2 rounded-2xl bg-zinc-950 border border-zinc-850 px-3 py-2.5"
                >
                  <span className="text-xs font-bold text-[#FFCC00] w-14">{row.label}</span>
                  <div className="text-center">
                    <span className="block text-[10px] text-zinc-400">Modern</span>
                    <span className="block text-lg font-black text-[#FFCC00] font-mono leading-tight">
                      {row.modern || '--'}
                    </span>
                  </div>
                  <div className="text-center">
                    <span className="block text-[10px] text-zinc-400">Internet</span>
                    <span className="block text-lg font-black text-[#FFCC00] font-mono leading-tight">
                      {row.internet || '--'}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'results_history' && (
          <div className="space-y-4 animate-in fade-in">
            <div className="p-4 rounded-3xl bg-black border border-zinc-800 space-y-3">
              <span className="text-xs font-bold text-[#FFCC00] block">
                ရက်စွဲအလိုက် ရှာဖွေရန် (Query by Date)
              </span>
              <div className="flex items-center gap-2">
                <input
                  type="date"
                  value={selectedResultDate}
                  onChange={(e) => setSelectedResultDate(e.target.value)}
                  className="flex-1 p-2.5 rounded-xl bg-zinc-900 border border-zinc-700 text-xs text-white focus:outline-none focus:border-[#FFCC00]"
                />
                <button
                  onClick={() => {
                    if (selectedResultDate) {

                      const parts = selectedResultDate.split('-');
                      const formatted = `${parts[2]}-${parts[1]}-${parts[0]}`;
                      loadResults(formatted);
                    } else {
                      loadResults();
                    }
                  }}
                  className="px-4 py-2.5 rounded-xl bg-[#FFCC00] text-black font-bold text-xs hover:bg-[#ffc107] transition cursor-pointer"
                >
                  ရှာဖွေမည်
                </button>
                {selectedResultDate && (
                  <button
                    onClick={() => {
                      setSelectedResultDate('');
                      loadResults();
                    }}
                    className="p-2.5 rounded-xl bg-zinc-800 text-zinc-400 text-xs hover:text-white"
                    title="Reset"
                  >
                    Reset
                  </button>
                )}
              </div>
            </div>

            {isLoadingResults ? (
              <div className="py-12 text-center text-zinc-500">
                <RefreshCw className="w-6 h-6 animate-spin mx-auto mb-2 text-[#FFCC00]" />
                <span className="text-xs">ရလဒ်မှတ်တမ်းများ ရယူနေပါသည်...</span>
              </div>
            ) : resultsList.length === 0 ? (
              <div className="p-8 text-center rounded-3xl bg-black border border-zinc-850 text-zinc-500 text-xs">
                မှတ်တမ်း မတွေ့ရှိပါ (No historical results found)
              </div>
            ) : (
              <div className="space-y-3">
                {resultsList.map((dayItem, dIdx) => {
                  const dateStr = dayItem.date || `Day ${dIdx + 1}`;
                  const children = dayItem.child || [];

                  return (
                    <div
                      key={dateStr + dIdx}
                      className="p-4 rounded-3xl bg-black border border-zinc-850 space-y-3"
                    >
                      <div className="flex items-center justify-between pb-2 border-b border-zinc-900">
                        <div className="flex items-center gap-2">
                          <Calendar className="w-4 h-4 text-[#FFCC00]" />
                          <span className="font-bold text-white text-sm">{dateStr}</span>
                        </div>
                        <span className="text-[10px] text-zinc-500">Official Thai Stock</span>
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        {children
                          .filter((sess: any) => sess.time?.startsWith('12:01') || sess.time?.startsWith('16:30'))
                          .map((sess: any, sIdx: number) => (
                            <div
                              key={sIdx}
                              className="p-3 rounded-2xl bg-zinc-950 border border-zinc-900 flex items-center justify-between"
                            >
                              <div>
                                <div className="text-xs font-bold text-zinc-200">
                                  {sess.time?.startsWith('12:01') ? '12:01 PM' : sess.time?.startsWith('16:30') ? '04:30 PM' : sess.time?.slice(0, 5) || '--'}
                                </div>
                                <div className="text-[10px] text-zinc-500 font-mono mt-0.5">
                                  SET: {sess.set}
                                </div>
                              </div>
                              <div className="text-2xl font-black text-[#FFCC00] font-mono px-2.5 py-1 rounded-xl bg-black border border-zinc-800">
                                {sess.twod}
                              </div>
                            </div>
                          ))}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {activeTab === 'stock_ticks' && (
          <div className="space-y-4 animate-in fade-in">
            <div className="p-4 rounded-3xl bg-black border border-zinc-800 space-y-3">
              <span className="text-xs font-bold text-[#FFCC00] block">
                မိနစ်အလိုက် အတက်အကျ ကြည့်ရှုရန် (Stock Change Ticks)
              </span>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[10px] text-zinc-400 block mb-1">ရက်စွဲ (Date)</label>
                  <input
                    type="date"
                    value={tickDate}
                    onChange={(e) => setTickDate(e.target.value)}
                    className="w-full p-2 rounded-xl bg-zinc-900 border border-zinc-700 text-xs text-white focus:outline-none focus:border-[#FFCC00]"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-zinc-400 block mb-1">2D ဂဏန်းဖြင့် စစ်ထုတ်ရန်</label>
                  <input
                    type="text"
                    maxLength={2}
                    placeholder="ဥပမာ- 23"
                    value={filterTwod}
                    onChange={(e) => setFilterTwod(e.target.value.replace(/\D/g, ''))}
                    className="w-full p-2 rounded-xl bg-zinc-900 border border-zinc-700 text-xs text-white focus:outline-none focus:border-[#FFCC00] font-mono text-center"
                  />
                </div>
              </div>
              <button
                onClick={() => loadTicks(tickDate, filterTwod)}
                className="w-full py-2.5 rounded-xl bg-[#FFCC00] text-black font-bold text-xs hover:bg-[#ffc107] transition"
              >
                ဒေတာဆွဲထုတ်မည် (Fetch Ticks)
              </button>
            </div>

            {isLoadingTicks ? (
              <div className="py-12 text-center text-zinc-500">
                <RefreshCw className="w-6 h-6 animate-spin mx-auto mb-2 text-[#FFCC00]" />
                <span className="text-xs">မိနစ်အလိုက် စတော့ အတက်အကျ ရယူနေပါသည်...</span>
              </div>
            ) : ticksList.length === 0 || !ticksList[0]?.child || ticksList[0].child.length === 0 ? (
              <div className="p-8 text-center rounded-3xl bg-black border border-zinc-850 text-zinc-500 text-xs">
                ဤရက်စွဲအတွက် စတော့ အတက်အကျ မရှိပါ သို့မဟုတ် စတော့ဈေးကွက် ပိတ်ထားပါသည်
              </div>
            ) : (
              <div className="p-4 rounded-3xl bg-black border border-zinc-800 space-y-3">
                <div className="flex items-center justify-between text-xs text-zinc-400 pb-2 border-b border-zinc-900">
                  <span>အချိန် / အညွှန်းကိန်း</span>
                  <span>2D ရလဒ်</span>
                </div>

                <div className="max-h-96 overflow-y-auto space-y-2 pretty-scrollbar pr-1">
                  {ticksList[0].child.map((tick, tIdx) => (
                    <div
                      key={tIdx}
                      className="flex items-center justify-between p-2.5 rounded-xl bg-zinc-950 border border-zinc-900 text-xs"
                    >
                      <div className="flex flex-col">
                        <span className="font-mono font-bold text-[#FFCC00]">{tick.time}</span>
                        <span className="text-[10px] text-zinc-400 font-mono">
                          SET: {tick.set} | VAL: {tick.value}
                        </span>
                      </div>
                      <div className="w-10 h-10 rounded-xl bg-black border border-zinc-800 flex items-center justify-center font-mono font-black text-lg text-white">
                        {tick.twod}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {activeTab === 'threed' && (
          <div className="space-y-4 animate-in fade-in">
            <div className="p-5 rounded-3xl bg-black border border-[#FFCC00] shadow-[0_0_25px_rgba(255,204,0,0.15)] text-center">
              <div className="flex items-center justify-center gap-2 text-xs font-bold text-[#FFCC00] mb-2">
                <Sparkles className="w-4 h-4" />
                <span>ထိုင်း 3D တရားဝင် ပေါက်ဂဏန်းများ (Thai 3D Lottery)</span>
              </div>
              <p className="text-[11px] text-zinc-400 mb-4">
                လစဉ် ၁ ရက်နေ့ နှင့် ၁၆ ရက်နေ့တိုင်း ထွက်ရှိသော တရားဝင် ရလဒ်များ
              </p>

              {threeD?.data && threeD.data.length > 0 && (
                <div className="py-2">
                  <div className="text-[11px] text-zinc-400">နောက်ဆုံးထွက်ရှိထားသော 3D ပေါက်ဂဏန်း</div>
                  <div className="flex items-center justify-center gap-3 my-3">
                    {threeD.data[0].result.split('').map((digit, dIdx) => (
                      <div
                        key={dIdx}
                        className="w-16 h-16 rounded-full bg-gradient-to-b from-[#FFCC00] to-amber-600 text-black font-mono font-black text-3xl flex items-center justify-center shadow-[0_4px_15px_rgba(255,204,0,0.4)] border-2 border-yellow-200"
                      >
                        {digit}
                      </div>
                    ))}
                  </div>
                  <div className="text-xs text-amber-300 font-mono">
                    ရက်စွဲ: {threeD.data[0].datetime}
                  </div>
                </div>
              )}
            </div>

            <div className="p-4 rounded-3xl bg-black border border-zinc-800 space-y-3">
              <div className="flex items-center justify-between pb-2 border-b border-zinc-900">
                <span className="text-sm font-bold text-[#FFCC00]">3D ပေါက်ဂဏန်း မှတ်တမ်းများ</span>
                <span className="text-[10px] text-zinc-500">Official API 2dboss</span>
              </div>

              {isLoading3D ? (
                <div className="py-8 text-center text-zinc-500">
                  <RefreshCw className="w-6 h-6 animate-spin mx-auto mb-2 text-[#FFCC00]" />
                  <span className="text-xs">3D ရလဒ်များ ရယူနေပါသည်...</span>
                </div>
              ) : !threeD?.data || threeD.data.length === 0 ? (
                <div className="p-6 text-center text-zinc-500 text-xs">
                  3D ရလဒ်များ မတွေ့ရှိပါ
                </div>
              ) : (
                <div className="space-y-2.5">
                  {threeD.data.map((item, idx) => (
                    <div
                      key={item.datetime + idx}
                      className="flex items-center justify-between p-3.5 rounded-2xl bg-zinc-950 border border-zinc-850 hover:border-zinc-700 transition"
                    >
                      <div className="flex flex-col">
                        <div className="flex items-center gap-2">
                          <Calendar className="w-3.5 h-3.5 text-[#FFCC00]" />
                          <span className="text-white font-bold text-xs">{item.datetime}</span>
                        </div>
                        <span className="text-[10px] text-zinc-500 mt-0.5">
                          {idx === 0 ? 'နောက်ဆုံးထွက်ထားသော ဂဏန်း' : 'ယခင်ထွက်ထားသော ဂဏန်း'}
                        </span>
                      </div>

                      <div className="flex items-center gap-1.5">
                        {item.result.split('').map((char, cIdx) => (
                          <div
                            key={cIdx}
                            className="w-9 h-9 rounded-xl bg-black border border-[#FFCC00] text-[#FFCC00] font-mono font-black text-base flex items-center justify-center shadow-sm"
                          >
                            {char}
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
