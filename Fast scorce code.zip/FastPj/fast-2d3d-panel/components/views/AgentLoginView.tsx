'use client';

import React, { useState, useEffect } from 'react';
import { Logo2D3D } from '../Logo2D3D';
import { ArrowLeft, ShieldCheck, RefreshCw, Eye, EyeOff } from 'lucide-react';

interface AgentLoginViewProps {
  onSuccess: () => void;
  onBack: () => void;
}

export function AgentLoginView({ onSuccess, onBack }: AgentLoginViewProps) {
  const [step, setStep] = useState<'credentials' | 'otp'>('credentials');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [agentCode, setAgentCode] = useState('');
  const [secretKey, setSecretKey] = useState('');
  const [showSecret, setShowSecret] = useState(false);
  const [otp, setOtp] = useState('');
  const [error, setError] = useState('');
  const [info, setInfo] = useState('');
  const [loading, setLoading] = useState(false);
  const [secondsLeft, setSecondsLeft] = useState(0);

  useEffect(() => {
    if (secondsLeft <= 0) return;
    const timer = setInterval(() => setSecondsLeft((s) => Math.max(0, s - 1)), 1000);
    return () => clearInterval(timer);
  }, [secondsLeft]);

  const requestOtp = async (isResend = false) => {
    if (!email.trim() || !email.includes('@')) {
      setError('မှန်ကန်သော အီးမေးလ် ရိုက်ထည့်ပါ');
      return;
    }
    if (!phone.trim() || !agentCode.trim() || !secretKey.trim()) {
      setError('Agent ID, ဖုန်းနံပါတ် နှင့် Secret Key အားလုံး ဖြည့်ပါ');
      return;
    }
    setError('');
    setLoading(true);
    try {
      const res = await fetch('/api/auth/agent/request-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: email.trim(),
          phone: phone.trim(),
          agentCode: agentCode.trim(),
          secretKey: secretKey.trim(),
        }),
      });
      const data = await res.json();
      if (!res.ok || !data.success) {
        setError(data.error || 'OTP ပေးပို့၍ မရပါ');
        return;
      }
      setStep('otp');
      setOtp('');
      setSecondsLeft(600);
      setInfo(isResend ? 'OTP အသစ် ပေးပို့ပြီးပါပြီ' : 'OTP ကို အီးမေးလ်သို့ ပေးပို့ပြီးပါပြီ');
    } catch {
      setError('ဆာဗာနှင့် ချိတ်ဆက်ရာတွင် အဆင်မပြေပါ');
    } finally {
      setLoading(false);
    }
  };

  const verifyOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!/^\d{6}$/.test(otp.trim())) {
      setError('ဂဏန်း ၆ လုံး OTP ရိုက်ထည့်ပါ');
      return;
    }
    setError('');
    setLoading(true);
    try {
      const res = await fetch('/api/auth/agent/verify-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: email.trim(), otp: otp.trim() }),
      });
      const data = await res.json();
      if (!res.ok || !data.success) {
        setError(data.error || 'OTP မှားယွင်းနေပါသည်');
        return;
      }
      onSuccess();
    } catch {
      setError('ဆာဗာနှင့် ချိတ်ဆက်ရာတွင် အဆင်မပြေပါ');
    } finally {
      setLoading(false);
    }
  };

  const minutes = Math.floor(secondsLeft / 60);
  const seconds = String(secondsLeft % 60).padStart(2, '0');

  const inputClass =
    'w-full h-11 px-4 rounded-2xl bg-black border border-[#FFCC00] text-white placeholder-zinc-500 text-sm focus:outline-none focus:ring-2 focus:ring-[#FFCC00]/50';

  return (
    <div className="flex flex-col min-h-screen px-6 py-6 bg-black text-white selection:bg-amber-400 selection:text-black">
      <div className="w-full flex items-center justify-between">
        <button
          onClick={onBack}
          className="w-10 h-10 rounded-full flex items-center justify-center text-[#FFCC00] hover:bg-zinc-900 transition active:scale-95"
          aria-label="Back"
        >
          <ArrowLeft className="w-6 h-6" />
        </button>
      </div>

      <div className="flex flex-col items-center mt-1 mb-4">
        <Logo2D3D size="lg" showText={true} />
        <h2 className="mt-4 text-xl sm:text-2xl font-bold tracking-wide text-[#FFCC00]">Agent Login</h2>
        <p className="mt-1 text-[11px] text-zinc-400">
          {step === 'credentials'
            ? 'Agent အချက်အလက်များ ဖြည့်ပြီး OTP ရယူပါ'
            : 'အီးမေးလ်သို့ ပေးပို့ထားသော OTP ကို ရိုက်ထည့်ပါ'}
        </p>
      </div>

      <div className="w-full max-w-sm mx-auto space-y-3 flex-1 flex flex-col justify-center">
        {error && (
          <div className="p-2.5 rounded-xl bg-red-950/60 border border-red-500/50 text-red-300 text-xs text-center font-medium">
            {error}
          </div>
        )}
        {info && !error && (
          <div className="p-2.5 rounded-xl bg-emerald-950/60 border border-emerald-500/50 text-emerald-300 text-xs text-center font-medium">
            {info}
          </div>
        )}

        {step === 'credentials' ? (
          <form
            onSubmit={(e) => {
              e.preventDefault();
              void requestOtp(false);
            }}
            className="space-y-3"
          >
            <div>
              <label className="block text-[#FFCC00] text-sm font-semibold mb-1 pl-1">Agent Email</label>
              <input
                id="input-agent-email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="e.g. agent01@fast2d3d.com"
                className={inputClass}
                required
              />
            </div>

            <div>
              <label className="block text-[#FFCC00] text-sm font-semibold mb-1 pl-1">
                Agent Phone Number
              </label>
              <input
                id="input-agent-phone"
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="e.g. 09798765432"
                className={inputClass}
                required
              />
            </div>

            <div>
              <label className="block text-[#FFCC00] text-sm font-semibold mb-1 pl-1">Agent ID / Code</label>
              <input
                id="input-agent-code"
                type="text"
                value={agentCode}
                onChange={(e) => setAgentCode(e.target.value)}
                placeholder="e.g. FAG0123456"
                className={inputClass}
                required
              />
            </div>

            <div>
              <label className="block text-[#FFCC00] text-sm font-semibold mb-1 pl-1">Agent Secret Key</label>
              <div className="relative">
                <input
                  id="input-agent-secret-key"
                  type={showSecret ? 'text' : 'password'}
                  value={secretKey}
                  onChange={(e) => setSecretKey(e.target.value)}
                  placeholder="Enter Agent Secret Key"
                  className={`${inputClass} pr-12`}
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowSecret(!showSecret)}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-[#FFCC00]"
                >
                  {showSecret ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 px-6 rounded-2xl bg-[#FFCC00] hover:bg-[#ffbe00] active:scale-[0.98] text-black font-bold text-base flex items-center justify-center gap-2 shadow-[0_4px_16px_rgba(255,204,0,0.3)] transition cursor-pointer disabled:opacity-60 mt-2"
            >
              <ShieldCheck className="w-4 h-4" />
              {loading ? 'Sending...' : 'Send OTP'}
            </button>
          </form>
        ) : (
          <form onSubmit={verifyOtp} className="space-y-4">
            <div>
              <label className="block text-[#FFCC00] text-sm font-semibold mb-1 pl-1">6-Digit OTP</label>
              <input
                id="input-agent-otp"
                type="text"
                inputMode="numeric"
                maxLength={6}
                value={otp}
                onChange={(e) => setOtp(e.target.value.replace(/\D/g, '').slice(0, 6))}
                placeholder="583214"
                className="w-full h-12 px-4 rounded-2xl bg-black border border-[#FFCC00] text-white placeholder-zinc-600 text-center font-mono text-xl tracking-[0.5em] focus:outline-none focus:ring-2 focus:ring-[#FFCC00]/50"
                required
              />
              <div className="flex items-center justify-between mt-2 px-1 text-[11px] text-zinc-400">
                <span>{email}</span>
                <span className={secondsLeft <= 60 ? 'text-red-400' : 'text-amber-400'}>
                  {minutes}:{seconds}
                </span>
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 px-6 rounded-2xl bg-[#FFCC00] hover:bg-[#ffbe00] active:scale-[0.98] text-black font-bold text-base flex items-center justify-center shadow-[0_4px_16px_rgba(255,204,0,0.3)] transition cursor-pointer disabled:opacity-60"
            >
              {loading ? 'Verifying...' : 'Verify & Login'}
            </button>

            <div className="flex items-center justify-between text-[11px]">
              <button
                type="button"
                onClick={() => {
                  setStep('credentials');
                  setError('');
                  setInfo('');
                }}
                className="text-zinc-400 hover:text-white"
              >
                Change credentials
              </button>
              <button
                type="button"
                onClick={() => void requestOtp(true)}
                disabled={loading || secondsLeft > 540}
                className="text-[#FFCC00] hover:underline flex items-center gap-1 disabled:opacity-50"
              >
                <RefreshCw className="w-3 h-3" />
                Resend OTP
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
