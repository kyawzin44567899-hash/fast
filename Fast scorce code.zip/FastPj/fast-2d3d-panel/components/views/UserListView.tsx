'use client';

import React, { useState, useEffect } from 'react';
import {
  ArrowLeft,
  Search,
  User,
  X,
  Check,
  AlertCircle,
  Plus,
  Minus,
  KeyRound,
  Eye,
  EyeOff,
  Copy,
  Lock,
  RefreshCw,
  Phone,
  ShieldAlert,
  ShieldCheck,
  Fingerprint,
} from 'lucide-react';
import { AppUser, UserRole, AppAgent } from '@/lib/types';
import { UserCheck } from 'lucide-react';

interface UserListViewProps {
  users: AppUser[];
  onBack: () => void;
  onUpdateUser: (user: AppUser) => void;
  role?: UserRole;
  currentAgent?: AppAgent | null;
  onAdjustBalance?: (uid: string, direction: 'add' | 'deduct', amount: number) => Promise<AppUser | null>;
  onSetStatus?: (uid: string, status: 'active' | 'suspended') => Promise<AppUser | null>;
  onSetPassword?: (uid: string, password: string) => Promise<boolean>;
}

export function UserListView({
  users,
  onBack,
  role = 'admin',
  currentAgent,
  onAdjustBalance,
  onSetStatus,
  onSetPassword,
}: UserListViewProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [remoteResults, setRemoteResults] = useState<AppUser[] | null>(null);
  const [isSearching, setIsSearching] = useState(false);
  const [selectedUser, setSelectedUser] = useState<AppUser | null>(null);
  const [amountInput, setAmountInput] = useState('');
  const [actionSuccess, setActionSuccess] = useState('');
  const [actionError, setActionError] = useState('');

  const [newPassword, setNewPassword] = useState('');
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [passwordError, setPasswordError] = useState('');
  const [copiedField, setCopiedField] = useState<string | null>(null);

  interface UserTransaction {
    id: string;
    type: string;
    amount: number;
    method: string;
    transaction_number: string | null;
    order_number?: string | null;
    status: string;
    timestamp: string;
    slip_image?: string | null;
  }
  interface BetItemDetail {
    number?: string;
    amount?: number;
    subNumbers?: { number: string; amount: number }[];
  }
  interface UserBet {
    id: string;
    type: string;
    session: string;
    amount: number;
    status: string;
    winning_number: string | null;
    win_amount: number | null;
    win_details?: string | null;
    payout_multiplier?: number | null;
    is_tood?: boolean | null;
    numbers?: unknown;
    items?: unknown;
    date: string;
  }
  const [historyView, setHistoryView] = useState<'transactions' | 'bets' | null>(null);
  const [historyTransactions, setHistoryTransactions] = useState<UserTransaction[]>([]);
  const [historyBets, setHistoryBets] = useState<UserBet[]>([]);
  const [historyLoading, setHistoryLoading] = useState(false);
  const [detailTx, setDetailTx] = useState<UserTransaction | null>(null);
  const [detailBet, setDetailBet] = useState<UserBet | null>(null);
  const [txTypeFilter, setTxTypeFilter] = useState<'deposit' | 'withdraw'>('deposit');
  const [betTypeFilter, setBetTypeFilter] = useState<'2D' | '3D' | 'TOOD'>('2D');

  const parseItems = (value: unknown): BetItemDetail[] => {
    let arr: unknown = value;
    if (typeof value === 'string') {
      try {
        arr = JSON.parse(value);
      } catch {
        arr = [];
      }
    }
    return Array.isArray(arr) ? (arr as BetItemDetail[]) : [];
  };

  const getBetNumbers = (b: UserBet): string => {
    const its = parseItems(b.items);
    const nums = its
      .flatMap((it) =>
        it.subNumbers && it.subNumbers.length > 0
          ? it.subNumbers.map((s) => s.number)
          : [it.number]
      )
      .filter((n): n is string => Boolean(n));
    if (nums.length > 0) return nums.join(', ');
    if (Array.isArray(b.numbers)) return (b.numbers as string[]).join(', ');
    return '';
  };

  const matchesBetFilter = (b: UserBet): boolean => {
    if (betTypeFilter === '2D') return b.type === '2D';
    if (betTypeFilter === '3D') return b.type === '3D';
    return b.type === '3D' && (Boolean(b.is_tood) || b.status === 'TOOD_WIN');
  };

  const loadHistory = async (uid: string, view: 'transactions' | 'bets') => {
    setHistoryView(view);
    if (view === 'transactions') setTxTypeFilter('deposit');
    else setBetTypeFilter('2D');
    setHistoryLoading(true);
    try {
      const res = await fetch(`/api/users/${encodeURIComponent(uid)}`, { cache: 'no-store' });
      if (res.ok) {
        const json = await res.json();
        if (json.success && json.data) {
          if (Array.isArray(json.data.transactions)) setHistoryTransactions(json.data.transactions);
          if (Array.isArray(json.data.bets)) setHistoryBets(json.data.bets);
        }
      }
    } catch {}
    setHistoryLoading(false);
  };

  const agentCode = currentAgent?.code || '';
  const scopedUsers = role === 'agent'
    ? users.filter((u) => u.agentCode === agentCode)
    : users;

  useEffect(() => {
    const term = searchTerm.trim();
    let cancelled = false;
    const timer = setTimeout(async () => {
      if (cancelled) return;
      if (!term) {
        setRemoteResults(null);
        setIsSearching(false);
        return;
      }
      setIsSearching(true);
      try {
        const res = await fetch(`/api/users?search=${encodeURIComponent(term)}`, { cache: 'no-store' });
        if (!res.ok) return;
        const json = await res.json();
        if (!cancelled && Array.isArray(json.data)) {
          setRemoteResults(json.data as AppUser[]);
        }
      } catch {
      } finally {
        if (!cancelled) setIsSearching(false);
      }
    }, 300);
    return () => {
      cancelled = true;
      clearTimeout(timer);
    };
  }, [searchTerm]);

  const filtered = remoteResults !== null
    ? remoteResults
    : scopedUsers.filter((u) => {
        const term = searchTerm.toLowerCase();
        const matchesName = u.name.toLowerCase().includes(term);
        const matchesUid = Boolean(u.uid && u.uid.toLowerCase().includes(term));
        const matchesPhone = role === 'admin' ? u.phone.includes(term) : false;
        return matchesName || matchesUid || matchesPhone;
      });

  const handleCopy = (text: string, fieldName: string) => {
    try {
      if (typeof navigator !== 'undefined' && navigator.clipboard) {
        navigator.clipboard.writeText(text);
      }
    } catch {

    }
    setCopiedField(fieldName);
    setTimeout(() => setCopiedField(null), 2000);
  };

  const handleAdjustBalance = async (type: 'add' | 'deduct') => {
    if (!selectedUser) return;
    const val = parseInt(amountInput, 10);
    if (isNaN(val) || val <= 0) return;

    setActionError('');
    const updated = onAdjustBalance
      ? await onAdjustBalance(selectedUser.uid, type, val)
      : null;

    if (!updated) {
      setActionError('လက်ကျန်ငွေ ချိန်ညှိမှု မအောင်မြင်ပါ');
      setTimeout(() => setActionError(''), 2500);
      return;
    }

    setSelectedUser(updated);
    setAmountInput('');
    setActionSuccess(`ငွေပမာဏ ${type === 'add' ? 'သွင်းခြင်း' : 'နုတ်ခြင်း'} ${val.toLocaleString()} MMK အောင်မြင်ပါသည်`);
    setTimeout(() => setActionSuccess(''), 2500);
  };

  const handleToggleStatus = async () => {
    if (!selectedUser) return;
    const nextStatus = selectedUser.status === 'active' ? 'suspended' : 'active';
    setActionError('');
    const updated = onSetStatus ? await onSetStatus(selectedUser.uid, nextStatus) : null;
    if (!updated) {
      setActionError('အကောင့်အခြေအနေ ပြောင်းလဲမှု မအောင်မြင်ပါ');
      setTimeout(() => setActionError(''), 2500);
      return;
    }
    setSelectedUser(updated);
    setActionSuccess(`အကောင့်အခြေအနေ ${updated.status === 'active' ? 'ဖွင့်ထားသည်' : 'ပိတ်ထားသည်'} သို့ ပြောင်းပြီးပါပြီ`);
    setTimeout(() => setActionSuccess(''), 2500);
  };

  const handleGenerateRandomPassword = () => {
    const chars = '23456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz';
    let result = '';
    for (let i = 0; i < 6; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    const generated = `2D@${result}`;
    setNewPassword(generated);
    setShowNewPassword(true);
    setPasswordError('');
  };

  const handleChangePassword = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!selectedUser) return;

    const trimmed = newPassword.trim();
    if (!trimmed) {
      setPasswordError('စကားဝှက် အသစ် ရိုက်ထည့်ပါ');
      return;
    }
    if (trimmed.length < 4) {
      setPasswordError('စကားဝှက်သည် အနည်းဆုံး ၄ လုံး ရှိရပါမည်');
      return;
    }

    const okPassword = onSetPassword ? await onSetPassword(selectedUser.uid, trimmed) : false;
    if (!okPassword) {
      setPasswordError('စကားဝှက် ပြောင်းလဲမှု မအောင်မြင်ပါ');
      return;
    }

    setNewPassword('');
    setPasswordError('');
    setActionSuccess('စကားဝှက် အသစ်ကို အောင်မြင်စွာ ပြောင်းလဲပြီးပါပြီ');
    setTimeout(() => setActionSuccess(''), 3000);
  };

  return (
    <div className="flex flex-col min-h-screen bg-[#101012] text-white selection:bg-amber-400 selection:text-black">
      <div className="sticky top-0 z-30 flex items-center justify-between px-4 py-3 bg-[#101012]/95 backdrop-blur-md border-b border-zinc-900">
        <button
          onClick={onBack}
          className="w-10 h-10 rounded-full flex items-center justify-center text-[#FFCC00] hover:bg-zinc-800 transition active:scale-95"
          aria-label="Back"
        >
          <ArrowLeft className="w-7 h-7 stroke-[2.5]" />
        </button>

        <div className="text-center">
          <h1 className="text-xl font-bold tracking-wide text-[#FFCC00]">
            {role === 'agent' ? 'ကျွန်ုပ်၏ Users' : 'အသုံးပြုသူများ'}
          </h1>
          <p className="text-[10px] text-zinc-400 font-medium">
            {role === 'agent' ? `Agent (${agentCode}) Members: ${scopedUsers.length} ဦး` : `User List (${scopedUsers.length} ဦး)`}
          </p>
        </div>

        <div className="w-10" />
      </div>

      {role === 'agent' && (
        <div className="mx-4 mt-3 p-2.5 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center gap-2 text-xs text-amber-300">
          <UserCheck className="w-4 h-4 text-[#FFCC00] shrink-0" />
          <span>
            သင့် Agent Code (<strong className="text-white font-mono">{agentCode}</strong>) ဖြင့် စာရင်းသွင်းထားသော Users {scopedUsers.length} ဦးသာ ပြသထားပါသည်။
          </span>
        </div>
      )}

      <div className="px-4 pt-3 pb-3">
        <div className="relative max-w-sm mx-auto">
          <input
            id="input-search-user"
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder={role === 'agent' ? "Search by Name or UID..." : "Search by Name, Phone, or UID..."}
            className="w-full h-11 pl-11 pr-10 rounded-full bg-[#101012] border border-[#FFCC00] text-white placeholder-[#FFCC00]/70 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-[#FFCC00]/40"
          />
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-[#FFCC00]" />
          {searchTerm && (
            <button
              onClick={() => setSearchTerm('')}
              className="absolute right-3.5 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
        {isSearching && (
          <div className="text-center text-[11px] text-zinc-500 mt-1.5">ရှာဖွေနေပါသည်...</div>
        )}
      </div>

      <div className="flex-1 px-4 pb-32">
        <div className="grid grid-cols-2 gap-3.5 max-w-sm mx-auto">
          {filtered.map((user) => (
            <button
              key={user.id}
              onClick={() => {
                setSelectedUser(user);
                setNewPassword('');
                setPasswordError('');
                setShowNewPassword(false);
              }}
              className="flex flex-col items-center justify-between p-3.5 rounded-3xl bg-[#FFCC00] hover:bg-[#ffc107] active:scale-[0.96] transition shadow-[0_4px_16px_rgba(255,204,0,0.15)] cursor-pointer text-center relative overflow-hidden min-h-[178px]"
            >
              <div className="relative mt-0.5">
                <div className="w-13 h-13 rounded-full bg-black flex items-center justify-center shadow-inner">
                  <User className="w-7 h-7 text-white fill-white" />
                </div>
                <span
                  title={user.status === 'active' ? 'Active' : 'Suspended'}
                  className={`absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full border-2 border-[#FFCC00] ${
                    user.status === 'active' ? 'bg-emerald-600' : 'bg-red-600'
                  }`}
                />
              </div>

              <div className="w-full space-y-0.5 px-0.5">
                <div
                  className="text-black font-extrabold text-sm sm:text-base leading-tight truncate w-full"
                  title={user.name}
                >
                  {user.name}
                </div>

                {role === 'admin' ? (
                  <div className="text-black/85 font-bold text-xs leading-tight tracking-tight truncate w-full font-mono">
                    {user.phone}
                  </div>
                ) : (
                  <div className="text-black/75 font-semibold text-[11px] leading-tight truncate w-full">
                    လက်ကျန်: {user.balance.toLocaleString()} Ks
                  </div>
                )}
              </div>

              <div className="w-full flex items-center justify-center mt-1">
                <span className="px-2.5 py-0.5 rounded-full bg-black/15 text-black font-mono font-bold text-[10px] tracking-wider truncate max-w-full">
                  {user.uid || `UID-${user.id}`}
                </span>
              </div>
            </button>
          ))}
        </div>

        {filtered.length === 0 && (
          <div className="text-center py-12 text-zinc-500 text-sm">
            အသုံးပြုသူ ရှာမတွေ့ပါ (&quot;{searchTerm}&quot;)
          </div>
        )}
      </div>

      {selectedUser && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/85 backdrop-blur-sm p-0 sm:p-4 animate-in fade-in duration-200">
          <div className="w-full max-w-sm max-h-[88vh] flex flex-col rounded-t-3xl sm:rounded-3xl bg-[#18181b] border border-[#FFCC00]/40 shadow-2xl overflow-hidden">
            <div className="flex items-center justify-between px-5 py-3.5 border-b border-zinc-800 bg-black/40 shrink-0">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-full bg-[#FFCC00] flex items-center justify-center text-black font-bold shadow">
                  <User className="w-5 h-5 text-black fill-black" />
                </div>
                <div>
                  <h3 className="text-white font-bold text-sm leading-tight">
                    အသုံးပြုသူ အချက်အလက်
                  </h3>
                  <p className="text-[10px] text-zinc-400">
                    {role === 'agent' ? 'Member Details' : 'User Details & Admin Settings'}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setSelectedUser(null)}
                className="w-8 h-8 rounded-full flex items-center justify-center text-zinc-400 hover:text-white hover:bg-zinc-800 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4 pretty-scrollbar">
              {actionSuccess && (
                <div className="p-2.5 rounded-2xl bg-emerald-950/70 border border-emerald-500/60 text-emerald-300 text-xs text-center flex items-center justify-center gap-1.5 shadow-sm animate-in fade-in">
                  <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span className="font-medium">{actionSuccess}</span>
                </div>
              )}

              {actionError && (
                <div className="p-2.5 rounded-2xl bg-red-950/70 border border-red-500/60 text-red-300 text-xs text-center flex items-center justify-center gap-1.5 shadow-sm animate-in fade-in">
                  <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
                  <span className="font-medium">{actionError}</span>
                </div>
              )}

              <div className="p-4 rounded-2xl bg-black border border-zinc-800 space-y-3 shadow-sm">
                <div className="flex items-center justify-between border-b border-zinc-800/80 pb-2">
                  <div className="flex items-center gap-1.5 text-zinc-400 text-xs font-semibold">
                    <Fingerprint className="w-4 h-4 text-[#FFCC00]" />
                    <span>အကောင့်အချက်အလက် (User Profile)</span>
                  </div>
                  <span
                    className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase tracking-wider ${
                      selectedUser.status === 'active'
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                        : 'bg-red-500/20 text-red-300 border border-red-500/40'
                    }`}
                  >
                    {selectedUser.status}
                  </span>
                </div>

                <div className="flex items-center justify-between text-xs">
                  <span className="text-zinc-400">နာမည်အပြည့်အစုံ (Full Name):</span>
                  <span className="font-extrabold text-white text-sm text-right">
                    {selectedUser.name}
                  </span>
                </div>

                <div className="flex items-center justify-between text-xs">
                  <span className="text-zinc-400">အသုံးပြုသူ ID (UID):</span>
                  <div className="flex items-center gap-1.5">
                    <span className="px-2 py-0.5 rounded-lg bg-[#FFCC00]/10 border border-[#FFCC00]/30 font-mono font-bold text-amber-300 text-xs">
                      {selectedUser.uid || `UID-${selectedUser.id}`}
                    </span>
                    <button
                      onClick={() => handleCopy(selectedUser.uid || selectedUser.id, 'uid')}
                      className="p-1 rounded-md text-zinc-400 hover:text-white hover:bg-zinc-800 transition active:scale-95"
                      title="Copy UID"
                    >
                      {copiedField === 'uid' ? (
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                    </button>
                  </div>
                </div>

                {role === 'admin' && (
                  <div className="flex items-center justify-between text-xs pt-1 border-t border-zinc-900">
                    <span className="text-zinc-400">ဖုန်းနံပါတ် (Phone):</span>
                    <div className="flex items-center gap-1.5">
                      <span className="font-mono font-bold text-[#FFCC00] text-sm">
                        {selectedUser.phone}
                      </span>
                      <button
                        onClick={() => handleCopy(selectedUser.phone, 'phone')}
                        className="p-1 rounded-md text-zinc-400 hover:text-white hover:bg-zinc-800 transition active:scale-95"
                        title="Copy Phone"
                      >
                        {copiedField === 'phone' ? (
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                      </button>
                    </div>
                  </div>
                )}

                <div className="flex items-center justify-between text-xs pt-1 border-t border-zinc-900">
                  <span className="text-zinc-400">အေးဂျင့်ကုဒ် (Agent Code):</span>
                  <span className="font-mono font-bold text-amber-400 text-xs">
                    {selectedUser.agentCode || '-'}
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div className="p-3 rounded-2xl bg-black border border-zinc-800">
                  <div className="text-zinc-400 text-[11px]">လက်ကျန်ငွေ (Balance)</div>
                  <div className="text-[#FFCC00] font-bold text-base mt-0.5">
                    {selectedUser.balance.toLocaleString()} MMK
                  </div>
                </div>
                <div className="p-3 rounded-2xl bg-black border border-zinc-800">
                  <div className="text-zinc-400 text-[11px]">ထိုးထားသည့်အကြိမ် (Bets)</div>
                  <div className="text-white font-bold text-base mt-0.5">
                    {selectedUser.totalBets} ကြိမ်
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => loadHistory(selectedUser.uid, 'transactions')}
                  className={`py-2.5 px-3 rounded-2xl text-xs font-bold border transition active:scale-[0.98] ${
                    historyView === 'transactions'
                      ? 'bg-[#FFCC00] text-black border-[#FFCC00]'
                      : 'bg-zinc-950 text-[#FFCC00] border-[#FFCC00]/40 hover:border-[#FFCC00]'
                  }`}
                  id="btn-check-transactions"
                >
                  Check Transaction Histories
                </button>
                <button
                  type="button"
                  onClick={() => loadHistory(selectedUser.uid, 'bets')}
                  className={`py-2.5 px-3 rounded-2xl text-xs font-bold border transition active:scale-[0.98] ${
                    historyView === 'bets'
                      ? 'bg-[#FFCC00] text-black border-[#FFCC00]'
                      : 'bg-zinc-950 text-[#FFCC00] border-[#FFCC00]/40 hover:border-[#FFCC00]'
                  }`}
                  id="btn-check-bets"
                >
                  Check Bet Histories
                </button>
              </div>

              {historyView && (
                <div className="p-3 rounded-2xl bg-black border border-zinc-800 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-[#FFCC00]">
                      {historyView === 'transactions' ? 'ငွေသွင်း/ထုတ် မှတ်တမ်း' : 'ထိုးစာရင်း မှတ်တမ်း'}
                    </span>
                    <button
                      type="button"
                      onClick={() => setHistoryView(null)}
                      className="text-[10px] text-zinc-400 hover:text-white"
                    >
                      ပိတ်မည်
                    </button>
                  </div>

                  {historyView === 'transactions' ? (
                    <div className="grid grid-cols-2 p-1 bg-zinc-900 rounded-xl border border-zinc-800">
                      <button
                        type="button"
                        onClick={() => setTxTypeFilter('deposit')}
                        className={`py-1.5 text-[11px] font-bold rounded-lg transition ${
                          txTypeFilter === 'deposit'
                            ? 'bg-[#FFCC00] text-black shadow'
                            : 'text-zinc-400 hover:text-white'
                        }`}
                      >
                        Deposit
                      </button>
                      <button
                        type="button"
                        onClick={() => setTxTypeFilter('withdraw')}
                        className={`py-1.5 text-[11px] font-bold rounded-lg transition ${
                          txTypeFilter === 'withdraw'
                            ? 'bg-[#FFCC00] text-black shadow'
                            : 'text-zinc-400 hover:text-white'
                        }`}
                      >
                        Withdrawal
                      </button>
                    </div>
                  ) : (
                    <div className="grid grid-cols-3 p-1 bg-zinc-900 rounded-xl border border-zinc-800">
                      {(['2D', '3D', 'TOOD'] as const).map((t) => (
                        <button
                          key={t}
                          type="button"
                          onClick={() => setBetTypeFilter(t)}
                          className={`py-1.5 text-[11px] font-bold rounded-lg transition ${
                            betTypeFilter === t
                              ? 'bg-[#FFCC00] text-black shadow'
                              : 'text-zinc-400 hover:text-white'
                          }`}
                        >
                          {t === 'TOOD' ? '3D Tood' : t}
                        </button>
                      ))}
                    </div>
                  )}

                  {historyLoading ? (
                    <div className="text-center text-[11px] text-zinc-500 py-3">ရယူနေပါသည်...</div>
                  ) : historyView === 'transactions' ? (
                    historyTransactions.filter((t) =>
                      txTypeFilter === 'deposit' ? t.type === 'deposit' : t.type !== 'deposit'
                    ).length === 0 ? (
                      <div className="text-center text-[11px] text-zinc-500 py-3">မှတ်တမ်း မရှိပါ</div>
                    ) : (
                      <div className="space-y-1.5 max-h-60 overflow-y-auto pretty-scrollbar">
                        {historyTransactions
                          .filter((t) =>
                            txTypeFilter === 'deposit' ? t.type === 'deposit' : t.type !== 'deposit'
                          )
                          .map((t) => (
                            <button
                              key={t.id}
                              type="button"
                              onClick={() => setDetailTx(t)}
                              className="w-full text-left p-2 rounded-xl bg-zinc-950 border border-zinc-800 hover:border-[#FFCC00]/50 transition text-[11px]"
                            >
                              <div className="flex items-center justify-between">
                                <span className={t.type === 'deposit' ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                                  {t.type === 'deposit' ? 'Deposit' : 'Withdraw'}
                                </span>
                                <span className="text-white font-bold">{Number(t.amount).toLocaleString()} MMK</span>
                              </div>
                              {(t as UserTransaction & { order_number?: string }).order_number ? (
                                <div className="text-[10px] text-[#FFCC00]/80 font-mono mt-0.5">
                                  {(t as UserTransaction & { order_number?: string }).order_number}
                                </div>
                              ) : null}
                              <div className="flex items-center justify-between text-[10px] text-zinc-500 mt-0.5">
                                <span>{t.method}</span>
                                <span>{t.status}</span>
                              </div>
                              <div className="text-[10px] text-zinc-500">{t.timestamp}</div>
                              <div className="text-[9px] text-[#FFCC00]/70 mt-0.5">အသေးစိတ် ကြည့်ရန် →</div>
                            </button>
                          ))}
                      </div>
                    )
                  ) : historyBets.filter(matchesBetFilter).length === 0 ? (
                    <div className="text-center text-[11px] text-zinc-500 py-3">မှတ်တမ်း မရှိပါ</div>
                  ) : (
                    <div className="space-y-1.5 max-h-60 overflow-y-auto pretty-scrollbar">
                      {historyBets
                        .filter(matchesBetFilter)
                        .map((b) => {
                          const numsText = getBetNumbers(b);
                          return (
                            <button
                              key={b.id}
                              type="button"
                              onClick={() => setDetailBet(b)}
                              className="w-full text-left p-2 rounded-xl bg-zinc-950 border border-zinc-800 hover:border-[#FFCC00]/50 transition text-[11px]"
                            >
                              <div className="flex items-center justify-between">
                                <span className="text-[#FFCC00] font-bold flex items-center gap-1">
                                  {b.type} • {b.session}
                                  {(b.is_tood || b.status === 'TOOD_WIN') && (
                                    <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-emerald-500/15 text-emerald-300 border border-emerald-500/40">
                                      TOOD
                                    </span>
                                  )}
                                </span>
                                <span className="text-white font-bold">{Number(b.amount).toLocaleString()} MMK</span>
                              </div>
                              <div className="mt-1">
                                <span className="text-[9px] text-zinc-500">ထိုးဂဏန်း: </span>
                                <span className="text-[11px] text-amber-300 font-mono break-words">
                                  {numsText || '-'}
                                </span>
                              </div>
                              <div className="flex items-center justify-between text-[10px] text-zinc-500 mt-0.5">
                                <span>Status: {b.status}</span>
                                {b.winning_number ? <span>Win: {b.winning_number}</span> : null}
                              </div>
                              <div className="text-[10px] text-zinc-500">{b.date}</div>
                              <div className="text-[9px] text-[#FFCC00]/70 mt-0.5">အသေးစိတ် ကြည့်ရန် →</div>
                            </button>
                          );
                        })}
                    </div>
                  )}
                </div>
              )}

              {role === 'admin' ? (
                <>
                  <div className="p-4 rounded-2xl bg-black border border-[#FFCC00]/40 space-y-3 shadow-md relative">
                    <div className="flex items-center justify-between border-b border-zinc-800/80 pb-2">
                      <div className="flex items-center gap-1.5 text-[#FFCC00] text-xs font-bold">
                        <KeyRound className="w-4 h-4" />
                        <span>စကားဝှက် ပြောင်းလဲရန် (Change Password)</span>
                      </div>
                      <span className="text-[10px] text-zinc-500 font-mono">Admin Control</span>
                    </div>

                    <div className="p-2.5 rounded-xl bg-zinc-900/90 border border-zinc-800">
                      <div className="text-[10px] text-zinc-400">
                        လုံခြုံရေးအရ လက်ရှိ စကားဝှက်ကို ဖတ်၍မရပါ။ အသစ် သတ်မှတ်ပေးပါ။
                      </div>
                    </div>

                    <form onSubmit={handleChangePassword} className="space-y-2 pt-1">
                      <div className="space-y-1">
                        <label className="text-[11px] text-zinc-300 font-medium flex items-center justify-between">
                          <span>စကားဝှက် အသစ် ရိုက်ထည့်ပါ (New Password):</span>
                          <button
                            type="button"
                            onClick={handleGenerateRandomPassword}
                            className="text-[10px] text-[#FFCC00] hover:underline flex items-center gap-1 cursor-pointer"
                          >
                            <RefreshCw className="w-2.5 h-2.5" />
                            <span>ကျပန်းထုတ်မည် (Auto Generate)</span>
                          </button>
                        </label>

                        <div className="relative">
                          <input
                            type={showNewPassword ? 'text' : 'password'}
                            value={newPassword}
                            onChange={(e) => {
                              setNewPassword(e.target.value);
                              if (passwordError) setPasswordError('');
                            }}
                            placeholder="ဥပမာ- user@2026 သို့မဟုတ် 123456"
                            className="w-full h-10 pl-3 pr-10 rounded-xl bg-zinc-900 border border-zinc-700 text-white font-mono text-xs focus:outline-none focus:border-[#FFCC00] focus:ring-1 focus:ring-[#FFCC00]"
                          />
                          <button
                            type="button"
                            onClick={() => setShowNewPassword(!showNewPassword)}
                            className="absolute right-2.5 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-white p-1"
                          >
                            {showNewPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5 text-zinc-400" />}
                          </button>
                        </div>
                      </div>

                      {passwordError && (
                        <div className="text-red-400 text-[11px] flex items-center gap-1 font-medium pt-0.5">
                          <AlertCircle className="w-3 h-3 shrink-0" />
                          <span>{passwordError}</span>
                        </div>
                      )}

                      <button
                        type="submit"
                        className="w-full h-9 rounded-xl bg-[#FFCC00] hover:bg-amber-400 active:scale-[0.98] text-black font-extrabold text-xs flex items-center justify-center gap-1.5 transition shadow cursor-pointer mt-2"
                      >
                        <Lock className="w-3.5 h-3.5" />
                        <span>စကားဝှက် ပြောင်းမည် (Save New Password)</span>
                      </button>
                    </form>
                  </div>

                  <div className="p-3 rounded-2xl bg-black/60 border border-zinc-800">
                    <div className="text-zinc-300 text-xs font-semibold mb-2">
                      လက်ကျန်ငွေ ချိန်ညှိရန် (Adjust Balance)
                    </div>
                    <div className="flex gap-2">
                      <input
                        type="number"
                        value={amountInput}
                        onChange={(e) => setAmountInput(e.target.value)}
                        placeholder="ပမာဏ (MMK)"
                        className="flex-1 h-9 px-3 rounded-xl bg-zinc-900 border border-zinc-700 text-xs text-white focus:outline-none focus:border-[#FFCC00]"
                      />
                      <button
                        onClick={() => handleAdjustBalance('add')}
                        className="px-3 h-9 rounded-xl bg-[#FFCC00] text-black font-bold text-xs flex items-center gap-1 hover:bg-amber-400 active:scale-95"
                      >
                        <Plus className="w-3 h-3" /> သွင်း
                      </button>
                      <button
                        onClick={() => handleAdjustBalance('deduct')}
                        className="px-3 h-9 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-white font-bold text-xs flex items-center gap-1 active:scale-95"
                      >
                        <Minus className="w-3 h-3" /> နုတ်
                      </button>
                    </div>
                  </div>

                  <div className="flex items-center justify-between p-3 rounded-2xl bg-black/40 border border-zinc-800">
                    <div>
                      <div className="text-xs text-zinc-300 font-medium">
                        အခြေအနေ: <span className={selectedUser.status === 'active' ? 'text-emerald-400 font-bold' : 'text-red-400 font-bold'}>{selectedUser.status === 'active' ? 'ACTIVE (အသုံးပြုနိုင်)' : 'SUSPENDED (ပိတ်ထား)'}</span>
                      </div>
                      <div className="text-[11px] text-zinc-500">စတင်ဝင်ရောက်သည့်ရက်: {selectedUser.createdAt}</div>
                    </div>
                    <button
                      onClick={handleToggleStatus}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold transition active:scale-95 cursor-pointer ${
                        selectedUser.status === 'active'
                          ? 'bg-red-500/20 text-red-300 border border-red-500/40 hover:bg-red-500/30'
                          : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 hover:bg-emerald-500/30'
                      }`}
                    >
                      {selectedUser.status === 'active' ? 'Suspend (ပိတ်)' : 'Activate (ဖွင့်)'}
                    </button>
                  </div>
                </>
              ) : (

                <div className="p-3 rounded-2xl bg-zinc-900/60 border border-zinc-800 text-center space-y-1">
                  <div className="text-xs font-semibold text-zinc-300">
                    စတင်ဝင်ရောက်သည့်ရက်: {selectedUser.createdAt}
                  </div>
                  <p className="text-[11px] text-zinc-500">
                    (စကားဝှက်နှင့် ငွေကြေးချိန်ညှိမှုများကို Master Admin သာ ပြုပြင်ခွင့်ရှိပါသည်)
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {detailTx && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/90 backdrop-blur-sm p-4">
          <div className="w-full max-w-sm max-h-[88vh] overflow-y-auto rounded-3xl bg-[#141416] border border-[#FFCC00]/60 p-5 shadow-2xl pretty-scrollbar">
            <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
              <h3 className="text-sm font-bold text-[#FFCC00]">ငွေလွှဲ အသေးစိတ် (Transaction Detail)</h3>
              <button onClick={() => setDetailTx(null)} className="text-zinc-400 hover:text-white p-1">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="mt-4 space-y-2.5 text-xs">
              <div className="flex justify-between">
                <span className="text-zinc-400">အမျိုးအစား (Type)</span>
                <span className={detailTx.type === 'deposit' ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>
                  {detailTx.type === 'deposit' ? 'ငွေသွင်း (Deposit)' : 'ငွေထုတ် (Withdraw)'}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-zinc-400">ပမာဏ (Amount)</span>
                <span className="text-[#FFCC00] font-black">{Number(detailTx.amount).toLocaleString()} MMK</span>
              </div>
              <div className="flex justify-between">
                <span className="text-zinc-400">ဘဏ် / ပိုက်ဆံအိတ်</span>
                <span className="text-white font-bold">{detailTx.method}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-zinc-400">ပြေစာအမှတ် (Ref No.)</span>
                <div className="flex items-center gap-1.5">
                  <span className="text-zinc-200 font-mono">{detailTx.transaction_number || '-'}</span>
                  <button
                    type="button"
                    onClick={() => handleCopy(detailTx.transaction_number || '', 'tx-ref')}
                    disabled={!detailTx.transaction_number}
                    className="p-1 rounded-md text-zinc-400 hover:text-[#FFCC00] hover:bg-zinc-800 transition active:scale-90 disabled:opacity-40 disabled:cursor-not-allowed"
                    title="Copy Ref No."
                    id="copy-user-tx-ref-btn"
                  >
                    {copiedField === 'tx-ref' ? (
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                  </button>
                </div>
              </div>
              {detailTx.order_number && (
                <div className="flex justify-between items-center">
                  <span className="text-zinc-400">အော်ဒါနံပါတ် (Order No.)</span>
                  <div className="flex items-center gap-1.5">
                    <span className="text-[#FFCC00] font-mono text-[11px]">{detailTx.order_number}</span>
                    <button
                      type="button"
                      onClick={() => handleCopy(detailTx.order_number || '', 'tx-order')}
                      className="p-1 rounded-md text-zinc-400 hover:text-[#FFCC00] hover:bg-zinc-800 transition active:scale-90"
                      title="Copy Order No."
                      id="copy-user-tx-order-btn"
                    >
                      {copiedField === 'tx-order' ? (
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                    </button>
                  </div>
                </div>
              )}
              <div className="flex justify-between">
                <span className="text-zinc-400">အခြေအနေ (Status)</span>
                <span className="capitalize font-bold text-amber-300">{detailTx.status}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-zinc-400">ရက်စွဲ (Date)</span>
                <span className="text-zinc-300">{detailTx.timestamp}</span>
              </div>
              <div className="text-zinc-500 text-[10px]">ID: {detailTx.id}</div>

              {detailTx.slip_image && (
                <div className="pt-2">
                  <div className="text-[11px] text-zinc-400 mb-1">ငွေလွှဲပြေစာ (Slip)</div>
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={detailTx.slip_image}
                    alt="slip"
                    className="w-full rounded-2xl border border-zinc-700 max-h-64 object-contain bg-black"
                  />
                </div>
              )}
            </div>
            <button
              type="button"
              onClick={() => setDetailTx(null)}
              className="mt-4 w-full py-2.5 rounded-xl bg-[#FFCC00] text-black text-xs font-bold hover:bg-amber-400 transition"
            >
              ပိတ်မည်
            </button>
          </div>
        </div>
      )}

      {detailBet && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/90 backdrop-blur-sm p-4">
          <div className="w-full max-w-sm max-h-[88vh] overflow-y-auto rounded-3xl bg-[#141416] border border-[#FFCC00]/60 p-5 shadow-2xl pretty-scrollbar">
            <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
              <h3 className="text-sm font-bold text-[#FFCC00]">ထိုးစာရင်း အသေးစိတ် (Bet Detail)</h3>
              <button onClick={() => setDetailBet(null)} className="text-zinc-400 hover:text-white p-1">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="mt-4 space-y-2.5 text-xs">
              <div className="flex justify-between">
                <span className="text-zinc-400">အမျိုးအစား (Type)</span>
                <span className="text-[#FFCC00] font-bold">{detailBet.type}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-zinc-400">ပွဲချိန် (Session)</span>
                <span className="text-white font-bold">{detailBet.session}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-zinc-400">ပမာဏ (Amount)</span>
                <span className="text-[#FFCC00] font-black">{Number(detailBet.amount).toLocaleString()} MMK</span>
              </div>
              <div className="flex justify-between">
                <span className="text-zinc-400">အခြေအနေ (Status)</span>
                <span className="capitalize font-bold text-amber-300">
                  {detailBet.status === 'TOOD_WIN' ? 'TOOD ပေါက် (Tood Win)' : detailBet.status}
                </span>
              </div>
              {(detailBet.is_tood || detailBet.status === 'TOOD_WIN') && (
                <div className="flex justify-between">
                  <span className="text-zinc-400">Tood Multiplier</span>
                  <span className="text-emerald-400 font-black">×{detailBet.payout_multiplier || 10}</span>
                </div>
              )}
              {detailBet.winning_number && (
                <div className="flex justify-between">
                  <span className="text-zinc-400">ပေါက်ဂဏန်း (Winning No.)</span>
                  <span className="text-emerald-400 font-bold">{detailBet.winning_number}</span>
                </div>
              )}
              {detailBet.win_amount ? (
                <div className="flex justify-between">
                  <span className="text-zinc-400">ဆုငွေ (Win Amount)</span>
                  <span className="text-emerald-400 font-black">{Number(detailBet.win_amount).toLocaleString()} MMK</span>
                </div>
              ) : null}
              {detailBet.win_details && (
                <div className="p-2 rounded-xl bg-zinc-950 border border-zinc-800 text-[10px] text-zinc-300">
                  {detailBet.win_details}
                </div>
              )}
              <div className="flex justify-between">
                <span className="text-zinc-400">ရက်စွဲ (Date)</span>
                <span className="text-zinc-300">{detailBet.date}</span>
              </div>

              <div className="pt-2">
                <div className="text-[11px] text-zinc-400 mb-1.5">ထိုးထားသော ဂဏန်းများ (Numbers)</div>
                <div className="space-y-1.5">
                  {parseItems(detailBet.items).length > 0 ? (
                    parseItems(detailBet.items).map((it, idx) => (
                      <div key={idx} className="p-2 rounded-xl bg-zinc-950 border border-zinc-800">
                        <div className="flex justify-between text-[11px]">
                          <span className="text-[#FFCC00] font-bold">{it.number}</span>
                          <span className="text-white">{Number(it.amount || 0).toLocaleString()} MMK</span>
                        </div>
                        {it.subNumbers && it.subNumbers.length > 0 && (
                          <div className="text-[10px] text-zinc-500 mt-0.5">
                            {it.subNumbers.map((s) => `${s.number}(${Number(s.amount).toLocaleString()})`).join(', ')}
                          </div>
                        )}
                      </div>
                    ))
                  ) : (
                    <div className="text-[11px] text-zinc-300">
                      {Array.isArray(detailBet.numbers)
                        ? (detailBet.numbers as string[]).join(', ')
                        : String(detailBet.numbers || '-')}
                    </div>
                  )}
                </div>
              </div>

              <div className="text-zinc-500 text-[10px]">ID: {detailBet.id}</div>
            </div>
            <button
              type="button"
              onClick={() => setDetailBet(null)}
              className="mt-4 w-full py-2.5 rounded-xl bg-[#FFCC00] text-black text-xs font-bold hover:bg-amber-400 transition"
            >
              ပိတ်မည်
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

