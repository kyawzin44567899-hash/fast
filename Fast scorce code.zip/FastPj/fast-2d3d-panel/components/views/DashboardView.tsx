'use client';

import React, { useState } from 'react';
import { Logo2D3D } from '../Logo2D3D';
import {
  UsersIcon,
  AgentsIcon,
  CashInOutIcon,
  NumbersGridIcon,
  CalendarIconCustom,
  AdsWindowIcon,
  Lucky777Icon,
  LiveAntennaIcon,
} from '../DashboardIcons';
import { ScreenType, UserRole, AppAgent } from '@/lib/types';
import { Receipt, Sparkles, ChevronRight, Ticket, ArrowUpRight, Shield, UserCheck, Trophy, RefreshCw, Wallet } from 'lucide-react';

interface DashboardViewProps {
  onNavigate: (screen: ScreenType) => void;
  onOpenNotifications: () => void;
  onRefresh?: () => void | Promise<void>;
  unreadCount?: number;
  role?: UserRole;
  currentAgent?: AppAgent | null;
}

export function DashboardView({
  onNavigate,
  onOpenNotifications,
  onRefresh,
  unreadCount = 2,
  role = 'admin',
  currentAgent,
}: DashboardViewProps) {
  const [isRefreshing, setIsRefreshing] = useState(false);

  const handleRefresh = async () => {
    if (isRefreshing) return;
    setIsRefreshing(true);
    try {
      await onRefresh?.();
    } finally {
      setIsRefreshing(false);
    }
  };

  const allCards = [
    {
      id: 'card-users',
      screen: 'user_list' as ScreenType,
      label: role === 'agent' ? 'ကျွန်ုပ်၏ Users' : 'အသုံးပြုသူများ',
      icon: UsersIcon,
    },
    {
      id: 'card-agents',
      screen: 'agents_list' as ScreenType,
      label: 'အေးဂျင့်များ',
      icon: AgentsIcon,
      adminOnly: true,
    },
    {
      id: 'card-transactions',
      screen: 'transactions' as ScreenType,
      label: 'ငွေသွင်း/ထုတ်',
      icon: CashInOutIcon,
    },
    {
      id: 'card-numbers',
      screen: 'numbers_manage' as ScreenType,
      label: 'ဂဏန်းဆိုင်ရာ',
      icon: NumbersGridIcon,
    },
    {
      id: 'card-schedule',
      screen: 'schedule' as ScreenType,
      label: 'အချိန်နှင့်ရက်',
      icon: CalendarIconCustom,
    },
    {
      id: 'card-ads',
      screen: 'ads' as ScreenType,
      label: 'ကြော်ငြာများ',
      icon: AdsWindowIcon,
      adminOnly: true,
    },
    {
      id: 'card-winning-numbers',
      screen: 'winning_numbers' as ScreenType,
      label: 'ယနေ့ပေါက်ဂဏန်း',
      icon: Lucky777Icon,
    },
    {
      id: 'card-live-2d3d',
      screen: 'live_feed' as ScreenType,
      label: '2D3D',
      icon: LiveAntennaIcon,
    },
    {
      id: 'card-win-bets',
      screen: 'win_bets' as ScreenType,
      label: 'Win Bets',
      icon: Trophy,
    },
    {
      id: 'card-agent-balance',
      screen: 'agent_balance' as ScreenType,
      label: role === 'agent' ? 'ကော်မရှင်/လက်ကျန်' : 'Agent Balance',
      icon: Wallet,
    },
    {
      id: 'card-results-history',
      screen: 'results_history' as ScreenType,
      label: 'ရလဒ် မှတ်တမ်း',
      icon: CalendarIconCustom,
    },
  ];

  const cards = allCards.filter((card) => {
    if (role === 'agent' && card.adminOnly) return false;
    return true;
  });

  return (
    <div className="flex flex-col min-h-screen bg-[#101012] text-white pb-32">
      <div className="sticky top-0 z-30 flex items-center justify-between px-5 py-4 bg-[#101012]/95 backdrop-blur-md border-b border-zinc-900">
        <div className="flex items-center">
          <Logo2D3D size="sm" showText={true} />
        </div>

        <div className="text-center">
          <h1 className="text-xl sm:text-2xl font-bold tracking-wide text-[#FFCC00]">
            Fast 2D3D
          </h1>
          {role === 'agent' && (
            <div className="flex flex-col items-center gap-0.5">
              <span className="inline-flex items-center gap-1 text-[10px] text-amber-400 font-semibold bg-amber-500/10 px-2 py-0.5 rounded-full border border-amber-500/30">
                <UserCheck className="w-3 h-3" />
                <span>Agent: {currentAgent?.name || 'Agent'} ({currentAgent?.code || ''})</span>
              </span>
              <span className="text-[10px] text-zinc-400 font-mono">
                Members: {currentAgent?.membersCount ?? 0} • Com: {currentAgent?.commission ?? 0}%
              </span>
            </div>
          )}
        </div>

        <div className="flex items-center gap-1">
          <button
            id="btn-dashboard-refresh"
            onClick={handleRefresh}
            disabled={isRefreshing}
            className="p-2 text-[#FFCC00] hover:text-amber-300 transition active:scale-95 disabled:opacity-60"
            aria-label="Refresh"
          >
            <RefreshCw className={`w-6 h-6 stroke-[2.4] ${isRefreshing ? 'animate-spin' : ''}`} />
          </button>

          <button
            id="btn-notifications"
            onClick={onOpenNotifications}
            className="relative p-2 text-[#FFCC00] hover:text-amber-300 transition active:scale-95"
            aria-label="Notifications"
          >
            <div className="relative w-8 h-8 flex items-center justify-center">
              <svg
                viewBox="0 0 24 24"
                className="w-7 h-7 fill-[#FFCC00] stroke-[#FFCC00]"
              >
                <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9" />
                <path d="M13.73 21a2 2 0 0 1-3.46 0" />
              </svg>
              <svg
                viewBox="0 0 24 24"
                className="absolute -top-1 -right-1 w-4 h-4 stroke-[#FFCC00] stroke-2 fill-none"
              >
                <path d="M18 4a8 8 0 0 1 3 3" />
                <path d="M20 2a11 11 0 0 1 4 4" />
              </svg>
              {unreadCount > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-600 text-white font-bold text-[10px] rounded-full flex items-center justify-center ring-2 ring-black">
                  {unreadCount}
                </span>
              )}
            </div>
          </button>
        </div>
      </div>

      <div className="flex-1 px-4 py-4 space-y-4 max-w-sm mx-auto w-full">
        <button
          type="button"
          id="box-bet-records-top"
          onClick={() => onNavigate('bet_records')}
          className="w-full text-left p-4 rounded-3xl bg-gradient-to-r from-[#1b190f] via-black to-[#1b190f] border-2 border-[#FFCC00] hover:border-amber-300 shadow-[0_6px_20px_rgba(255,204,0,0.22)] active:scale-[0.98] transition group cursor-pointer relative overflow-hidden"
        >
          <div className="absolute top-0 right-0 w-32 h-32 bg-[#FFCC00]/10 rounded-full blur-2xl pointer-events-none" />

          <div className="flex items-center justify-between">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#FFCC00]/15 border border-[#FFCC00]/40 text-[#FFCC00] text-[11px] font-black tracking-wide">
              <Sparkles className="w-3.5 h-3.5 fill-[#FFCC00]" />
              <span>ထိုးစာရင်းများ (Bet Slips)</span>
            </div>

            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 text-[10px] font-bold">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>Incoming Bets</span>
            </div>
          </div>

          <div className="mt-3 flex items-center justify-between gap-2">
            <div>
              <h2 className="text-base font-black text-white group-hover:text-[#FFCC00] transition flex items-center gap-1.5">
                <span>အသုံးပြုသူ ထိုးစာရင်းများ စစ်ဆေးရန်</span>
              </h2>
              <p className="text-[11px] text-zinc-400 mt-0.5">
                2D/3D ထိုးဂဏန်း၊ ထိုးကြေးနှင့် Digital Receipt ဘောက်ချာများ
              </p>
            </div>

            <div className="w-10 h-10 rounded-2xl bg-[#FFCC00] text-black flex items-center justify-center shrink-0 group-hover:scale-105 transition shadow-md">
              <Receipt className="w-5 h-5 stroke-[2.5]" />
            </div>
          </div>

          <div className="mt-3 p-2.5 rounded-2xl bg-black/80 border border-zinc-800 flex items-center justify-between text-xs">
            <div className="flex items-center gap-2 overflow-hidden">
              <span className="text-[10px] font-mono font-bold text-[#FFCC00] shrink-0 bg-[#FFCC00]/10 px-1.5 py-0.5 rounded-lg border border-[#FFCC00]/30">
                2D (12:01 PM)
              </span>
              <span className="text-[11px] text-zinc-300 truncate">
                Aung Aung • <span className="text-[#FFCC00] font-mono font-bold">85, 58</span> (200 Ks)
              </span>
            </div>
            <span className="text-[10px] font-bold text-[#FFCC00] shrink-0 flex items-center gap-0.5 group-hover:translate-x-0.5 transition">
              <span>ကြည့်ရန်</span>
              <ChevronRight className="w-3 h-3" />
            </span>
          </div>
        </button>

        <div className="grid grid-cols-2 gap-4">
          {cards.map((card) => {
            const Icon = card.icon;
            return (
              <button
                key={card.id}
                id={card.id}
                onClick={() => onNavigate(card.screen)}
                className="group relative flex flex-col items-center justify-between p-4 rounded-3xl bg-[#FFCC00] hover:bg-[#ffc107] active:scale-[0.96] shadow-[0_6px_20px_rgba(255,204,0,0.18)] transition-all duration-150 aspect-[1/1.08] cursor-pointer"
              >
                <div className="flex-1 flex items-center justify-center w-full pt-1">
                  <Icon className="w-16 h-16 text-black transition-transform group-hover:scale-105" />
                </div>

                <div className="w-full text-center mt-1 pb-1">
                  <span className="text-black font-extrabold text-[15px] sm:text-base tracking-tight leading-tight block whitespace-nowrap">
                    {card.label}
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
