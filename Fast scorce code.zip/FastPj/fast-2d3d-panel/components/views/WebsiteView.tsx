'use client';

import React, { useState, useRef } from 'react';
import { Logo2D3D } from '../Logo2D3D';
import {
  Users,
  UserCheck,
  UserX,
  CreditCard,
  Headphones,
  Settings,
  X,
  Plus,
  Trash2,
  Edit3,
  Save,
  Check,
  AlertTriangle,
  Smartphone,
  Send,
  Hash,
  QrCode,
  Upload,
  Image as ImageIcon,
  Search,
  Copy,
  Activity,
  ShieldAlert,
  ChevronRight,
  Receipt,
  Sparkles,
} from 'lucide-react';
import { AdsConfig, WinningSlot, AppUser, WebsiteSettings, PaymentMethod, SupportLinkConfig, BetRecord, UserRole } from '@/lib/types';
import { BetReceiptModal } from '../BetReceiptModal';

interface WebsiteViewProps {
  ads?: AdsConfig;
  slots?: WinningSlot[];
  users?: AppUser[];
  betRecords?: BetRecord[];
  settings: WebsiteSettings;
  onUpdateSettings: (settings: WebsiteSettings) => void;
  role?: UserRole;
}

export function WebsiteView({
  users = [],
  betRecords = [],
  settings,
  onUpdateSettings,
  role = 'admin',
}: WebsiteViewProps) {
  const [activeModal, setActiveModal] = useState<'payments' | 'support' | 'others' | 'users_directory' | 'bet_receipts' | null>(null);
  const [selectedReceiptBet, setSelectedReceiptBet] = useState<BetRecord | null>(null);
  const [userModalTab, setUserModalTab] = useState<'all' | 'active' | 'inactive'>('active');
  const [userSearchQuery, setUserSearchQuery] = useState('');
  const [copiedUid, setCopiedUid] = useState<string | null>(null);
  const [toastMessage, setToastMessage] = useState('');

  const [paymentList, setPaymentList] = useState<PaymentMethod[]>(settings.payments || []);
  const [withdrawalPaymentList, setWithdrawalPaymentList] = useState<PaymentMethod[]>(
    settings.withdrawalPayments || []
  );
  const [paymentTarget, setPaymentTarget] = useState<'deposit' | 'withdrawal'>('deposit');
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingPaymentId, setEditingPaymentId] = useState<string | null>(null);

  const [payFormName, setPayFormName] = useState('');
  const [payFormMode, setPayFormMode] = useState<'number' | 'qr'>('number');
  const [payFormNumber, setPayFormNumber] = useState('');
  const [payFormQr, setPayFormQr] = useState('');
  const [payFormLogo, setPayFormLogo] = useState('');
  const [payFormReceiverName, setPayFormReceiverName] = useState('');
  const [payFormMin, setPayFormMin] = useState('1000');
  const [payFormMax, setPayFormMax] = useState('1000000');
  const qrFileInputRef = useRef<HTMLInputElement>(null);
  const logoFileInputRef = useRef<HTMLInputElement>(null);
  const payIdCounterRef = useRef(0);

  const [supportState, setSupportState] = useState<SupportLinkConfig>(settings.support);

  const [otherStatus, setOtherStatus] = useState<'online' | 'maintenance' | 'closed'>(settings.siteStatus);
  const [otherMaintenanceMsg, setOtherMaintenanceMsg] = useState(settings.maintenanceMessage);

  const activePaymentList = paymentTarget === 'deposit' ? paymentList : withdrawalPaymentList;
  const setActivePaymentList = (list: PaymentMethod[]) => {
    if (paymentTarget === 'deposit') setPaymentList(list);
    else setWithdrawalPaymentList(list);
  };
  const paymentSettingsPayload = (list: PaymentMethod[]) =>
    paymentTarget === 'deposit'
      ? { ...settings, payments: list }
      : { ...settings, withdrawalPayments: list };

  const totalUsers = users.length;

  const activeUsersList = users.filter((u) => u.status === 'active');
  const inactiveUsersList = users.filter((u) => u.status !== 'active');
  const active7Days = activeUsersList.length;
  const inActiveUsers = inactiveUsersList.length;

  const displayedUsers = (
    userModalTab === 'active'
      ? activeUsersList
      : userModalTab === 'inactive'
      ? inactiveUsersList
      : users
  ).filter((u) => {
    if (!userSearchQuery.trim()) return true;
    const q = userSearchQuery.toLowerCase().trim();
    return (
      u.name.toLowerCase().includes(q) ||
      u.phone.toLowerCase().includes(q) ||
      u.uid.toLowerCase().includes(q)
    );
  });

  const handleOpenUserModal = (tab: 'all' | 'active' | 'inactive') => {
    setUserModalTab(tab);
    setUserSearchQuery('');
    setActiveModal('users_directory');
  };

  const handleCopyText = (text: string, id: string) => {
    if (typeof navigator !== 'undefined' && navigator.clipboard) {
      navigator.clipboard.writeText(text);
      setCopiedUid(id);
      setTimeout(() => setCopiedUid(null), 2000);
    }
  };

  const handleOpenPayments = () => {
    setPaymentList(settings.payments || []);
    setWithdrawalPaymentList(settings.withdrawalPayments || []);
    setPaymentTarget('deposit');
    setIsFormOpen(false);
    setEditingPaymentId(null);
    setActiveModal('payments');
  };

  const handleStartAddPayment = () => {
    setEditingPaymentId(null);
    setPayFormName('');
    setPayFormMode('number');
    setPayFormNumber('');
    setPayFormQr('');
    setPayFormLogo('');
    setPayFormReceiverName('');
    setPayFormMin('1000');
    setPayFormMax('1000000');
    setIsFormOpen(true);
  };

  const handleStartEditPayment = (pay: PaymentMethod) => {
    setEditingPaymentId(pay.id);
    setPayFormName(pay.name || '');
    setPayFormMode(pay.mode || (pay.qrImageUrl ? 'qr' : 'number'));
    setPayFormNumber(pay.accountNumber || '');
    setPayFormQr(pay.qrImageUrl || '');
    setPayFormLogo(pay.logoUrl || '');
    setPayFormReceiverName(pay.accountName || '');
    setPayFormMin(String(pay.minDeposit || 1000));
    setPayFormMax(String(pay.maxDeposit || 1000000));
    setIsFormOpen(true);
  };

  const handleQrUpload = (file: File) => {
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      showToast('ပုံဖိုင် (Image file) သာ တင်ပေးပါ');
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setPayFormQr(reader.result);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleLogoUpload = (file: File) => {
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      showToast('ပုံဖိုင် (Image file) သာ တင်ပေးပါ');
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setPayFormLogo(reader.result);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSavePaymentForm = () => {
    if (!payFormName.trim()) {
      showToast('Payment Name ဖြည့်စွက်ပါ');
      return;
    }
    if (paymentTarget === 'deposit') {
      if (payFormMode === 'number' && !payFormNumber.trim()) {
        showToast('Payment Account / Phone Number ဖြည့်စွက်ပါ');
        return;
      }
      if (payFormMode === 'qr' && !payFormQr) {
        showToast('QR Code ပုံ စက်ထဲမှ ရွေးချယ်တင်ပေးပါ');
        return;
      }
      if (!payFormReceiverName.trim()) {
        showToast('Payment Receiver Name ဖြည့်စွက်ပါ');
        return;
      }
    }

    const isWithdrawal = paymentTarget === 'withdrawal';
    const mode = isWithdrawal ? 'number' : payFormMode;
    const accountName = isWithdrawal ? '' : payFormReceiverName.trim();
    const accountNumber = isWithdrawal ? '' : payFormMode === 'number' ? payFormNumber.trim() : '';
    const qrImageUrl = isWithdrawal ? '' : payFormMode === 'qr' ? payFormQr : '';

    let nextList: PaymentMethod[];

    if (editingPaymentId) {
      nextList = activePaymentList.map((p) =>
        p.id === editingPaymentId
          ? {
              ...p,
              name: payFormName.trim(),
              mode,
              accountName,
              accountNumber,
              qrImageUrl,
              logoUrl: payFormLogo,
              minDeposit: Number(payFormMin) || 1000,
              maxDeposit: Number(payFormMax) || 1000000,
            }
          : p
      );
      showToast('ငွေပေးချေမှု အချက်အလက်များကို ပြင်ဆင်ပြီးပါပြီ');
    } else {
      const slug = payFormName.toLowerCase().replace(/\s+/g, '') || 'payment';
      let newId: string;
      do {
        payIdCounterRef.current += 1;
        newId = `pay-${payIdCounterRef.current}-${slug}`;
      } while (activePaymentList.some((p) => p.id === newId));

      const newMethod: PaymentMethod = {
        id: newId,
        name: payFormName.trim(),
        mode,
        accountName,
        accountNumber,
        qrImageUrl,
        logoUrl: payFormLogo,
        minDeposit: Number(payFormMin) || 1000,
        maxDeposit: Number(payFormMax) || 1000000,
        active: true,
        type: 'mobile_banking',
      };
      nextList = [...activePaymentList, newMethod];
      showToast('ငွေပေးချေမှု အသစ် ထည့်သွင်းပြီးပါပြီ');
    }

    setActivePaymentList(nextList);

    onUpdateSettings(paymentSettingsPayload(nextList));
    setIsFormOpen(false);
    setEditingPaymentId(null);
  };

  const handleTogglePayment = (id: string) => {
    const nextList = activePaymentList.map((p) => (p.id === id ? { ...p, active: !p.active } : p));
    setActivePaymentList(nextList);
    onUpdateSettings(paymentSettingsPayload(nextList));
  };

  const handleDeletePayment = (id: string) => {
    const nextList = activePaymentList.filter((p) => p.id !== id);
    setActivePaymentList(nextList);
    onUpdateSettings(paymentSettingsPayload(nextList));
    if (editingPaymentId === id) {
      setIsFormOpen(false);
      setEditingPaymentId(null);
    }
  };

  const handleSavePayments = () => {
    onUpdateSettings({
      ...settings,
      payments: paymentList,
      withdrawalPayments: withdrawalPaymentList,
    });
    setActiveModal(null);
    showToast('ငွေပေးချေမှု လမ်းကြောင်းများကို အောင်မြင်စွာ သိမ်းဆည်းပြီးပါပြီ');
  };

  const handleOpenSupport = () => {
    setSupportState(settings.support);
    setActiveModal('support');
  };

  const handleSaveSupport = () => {
    onUpdateSettings({
      ...settings,
      support: supportState,
    });
    setActiveModal(null);
    showToast('အကူအညီ လင့်ခ်များကို အောင်မြင်စွာ သိမ်းဆည်းပြီးပါပြီ');
  };

  const handleOpenOthers = () => {
    setOtherStatus(settings.siteStatus);
    setOtherMaintenanceMsg(settings.maintenanceMessage);
    setActiveModal('others');
  };

  const handleSaveOthers = () => {
    onUpdateSettings({
      ...settings,
      siteStatus: otherStatus,
      maintenanceMessage: otherMaintenanceMsg,
    });
    setActiveModal(null);
    showToast('အခြား ဆက်တင်များကို အောင်မြင်စွာ သိမ်းဆည်းပြီးပါပြီ');
  };

  const handleQuickStatusChange = (status: 'online' | 'maintenance' | 'closed') => {
    onUpdateSettings({
      ...settings,
      siteStatus: status,
    });
    showToast(`Client Site Status: ${status.toUpperCase()} သို့ ပြောင်းလဲပြီးပါပြီ`);
  };

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(''), 3000);
  };

  return (
    <div className="flex flex-col min-h-screen bg-[#101012] text-white pb-32 selection:bg-amber-400 selection:text-black">
      <div className="sticky top-0 z-30 flex items-center justify-between px-5 py-3.5 bg-[#101012]/95 backdrop-blur-md border-b border-zinc-900">
        <div className="flex items-center gap-2">
          <Logo2D3D size="sm" showText={false} />
          <div>
            <span className="font-bold text-base text-[#FFCC00] block leading-none">Fast 2D3D Official Web</span>
            <span className="text-[10px] text-zinc-400">ဝဘ်ဆိုဒ် စီမံခန့်ခွဲမှု ပေါ်တယ် (Admin Only)</span>
          </div>
        </div>

        <div
          className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold border transition ${
            settings.siteStatus === 'online'
              ? 'bg-emerald-500/15 border-emerald-500/30 text-emerald-400'
              : settings.siteStatus === 'maintenance'
              ? 'bg-amber-500/15 border-amber-500/30 text-amber-300'
              : 'bg-rose-500/15 border-rose-500/30 text-rose-300'
          }`}
        >
          <span
            className={`w-2 h-2 rounded-full ${
              settings.siteStatus === 'online'
                ? 'bg-emerald-400 animate-pulse'
                : settings.siteStatus === 'maintenance'
                ? 'bg-amber-400 animate-pulse'
                : 'bg-rose-400'
            }`}
          />
          <span className="capitalize">{settings.siteStatus}</span>
        </div>
      </div>

      {role === 'agent' && (
        <div className="mx-4 mt-3 p-3 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center gap-2 text-xs text-amber-300">
          <ShieldAlert className="w-4 h-4 text-[#FFCC00] shrink-0" />
          <span>
            ဝဘ်ဆိုဒ် အချက်အလက် ကြည့်ရှုမှု ပေါ်တယ် (Agent View - ခလုတ်များနှင့် ဆက်တင်များကို Master Admin သာ ပြင်ဆင်ခွင့်ရှိသည်)
          </span>
        </div>
      )}

      {toastMessage && (
        <div className="mx-4 mt-2.5 p-2.5 rounded-xl bg-emerald-950/90 border border-emerald-500/60 text-emerald-300 text-xs text-center flex items-center justify-center gap-2 animate-in fade-in shadow-lg">
          <Check className="w-4 h-4 text-emerald-400 shrink-0" />
          <span className="font-medium">{toastMessage}</span>
        </div>
      )}

      {settings.siteStatus === 'maintenance' && (
        <div className="mx-4 mt-3 p-3 rounded-2xl bg-amber-950/80 border border-amber-500/50 flex items-start gap-2.5 text-amber-200 text-xs">
          <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
          <div className="flex-1">
            <span className="font-bold text-amber-300 block">ဆာဗာ ပြုပြင်ထိန်းသိမ်းမှု စနစ်ဖွင့်ထားပါသည်:</span>
            <p className="text-[11px] text-zinc-300 mt-0.5">{settings.maintenanceMessage}</p>
          </div>
        </div>
      )}

      <div className="flex-1 px-4 py-4 max-w-sm mx-auto w-full space-y-4">
        <div className="p-4 rounded-3xl bg-zinc-950 border border-zinc-800/90 shadow-xl space-y-3.5">
          <div className="flex items-center justify-between pb-3 border-b border-zinc-850">
            <div>
              <span className="text-[11px] text-zinc-400 font-medium block">Client Site Status (ဝဘ်ဆိုဒ် အခြေအနေ)</span>
              <div className="flex items-center gap-1.5 mt-0.5">
                <span
                  className={`w-2.5 h-2.5 rounded-full ${
                    settings.siteStatus === 'online'
                      ? 'bg-emerald-400 animate-pulse'
                      : settings.siteStatus === 'maintenance'
                      ? 'bg-amber-400'
                      : 'bg-rose-500'
                  }`}
                />
                <span className="text-sm font-black text-white capitalize">
                  {settings.siteStatus === 'online'
                    ? 'Online (ပုံမှန်ဖွင့်ထားသည်)'
                    : settings.siteStatus === 'maintenance'
                    ? 'Maintenance (ဆာဗာပြုပြင်ဆဲ)'
                    : 'Closed (လောင်းကစားပိတ်ထားသည်)'}
                </span>
              </div>
            </div>

            {role === 'admin' && (
              <div className="flex p-0.5 bg-black rounded-xl border border-zinc-800">
                <button
                  type="button"
                  onClick={() => handleQuickStatusChange('online')}
                  className={`px-2 py-1 rounded-lg text-[10px] font-bold transition cursor-pointer ${
                    settings.siteStatus === 'online'
                      ? 'bg-emerald-500 text-black shadow'
                      : 'text-zinc-400 hover:text-white'
                  }`}
                  title="Online"
                >
                  Online
                </button>
                <button
                  type="button"
                  onClick={() => handleQuickStatusChange('maintenance')}
                  className={`px-2 py-1 rounded-lg text-[10px] font-bold transition cursor-pointer ${
                    settings.siteStatus === 'maintenance'
                      ? 'bg-amber-400 text-black shadow'
                      : 'text-zinc-400 hover:text-white'
                  }`}
                  title="Maintenance"
                >
                  Maint
                </button>
              </div>
            )}
          </div>

          <div>
            <div className="text-[11px] text-[#FFCC00] font-bold mb-2 flex items-center gap-1">
              <Users className="w-3.5 h-3.5" />
              <span>အသုံးပြုသူ စာရင်းအင်း (Users Analytics)</span>
            </div>

            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                id="stat-total-users"
                onClick={() => handleOpenUserModal('all')}
                className="p-3 rounded-2xl bg-black/90 border border-zinc-800 hover:border-[#FFCC00]/60 flex flex-col justify-between text-left transition active:scale-95 group cursor-pointer shadow-sm hover:shadow-[0_0_12px_rgba(255,204,0,0.15)]"
              >
                <div className="flex items-center justify-between text-zinc-400 group-hover:text-[#FFCC00] transition">
                  <span className="text-[10px] font-medium leading-tight">Total Users</span>
                  <Users className="w-3.5 h-3.5 text-[#FFCC00]" />
                </div>
                <div className="mt-2">
                  <span className="text-lg font-black text-white group-hover:text-[#FFCC00] font-mono block leading-none transition">
                    {totalUsers.toLocaleString()}
                  </span>
                  <span className="text-[9px] text-zinc-500 group-hover:text-zinc-400 mt-1 block flex items-center justify-between">
                    <span>စုစုပေါင်း</span>
                    <span className="text-[8px] text-[#FFCC00] opacity-0 group-hover:opacity-100 transition">ကြည့်ရန် →</span>
                  </span>
                </div>
              </button>

              <button
                type="button"
                id="stat-active-7d-users"
                onClick={() => handleOpenUserModal('active')}
                className="p-3 rounded-2xl bg-black/90 border-2 border-emerald-500/50 hover:border-emerald-400 flex flex-col justify-between text-left transition active:scale-95 group cursor-pointer shadow-sm hover:shadow-[0_0_15px_rgba(16,185,129,0.25)] relative overflow-hidden"
              >
                <div className="absolute top-1 right-1 w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <div className="flex items-center justify-between text-emerald-400">
                  <span className="text-[10px] font-bold leading-tight">Active 7 Days</span>
                  <UserCheck className="w-3.5 h-3.5 text-emerald-400" />
                </div>
                <div className="mt-2">
                  <span className="text-lg font-black text-emerald-400 font-mono block leading-none">
                    {active7Days.toLocaleString()}
                  </span>
                  <span className="text-[9px] text-emerald-500 mt-1 block flex items-center justify-between">
                    <span>၇ ရက်အတွင်း</span>
                    <span className="text-[8px] font-bold text-emerald-300">ကြည့်ရန် →</span>
                  </span>
                </div>
              </button>

              <button
                type="button"
                id="stat-inactive-users"
                onClick={() => handleOpenUserModal('inactive')}
                className="p-3 rounded-2xl bg-black/90 border-2 border-zinc-800 hover:border-zinc-500 flex flex-col justify-between text-left transition active:scale-95 group cursor-pointer shadow-sm hover:shadow-[0_0_12px_rgba(255,255,255,0.1)] relative"
              >
                <div className="flex items-center justify-between text-zinc-400 group-hover:text-zinc-200">
                  <span className="text-[10px] font-medium leading-tight">In-active</span>
                  <UserX className="w-3.5 h-3.5 text-zinc-400 group-hover:text-rose-400 transition" />
                </div>
                <div className="mt-2">
                  <span className="text-lg font-black text-zinc-400 group-hover:text-white font-mono block leading-none transition">
                    {inActiveUsers.toLocaleString()}
                  </span>
                  <span className="text-[9px] text-zinc-500 group-hover:text-zinc-300 mt-1 block flex items-center justify-between">
                    <span>အသုံးမပြုသူ</span>
                    <span className="text-[8px] font-bold text-zinc-400">ကြည့်ရန် →</span>
                  </span>
                </div>
              </button>
            </div>
          </div>
        </div>

        {role === 'admin' ? (
          <div className="space-y-2.5">
            <div className="text-[11px] text-zinc-400 font-semibold px-1">ဝဘ်ဆိုဒ် စီမံခန့်ခွဲမှု ခလုတ်များ</div>

            <button
              id="btn-change-payments"
              type="button"
              onClick={handleOpenPayments}
              className="w-full py-3.5 px-4 rounded-2xl bg-black border-2 border-[#FFCC00] hover:border-amber-300 active:scale-[0.98] text-white transition flex items-center justify-between group shadow-md cursor-pointer"
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-[#FFCC00] text-black flex items-center justify-center font-bold shadow-sm">
                  <CreditCard className="w-5 h-5" />
                </div>
                <div className="text-left">
                  <span className="text-xs font-extrabold text-[#FFCC00] block leading-tight">
                    Change Payments (ငွေပေးချေမှု ပြင်ရန်)
                  </span>
                  <span className="text-[10px] text-zinc-400">
                    Number & QR ငွေပေးချေမှု လမ်းကြောင်းများ ({settings.payments.filter((p) => p.active).length} ခုဖွင့်ထား)
                  </span>
                </div>
              </div>
              <span className="text-xs text-[#FFCC00] font-bold group-hover:translate-x-0.5 transition">&rarr;</span>
            </button>

            <button
              id="btn-change-support-link"
              type="button"
              onClick={handleOpenSupport}
              className="w-full py-3.5 px-4 rounded-2xl bg-black border-2 border-[#FFCC00] hover:border-amber-300 active:scale-[0.98] text-white transition flex items-center justify-between group shadow-md cursor-pointer"
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-[#FFCC00] text-black flex items-center justify-center font-bold shadow-sm">
                  <Headphones className="w-5 h-5" />
                </div>
                <div className="text-left">
                  <span className="text-xs font-extrabold text-[#FFCC00] block leading-tight">
                    Change Support Link (အကူအညီ လင့်ခ် ပြင်ရန်)
                  </span>
                  <span className="text-[10px] text-zinc-400">
                    Telegram လင့်ခ်
                  </span>
                </div>
              </div>
              <span className="text-xs text-[#FFCC00] font-bold group-hover:translate-x-0.5 transition">&rarr;</span>
            </button>

            <button
              id="btn-change-others"
              type="button"
              onClick={handleOpenOthers}
              className="w-full py-3.5 px-4 rounded-2xl bg-black border-2 border-[#FFCC00] hover:border-amber-300 active:scale-[0.98] text-white transition flex items-center justify-between group shadow-md cursor-pointer"
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-[#FFCC00] text-black flex items-center justify-center font-bold shadow-sm">
                  <Settings className="w-5 h-5" />
                </div>
                <div className="text-left">
                  <span className="text-xs font-extrabold text-[#FFCC00] block leading-tight">
                    Others (အခြား ဆက်တင်များ ပြင်ရန်)
                  </span>
                  <span className="text-[10px] text-zinc-400">
                    ဝဘ်ဆိုဒ် လည်ပတ်မှု အခြေအနေ နှင့် ဆာဗာပြုပြင်မှု စာတန်း
                  </span>
                </div>
              </div>
              <span className="text-xs text-[#FFCC00] font-bold group-hover:translate-x-0.5 transition">&rarr;</span>
            </button>
          </div>
        ) : (

          <div className="p-4 rounded-3xl bg-zinc-950 border border-zinc-850 space-y-3">
            <div className="text-xs font-bold text-zinc-300 flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-[#FFCC00]" />
              <span>ဝဘ်ဆိုဒ် အချက်အလက် အနှစ်ချုပ် (Website Overview - View Only)</span>
            </div>

            <div className="space-y-2 text-xs">
              <div className="p-3 rounded-2xl bg-black border border-zinc-800 flex items-center justify-between">
                <span className="text-zinc-400">ဖွင့်လှစ်ထားသော ငွေပေးချေမှုများ</span>
                <span className="text-[#FFCC00] font-bold font-mono">
                  {settings.payments.filter((p) => p.active).length} Channels Active
                </span>
              </div>

              <div className="p-3 rounded-2xl bg-black border border-zinc-800 flex items-center justify-between">
                <span className="text-zinc-400">ဆက်သွယ်ရန် အကူအညီ လိုင်းများ</span>
                <span className="text-white font-medium">Telegram / Viber / Phone</span>
              </div>

              <div className="p-3 rounded-2xl bg-black border border-zinc-800 flex items-center justify-between">
                <span className="text-zinc-400">ဆာဗာ ပြုပြင်မှု မက်ဆေ့ခ်ျ</span>
                <span className="text-zinc-300 text-[11px] truncate max-w-[180px]">
                  {settings.maintenanceMessage}
                </span>
              </div>
            </div>

            <div className="p-2.5 rounded-xl bg-zinc-900/80 border border-zinc-800 text-center text-zinc-500 text-[11px]">
              (Change Payments, Support Links နှင့် အခြားခလုတ်များကို Master Admin သာ ပြင်ဆင်ခွင့်ရှိပါသည်)
            </div>
          </div>
        )}
      </div>

      {activeModal === 'payments' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-sm p-4 animate-in fade-in duration-200">
          <div className="w-full max-w-sm max-h-[90vh] flex flex-col rounded-3xl bg-[#141416] border border-[#FFCC00]/60 shadow-2xl overflow-hidden text-left">
            <div className="flex items-center justify-between px-5 py-3.5 border-b border-zinc-800 bg-black/40 shrink-0">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-[#FFCC00] flex items-center justify-center text-black font-bold">
                  <CreditCard className="w-4 h-4 text-black" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-[#FFCC00]">ငွေပေးချေမှု လမ်းကြောင်းများ</h3>
                  <p className="text-[10px] text-zinc-400">Payment Accounts & QR Management</p>
                </div>
              </div>
              <button
                onClick={() => setActiveModal(null)}
                className="w-8 h-8 rounded-full flex items-center justify-center text-zinc-400 hover:text-white hover:bg-zinc-800 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto px-4 py-3.5 space-y-3 pretty-scrollbar">
              <div className="grid grid-cols-2 p-1 bg-black rounded-2xl border border-zinc-800">
                <button
                  type="button"
                  onClick={() => {
                    setPaymentTarget('deposit');
                    setIsFormOpen(false);
                    setEditingPaymentId(null);
                  }}
                  className={`py-2 text-xs font-bold rounded-xl transition ${
                    paymentTarget === 'deposit'
                      ? 'bg-[#FFCC00] text-black shadow'
                      : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  Deposit Payments
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setPaymentTarget('withdrawal');
                    setIsFormOpen(false);
                    setEditingPaymentId(null);
                  }}
                  className={`py-2 text-xs font-bold rounded-xl transition ${
                    paymentTarget === 'withdrawal'
                      ? 'bg-[#FFCC00] text-black shadow'
                      : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  Withdrawal Payments
                </button>
              </div>
              {isFormOpen ? (
                <div className="p-3.5 rounded-2xl bg-black border border-[#FFCC00]/60 space-y-3 animate-in fade-in">
                  <div className="flex items-center justify-between pb-2 border-b border-zinc-800">
                    <span className="text-xs font-bold text-[#FFCC00]">
                      {editingPaymentId ? 'ငွေပေးချေမှု ပြင်ဆင်ရန် (Edit Payment)' : 'ငွေပေးချေမှု အသစ်ထည့်ရန် (Add Payment)'}
                    </span>
                    <button
                      type="button"
                      onClick={() => {
                        setIsFormOpen(false);
                        setEditingPaymentId(null);
                      }}
                      className="text-zinc-400 hover:text-white"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>

                  <div>
                    <label className="text-xs font-bold text-[#FFCC00] block mb-1">
                      Enter Payment Name
                    </label>
                    <input
                      type="text"
                      value={payFormName}
                      onChange={(e) => setPayFormName(e.target.value)}
                      placeholder="Enter Payment Name (ဥပမာ- KBZPay, WavePay)"
                      className="w-full h-9 px-3 rounded-xl bg-zinc-900 border border-zinc-700 text-xs text-white focus:border-[#FFCC00] focus:outline-none font-medium"
                    />
                  </div>

                  {paymentTarget === 'deposit' && (
                  <div>
                    <label className="text-xs font-bold text-[#FFCC00] block mb-1">
                      ငွေပေးချေမှု ပုံစံ ရွေးချယ်ပါ (Number / QR)
                    </label>
                    <div className="grid grid-cols-2 p-1 bg-zinc-900 rounded-xl border border-zinc-700">
                      <button
                        type="button"
                        onClick={() => setPayFormMode('number')}
                        className={`py-2 text-xs font-bold rounded-lg transition flex items-center justify-center gap-1.5 cursor-pointer ${
                          payFormMode === 'number'
                            ? 'bg-[#FFCC00] text-black shadow'
                            : 'text-zinc-400 hover:text-white'
                        }`}
                      >
                        <Hash className="w-3.5 h-3.5" />
                        <span>Number</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => setPayFormMode('qr')}
                        className={`py-2 text-xs font-bold rounded-lg transition flex items-center justify-center gap-1.5 cursor-pointer ${
                          payFormMode === 'qr'
                            ? 'bg-[#FFCC00] text-black shadow'
                            : 'text-zinc-400 hover:text-white'
                        }`}
                      >
                        <QrCode className="w-3.5 h-3.5" />
                        <span>QR</span>
                      </button>
                    </div>
                  </div>
                  )}

                  {paymentTarget === 'deposit' && payFormMode === 'number' && (
                    <div>
                      <label className="text-xs font-bold text-[#FFCC00] block mb-1">
                        Payment Number / Phone (အကောင့် / ဖုန်းနံပါတ်)
                      </label>
                      <input
                        type="text"
                        value={payFormNumber}
                        onChange={(e) => setPayFormNumber(e.target.value)}
                        placeholder="ဥပမာ- 09772819281"
                        className="w-full h-9 px-3 rounded-xl bg-zinc-900 border border-zinc-700 text-xs text-white focus:border-[#FFCC00] focus:outline-none font-mono"
                      />
                    </div>
                  )}

                  {paymentTarget === 'deposit' && payFormMode === 'qr' && (
                    <div>
                      <label className="text-xs font-bold text-[#FFCC00] block mb-1">
                        Upload QR Code from Device
                      </label>
                      <div
                        onDragOver={(e) => e.preventDefault()}
                        onDrop={(e) => {
                          e.preventDefault();
                          if (e.dataTransfer.files?.[0]) handleQrUpload(e.dataTransfer.files[0]);
                        }}
                        onClick={() => qrFileInputRef.current?.click()}
                        className="border-2 border-dashed border-zinc-700 hover:border-[#FFCC00] rounded-2xl p-3 text-center cursor-pointer transition bg-zinc-900/60"
                      >
                        <input
                          ref={qrFileInputRef}
                          type="file"
                          accept="image/*"
                          onChange={(e) => {
                            if (e.target.files?.[0]) handleQrUpload(e.target.files[0]);
                          }}
                          className="hidden"
                        />
                        {payFormQr ? (
                          <div className="flex flex-col items-center gap-2">
                            {/* eslint-disable-next-line @next/next/no-img-element */}
                            <img
                              src={payFormQr}
                              alt="Uploaded QR Preview"
                              className="w-28 h-28 object-contain rounded-xl border border-amber-400/60 bg-white p-1 shadow-md"
                            />
                            <div className="flex items-center gap-2">
                              <span className="text-[11px] text-amber-300 font-bold">QR တင်ပြီးပါပြီ (Click to change)</span>
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setPayFormQr('');
                                }}
                                className="text-[10px] text-red-400 hover:underline"
                              >
                                ဖျက်မည်
                              </button>
                            </div>
                          </div>
                        ) : (
                          <div className="flex flex-col items-center gap-1.5 py-3">
                            <div className="w-10 h-10 rounded-full bg-[#FFCC00]/15 text-[#FFCC00] flex items-center justify-center">
                              <Upload className="w-5 h-5" />
                            </div>
                            <span className="text-xs font-bold text-white">Click or Drag & Drop to Upload QR</span>
                            <span className="text-[10px] text-zinc-400">စက်ထဲမှ QR Code ဓာတ်ပုံ ရွေးချယ်ပါ</span>
                          </div>
                        )}
                      </div>
                    </div>
                  )}

                  <div>
                    <label className="text-xs font-bold text-[#FFCC00] block mb-1">
                      Payment Logo (ငွေပေးချေမှု လိုဂို)
                    </label>
                    <div className="flex items-center gap-2">
                      <div className="w-12 h-12 rounded-xl bg-zinc-900 border border-zinc-700 flex items-center justify-center overflow-hidden shrink-0">
                        {payFormLogo ? (
                          // eslint-disable-next-line @next/next/no-img-element
                          <img src={payFormLogo} alt="Payment logo" className="w-full h-full object-contain p-1" />
                        ) : (
                          <span className="text-[9px] text-zinc-500 text-center px-1">No logo</span>
                        )}
                      </div>
                      <div className="flex-1 space-y-1.5">
                        <input
                          type="text"
                          value={payFormLogo.startsWith('data:') ? '' : payFormLogo}
                          onChange={(e) => setPayFormLogo(e.target.value)}
                          placeholder="Logo image URL (https://...)"
                          className="w-full h-9 px-3 rounded-xl bg-zinc-900 border border-zinc-700 text-xs text-white focus:border-[#FFCC00] focus:outline-none font-mono"
                        />
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => logoFileInputRef.current?.click()}
                            className="px-2.5 py-1 rounded-lg bg-zinc-800 text-[#FFCC00] text-[11px] font-bold hover:bg-zinc-700 transition flex items-center gap-1"
                          >
                            <Upload className="w-3 h-3" />
                            <span>Upload Logo</span>
                          </button>
                          {payFormLogo && (
                            <button
                              type="button"
                              onClick={() => setPayFormLogo('')}
                              className="text-[10px] text-red-400 hover:underline"
                            >
                              ဖျက်မည်
                            </button>
                          )}
                        </div>
                        <input
                          ref={logoFileInputRef}
                          type="file"
                          accept="image/*"
                          onChange={(e) => {
                            if (e.target.files?.[0]) handleLogoUpload(e.target.files[0]);
                          }}
                          className="hidden"
                        />
                      </div>
                    </div>
                  </div>

                  {paymentTarget === 'deposit' && (
                  <div>
                    <label className="text-xs font-bold text-[#FFCC00] block mb-1">
                      Payment Receiver Name (ငွေလက်ခံသူ အမည်)
                    </label>
                    <input
                      type="text"
                      value={payFormReceiverName}
                      onChange={(e) => setPayFormReceiverName(e.target.value)}
                      placeholder="ဥပမာ- Fast 2D3D Official / U Aung Aung"
                      className="w-full h-9 px-3 rounded-xl bg-zinc-900 border border-zinc-700 text-xs text-white focus:border-[#FFCC00] focus:outline-none font-medium"
                    />
                  </div>
                  )}

                  {paymentTarget === 'deposit' && (
                  <div className="grid grid-cols-2 gap-2.5">
                    <div>
                      <label className="text-xs font-bold text-[#FFCC00] block mb-1">
                        Min (အနည်းဆုံး)
                      </label>
                      <input
                        type="number"
                        value={payFormMin}
                        onChange={(e) => setPayFormMin(e.target.value)}
                        placeholder="1000"
                        className="w-full h-9 px-3 rounded-xl bg-zinc-900 border border-zinc-700 text-xs text-white focus:border-[#FFCC00] focus:outline-none font-mono"
                      />
                    </div>
                    <div>
                      <label className="text-xs font-bold text-[#FFCC00] block mb-1">
                        Max (အများဆုံး)
                      </label>
                      <input
                        type="number"
                        value={payFormMax}
                        onChange={(e) => setPayFormMax(e.target.value)}
                        placeholder="1000000"
                        className="w-full h-9 px-3 rounded-xl bg-zinc-900 border border-zinc-700 text-xs text-white focus:border-[#FFCC00] focus:outline-none font-mono"
                      />
                    </div>
                  </div>
                  )}

                  <div className="flex gap-2 pt-1">
                    <button
                      type="button"
                      onClick={handleSavePaymentForm}
                      className="flex-1 py-2.5 rounded-xl bg-[#FFCC00] hover:bg-amber-400 text-black text-xs font-black transition shadow"
                    >
                      {editingPaymentId ? 'ပြင်ဆင်ချက် သိမ်းမည် (Update)' : 'ထည့်သွင်းမည် (Add Payment)'}
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        setIsFormOpen(false);
                        setEditingPaymentId(null);
                      }}
                      className="px-3 py-2.5 rounded-xl bg-zinc-800 text-zinc-300 text-xs font-bold hover:bg-zinc-700 transition"
                    >
                      မလုပ်တော့ပါ
                    </button>
                  </div>
                </div>
              ) : (

                <button
                  type="button"
                  onClick={handleStartAddPayment}
                  className="w-full py-3 rounded-2xl border-2 border-dashed border-[#FFCC00]/50 text-[#FFCC00] text-xs font-bold hover:bg-[#FFCC00]/5 transition flex items-center justify-center gap-2 cursor-pointer shadow-sm"
                >
                  <Plus className="w-4 h-4" />
                  <span>ငွေပေးချေမှု အသစ်ထည့်မည် (Add New Payment)</span>
                </button>
              )}

              <div className="space-y-2.5 pt-1">
                <div className="text-[11px] text-zinc-400 font-bold px-1">
                  {paymentTarget === 'deposit' ? 'Deposit' : 'Withdrawal'} လမ်းကြောင်းများ ({activePaymentList.length})
                </div>

                {activePaymentList.length === 0 ? (
                  <div className="p-4 rounded-2xl bg-zinc-950 border border-zinc-800 text-center text-xs text-zinc-500">
                    ငွေပေးချေမှု မရှိသေးပါ။ အထက်ပါခလုတ်ဖြင့် အသစ်ထည့်သွင်းပါ။
                  </div>
                ) : (
                  activePaymentList.map((pay) => (
                    <div
                      key={pay.id}
                      className="p-3.5 rounded-2xl bg-zinc-950 border border-zinc-800 space-y-2.5 hover:border-zinc-700 transition"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-xs font-black text-[#FFCC00] bg-black px-2.5 py-1 rounded-lg border border-[#FFCC00]/40">
                            {pay.name}
                          </span>

                          {paymentTarget === 'deposit' && (
                          <span
                            className={`text-[10px] font-bold px-2 py-0.5 rounded-md flex items-center gap-1 border ${
                              pay.mode === 'qr' || pay.qrImageUrl
                                ? 'bg-purple-500/15 text-purple-300 border-purple-500/30'
                                : 'bg-blue-500/15 text-blue-300 border-blue-500/30'
                            }`}
                          >
                            {pay.mode === 'qr' || pay.qrImageUrl ? (
                              <>
                                <QrCode className="w-3 h-3" />
                                <span>QR Code</span>
                              </>
                            ) : (
                              <>
                                <Hash className="w-3 h-3" />
                                <span>Number</span>
                              </>
                            )}
                          </span>
                          )}

                          <span
                            className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                              pay.active
                                ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                                : 'bg-zinc-800 text-zinc-500'
                            }`}
                          >
                            {pay.active ? 'Active' : 'Disabled'}
                          </span>
                        </div>

                        <div className="flex items-center gap-1">
                          <button
                            type="button"
                            onClick={() => handleStartEditPayment(pay)}
                            className="p-1.5 rounded-lg text-amber-300 hover:text-white hover:bg-zinc-900 transition"
                            title="Edit (ပြင်ဆင်မည်)"
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDeletePayment(pay.id)}
                            className="p-1.5 rounded-lg text-zinc-500 hover:text-red-400 hover:bg-zinc-900 transition"
                            title="Delete (ဖျက်မည်)"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>

                      <div className="flex items-start gap-3">
                        {pay.logoUrl && (
                          <div className="shrink-0">
                            {/* eslint-disable-next-line @next/next/no-img-element */}
                            <img
                              src={pay.logoUrl}
                              alt={`${pay.name} logo`}
                              className="w-14 h-14 object-contain rounded-xl bg-white p-1 border border-zinc-700 shadow"
                            />
                          </div>
                        )}

                        {paymentTarget === 'deposit' && (pay.mode === 'qr' || pay.qrImageUrl) && pay.qrImageUrl && (
                          <div className="shrink-0">
                            {/* eslint-disable-next-line @next/next/no-img-element */}
                            <img
                              src={pay.qrImageUrl}
                              alt={pay.name}
                              className="w-14 h-14 object-contain rounded-xl bg-white p-1 border border-zinc-700 shadow"
                            />
                          </div>
                        )}

                        {paymentTarget === 'deposit' && (
                        <div className="flex-1 text-xs space-y-1">
                          <div className="text-zinc-400 text-[11px]">
                            ငွေလက်ခံသူ (Receiver): <span className="text-white font-bold">{pay.accountName}</span>
                          </div>

                          {pay.accountNumber && (
                            <div className="text-zinc-400 text-[11px]">
                              အကောင့် / ဖုန်း: <span className="text-[#FFCC00] font-mono font-bold">{pay.accountNumber}</span>
                            </div>
                          )}

                          <div className="text-zinc-500 text-[10px]">
                            ကန့်သတ်ငွေ: {pay.minDeposit.toLocaleString()} မှ {pay.maxDeposit.toLocaleString()} ကျပ်ထိ
                          </div>
                        </div>
                        )}
                      </div>

                      <div className="flex items-center justify-between pt-1 border-t border-zinc-900 text-xs">
                        <span className="text-[11px] text-zinc-400">ဝန်ဆောင်မှု အခြေအနေ:</span>
                        <button
                          type="button"
                          onClick={() => handleTogglePayment(pay.id)}
                          className={`px-2.5 py-1 rounded-lg text-[10px] font-bold transition ${
                            pay.active ? 'bg-zinc-800 text-zinc-300 hover:bg-zinc-700' : 'bg-[#FFCC00] text-black hover:bg-amber-400'
                          }`}
                        >
                          {pay.active ? 'ပိတ်မည် (Disable)' : 'ဖွင့်မည် (Enable)'}
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>

            <div className="p-4 border-t border-zinc-800 bg-black/60 shrink-0">
              <button
                type="button"
                onClick={handleSavePayments}
                className="w-full h-11 rounded-xl bg-[#FFCC00] hover:bg-amber-400 text-black font-extrabold text-sm flex items-center justify-center gap-2 transition shadow cursor-pointer"
              >
                <Save className="w-4 h-4" />
                <span>သိမ်းဆည်းမည် (Save Payments)</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {activeModal === 'support' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-sm p-4 animate-in fade-in duration-200">
          <div className="w-full max-w-sm max-h-[88vh] flex flex-col rounded-3xl bg-[#141416] border border-[#FFCC00]/60 shadow-2xl overflow-hidden text-left">
            <div className="flex items-center justify-between px-5 py-3.5 border-b border-zinc-800 bg-black/40 shrink-0">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-[#FFCC00] flex items-center justify-center text-black font-bold">
                  <Headphones className="w-4 h-4 text-black" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-[#FFCC00]">အကူအညီ လင့်ခ်များ ပြင်ဆင်ရန်</h3>
                  <p className="text-[10px] text-zinc-400">Change Support Link</p>
                </div>
              </div>
              <button
                onClick={() => setActiveModal(null)}
                className="w-8 h-8 rounded-full flex items-center justify-center text-zinc-400 hover:text-white hover:bg-zinc-800 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto px-5 py-4 space-y-3.5 pretty-scrollbar">
              <div>
                <label className="text-xs font-bold text-[#FFCC00] flex items-center gap-1.5 mb-1">
                  <Send className="w-3.5 h-3.5" />
                  <span>Telegram Channel / Username</span>
                </label>
                <input
                  type="text"
                  value={supportState.telegram}
                  onChange={(e) => setSupportState({ ...supportState, telegram: e.target.value })}
                  placeholder="https://t.me/Fast2D3D_Support"
                  className="w-full h-10 px-3 rounded-xl bg-black border border-zinc-700 text-xs text-white focus:border-[#FFCC00] focus:outline-none"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-[#FFCC00] flex items-center gap-1.5 mb-1">
                  <Smartphone className="w-3.5 h-3.5" />
                  <span>Viber Number / Link</span>
                </label>
                <input
                  type="text"
                  value={supportState.viber}
                  onChange={(e) => setSupportState({ ...supportState, viber: e.target.value })}
                  placeholder="viber://chat?number=09772819281"
                  className="w-full h-10 px-3 rounded-xl bg-black border border-zinc-700 text-xs text-white focus:border-[#FFCC00] focus:outline-none"
                />
              </div>

              <div className="p-3 rounded-2xl bg-zinc-950 border border-zinc-800 space-y-1 text-xs">
                <span className="text-[10px] text-zinc-400 font-bold block">Support Channels:</span>
                <div className="text-[#FFCC00] text-[11px]">
                  Telegram: {supportState.telegram || '(မထည့်ရသေးပါ)'}
                </div>
                <div className="text-purple-300 text-[11px]">
                  Viber: {supportState.viber || '(မထည့်ရသေးပါ)'}
                </div>
              </div>
            </div>

            <div className="p-4 border-t border-zinc-800 bg-black/60 shrink-0">
              <button
                type="button"
                onClick={handleSaveSupport}
                className="w-full h-11 rounded-xl bg-[#FFCC00] hover:bg-[#ffc107] text-black font-extrabold text-sm flex items-center justify-center gap-2 transition shadow cursor-pointer"
              >
                <Save className="w-4 h-4" />
                <span>သိမ်းဆည်းမည် (Save Support Link)</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {activeModal === 'others' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-sm p-4 animate-in fade-in duration-200">
          <div className="w-full max-w-sm max-h-[88vh] flex flex-col rounded-3xl bg-[#141416] border border-[#FFCC00]/60 shadow-2xl overflow-hidden text-left">
            <div className="flex items-center justify-between px-5 py-3.5 border-b border-zinc-800 bg-black/40 shrink-0">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-[#FFCC00] flex items-center justify-center text-black font-bold">
                  <Settings className="w-4 h-4 text-black" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-[#FFCC00]">အခြား ဆက်တင်များ ပြင်ဆင်ရန်</h3>
                  <p className="text-[10px] text-zinc-400">Other Configurations</p>
                </div>
              </div>
              <button
                onClick={() => setActiveModal(null)}
                className="w-8 h-8 rounded-full flex items-center justify-center text-zinc-400 hover:text-white hover:bg-zinc-800 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4 pretty-scrollbar">
              <div>
                <label className="text-xs font-bold text-[#FFCC00] block mb-1.5">
                  Client Site Status (ဝဘ်ဆိုဒ် လည်ပတ်မှု အခြေအနေ)
                </label>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setOtherStatus('online')}
                    className={`py-2 px-1 rounded-xl text-xs font-bold border transition ${
                      otherStatus === 'online'
                        ? 'bg-emerald-500 text-black border-emerald-400 shadow'
                        : 'bg-zinc-900 text-zinc-400 border-zinc-800'
                    }`}
                  >
                    Online
                  </button>
                  <button
                    type="button"
                    onClick={() => setOtherStatus('maintenance')}
                    className={`py-2 px-1 rounded-xl text-xs font-bold border transition ${
                      otherStatus === 'maintenance'
                        ? 'bg-amber-400 text-black border-amber-300 shadow'
                        : 'bg-zinc-900 text-zinc-400 border-zinc-800'
                    }`}
                  >
                    Maintenance
                  </button>
                  <button
                    type="button"
                    onClick={() => setOtherStatus('closed')}
                    className={`py-2 px-1 rounded-xl text-xs font-bold border transition ${
                      otherStatus === 'closed'
                        ? 'bg-rose-500 text-white border-rose-400 shadow'
                        : 'bg-zinc-900 text-zinc-400 border-zinc-800'
                    }`}
                  >
                    Closed
                  </button>
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-[#FFCC00] block mb-1">
                  ဆာဗာ ပြုပြင်စဉ် ပြသမည့် စာတန်း (Maintenance Notice)
                </label>
                <textarea
                  rows={4}
                  value={otherMaintenanceMsg}
                  onChange={(e) => setOtherMaintenanceMsg(e.target.value)}
                  placeholder="စနစ်ပိုင်းဆိုင်ရာ ပြုပြင်ထိန်းသိမ်းမှုများ ပြုလုပ်နေပါသည်..."
                  className="w-full p-3 rounded-xl bg-black border border-zinc-700 text-xs text-white focus:border-[#FFCC00] focus:outline-none"
                />
              </div>
            </div>

            <div className="p-4 border-t border-zinc-800 bg-black/60 shrink-0">
              <button
                type="button"
                onClick={handleSaveOthers}
                className="w-full h-11 rounded-xl bg-[#FFCC00] hover:bg-[#ffc107] text-black font-extrabold text-sm flex items-center justify-center gap-2 transition shadow cursor-pointer"
              >
                <Save className="w-4 h-4" />
                <span>သိမ်းဆည်းမည် (Save Others)</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {activeModal === 'users_directory' && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-3 animate-in fade-in">
          <div className="w-full max-w-md bg-[#141417] border-2 border-[#FFCC00] rounded-3xl shadow-2xl flex flex-col max-h-[90vh] overflow-hidden">
            <div className="p-4 border-b border-zinc-800 flex items-center justify-between bg-black/80 shrink-0">
              <div className="flex items-center gap-2.5">
                <div
                  className={`w-9 h-9 rounded-2xl flex items-center justify-center ${
                    userModalTab === 'active'
                      ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                      : userModalTab === 'inactive'
                      ? 'bg-rose-500/20 text-rose-400 border border-rose-500/40'
                      : 'bg-[#FFCC00]/20 text-[#FFCC00] border border-[#FFCC00]/40'
                  }`}
                >
                  {userModalTab === 'active' ? (
                    <UserCheck className="w-5 h-5" />
                  ) : userModalTab === 'inactive' ? (
                    <UserX className="w-5 h-5" />
                  ) : (
                    <Users className="w-5 h-5" />
                  )}
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <span>
                      {userModalTab === 'active'
                        ? 'Active Users'
                        : userModalTab === 'inactive'
                        ? 'In-active Users'
                        : 'Total Users'}
                    </span>
                    <span
                      className={`text-[10px] px-2 py-0.5 rounded-full font-mono font-bold ${
                        userModalTab === 'active'
                          ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                          : userModalTab === 'inactive'
                          ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                          : 'bg-yellow-500/20 text-yellow-300 border border-yellow-500/30'
                      }`}
                    >
                      {displayedUsers.length} ဦး
                    </span>
                  </h3>
                  <p className="text-[10px] text-zinc-400">
                    {userModalTab === 'active'
                      ? '၇ ရက်အတွင်း ပုံမှန်အသုံးပြုနေသော အကောင့်များ'
                      : userModalTab === 'inactive'
                      ? 'ရက်ပေါင်း ၃၀+ မဝင်ရောက်သူ / ရပ်ဆိုင်းထားသော အကောင့်များ'
                      : 'စနစ်အတွင်းရှိ အသုံးပြုသူ အကောင့်များ အားလုံး'}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setActiveModal(null)}
                className="w-8 h-8 rounded-full flex items-center justify-center text-zinc-400 hover:text-white hover:bg-zinc-800 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-3 bg-black/40 border-b border-zinc-800/80 shrink-0 space-y-2.5">
              <div className="grid grid-cols-3 gap-1.5 p-1 bg-zinc-900/90 rounded-2xl border border-zinc-800">
                <button
                  type="button"
                  onClick={() => setUserModalTab('active')}
                  className={`py-2 px-1 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${
                    userModalTab === 'active'
                      ? 'bg-emerald-500 text-black shadow-md'
                      : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  <span className={`w-2 h-2 rounded-full ${userModalTab === 'active' ? 'bg-black' : 'bg-emerald-400'}`} />
                  <span>Active ({activeUsersList.length})</span>
                </button>

                <button
                  type="button"
                  onClick={() => setUserModalTab('inactive')}
                  className={`py-2 px-1 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${
                    userModalTab === 'inactive'
                      ? 'bg-rose-500 text-white shadow-md'
                      : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  <span className={`w-2 h-2 rounded-full ${userModalTab === 'inactive' ? 'bg-white' : 'bg-rose-400'}`} />
                  <span>In-active ({inactiveUsersList.length})</span>
                </button>

                <button
                  type="button"
                  onClick={() => setUserModalTab('all')}
                  className={`py-2 px-1 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer ${
                    userModalTab === 'all'
                      ? 'bg-[#FFCC00] text-black shadow-md'
                      : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  <Users className="w-3.5 h-3.5" />
                  <span>အားလုံး ({users.length})</span>
                </button>
              </div>

              <div className="relative">
                <Search className="w-4 h-4 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={userSearchQuery}
                  onChange={(e) => setUserSearchQuery(e.target.value)}
                  placeholder="နာမည်၊ ဖုန်းနံပါတ် သို့မဟုတ် UID ဖြင့် ရှာရန်..."
                  className="w-full pl-9 pr-8 py-2 rounded-xl bg-black border border-zinc-700 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-[#FFCC00]"
                />
                {userSearchQuery && (
                  <button
                    type="button"
                    onClick={() => setUserSearchQuery('')}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-white"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>

            <div className="flex-1 overflow-y-auto px-4 py-3 space-y-2.5 pretty-scrollbar">
              {displayedUsers.length === 0 ? (
                <div className="py-12 px-4 text-center">
                  <div className="w-12 h-12 rounded-2xl bg-zinc-900 border border-zinc-800 flex items-center justify-center mx-auto text-zinc-500 mb-3">
                    <Search className="w-6 h-6" />
                  </div>
                  <h4 className="text-sm font-bold text-zinc-300">ရှာဖွေမှု မတွေ့ရှိပါ</h4>
                  <p className="text-xs text-zinc-500 mt-1">
                    &quot;{userSearchQuery}&quot; နှင့် ကိုက်ညီသော {userModalTab === 'active' ? 'Active' : userModalTab === 'inactive' ? 'In-active' : ''} User မရှိပါ
                  </p>
                  <button
                    type="button"
                    onClick={() => setUserSearchQuery('')}
                    className="mt-3 px-3 py-1.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-xs text-zinc-300 font-semibold transition"
                  >
                    ရှာဖွေမှု ပြန်ဖျက်ပါ
                  </button>
                </div>
              ) : (
                displayedUsers.map((user) => {
                  const isActive = user.status === 'active';
                  return (
                    <div
                      key={user.id}
                      className={`p-3.5 rounded-2xl bg-black/70 border transition ${
                        isActive
                          ? 'border-emerald-500/30 hover:border-emerald-400/60'
                          : 'border-zinc-800 hover:border-zinc-700'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <div
                            className={`w-8 h-8 rounded-xl flex items-center justify-center font-bold text-xs ${
                              isActive
                                ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                                : 'bg-zinc-800 text-zinc-400 border border-zinc-700'
                            }`}
                          >
                            {user.name.charAt(0)}
                          </div>
                          <div>
                            <div className="text-xs font-bold text-white flex items-center gap-1.5">
                              <span>{user.name}</span>
                              <span
                                className={`w-1.5 h-1.5 rounded-full ${
                                  isActive ? 'bg-emerald-400 animate-pulse' : 'bg-rose-500'
                                }`}
                              />
                            </div>
                            <div className="flex items-center gap-1.5 mt-0.5">
                              <span className="text-[10px] font-mono text-zinc-400">{user.uid}</span>
                              <button
                                type="button"
                                onClick={() => handleCopyText(user.uid, `uid-${user.id}`)}
                                className="text-zinc-500 hover:text-[#FFCC00] transition"
                                title="Copy UID"
                              >
                                {copiedUid === `uid-${user.id}` ? (
                                  <Check className="w-3 h-3 text-emerald-400" />
                                ) : (
                                  <Copy className="w-3 h-3" />
                                )}
                              </button>
                            </div>
                          </div>
                        </div>

                        <div className="text-right">
                          <span
                            className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold ${
                              isActive
                                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                                : 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                            }`}
                          >
                            {isActive ? (
                              <>
                                <UserCheck className="w-2.5 h-2.5" />
                                <span>Active</span>
                              </>
                            ) : (
                              <>
                                <UserX className="w-2.5 h-2.5" />
                                <span>In-active</span>
                              </>
                            )}
                          </span>
                        </div>
                      </div>

                      <div className="mt-2.5 grid grid-cols-2 gap-2 pt-2 border-t border-zinc-800/60 text-xs">
                        <div className="flex items-center justify-between bg-zinc-900/60 p-2 rounded-xl border border-zinc-800/80">
                          <div className="flex items-center gap-1.5 text-zinc-400">
                            <Smartphone className="w-3 h-3 text-[#FFCC00]" />
                            <span className="text-[11px] font-mono text-zinc-300">{user.phone}</span>
                          </div>
                          <button
                            type="button"
                            onClick={() => handleCopyText(user.phone, `phone-${user.id}`)}
                            className="text-zinc-500 hover:text-[#FFCC00] transition p-0.5"
                            title="Copy Phone"
                          >
                            {copiedUid === `phone-${user.id}` ? (
                              <Check className="w-3 h-3 text-emerald-400" />
                            ) : (
                              <Copy className="w-3 h-3" />
                            )}
                          </button>
                        </div>

                        <div className="bg-zinc-900/60 p-2 rounded-xl border border-zinc-800/80 flex items-center justify-between">
                          <span className="text-[10px] text-zinc-400">လက်ကျန်ငွေ:</span>
                          <span className="text-[11px] font-bold font-mono text-[#FFCC00]">
                            {user.balance.toLocaleString()} Ks
                          </span>
                        </div>
                      </div>

                      <div className="mt-2 flex items-center justify-between text-[10px]">
                        <div className="flex items-center gap-1.5">
                          {isActive ? (
                            <span className="text-emerald-400/90 flex items-center gap-1">
                              <Activity className="w-3 h-3" />
                              <span>လောင်းကစားကြိမ်ရေ: {user.totalBets} ကြိမ်</span>
                            </span>
                          ) : (
                            <span className="text-rose-400/90 flex items-center gap-1">
                              <ShieldAlert className="w-3 h-3" />
                              <span>ရက်ပေါင်း ၃၀+ လှုပ်ရှားမှုမရှိပါ</span>
                            </span>
                          )}
                        </div>
                        <span className="text-zinc-500">
                          စာရင်းဖွင့်: {user.createdAt}
                        </span>
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            <div className="p-3.5 border-t border-zinc-800 bg-black/80 flex items-center justify-between shrink-0">
              <div className="text-[11px] text-zinc-400">
                <span>Active နှုန်း: </span>
                <span className="font-bold text-emerald-400">
                  {Math.round((activeUsersList.length / Math.max(1, users.length)) * 100)}%
                </span>
                <span className="text-zinc-500 ml-1">({activeUsersList.length}/{users.length})</span>
              </div>
              <button
                type="button"
                onClick={() => setActiveModal(null)}
                className="px-4 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-white font-bold text-xs transition cursor-pointer"
              >
                ပိတ်မည် (Close)
              </button>
            </div>
          </div>
        </div>
      )}

      {selectedReceiptBet && (
        <BetReceiptModal
          bet={selectedReceiptBet}
          onClose={() => setSelectedReceiptBet(null)}
        />
      )}
    </div>
  );
}
