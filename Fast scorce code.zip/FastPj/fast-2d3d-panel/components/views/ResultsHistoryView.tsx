'use client';

import React, { useCallback, useEffect, useState } from 'react';
import { ArrowLeft, Calendar, RefreshCw, Trophy } from 'lucide-react';
import { UserRole } from '@/lib/types';
import { getMyanmarDate } from '@/lib/date';

interface ResultsHistoryViewProps {
  onBack: () => void;
  role?: UserRole;
}

interface ResultRow {
  id: number;
  type: string;
  session: string;
  result_date: string;
  winning_number: string;
  created_at: string;
}

export function ResultsHistoryView({ onBack }: ResultsHistoryViewProps) {
  const [date, setDate] = useState<string>(getMyanmarDate());
  const [results, setResults] = useState<ResultRow[]>([]);
  const [loading, setLoading] = useState(false);

  const load = useCallback(async (targetDate: string) => {
    setLoading(true);
    try {
      const res = await fetch(`/api/results?date=${encodeURIComponent(targetDate)}`, { cache: 'no-store' });
      if (res.ok) {
        const json = await res.json();
        if (json.success && Array.isArray(json.data)) setResults(json.data as ResultRow[]);
        else setResults([]);
      }
    } catch {
      setResults([]);
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    const timer = setTimeout(() => {
      void load(date);
    }, 0);
    return () => clearTimeout(timer);
  }, [date, load]);

  const twoD = results.filter((r) => r.type === '2D');
  const threeD = results.filter((r) => r.type === '3D');

  const changeDate = (delta: number) => {
    const d = new Date(`${date}T00:00:00`);
    d.setDate(d.getDate() + delta);
    setDate(getMyanmarDate(d));
  };

  return (
    <div className="flex flex-col min-h-screen bg-[#101012] text-white pb-32">
      <div className="sticky top-0 z-30 flex items-center justify-between px-4 py-3 bg-[#101012]/95 backdrop-blur-md border-b border-zinc-900">
        <button
          onClick={onBack}
          className="w-10 h-10 rounded-full flex items-center justify-center text-[#FFCC00] hover:bg-zinc-800 transition active:scale-95"
          aria-label="Back"
        >
          <ArrowLeft className="w-7 h-7 stroke-[2.5]" />
        </button>
        <div className="text-center">
          <h1 className="text-xl font-bold tracking-wide text-[#FFCC00]">ရလဒ် မှတ်တမ်း</h1>
          <p className="text-[10px] text-zinc-400">Results by Date</p>
        </div>
        <button
          onClick={() => load(date)}
          className="w-10 h-10 rounded-full flex items-center justify-center text-[#FFCC00] hover:bg-zinc-800 transition active:scale-95"
          aria-label="Refresh"
        >
          <RefreshCw className={`w-5 h-5 ${loading ? 'animate-spin' : ''}`} />
        </button>
      </div>

      <div className="px-4 pt-4 max-w-sm mx-auto w-full space-y-4">
        <div className="p-3 rounded-2xl bg-black border border-[#FFCC00]/40 flex items-center justify-between gap-2">
          <button
            type="button"
            onClick={() => changeDate(-1)}
            className="px-3 py-2 rounded-xl bg-zinc-900 border border-zinc-700 text-xs font-bold text-zinc-300 hover:border-[#FFCC00]"
          >
            ‹ ယမန်နေ့
          </button>
          <div className="flex items-center gap-1.5 text-[#FFCC00] font-mono font-bold text-sm">
            <Calendar className="w-4 h-4" />
            <input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value || getMyanmarDate())}
              className="bg-transparent text-[#FFCC00] font-mono font-bold text-sm focus:outline-none"
            />
          </div>
          <button
            type="button"
            onClick={() => changeDate(1)}
            className="px-3 py-2 rounded-xl bg-zinc-900 border border-zinc-700 text-xs font-bold text-zinc-300 hover:border-[#FFCC00]"
          >
            နောက်နေ့ ›
          </button>
        </div>

        <div className="p-4 rounded-3xl bg-black border border-zinc-800 space-y-3">
          <div className="flex items-center gap-1.5 text-xs font-bold text-[#FFCC00]">
            <Trophy className="w-4 h-4" /> 2D ရလဒ် ({date})
          </div>
          {twoD.length === 0 ? (
            <div className="text-[11px] text-zinc-500 py-2">ဒီနေ့အတွက် 2D ရလဒ် မရှိပါ</div>
          ) : (
            <div className="space-y-2">
              {twoD.map((r) => (
                <div
                  key={r.id}
                  className="flex items-center justify-between p-2.5 rounded-2xl bg-zinc-950 border border-zinc-800"
                >
                  <span className="text-[11px] text-zinc-400 font-mono">{r.session}</span>
                  <span className="px-3 py-1 rounded-xl bg-black border border-[#FFCC00] text-[#FFCC00] font-mono font-black">
                    {r.winning_number}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="p-4 rounded-3xl bg-black border border-zinc-800 space-y-3">
          <div className="flex items-center gap-1.5 text-xs font-bold text-[#FFCC00]">
            <Trophy className="w-4 h-4" /> 3D ရလဒ် ({date})
          </div>
          {threeD.length === 0 ? (
            <div className="text-[11px] text-zinc-500 py-2">ဒီနေ့အတွက် 3D ရလဒ် မရှိပါ</div>
          ) : (
            <div className="space-y-2">
              {threeD.map((r) => (
                <div
                  key={r.id}
                  className="flex items-center justify-between p-2.5 rounded-2xl bg-zinc-950 border border-zinc-800"
                >
                  <span className="text-[11px] text-zinc-400 font-mono">{r.session}</span>
                  <span className="px-3 py-1 rounded-xl bg-black border border-[#FFCC00] text-[#FFCC00] font-mono font-black">
                    {r.winning_number}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
