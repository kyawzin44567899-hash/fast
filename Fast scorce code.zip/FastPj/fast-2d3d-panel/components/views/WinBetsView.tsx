'use client';

import React, { useEffect, useState } from 'react';
import { ArrowLeft, Trophy, RefreshCw, Award, Hash, Clock, User } from 'lucide-react';
import { BetRecord, UserRole, AppAgent } from '@/lib/types';

interface WinBetsViewProps {
  onBack: () => void;
  role?: UserRole;
  currentAgent?: AppAgent | null;
}

export function WinBetsView({ onBack, role = 'admin', currentAgent }: WinBetsViewProps) {
  const [bets, setBets] = useState<BetRecord[]>([]);
  const [loading, setLoading] = useState(false);
  const [lastSync, setLastSync] = useState('');

  const load = async (showLoading = false) => {
    if (showLoading) setLoading(true);
    try {
      const res = await fetch('/api/bets?status=win', { cache: 'no-store' });
      if (res.ok) {
        const json = await res.json();
        if (Array.isArray(json.data)) setBets(json.data as BetRecord[]);
        setLastSync(new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
      }
    } catch {}
    if (showLoading) setLoading(false);
  };

  useEffect(() => {
    const initial = setTimeout(() => {
      void load();
    }, 0);
    const interval = setInterval(() => {
      if (typeof document !== 'undefined' && document.hidden) return;
      void load();
    }, 30000);
    return () => {
      clearTimeout(initial);
      clearInterval(interval);
    };
  }, []);

  const agentCode = currentAgent?.code || '';
  const scoped = role === 'agent' ? bets.filter((b) => b.agentCode === agentCode) : bets;
  const totalWin = scoped.reduce((s, b) => s + (b.winAmount || 0), 0);
  const totalBet = scoped.reduce((s, b) => s + b.totalAmount, 0);

  const wonNumbers = (b: BetRecord): string => {
    const set = new Set<string>();
    for (const it of b.items || []) {
      if (it.subNumbers && it.subNumbers.length > 0) {
        for (const s of it.subNumbers) {
          if (s.number === b.winningNumber) set.add(s.number);
        }
      } else if (it.number === b.winningNumber) {
        set.add(it.number);
      }
    }
    return Array.from(set).join(', ') || b.winningNumber || '-';
  };

  return (
    <div className="flex flex-col min-h-screen bg-[#101012] text-white selection:bg-amber-400 selection:text-black">
      <div className="sticky top-0 z-30 flex items-center justify-between px-4 py-3 bg-[#101012]/95 backdrop-blur-md border-b border-zinc-900">
        <button
          onClick={onBack}
          className="w-10 h-10 rounded-full flex items-center justify-center text-[#FFCC00] hover:bg-zinc-800 transition active:scale-95"
          aria-label="Back"
        >
          <ArrowLeft className="w-7 h-7 stroke-[2.5]" />
        </button>

        <div className="text-center">
          <h1 className="text-xl font-bold tracking-wide text-[#FFCC00] flex items-center gap-2 justify-center">
            <Trophy className="w-5 h-5" /> Win Bets
          </h1>
          <p className="text-[10px] text-zinc-400 font-medium">
            ပေါက်ကြေးရရှိသော ထိုးစာရင်းများ ({scoped.length} ခု)
          </p>
        </div>

        <button
          onClick={() => load(true)}
          className="w-10 h-10 rounded-full flex items-center justify-center text-[#FFCC00] hover:bg-zinc-800 transition active:scale-95"
          aria-label="Refresh"
        >
          <RefreshCw className={`w-5 h-5 ${loading ? 'animate-spin' : ''}`} />
        </button>
      </div>

      <div className="px-4 pt-4 max-w-md mx-auto w-full space-y-3">
        <div className="grid grid-cols-2 gap-3">
          <div className="p-3 rounded-3xl bg-black border border-zinc-800">
            <div className="text-[11px] text-zinc-400">စုစုပေါင်း ထိုးငွေ</div>
            <div className="text-[#FFCC00] font-black text-lg font-mono mt-0.5">
              {totalBet.toLocaleString()}
            </div>
          </div>
          <div className="p-3 rounded-3xl bg-black border border-emerald-800/60">
            <div className="text-[11px] text-emerald-400">စုစုပေါင်း ဆုငွေ</div>
            <div className="text-emerald-400 font-black text-lg font-mono mt-0.5">
              {totalWin.toLocaleString()}
            </div>
          </div>
        </div>

        {lastSync && (
          <div className="text-[10px] text-zinc-500 text-right">Updated: {lastSync}</div>
        )}
      </div>

      <div className="flex-1 px-4 pt-3 pb-32 space-y-3 max-w-md mx-auto w-full">
        {loading && scoped.length === 0 ? (
          <div className="py-16 text-center text-zinc-500 text-xs">ရယူနေပါသည်...</div>
        ) : scoped.length === 0 ? (
          <div className="py-16 text-center text-zinc-500 text-xs">ပေါက်ကြေးစာရင်း မရှိသေးပါ</div>
        ) : (
          scoped.map((bet) => (
            <div
              key={bet.id}
              className="p-4 rounded-3xl bg-black border border-emerald-700/60 shadow-md space-y-3"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-black text-[#FFCC00] font-mono">{bet.voucherNo}</span>
                  <span
                    className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase ${
                      bet.category === '2D'
                        ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                        : 'bg-purple-500/20 text-purple-300 border border-purple-500/40'
                    }`}
                  >
                    {bet.category}
                  </span>
                </div>
                <span className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/30">
                  <Award className="w-3 h-3" /> {bet.isTood ? 'TOOD WON ×10' : 'WON'}
                </span>
              </div>

              <div className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-1.5 text-zinc-300">
                  <User className="w-3.5 h-3.5 text-[#FFCC00]" />
                  <span className="font-semibold text-white">{bet.userName}</span>
                  <span className="text-[10px] font-mono text-zinc-500">(ID: {bet.userUid})</span>
                </div>
                <div className="flex items-center gap-1 text-zinc-400 text-[11px]">
                  <Clock className="w-3 h-3 text-[#FFCC00]" />
                  <span>{bet.timeSlot}</span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="p-2 rounded-2xl bg-zinc-950 border border-zinc-800">
                  <div className="text-[10px] text-zinc-400">User Bet Amount</div>
                  <div className="text-white font-bold font-mono mt-0.5">
                    {bet.totalAmount.toLocaleString()} Ks
                  </div>
                </div>
                <div className="p-2 rounded-2xl bg-zinc-950 border border-emerald-800/50">
                  <div className="text-[10px] text-emerald-400">Win Amount</div>
                  <div className="text-emerald-400 font-bold font-mono mt-0.5">
                    {(bet.winAmount || 0).toLocaleString()} Ks
                  </div>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2 text-[11px]">
                <span className="inline-flex items-center gap-1 px-2 py-1 rounded-xl bg-zinc-950 border border-zinc-800 text-zinc-300">
                  <Hash className="w-3 h-3 text-[#FFCC00]" />
                  Bet Type: <strong className="text-[#FFCC00]">{bet.category}</strong>
                </span>
                <span className="inline-flex items-center gap-1 px-2 py-1 rounded-xl bg-zinc-950 border border-zinc-800 text-zinc-300">
                  Winning No: <strong className="text-emerald-400 font-mono">{bet.winningNumber || '-'}</strong>
                </span>
                <span className="inline-flex items-center gap-1 px-2 py-1 rounded-xl bg-zinc-950 border border-zinc-800 text-zinc-300">
                  Total Numbers: <strong className="text-white">{bet.totalNumbers}</strong>
                </span>
              </div>

              <div className="p-2.5 rounded-2xl bg-emerald-950/30 border border-emerald-800/40">
                <div className="text-[10px] text-emerald-400 font-bold mb-0.5">
                  ပေါက်သည့် ဂဏန်း (Won Number)
                </div>
                <div className="text-sm font-black text-emerald-300 font-mono break-words">
                  {wonNumbers(bet)}
                </div>
                {bet.winDetails && (
                  <div className="text-[10px] text-zinc-400 mt-1 break-words">{bet.winDetails}</div>
                )}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
