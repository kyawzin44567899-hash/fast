'use client';

import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  ArrowLeft,
  Check,
  RefreshCw,
  Trophy,
  Sparkles,
  Calendar,
  AlertCircle,
  Radio,
  CheckCircle2,
} from 'lucide-react';
import { WinningSlot, Thai2DLiveResponse, Thai3DResponse, UserRole } from '@/lib/types';
import {
  fetchThai2DLive,
  fetchThai3DResults,
} from '@/lib/thaiLotteryService';

interface WinningNumbersViewProps {
  slots: WinningSlot[];
  onBack: () => void;
  onUpdateSlot?: (slotId: string, newNumber: string) => void;
  role?: UserRole;
}

function findSlotBySession(slots: WinningSlot[], open1201: boolean): WinningSlot | undefined {
  return slots.find((s) =>
    open1201
      ? s.timeSlot === '12:01 PM' || s.id === 'slot-1201' || s.id === 'slot-2'
      : s.timeSlot === '04:30 PM' || s.id === 'slot-1630' || s.id === 'slot-4'
  );
}

function getMyanmarToday(): string {
  return new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Yangon' }).format(new Date());
}

function isTodayDate(dateStr?: string | null): boolean {
  if (!dateStr) return false;
  return String(dateStr).slice(0, 10) === getMyanmarToday();
}

export function WinningNumbersView({
  slots,
  onBack,
  onUpdateSlot,
  role = 'admin',
}: WinningNumbersViewProps) {
  const [toastMessage, setToastMessage] = useState('');
  const [isSyncing, setIsSyncing] = useState(false);
  const [liveInfo, setLiveInfo] = useState<Thai2DLiveResponse | null>(null);
  const [threeDData, setThreeDData] = useState<Thai3DResponse | null>(null);
  const [viewCategory, setViewCategory] = useState<'2d' | '3d'>('2d');
  const [lastSyncTime, setLastSyncTime] = useState<string>('');
  const [toodSummary, setToodSummary] = useState<{
    result: string;
    isTood: boolean;
    multiplier: number | null;
    winners: number;
    totalPayout: number;
  } | null>(null);

  const slotsRef = useRef(slots);
  const onUpdateSlotRef = useRef(onUpdateSlot);

  useEffect(() => {
    slotsRef.current = slots;
  }, [slots]);

  useEffect(() => {
    onUpdateSlotRef.current = onUpdateSlot;
  }, [onUpdateSlot]);

  const processLiveResultData = useCallback((data: Thai2DLiveResponse | null) => {
    if (!data || !data.result || !Array.isArray(data.result)) return 0;
    setLiveInfo(data);

    const liveDate = data.live?.date;
    let updatedCount = 0;
    data.result.forEach((item) => {
      if (!isTodayDate(item.stock_date || liveDate)) return;
      if (!item.twod || item.twod === '--') return;
      const isOpen1201 = item.open_time?.startsWith('12:01');
      const isOpen1630 = item.open_time?.startsWith('16:30') || item.open_time?.startsWith('04:30');

      if (isOpen1201 || isOpen1630) {
        const matchedSlot = findSlotBySession(slotsRef.current, isOpen1201);
        const update = onUpdateSlotRef.current;
        if (matchedSlot && update && matchedSlot.luckyNumber !== item.twod) {
          update(matchedSlot.id, item.twod);
          updatedCount++;
        }
      }
    });

    return updatedCount;
  }, []);

  const handleSyncRealThaiStock = async (showNotification = true) => {
    setIsSyncing(true);
    try {
      const [liveData, threeD] = await Promise.all([
        fetchThai2DLive(),
        fetchThai3DResults(),
      ]);

      if (threeD) setThreeDData(threeD);

      if (liveData) {
        processLiveResultData(liveData);
      }

      const now = new Date();
      setLastSyncTime(now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' }));

      if (showNotification) {
        setToastMessage('ယနေ့ 12:01 PM နှင့် 4:30 PM ပေါက်ဂဏန်းများကို ရယူပြီးပါပြီ');
      }
    } catch (err) {
      console.error(err);
      if (showNotification) {
        setToastMessage('API ရယူရာတွင် ချို့ယွင်းချက် ဖြစ်ပေါ်ခဲ့ပါသည်');
      }
    } finally {
      setIsSyncing(false);
      if (showNotification) {
        setTimeout(() => setToastMessage(''), 3500);
      }
    }
  };

  useEffect(() => {
    let isMounted = true;

    const performSync = async () => {
      try {
        const [liveData, threeD] = await Promise.all([
          fetchThai2DLive(),
          fetchThai3DResults(),
        ]);

        if (!isMounted) return;
        if (threeD) setThreeDData(threeD);

        if (liveData) {
          processLiveResultData(liveData);
        }

        const now = new Date();
        setLastSyncTime(now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
      } catch (err) {
        console.error(err);
      }
    };

    performSync();
    const interval = setInterval(performSync, 5000);
    return () => {
      isMounted = false;
      clearInterval(interval);
    };
  }, [processLiveResultData]);

  useEffect(() => {
    const latest = threeDData?.data?.[0]?.result;
    if (!latest) return;
    let active = true;
    fetch(`/api/results/tood-summary?result=${encodeURIComponent(latest)}`, { cache: 'no-store' })
      .then((r) => (r.ok ? r.json() : null))
      .then((j) => {
        if (active && j?.success) setToodSummary(j.data);
      })
      .catch(() => {});
    return () => {
      active = false;
    };
  }, [threeDData]);

  return (
    <div className="flex flex-col min-h-screen bg-[#101012] text-white selection:bg-amber-400 selection:text-black">
      <div className="sticky top-0 z-30 flex items-center justify-between px-4 py-3 bg-[#101012]/95 backdrop-blur-md border-b border-zinc-900">
        <button
          onClick={onBack}
          className="w-10 h-10 rounded-full flex items-center justify-center text-[#FFCC00] hover:bg-zinc-800 transition active:scale-95"
          aria-label="Back"
        >
          <ArrowLeft className="w-7 h-7 stroke-[2.5]" />
        </button>

        <h1 className="text-xl font-bold tracking-wide text-[#FFCC00]">
          ယနေ့ပေါက်ဂဏန်း
        </h1>

        <button
          onClick={() => handleSyncRealThaiStock(true)}
          disabled={isSyncing}
          className="p-2 text-[#FFCC00] hover:text-amber-300 transition active:scale-90"
          title="Sync with Thai Stock 2D API"
        >
          <RefreshCw className={`w-5 h-5 ${isSyncing ? 'animate-spin' : ''}`} />
        </button>
      </div>

      {toastMessage && (
        <div className="mx-4 mt-3 p-2.5 rounded-xl bg-emerald-950/80 border border-emerald-500/50 text-emerald-300 text-xs text-center flex items-center justify-center gap-1.5 animate-in fade-in">
          <Check className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      <div className="px-4 pt-4 pb-1 max-w-sm mx-auto w-full">
        <div className="flex p-1 bg-black rounded-2xl border border-zinc-800">
          <button
            onClick={() => setViewCategory('2d')}
            className={`flex-1 py-2 rounded-xl text-xs font-bold transition cursor-pointer ${
              viewCategory === '2d'
                ? 'bg-[#FFCC00] text-black shadow'
                : 'text-zinc-400 hover:text-white'
            }`}
          >
            ထိုင်း 2D ပေါက်ဂဏန်း (12:01 / 4:30)
          </button>
          <button
            onClick={() => setViewCategory('3d')}
            className={`flex-1 py-2 rounded-xl text-xs font-bold transition cursor-pointer ${
              viewCategory === '3d'
                ? 'bg-[#FFCC00] text-black shadow'
                : 'text-zinc-400 hover:text-white'
            }`}
          >
            ထိုင်း 3D ပေါက်ဂဏန်း
          </button>
        </div>
      </div>

      <div className="flex-1 px-4 pt-3 pb-32 max-w-sm mx-auto w-full space-y-4">
        {viewCategory === '2d' ? (
          <>
            <div className="p-3.5 rounded-3xl bg-black border border-[#FFCC00]/60 flex items-center justify-between shadow-sm">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-[#FFCC00]/15 border border-[#FFCC00]/40 flex items-center justify-center text-[#FFCC00]">
                  <Radio className="w-4 h-4 animate-pulse" />
                </div>
                <div>
                  <div className="text-xs font-bold text-[#FFCC00] flex items-center gap-1.5">
                    <span>2D Result API Auto-Sync</span>
                    <span className="text-[9px] bg-emerald-500/20 text-emerald-400 px-1.5 py-0.2 rounded-full border border-emerald-500/40 uppercase">Live</span>
                  </div>
                  <div className="text-[10px] text-zinc-400">
                    12:01 PM & 4:30 PM သာ တိုက်ရိုက် ရယူသည်
                  </div>
                </div>
              </div>

              <button
                onClick={() => handleSyncRealThaiStock(true)}
                disabled={isSyncing}
                className="px-3 py-1.5 rounded-xl bg-[#FFCC00] text-black font-bold text-xs hover:bg-amber-300 active:scale-95 transition flex items-center gap-1 cursor-pointer"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
                <span>Sync</span>
              </button>
            </div>

            <div className="space-y-3.5">
              {slots.map((slot) => {

                const is1201 = slot.timeSlot === '12:01 PM' || slot.id === 'slot-1201' || slot.id === 'slot-2';
                const is1630 = slot.timeSlot === '04:30 PM' || slot.id === 'slot-1630' || slot.id === 'slot-4';

                const match = liveInfo?.result?.find((r) => {
                  if (!isTodayDate(r.stock_date || liveInfo?.live?.date)) return false;
                  if (is1201 && r.open_time?.startsWith('12:01')) return true;
                  if (is1630 && (r.open_time?.startsWith('16:30') || r.open_time?.startsWith('04:30'))) return true;
                  return false;
                });

                const displayNum = match?.twod && match.twod !== '--' ? match.twod : '--';

                const hasResult = displayNum !== '--';

                return (
                  <div
                    key={slot.id}
                    className="w-full p-5 rounded-3xl bg-black border-2 border-[#FFCC00] shadow-[0_4px_20px_rgba(0,0,0,0.5)] transition text-left relative overflow-hidden"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex flex-col">
                        <div className="flex items-center gap-2">
                          <span className="text-[#FFCC00] font-black text-2xl sm:text-3xl tracking-tight font-mono">
                            {slot.timeSlot}
                          </span>
                          <span className="px-2 py-0.5 rounded-full bg-[#FFCC00]/15 border border-[#FFCC00]/40 text-[#FFCC00] text-[10px] font-bold uppercase">
                            {is1201 ? 'Morning (မနက်)' : 'Evening (ညနေ)'}
                          </span>
                        </div>

                        <span className="text-zinc-400 font-medium text-xs tracking-wide mt-1">
                          {slot.dateTime}
                        </span>

                        {match && match.set && (
                          <div className="flex items-center gap-2 mt-1.5 text-[11px] font-mono text-amber-300/90">
                            <span>SET: {match.set}</span>
                            <span>•</span>
                            <span>VAL: {match.value}</span>
                          </div>
                        )}
                      </div>

                      <div className="flex flex-col items-end">
                        <div className="w-16 h-16 rounded-2xl bg-gradient-to-b from-[#FFCC00] to-amber-500 text-black font-black text-3xl sm:text-4xl flex items-center justify-center font-mono shadow-lg border-2 border-yellow-200">
                          {displayNum}
                        </div>
                        <span className="text-[10px] text-zinc-400 mt-1 flex items-center gap-1 font-mono">
                          {hasResult ? (
                            <>
                              <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                              <span className="text-emerald-400 font-semibold">Official API</span>
                            </>
                          ) : (
                            <span className="text-zinc-500">စောင့်ဆိုင်းဆဲ...</span>
                          )}
                        </span>
                      </div>
                    </div>

                    <div className="mt-3 pt-2.5 border-t border-zinc-850 flex items-center justify-between text-[11px]">
                      <span className="text-zinc-400 flex items-center gap-1">
                        <Sparkles className="w-3 h-3 text-[#FFCC00]" />
                        <span>ပေါက်ဂဏန်း အရင်းအမြစ်:</span>
                      </span>
                      <span className="text-[#FFCC00] font-mono font-bold">
                        Thai Stock 2D Result API ({is1201 ? '12:01 PM' : '4:30 PM'})
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="mt-4 p-4 rounded-3xl bg-zinc-950 border border-zinc-850 text-xs text-zinc-400 space-y-1.5">
              <div className="flex items-center justify-between text-[#FFCC00] font-bold">
                <span className="flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5" /> Thai Stock 2D Official Result
                </span>
                <span className="text-[10px] text-zinc-500 font-mono">
                  {lastSyncTime ? `Last Sync: ${lastSyncTime}` : 'Auto-Sync Active'}
                </span>
              </div>
              <p className="text-[11px] text-zinc-400 leading-relaxed">
                ၁၂:၀၁ နာရီ နှင့် ၄:၃၀ နာရီ ထိုင်း 2D ပေါက်ဂဏန်းများကို တရားဝင် Thai Stock API မှ အလိုအလျောက် တိုက်ရိုက်ရယူပြသထားပါသည်။ Manual လက်ဖြင့် ရိုက်ထည့်ပြင်ဆင်ခြင်းကို ခွင့်မပြုဘဲ API ထွက်ဂဏန်း အတိုင်းသာ တိကျစွာ ထုတ်ပြန်ပါသည်။
              </p>
            </div>
          </>
        ) : (

          <div className="space-y-4 animate-in fade-in">
            <div className="p-5 rounded-3xl bg-black border border-[#FFCC00] shadow-[0_0_20px_rgba(255,204,0,0.2)] text-center">
              <div className="flex items-center justify-center gap-1.5 text-xs font-bold text-[#FFCC00] mb-2">
                <Trophy className="w-4 h-4" />
                <span>ထိုင်း 3D တရားဝင် ထွက်ဂဏန်းများ (Thai 3D Lottery)</span>
              </div>
              <p className="text-[11px] text-zinc-400 mb-3">
                လစဉ် ၁ ရက် နှင့် ၁၆ ရက်နေ့ ထွက်ဂဏန်းများကို တရားဝင် 2dboss API မှ ရယူထားပါသည်
              </p>

              {threeDData?.data && threeDData.data.length > 0 && (
                <div className="py-2">
                  <div className="text-[11px] text-zinc-400">နောက်ဆုံးထွက်ရှိသော 3D ဂဏန်း</div>
                  <div className="flex items-center justify-center gap-2.5 my-3">
                    {threeDData.data[0].result.split('').map((ch, idx) => (
                      <div
                        key={idx}
                        className="w-14 h-14 rounded-2xl bg-gradient-to-b from-[#FFCC00] to-amber-600 text-black font-black text-2xl flex items-center justify-center font-mono shadow-md border-2 border-yellow-200"
                      >
                        {ch}
                      </div>
                    ))}
                  </div>
                  <span className="text-xs text-[#FFCC00] font-mono">
                    ရက်စွဲ: {threeDData.data[0].datetime}
                  </span>

                  {toodSummary?.isTood && toodSummary.result === threeDData.data[0].result && (
                    <div className="mt-3 p-2.5 rounded-2xl bg-emerald-950/50 border border-emerald-500/50 text-center">
                      <div className="text-xs font-black text-emerald-300">
                        Type: TOOD &nbsp;|&nbsp; Multiplier: ×{toodSummary.multiplier}
                      </div>
                      <div className="text-[11px] text-emerald-200 mt-1">
                        TOOD Winners: {toodSummary.winners} &nbsp;|&nbsp; Total Tood Payout:{' '}
                        {toodSummary.totalPayout.toLocaleString()}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>

            <div className="p-4 rounded-3xl bg-black border border-zinc-800 space-y-2.5">
              <span className="text-xs font-bold text-[#FFCC00] block mb-2">
                ယခင် 3D ပေါက်ဂဏန်း မှတ်တမ်းများ
              </span>

              {!threeDData?.data || threeDData.data.length === 0 ? (
                <div className="p-6 text-center text-zinc-500 text-xs">
                  3D ဒေတာ ရယူနေပါသည်...
                </div>
              ) : (
                threeDData.data.map((item, idx) => (
                  <div
                    key={item.datetime + idx}
                    className="flex items-center justify-between p-3 rounded-2xl bg-zinc-950 border border-zinc-850"
                  >
                    <div className="flex items-center gap-2">
                      <Calendar className="w-3.5 h-3.5 text-[#FFCC00]" />
                      <span className="text-xs font-bold text-white font-mono">{item.datetime}</span>
                    </div>
                    <div className="px-3 py-1 rounded-xl bg-black border border-[#FFCC00] text-[#FFCC00] font-mono font-black text-lg">
                      {item.result}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
