'use client';

import React, { useState, useEffect } from 'react';
import { User, Shield, KeyRound, Bell, Globe, LogOut, Check, Lock, ShieldCheck, Smartphone } from 'lucide-react';
import { UserRole } from '@/lib/types';

interface ProfileViewProps {
  role: UserRole;
  onSwitchRole?: (targetRole: UserRole) => void;
  onLogout: () => void;
  userName?: string;
  userEmail?: string;
  userCode?: string;
  soundEnabled?: boolean;
  onToggleSound?: (enabled: boolean) => void;
}

export function ProfileView({
  role,
  onLogout,
  userName,
  userEmail,
  userCode,
  soundEnabled = true,
  onToggleSound,
}: ProfileViewProps) {
  const [showKeyModal, setShowKeyModal] = useState(false);
  const [currentKey, setCurrentKey] = useState('');
  const [newKey, setNewKey] = useState('');
  const [keyError, setKeyError] = useState('');
  const [keySuccess, setKeySuccess] = useState('');
  const [keyLoading, setKeyLoading] = useState(false);

  interface LoginRecord {
    id: number;
    device: string | null;
    ip: string | null;
    created_at: string;
  }
  const [loginHistory, setLoginHistory] = useState<LoginRecord[]>([]);
  const [historyLoading, setHistoryLoading] = useState(false);
  const [showHistory, setShowHistory] = useState(false);

  useEffect(() => {
    const timer = setTimeout(async () => {
      setHistoryLoading(true);
      try {
        const res = await fetch('/api/auth/login-history', { cache: 'no-store' });
        if (res.ok) {
          const json = await res.json();
          if (json.success && Array.isArray(json.data)) setLoginHistory(json.data);
        }
      } catch {}
      setHistoryLoading(false);
    }, 0);
    return () => clearTimeout(timer);
  }, []);

  const handleUpdateKey = async (e: React.FormEvent) => {
    e.preventDefault();
    if (role !== 'admin') return;
    if (!currentKey.trim() || !newKey.trim()) {
      setKeyError('Current and new secret key are required');
      return;
    }
    setKeyError('');
    setKeyLoading(true);
    try {
      const res = await fetch('/api/auth/change-secret', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ currentSecret: currentKey, newSecret: newKey }),
      });
      const data = await res.json();
      if (!res.ok || !data.success) {
        setKeyError(data.error || 'Failed to update secret key');
        return;
      }
      setKeySuccess('Secret Key updated successfully (လျှို့ဝှက်ကုဒ် အောင်မြင်စွာ ပြောင်းပြီးပါပြီ)');
      setCurrentKey('');
      setNewKey('');
      setTimeout(() => {
        setKeySuccess('');
        setShowKeyModal(false);
      }, 2000);
    } catch {
      setKeyError('Unable to reach the server');
    } finally {
      setKeyLoading(false);
    }
  };

  const displayName = userName || (role === 'admin' ? 'Administrator' : 'Agent');
  const displayEmail = userEmail || '';
  const displayId = role === 'admin' ? displayEmail || 'Administrator' : `Agent Code: ${userCode || '—'}`;

  return (
    <div className="flex flex-col min-h-screen bg-[#101012] text-white pb-32 selection:bg-amber-400 selection:text-black">
      <div className="sticky top-0 z-30 flex items-center justify-between px-5 py-4 bg-[#101012]/95 backdrop-blur-md border-b border-zinc-900">
        <h1 className="text-xl font-bold tracking-wide text-[#FFCC00]">
          ကျွန်ုပ် (Profile)
        </h1>
        <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#FFCC00]/20 border border-[#FFCC00]/40 text-[#FFCC00] text-xs font-bold uppercase">
          <Shield className="w-3.5 h-3.5" />
          <span>{role === 'admin' ? 'Master Admin' : 'Agent Profile'}</span>
        </div>
      </div>

      <div className="flex-1 px-4 py-4 max-w-sm mx-auto w-full space-y-4">
        <div className="p-5 rounded-3xl bg-black border border-[#FFCC00] text-center shadow-lg relative overflow-hidden">
          <div className="w-20 h-20 rounded-full bg-[#FFCC00] text-black flex items-center justify-center mx-auto mb-3 shadow-[0_0_20px_rgba(255,204,0,0.3)]">
            <User className="w-11 h-11 text-black fill-black" />
          </div>

          <h2 className="text-white font-extrabold text-lg">{displayName}</h2>

          <p className="text-[#FFCC00] text-xs font-mono font-bold mt-0.5">{displayId}</p>

          {role === 'agent' && displayEmail && (
            <p className="text-zinc-400 text-xs mt-1">{displayEmail}</p>
          )}

          {role === 'agent' && (
            <div className="mt-3 py-1.5 px-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-300 text-[11px] font-medium inline-flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-[#FFCC00]" />
              <span>Registered Authorized Agent (အတည်ပြုထားသော အေးဂျင့်)</span>
            </div>
          )}
        </div>

        <div className="p-2 rounded-3xl bg-black border border-zinc-900 divide-y divide-zinc-900 text-xs">
          {role === 'admin' ? (
            <button
              onClick={() => setShowKeyModal(true)}
              className="w-full flex items-center justify-between p-3.5 hover:bg-zinc-900 rounded-2xl transition cursor-pointer"
            >
              <div className="flex items-center gap-3">
                <KeyRound className="w-4 h-4 text-[#FFCC00]" />
                <span className="text-white font-medium">Change Secret Key (လျှို့ဝှက်ကုဒ် ပြောင်းမည်)</span>
              </div>
              <span className="text-zinc-500 font-mono">••••••••</span>
            </button>
          ) : (
            <div className="flex items-center justify-between p-3.5 opacity-60">
              <div className="flex items-center gap-3">
                <Lock className="w-4 h-4 text-zinc-500" />
                <span className="text-zinc-400 font-medium">Secret Key (Admin Only)</span>
              </div>
              <span className="text-[10px] text-amber-400/80 font-medium">(Locked)</span>
            </div>
          )}

          <div className="flex items-center justify-between p-3.5">
            <div className="flex items-center gap-3">
              <Bell className="w-4 h-4 text-[#FFCC00]" />
              <span className="text-white font-medium">Transaction Sounds & Alerts</span>
            </div>
            <button
              onClick={() => onToggleSound && onToggleSound(!soundEnabled)}
              className={`w-11 h-6 rounded-full transition-colors relative ${
                soundEnabled ? 'bg-[#FFCC00]' : 'bg-zinc-800'
              }`}
            >
              <span
                className={`absolute top-1 left-1 w-4 h-4 rounded-full bg-black transition-transform ${
                  soundEnabled ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          <div className="flex items-center justify-between p-3.5">
            <div className="flex items-center gap-3">
              <Globe className="w-4 h-4 text-[#FFCC00]" />
              <span className="text-white font-medium">System Language (ဘာသာစကား)</span>
            </div>
            <span className="text-[#FFCC00] font-bold">မြန်မာ (Unicode)</span>
          </div>
        </div>

        <div className="p-3 rounded-3xl bg-black border border-zinc-900">
          <button
            type="button"
            onClick={() => setShowHistory((v) => !v)}
            className="w-full flex items-center justify-between text-xs"
          >
            <div className="flex items-center gap-3">
              <Smartphone className="w-4 h-4 text-[#FFCC00]" />
              <span className="text-white font-medium">Device &amp; Login History</span>
            </div>
            <span className="text-[#FFCC00] font-bold">{showHistory ? 'Hide' : 'Show'}</span>
          </button>

          {showHistory && (
            <div className="mt-3 space-y-2">
              {historyLoading ? (
                <div className="text-center text-[11px] text-zinc-500 py-3">ရယူနေပါသည်...</div>
              ) : loginHistory.length === 0 ? (
                <div className="text-center text-[11px] text-zinc-500 py-3">Login History မရှိသေးပါ</div>
              ) : (
                loginHistory.map((rec) => (
                  <div
                    key={rec.id}
                    className="p-2.5 rounded-xl bg-zinc-950 border border-zinc-800 space-y-0.5"
                  >
                    <div className="text-[11px] text-white font-semibold">
                      {rec.device || 'Unknown device'}
                    </div>
                    <div className="text-[10px] text-zinc-400 font-mono">
                      IP: {rec.ip || 'unknown'}
                    </div>
                    <div className="text-[10px] text-zinc-500">
                      {rec.created_at ? new Date(rec.created_at).toLocaleString() : ''}
                    </div>
                  </div>
                ))
              )}
            </div>
          )}
        </div>

        <div className="pt-2">
          <button
            id="btn-logout"
            onClick={onLogout}
            className="w-full py-3.5 rounded-2xl bg-red-950/40 border border-red-500/40 hover:bg-red-900/50 active:scale-[0.98] text-red-400 font-bold text-xs flex items-center justify-center gap-2 transition cursor-pointer"
          >
            <LogOut className="w-4 h-4" />
            <span>အကောင့်မှ ထွက်မည် (Logout)</span>
          </button>
        </div>
      </div>

      {showKeyModal && role === 'admin' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-sm p-4">
          <div className="w-full max-w-xs rounded-3xl bg-[#141416] border border-[#FFCC00]/60 p-5 shadow-2xl animate-in zoom-in-95">
            <h3 className="text-base font-bold text-[#FFCC00] mb-3">Change Secret Key</h3>
            {keySuccess ? (
              <div className="p-3 rounded-xl bg-emerald-950 border border-emerald-500/50 text-emerald-300 text-xs flex items-center gap-2">
                <Check className="w-4 h-4" />
                <span>{keySuccess}</span>
              </div>
            ) : (
              <form onSubmit={handleUpdateKey} className="space-y-3">
                {keyError && (
                  <div className="p-2.5 rounded-xl bg-red-950 border border-red-500/50 text-red-300 text-[11px] text-center">
                    {keyError}
                  </div>
                )}
                <input
                  type="password"
                  value={currentKey}
                  onChange={(e) => setCurrentKey(e.target.value)}
                  placeholder="Current secret key"
                  className="w-full h-11 px-3 rounded-xl bg-black border border-zinc-700 text-white text-xs focus:border-[#FFCC00]"
                />
                <input
                  type="password"
                  value={newKey}
                  onChange={(e) => setNewKey(e.target.value)}
                  placeholder="New secret key"
                  className="w-full h-11 px-3 rounded-xl bg-black border border-zinc-700 text-white text-xs focus:border-[#FFCC00]"
                />
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => setShowKeyModal(false)}
                    className="flex-1 py-2 rounded-xl bg-zinc-800 text-zinc-300 text-xs font-bold"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={keyLoading}
                    className="flex-1 py-2 rounded-xl bg-[#FFCC00] text-black text-xs font-bold hover:bg-[#ffc107] disabled:opacity-60"
                  >
                    {keyLoading ? 'Saving...' : 'Save'}
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
