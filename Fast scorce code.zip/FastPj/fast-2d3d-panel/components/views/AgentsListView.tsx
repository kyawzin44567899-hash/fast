'use client';

import React, { useState } from 'react';
import {
  ArrowLeft,
  Search,
  Plus,
  User,
  X,
  Check,
  ShieldAlert,
  Percent,
  Phone,
  Hash,
  Mail,
  KeyRound,
  Eye,
  EyeOff,
  Copy,
  RefreshCw,
  Lock,
  Save,
  Wallet,
  Users,
  ShieldCheck,
  Share2,
  Trash2,
} from 'lucide-react';
import { AppAgent } from '@/lib/types';

interface AgentsListViewProps {
  agents: AppAgent[];
  onBack: () => void;
  onAddAgent: (agent: AppAgent) => void;
  onUpdateAgent: (agent: AppAgent) => void;
  onDeleteAgent?: (code: string) => void;
}

function generateAgentCode(): string {
  return 'FAG' + Math.floor(100000 + Math.random() * 900000);
}

function generateSecretKey(): string {
  const chars = '23456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz';
  let result = '';
  for (let i = 0; i < 6; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return `AGT@${result}`;
}

export function AgentsListView({ agents, onBack, onAddAgent, onUpdateAgent, onDeleteAgent }: AgentsListViewProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedAgent, setSelectedAgent] = useState<AppAgent | null>(null);
  const [showAddModal, setShowAddModal] = useState(false);
  const [agentToDelete, setAgentToDelete] = useState<AppAgent | null>(null);

  const [newName, setNewName] = useState('');
  const [newEmail, setNewEmail] = useState('');
  const [newPhone, setNewPhone] = useState('');
  const [newCode, setNewCode] = useState(() => generateAgentCode());
  const [newSecretKey, setNewSecretKey] = useState(() => generateSecretKey());
  const [newCommission, setNewCommission] = useState('5.0');
  const [showAddSecret, setShowAddSecret] = useState(false);
  const [formError, setFormError] = useState('');

  const [editName, setEditName] = useState('');
  const [editEmail, setEditEmail] = useState('');
  const [editPhone, setEditPhone] = useState('');
  const [editCode, setEditCode] = useState('');
  const [editSecretKey, setEditSecretKey] = useState('');
  const [editCommission, setEditCommission] = useState('5.0');
  const [editStatus, setEditStatus] = useState<'active' | 'suspended'>('active');
  const [editBalance, setEditBalance] = useState('');
  const [showEditSecret, setShowEditSecret] = useState(false);
  const [editError, setEditError] = useState('');
  const [editSuccess, setEditSuccess] = useState('');
  const [copiedField, setCopiedField] = useState<string | null>(null);

  const handleOpenAddModal = () => {
    setNewName('');
    setNewEmail('');
    setNewPhone('');
    setNewCode(generateAgentCode());
    setNewSecretKey(generateSecretKey());
    setNewCommission('5.0');
    setShowAddSecret(false);
    setFormError('');
    setShowAddModal(true);
  };

  const handleSelectAgent = (agent: AppAgent) => {
    setSelectedAgent(agent);
    setEditName(agent.name);
    setEditEmail(agent.email || '');
    setEditPhone(agent.phone);
    setEditCode(agent.code);
    setEditSecretKey('');
    setEditCommission(agent.commission.toString());
    setEditStatus(agent.status);
    setEditBalance(agent.balance.toString());
    setShowEditSecret(false);
    setEditError('');
    setEditSuccess('');
    setCopiedField(null);
  };

  const handleCopy = (text: string, fieldName: string) => {
    try {
      if (typeof navigator !== 'undefined' && navigator.clipboard) {
        navigator.clipboard.writeText(text);
      }
    } catch {

    }
    setCopiedField(fieldName);
    setTimeout(() => setCopiedField(null), 2000);
  };

  const handleCopyAllCredentials = (agent: {
    name: string;
    email: string;
    phone: string;
    code: string;
    secretKey: string;
    commission: number | string;
  }) => {
    const text = `===== FAST 2D/3D AGENT CREDENTIALS =====\nName: ${agent.name}\nEmail: ${agent.email}\nPhone: ${agent.phone}\nAgent Code: ${agent.code}\nSecret Key: ${agent.secretKey}\nCommission: ${agent.commission}%\n========================================`;
    handleCopy(text, 'all');
  };

  const handleCreateAgent = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmedName = newName.trim();
    const trimmedEmail = newEmail.trim();
    const trimmedPhone = newPhone.trim();
    const trimmedCode = newCode.trim().toUpperCase();
    const trimmedSecretKey = newSecretKey.trim();
    const commissionNum = parseFloat(newCommission);

    if (!trimmedName) {
      setFormError('ကျေးဇူးပြု၍ ကိုယ်စားလှယ် အမည် (Agent Name) ထည့်သွင်းပါ');
      return;
    }
    if (!trimmedEmail) {
      setFormError('ကျေးဇူးပြု၍ ကိုယ်စားလှယ် အီးမေးလ် (Agent Email) ထည့်သွင်းပါ');
      return;
    }
    if (!trimmedEmail.includes('@') || !trimmedEmail.includes('.')) {
      setFormError('မှန်ကန်သော အီးမေးလ်လိပ်စာ ရိုက်ထည့်ပါ (ဥပမာ- agent@gmail.com)');
      return;
    }
    if (!trimmedPhone) {
      setFormError('ကျေးဇူးပြု၍ ဖုန်းနံပါတ် (Agent Phone Number) ထည့်သွင်းပါ');
      return;
    }
    if (!trimmedCode) {
      setFormError('Agent Code မရှိပါက Auto Generate ပြုလုပ်ပါ');
      return;
    }
    if (!trimmedSecretKey) {
      setFormError('Agent Secret Key မရှိပါက Auto Generate ပြုလုပ်ပါ');
      return;
    }
    if (isNaN(commissionNum) || commissionNum < 0 || commissionNum > 100) {
      setFormError('မှန်ကန်သော ကော်မရှင် ရာခိုင်နှုန်း (၀ မှ ၁၀၀ ကြား) ထည့်ပါ');
      return;
    }

    const newAgent: AppAgent = {
      id: 'agent-' + Date.now(),
      name: trimmedName,
      email: trimmedEmail,
      phone: trimmedPhone,
      code: trimmedCode,
      secretKey: trimmedSecretKey,
      commission: commissionNum,
      membersCount: 0,
      balance: 100000,
      status: 'active',
      createdAt: new Date().toISOString().split('T')[0],
    };

    onAddAgent(newAgent);
    setShowAddModal(false);
  };

  const handleSaveEditAgent = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedAgent) return;

    const trimmedName = editName.trim();
    const trimmedEmail = editEmail.trim();
    const trimmedPhone = editPhone.trim();
    const trimmedCode = editCode.trim().toUpperCase();
    const trimmedSecretKey = editSecretKey.trim();
    const commissionNum = parseFloat(editCommission);
    const balanceNum = parseFloat(editBalance);

    if (!trimmedName) {
      setEditError('ကျေးဇူးပြု၍ ကိုယ်စားလှယ် အမည် ထည့်ပါ');
      return;
    }
    if (!trimmedEmail || !trimmedEmail.includes('@')) {
      setEditError('မှန်ကန်သော အီးမေးလ်လိပ်စာ ရိုက်ထည့်ပါ');
      return;
    }
    if (!trimmedPhone) {
      setEditError('ကျေးဇူးပြု၍ ဖုန်းနံပါတ် ထည့်ပါ');
      return;
    }
    if (!trimmedCode) {
      setEditError('Agent Code ထည့်သွင်းပါ');
      return;
    }
    if (isNaN(commissionNum) || commissionNum < 0 || commissionNum > 100) {
      setEditError('မှန်ကန်သော ကော်မရှင် ရာခိုင်နှုန်း ထည့်ပါ');
      return;
    }

    const updated: AppAgent = {
      ...selectedAgent,
      name: trimmedName,
      email: trimmedEmail,
      phone: trimmedPhone,
      code: trimmedCode,
      secretKey: trimmedSecretKey,
      commission: commissionNum,
      status: editStatus,
      balance: !isNaN(balanceNum) ? balanceNum : selectedAgent.balance,
    };

    onUpdateAgent(updated);
    setSelectedAgent(updated);
    setEditError('');
    setEditSuccess('အချက်အလက်များကို အောင်မြင်စွာ သိမ်းဆည်းပြီးပါပြီ');
    setTimeout(() => setEditSuccess(''), 2500);
  };

  const filtered = agents.filter(
    (a) =>
      a.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      a.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (a.email && a.email.toLowerCase().includes(searchTerm.toLowerCase())) ||
      a.phone.includes(searchTerm)
  );

  return (
    <div className="flex flex-col min-h-screen bg-[#101012] text-white selection:bg-amber-400 selection:text-black">
      <div className="sticky top-0 z-30 flex items-center justify-between px-4 py-3 bg-[#101012]/95 backdrop-blur-md border-b border-zinc-900">
        <button
          onClick={onBack}
          className="w-10 h-10 rounded-full flex items-center justify-center text-[#FFCC00] hover:bg-zinc-800 transition active:scale-95"
          aria-label="Back"
        >
          <ArrowLeft className="w-7 h-7 stroke-[2.5]" />
        </button>

        <div className="text-center">
          <h1 className="text-xl font-bold tracking-wide text-[#FFCC00]">
            Agents List
          </h1>
          <p className="text-[10px] text-zinc-400 font-medium">
            ကိုယ်စားလှယ်များ ({agents.length} ဦး)
          </p>
        </div>

        <div className="w-10" />
      </div>

      <div className="px-4 pt-3 pb-3">
        <div className="relative max-w-sm mx-auto">
          <input
            id="input-search-agent"
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search by Name, Code, Email or Phone..."
            className="w-full h-11 pl-11 pr-10 rounded-full bg-[#101012] border border-[#FFCC00] text-white placeholder-[#FFCC00]/70 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-[#FFCC00]/40"
          />
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4.5 h-4.5 text-[#FFCC00]" />
          {searchTerm && (
            <button
              onClick={() => setSearchTerm('')}
              className="absolute right-3.5 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      <div className="px-4 pb-4 flex justify-center">
        <button
          id="btn-add-agent"
          onClick={handleOpenAddModal}
          className="py-2.5 px-6 rounded-full bg-[#FFCC00] hover:bg-[#ffc107] active:scale-95 text-black font-extrabold text-sm flex items-center justify-center gap-2 shadow-[0_4px_16px_rgba(255,204,0,0.25)] transition cursor-pointer"
        >
          <div className="w-5 h-5 rounded-full border-2 border-black flex items-center justify-center">
            <Plus className="w-3.5 h-3.5 stroke-[3]" />
          </div>
          <span>Add Agent (အသစ်ထည့်မည်)</span>
        </button>
      </div>

      <div className="flex-1 px-4 pb-32">
        <div className="grid grid-cols-2 gap-3.5 max-w-sm mx-auto">
          {filtered.map((agent) => (
            <div key={agent.id} className="relative">
              <button
                onClick={() => handleSelectAgent(agent)}
                className="w-full flex flex-col items-center justify-between p-3.5 rounded-3xl bg-[#FFCC00] hover:bg-[#ffc107] active:scale-[0.96] transition shadow-[0_4px_16px_rgba(255,204,0,0.15)] cursor-pointer text-center relative overflow-hidden min-h-[185px]"
              >
                <div className="relative mt-0.5">
                  <div className="w-13 h-13 rounded-full bg-black flex items-center justify-center shadow-inner">
                    <User className="w-7 h-7 text-white fill-white" />
                  </div>
                  <span
                    title={agent.status === 'active' ? 'Active' : 'Suspended'}
                    className={`absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full border-2 border-[#FFCC00] ${
                      agent.status === 'active' ? 'bg-emerald-600' : 'bg-red-600'
                    }`}
                  />
                </div>

                <div className="w-full space-y-0.5 px-0.5">
                  <div
                    className="text-black font-extrabold text-sm sm:text-base leading-tight truncate w-full"
                    title={agent.name}
                  >
                    {agent.name}
                  </div>

                  <div className="text-black font-black text-xs leading-tight tracking-wider uppercase font-mono">
                    {agent.code}
                  </div>

                  <div className="text-black/80 font-bold text-[11px] leading-tight tracking-tight truncate w-full font-mono">
                    {agent.phone}
                  </div>
                </div>

                <div className="w-full flex items-center justify-center gap-1.5 mt-1">
                  <span className="px-2 py-0.5 rounded-full bg-black/15 text-black font-mono font-extrabold text-[10px] tracking-tight">
                    {agent.commission}% Com
                  </span>
                  <span className="px-2 py-0.5 rounded-full bg-black text-[#FFCC00] font-bold text-[10px]">
                    {agent.membersCount} users
                  </span>
                </div>
              </button>

              {onDeleteAgent && (
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setAgentToDelete(agent);
                  }}
                  className="absolute top-2 right-2 z-10 p-1.5 rounded-full bg-red-600/90 text-white hover:bg-red-500 active:scale-90 transition shadow"
                  title="Delete Agent"
                  id={`delete-agent-${agent.code}`}
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          ))}
        </div>

        {filtered.length === 0 && (
          <div className="text-center py-12 text-zinc-500 text-sm">
            ကိုယ်စားလှယ် ရှာမတွေ့ပါ (&quot;{searchTerm}&quot;)
          </div>
        )}
      </div>

      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-sm p-4 animate-in fade-in duration-200">
          <div className="w-full max-w-sm max-h-[90vh] flex flex-col rounded-3xl bg-[#141416] border border-[#FFCC00]/50 shadow-2xl overflow-hidden">
            <div className="flex items-center justify-between px-5 py-3.5 border-b border-zinc-800 bg-black/50 shrink-0">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-[#FFCC00] flex items-center justify-center text-black font-bold">
                  <Plus className="w-5 h-5 stroke-[3]" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-[#FFCC00]">Add New Agent</h3>
                  <p className="text-[10px] text-zinc-400">ကိုယ်စားလှယ်အသစ် စာရင်းသွင်းရန်</p>
                </div>
              </div>
              <button
                onClick={() => setShowAddModal(false)}
                className="w-8 h-8 rounded-full flex items-center justify-center text-zinc-400 hover:text-white hover:bg-zinc-800 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto px-5 py-4 space-y-3.5 pretty-scrollbar">
              {formError && (
                <div className="p-2.5 rounded-xl bg-red-950/70 border border-red-500/60 text-red-300 text-xs flex items-center gap-1.5 animate-in fade-in">
                  <ShieldAlert className="w-4 h-4 shrink-0 text-red-400" />
                  <span>{formError}</span>
                </div>
              )}

              <form id="add-agent-form" onSubmit={handleCreateAgent} className="space-y-3">
                <div>
                  <label className="block text-zinc-300 text-xs font-semibold mb-1">
                    Agent Name (အမည်) <span className="text-red-400">*</span>
                  </label>
                  <div className="relative">
                    <input
                      id="input-agent-name"
                      type="text"
                      value={newName}
                      onChange={(e) => {
                        setNewName(e.target.value);
                        if (formError) setFormError('');
                      }}
                      placeholder="ဥပမာ- Ko Phyo သို့မဟုတ် ဦးမင်းမင်း"
                      className="w-full h-10 pl-9 pr-3 rounded-xl bg-black border border-zinc-700 text-white text-xs focus:outline-none focus:border-[#FFCC00]"
                      required
                    />
                    <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-400" />
                  </div>
                </div>

                <div>
                  <label className="block text-zinc-300 text-xs font-semibold mb-1">
                    Agent Email (အီးမေးလ်) <span className="text-red-400">*</span>
                  </label>
                  <div className="relative">
                    <input
                      id="input-agent-email"
                      type="email"
                      value={newEmail}
                      onChange={(e) => {
                        setNewEmail(e.target.value);
                        if (formError) setFormError('');
                      }}
                      placeholder="ဥပမာ- kophyo@fast2d3d.com"
                      className="w-full h-10 pl-9 pr-3 rounded-xl bg-black border border-zinc-700 text-white text-xs focus:outline-none focus:border-[#FFCC00]"
                      required
                    />
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-400" />
                  </div>
                </div>

                <div>
                  <label className="block text-zinc-300 text-xs font-semibold mb-1">
                    Agent Phone Number (ဖုန်းနံပါတ်) <span className="text-red-400">*</span>
                  </label>
                  <div className="relative">
                    <input
                      id="input-agent-phone"
                      type="tel"
                      value={newPhone}
                      onChange={(e) => {
                        setNewPhone(e.target.value);
                        if (formError) setFormError('');
                      }}
                      placeholder="ဥပမာ- 09789123456"
                      className="w-full h-10 pl-9 pr-3 rounded-xl bg-black border border-zinc-700 text-white font-mono text-xs focus:outline-none focus:border-[#FFCC00]"
                      required
                    />
                    <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-400" />
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-zinc-300 text-xs font-semibold flex items-center gap-1">
                      <span>Agent Code</span>
                      <span className="text-[10px] text-amber-400 font-normal">(Auto Generate)</span>
                    </label>
                    <button
                      type="button"
                      onClick={() => setNewCode(generateAgentCode())}
                      className="text-[10px] text-[#FFCC00] hover:underline flex items-center gap-1 cursor-pointer"
                    >
                      <RefreshCw className="w-2.5 h-2.5" />
                      <span>ပြန်ထုတ်မည်</span>
                    </button>
                  </div>
                  <div className="relative">
                    <input
                      id="input-agent-code"
                      type="text"
                      value={newCode}
                      onChange={(e) => setNewCode(e.target.value.toUpperCase())}
                      className="w-full h-10 pl-9 pr-3 rounded-xl bg-zinc-900 border border-zinc-700 text-amber-300 font-mono font-bold text-xs focus:outline-none focus:border-[#FFCC00]"
                      required
                    />
                    <Hash className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-amber-400" />
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-zinc-300 text-xs font-semibold flex items-center gap-1">
                      <span>Agent Secret Key</span>
                      <span className="text-[10px] text-amber-400 font-normal">(Auto Generate)</span>
                    </label>
                    <button
                      type="button"
                      onClick={() => setNewSecretKey(generateSecretKey())}
                      className="text-[10px] text-[#FFCC00] hover:underline flex items-center gap-1 cursor-pointer"
                    >
                      <RefreshCw className="w-2.5 h-2.5" />
                      <span>ပြန်ထုတ်မည်</span>
                    </button>
                  </div>
                  <div className="relative">
                    <input
                      id="input-agent-secret"
                      type={showAddSecret ? 'text' : 'password'}
                      value={newSecretKey}
                      onChange={(e) => setNewSecretKey(e.target.value)}
                      className="w-full h-10 pl-9 pr-10 rounded-xl bg-zinc-900 border border-zinc-700 text-white font-mono text-xs focus:outline-none focus:border-[#FFCC00]"
                      required
                    />
                    <KeyRound className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-amber-400" />
                    <button
                      type="button"
                      onClick={() => setShowAddSecret(!showAddSecret)}
                      className="absolute right-2.5 top-1/2 -translate-y-1/2 p-1 text-zinc-400 hover:text-white"
                    >
                      {showAddSecret ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block text-zinc-300 text-xs font-semibold mb-1">
                    Agent Commission (%) (ကော်မရှင် ရာခိုင်နှုန်း)
                  </label>
                  <div className="relative">
                    <input
                      id="input-agent-commission"
                      type="number"
                      step="0.1"
                      min="0"
                      max="100"
                      value={newCommission}
                      onChange={(e) => setNewCommission(e.target.value)}
                      className="w-full h-10 pl-9 pr-3 rounded-xl bg-black border border-zinc-700 text-white font-mono text-xs focus:outline-none focus:border-[#FFCC00]"
                      required
                    />
                    <Percent className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-400" />
                  </div>
                </div>

                <div className="pt-2">
                  <button
                    id="btn-submit-add-agent"
                    type="submit"
                    className="w-full h-11 rounded-xl bg-[#FFCC00] hover:bg-[#ffc107] active:scale-[0.98] text-black font-extrabold text-sm flex items-center justify-center gap-1.5 transition shadow-[0_4px_16px_rgba(255,204,0,0.25)] cursor-pointer"
                  >
                    <Plus className="w-4 h-4 stroke-[3]" />
                    <span>Create Agent (ကိုယ်စားလှယ် အသစ်ဖွင့်မည်)</span>
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {selectedAgent && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/85 backdrop-blur-sm p-0 sm:p-4 animate-in fade-in duration-200">
          <div className="w-full max-w-sm max-h-[88vh] flex flex-col rounded-t-3xl sm:rounded-3xl bg-[#18181b] border border-[#FFCC00]/50 shadow-2xl overflow-hidden">
            <div className="flex items-center justify-between px-5 py-3.5 border-b border-zinc-800 bg-black/40 shrink-0">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-full bg-[#FFCC00] flex items-center justify-center text-black font-bold shadow">
                  <User className="w-5 h-5 text-black fill-black" />
                </div>
                <div>
                  <h3 className="text-white font-bold text-sm leading-tight">
                    ကိုယ်စားလှယ် အချက်အလက် ပြင်ဆင်ရန်
                  </h3>
                  <p className="text-[10px] text-zinc-400">Edit Agent Details (Admin)</p>
                </div>
              </div>
              <button
                onClick={() => setSelectedAgent(null)}
                className="w-8 h-8 rounded-full flex items-center justify-center text-zinc-400 hover:text-white hover:bg-zinc-800 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4 pretty-scrollbar">
              {editSuccess && (
                <div className="p-2.5 rounded-2xl bg-emerald-950/70 border border-emerald-500/60 text-emerald-300 text-xs text-center flex items-center justify-center gap-1.5 shadow-sm animate-in fade-in">
                  <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span className="font-medium">{editSuccess}</span>
                </div>
              )}

              {editError && (
                <div className="p-2.5 rounded-xl bg-red-950/70 border border-red-500/60 text-red-300 text-xs flex items-center gap-1.5 animate-in fade-in">
                  <ShieldAlert className="w-4 h-4 shrink-0 text-red-400" />
                  <span>{editError}</span>
                </div>
              )}

              <div className="p-3.5 rounded-2xl bg-black border border-[#FFCC00]/30 space-y-2.5 shadow-sm">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 text-[#FFCC00] text-xs font-bold">
                    <ShieldCheck className="w-4 h-4" />
                    <span>Agent Login Credentials</span>
                  </div>
                  <button
                    type="button"
                    onClick={() =>
                      handleCopyAllCredentials({
                        name: editName,
                        email: editEmail,
                        phone: editPhone,
                        code: editCode,
                        secretKey: editSecretKey,
                        commission: editCommission,
                      })
                    }
                    className="flex items-center gap-1 px-2 py-0.5 rounded-lg bg-[#FFCC00]/15 hover:bg-[#FFCC00]/25 text-[#FFCC00] text-[10px] font-bold border border-[#FFCC00]/40 transition active:scale-95 cursor-pointer"
                  >
                    {copiedField === 'all' ? (
                      <>
                        <Check className="w-3 h-3 text-emerald-400" />
                        <span>Copied!</span>
                      </>
                    ) : (
                      <>
                        <Share2 className="w-3 h-3" />
                        <span>Copy All (အားလုံးကူးယူမည်)</span>
                      </>
                    )}
                  </button>
                </div>

                <div className="text-[11px] text-zinc-400 flex items-center justify-between pt-1 border-t border-zinc-900">
                  <span>စတင်ဝင်ရောက်သည့်ရက်: {selectedAgent.createdAt}</span>
                  <span
                    className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                      editStatus === 'active'
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                        : 'bg-red-500/20 text-red-300 border border-red-500/40'
                    }`}
                  >
                    {editStatus}
                  </span>
                </div>
              </div>

              <form onSubmit={handleSaveEditAgent} className="space-y-3.5">
                <div>
                  <label className="block text-zinc-300 text-xs font-semibold mb-1">
                    Agent Name (အမည်) <span className="text-red-400">*</span>
                  </label>
                  <div className="relative">
                    <input
                      id="edit-agent-name"
                      type="text"
                      value={editName}
                      onChange={(e) => setEditName(e.target.value)}
                      className="w-full h-10 pl-9 pr-3 rounded-xl bg-black border border-zinc-700 text-white text-xs font-bold focus:outline-none focus:border-[#FFCC00]"
                      required
                    />
                    <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#FFCC00]" />
                  </div>
                </div>

                <div>
                  <label className="block text-zinc-300 text-xs font-semibold mb-1">
                    Agent Email (အီးမေးလ်) <span className="text-red-400">*</span>
                  </label>
                  <div className="relative">
                    <input
                      id="edit-agent-email"
                      type="email"
                      value={editEmail}
                      onChange={(e) => setEditEmail(e.target.value)}
                      className="w-full h-10 pl-9 pr-10 rounded-xl bg-black border border-zinc-700 text-white text-xs focus:outline-none focus:border-[#FFCC00]"
                      required
                    />
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#FFCC00]" />
                    <button
                      type="button"
                      onClick={() => handleCopy(editEmail, 'email')}
                      className="absolute right-2.5 top-1/2 -translate-y-1/2 p-1 text-zinc-400 hover:text-white"
                      title="Copy Email"
                    >
                      {copiedField === 'email' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block text-zinc-300 text-xs font-semibold mb-1">
                    Agent Phone Number (ဖုန်းနံပါတ်) <span className="text-red-400">*</span>
                  </label>
                  <div className="relative">
                    <input
                      id="edit-agent-phone"
                      type="tel"
                      value={editPhone}
                      onChange={(e) => setEditPhone(e.target.value)}
                      className="w-full h-10 pl-9 pr-10 rounded-xl bg-black border border-zinc-700 text-white font-mono text-xs focus:outline-none focus:border-[#FFCC00]"
                      required
                    />
                    <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#FFCC00]" />
                    <button
                      type="button"
                      onClick={() => handleCopy(editPhone, 'phone')}
                      className="absolute right-2.5 top-1/2 -translate-y-1/2 p-1 text-zinc-400 hover:text-white"
                      title="Copy Phone"
                    >
                      {copiedField === 'phone' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-zinc-300 text-xs font-semibold flex items-center gap-1">
                      <span>Agent Code</span>
                      <span className="text-[10px] text-zinc-500 font-mono">(Login Code)</span>
                    </label>
                    <button
                      type="button"
                      onClick={() => setEditCode(generateAgentCode())}
                      className="text-[10px] text-[#FFCC00] hover:underline flex items-center gap-1 cursor-pointer"
                    >
                      <RefreshCw className="w-2.5 h-2.5" />
                      <span>ကျပန်းပြန်ထုတ်မည်</span>
                    </button>
                  </div>
                  <div className="relative">
                    <input
                      id="edit-agent-code"
                      type="text"
                      value={editCode}
                      onChange={(e) => setEditCode(e.target.value.toUpperCase())}
                      className="w-full h-10 pl-9 pr-10 rounded-xl bg-zinc-900 border border-zinc-700 text-amber-300 font-mono font-bold text-xs focus:outline-none focus:border-[#FFCC00]"
                      required
                    />
                    <Hash className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-amber-400" />
                    <button
                      type="button"
                      onClick={() => handleCopy(editCode, 'code')}
                      className="absolute right-2.5 top-1/2 -translate-y-1/2 p-1 text-zinc-400 hover:text-white"
                      title="Copy Code"
                    >
                      {copiedField === 'code' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-zinc-300 text-xs font-semibold flex items-center gap-1">
                      <span>Agent Secret Key</span>
                      <span className="text-[10px] text-zinc-500 font-mono">(Login Password/Key)</span>
                    </label>
                    <button
                      type="button"
                      onClick={() => {
                        setEditSecretKey(generateSecretKey());
                        setShowEditSecret(true);
                      }}
                      className="text-[10px] text-[#FFCC00] hover:underline flex items-center gap-1 cursor-pointer"
                    >
                      <RefreshCw className="w-2.5 h-2.5" />
                      <span>စကားဝှက်အသစ်ထုတ်မည်</span>
                    </button>
                  </div>
                  <div className="relative">
                    <input
                      id="edit-agent-secret"
                      type={showEditSecret ? 'text' : 'password'}
                      value={editSecretKey}
                      onChange={(e) => setEditSecretKey(e.target.value)}
                      placeholder="Leave blank to keep current"
                      className="w-full h-10 pl-9 pr-18 rounded-xl bg-zinc-900 border border-zinc-700 text-white font-mono text-xs focus:outline-none focus:border-[#FFCC00]"
                    />
                    <KeyRound className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-amber-400" />
                    <div className="absolute right-2.5 top-1/2 -translate-y-1/2 flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => setShowEditSecret(!showEditSecret)}
                        className="p-1 text-zinc-400 hover:text-white"
                        title={showEditSecret ? 'Hide secret' : 'Show secret'}
                      >
                        {showEditSecret ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                      </button>
                      <button
                        type="button"
                        onClick={() => handleCopy(editSecretKey, 'secret')}
                        className="p-1 text-zinc-400 hover:text-white"
                        title="Copy Secret Key"
                      >
                        {copiedField === 'secret' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  </div>
                </div>

                <div>
                  <label className="block text-zinc-300 text-xs font-semibold mb-1">
                    Agent Commission (%) (ကော်မရှင် ရာခိုင်နှုန်း) <span className="text-red-400">*</span>
                  </label>
                  <div className="relative">
                    <input
                      id="edit-agent-commission"
                      type="number"
                      step="0.1"
                      min="0"
                      max="100"
                      value={editCommission}
                      onChange={(e) => setEditCommission(e.target.value)}
                      className="w-full h-10 pl-9 pr-3 rounded-xl bg-black border border-zinc-700 text-[#FFCC00] font-mono font-bold text-xs focus:outline-none focus:border-[#FFCC00]"
                      required
                    />
                    <Percent className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-amber-400" />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 pt-1">
                  <div className="p-3 rounded-2xl bg-black border border-zinc-800">
                    <div className="text-zinc-400 text-[10px] flex items-center gap-1">
                      <Wallet className="w-3 h-3 text-[#FFCC00]" />
                      <span>Agent Balance (MMK)</span>
                    </div>
                    <input
                      type="number"
                      value={editBalance}
                      onChange={(e) => setEditBalance(e.target.value)}
                      className="w-full mt-1 bg-transparent text-[#FFCC00] font-mono font-bold text-sm focus:outline-none border-b border-zinc-700 pb-0.5"
                    />
                  </div>
                  <div className="p-3 rounded-2xl bg-black border border-zinc-800 flex flex-col justify-center">
                    <div className="text-zinc-400 text-[10px] flex items-center gap-1">
                      <Users className="w-3 h-3 text-zinc-400" />
                      <span>Active Members</span>
                    </div>
                    <div className="text-white font-bold text-sm mt-1 font-mono">
                      {selectedAgent.membersCount} users
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between p-3 rounded-2xl bg-black border border-zinc-800">
                  <div>
                    <div className="text-xs text-zinc-200 font-semibold">
                      အကောင့်အခြေအနေ: <span className={editStatus === 'active' ? 'text-emerald-400' : 'text-red-400'}>{editStatus === 'active' ? 'ဖွင့်ထားသည် (ACTIVE)' : 'ပိတ်ထားသည် (SUSPENDED)'}</span>
                    </div>
                    <div className="text-[10px] text-zinc-500">Suspend ပြုလုပ်ထားပါက Agent Login မရပါ</div>
                  </div>
                  <button
                    type="button"
                    onClick={() => setEditStatus(editStatus === 'active' ? 'suspended' : 'active')}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition active:scale-95 cursor-pointer ${
                      editStatus === 'active'
                        ? 'bg-red-500/20 text-red-300 border border-red-500/40 hover:bg-red-500/30'
                        : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 hover:bg-emerald-500/30'
                    }`}
                  >
                    {editStatus === 'active' ? 'Suspend (ပိတ်မည်)' : 'Activate (ဖွင့်မည်)'}
                  </button>
                </div>

                <div className="pt-2 pb-2">
                  <button
                    id="btn-save-agent-details"
                    type="submit"
                    className="w-full h-11 rounded-xl bg-[#FFCC00] hover:bg-[#ffc107] active:scale-[0.98] text-black font-extrabold text-sm flex items-center justify-center gap-1.5 transition shadow-[0_4px_16px_rgba(255,204,0,0.25)] cursor-pointer"
                  >
                    <Save className="w-4 h-4" />
                    <span>သိမ်းဆည်းမည် (Save Agent Details)</span>
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {agentToDelete && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center bg-black/85 backdrop-blur-sm p-4">
          <div className="w-full max-w-xs rounded-3xl bg-[#141416] border border-red-500/60 p-5 shadow-2xl text-center">
            <div className="w-12 h-12 rounded-full bg-red-500/15 text-red-400 flex items-center justify-center mx-auto mb-3">
              <Trash2 className="w-6 h-6" />
            </div>
            <h3 className="text-sm font-bold text-white">Delete Agent?</h3>
            <p className="mt-2 text-[11px] text-zinc-400 leading-relaxed">
              <strong className="text-white">{agentToDelete.name}</strong> ({agentToDelete.code}) နှင့်
              သက်ဆိုင်သော data (sessions, OTP, login history) အားလုံးကို ဖျက်ပါမည်။ ဤအေးဂျင့်၏ Users များကို
              အေးဂျင့်မှ ဖယ်ရှားပေးပါမည် (User account များ မဖျက်ပါ)။
            </p>
            <div className="mt-4 flex gap-2">
              <button
                type="button"
                onClick={() => setAgentToDelete(null)}
                className="flex-1 py-2.5 rounded-xl bg-zinc-800 text-zinc-200 text-xs font-bold hover:bg-zinc-700 transition"
              >
                မလုပ်တော့ပါ
              </button>
              <button
                type="button"
                onClick={() => {
                  if (onDeleteAgent) onDeleteAgent(agentToDelete.code);
                  setAgentToDelete(null);
                }}
                className="flex-1 py-2.5 rounded-xl bg-red-600 text-white text-xs font-bold hover:bg-red-500 transition"
                id="confirm-delete-agent-btn"
              >
                ဖျက်မည် (Delete)
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

