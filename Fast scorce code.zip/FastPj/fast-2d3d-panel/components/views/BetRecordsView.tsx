'use client';

import React, { useState } from 'react';
import {
  ArrowLeft,
  Search,
  Filter,
  Receipt,
  Sparkles,
  ChevronRight,
  Clock,
  User,
  Smartphone,
  Eye,
  CheckCircle2,
  Calendar,
  Hash,
  RefreshCw,
} from 'lucide-react';
import { BetRecord, UserRole, AppAgent } from '@/lib/types';
import { BetReceiptModal } from '../BetReceiptModal';

interface BetRecordsViewProps {
  onBack: () => void;
  betRecords: BetRecord[];
  role?: UserRole;
  currentAgent?: AppAgent | null;
}

export function BetRecordsView({ onBack, betRecords, role = 'admin', currentAgent }: BetRecordsViewProps) {
  const [selectedCategory, setSelectedCategory] = useState<'all' | '2D' | '3D'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedBet, setSelectedBet] = useState<BetRecord | null>(null);
  const [toastMessage, setToastMessage] = useState('');

  const agentCodeToFilter = role === 'agent' ? (currentAgent?.code || '') : null;
  const scopedBetRecords = agentCodeToFilter
    ? betRecords.filter((b) => b.agentCode === agentCodeToFilter)
    : betRecords;

  const filteredBets = scopedBetRecords.filter((bet) => {
    if (selectedCategory !== 'all' && bet.category !== selectedCategory) return false;
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase().trim();
    return (
      bet.voucherNo.toLowerCase().includes(q) ||
      bet.userName.toLowerCase().includes(q) ||
      (role === 'admin' && bet.userPhone.toLowerCase().includes(q)) ||
      bet.userUid.toLowerCase().includes(q) ||
      bet.items.some((item) => item.number.includes(q))
    );
  });

  const totalBetAmount = filteredBets.reduce((sum, b) => sum + b.totalAmount, 0);
  const total2DAmount = scopedBetRecords
    .filter((b) => b.category === '2D')
    .reduce((sum, b) => sum + b.totalAmount, 0);
  const total3DAmount = scopedBetRecords
    .filter((b) => b.category === '3D')
    .reduce((sum, b) => sum + b.totalAmount, 0);

  return (
    <div className="flex flex-col min-h-screen bg-[#101012] text-white pb-32">
      <div className="sticky top-0 z-30 flex items-center justify-between px-4 py-3.5 bg-[#101012]/95 backdrop-blur-md border-b border-zinc-900">
        <button
          onClick={onBack}
          className="w-10 h-10 rounded-full flex items-center justify-center text-[#FFCC00] hover:bg-zinc-800 transition active:scale-95"
          aria-label="Back"
        >
          <ArrowLeft className="w-7 h-7 stroke-[2.5]" />
        </button>

        <div className="text-center">
          <h1 className="text-xl font-bold tracking-wide text-[#FFCC00]">
            ထိုးစာရင်းများ
          </h1>
          <span className="text-[10px] text-zinc-400 font-mono">Live Betting Slips & Receipts</span>
        </div>

        <button
          onClick={() => {
            setToastMessage('ထိုးစာရင်းများ နောက်ဆုံးအခြေအနေ ရယူပြီးပါပြီ');
            setTimeout(() => setToastMessage(''), 3000);
          }}
          className="p-2 text-[#FFCC00] hover:text-amber-300 transition active:scale-90"
          title="Refresh Slips"
        >
          <RefreshCw className="w-5 h-5" />
        </button>
      </div>

      {toastMessage && (
        <div className="mx-4 mt-3 p-2.5 rounded-xl bg-emerald-950/80 border border-emerald-500/50 text-emerald-300 text-xs text-center flex items-center justify-center gap-1.5 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      <div className="flex-1 px-4 pt-3 max-w-sm mx-auto w-full space-y-3.5">
        <div className="p-4 rounded-3xl bg-gradient-to-br from-zinc-900 via-black to-zinc-900 border border-zinc-800 shadow-xl space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-[#FFCC00]/20 text-[#FFCC00] flex items-center justify-center border border-[#FFCC00]/30">
                <Receipt className="w-4 h-4" />
              </div>
              <div>
                <span className="text-xs font-bold text-white block">စုစုပေါင်း ထိုးငွေပမာဏ</span>
                <span className="text-[10px] text-zinc-400">Total Bets Inflow</span>
              </div>
            </div>
            <div className="text-right">
              <span className="text-lg font-black text-[#FFCC00] font-mono block">
                {totalBetAmount.toLocaleString()} Ks
              </span>
              <span className="text-[10px] text-emerald-400 font-bold">
                {filteredBets.length} စောင်
              </span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2 pt-2 border-t border-zinc-800/80 text-xs">
            <div className="p-2 rounded-xl bg-black/60 border border-zinc-800">
              <span className="text-[10px] text-zinc-400 block">2D စုစုပေါင်း:</span>
              <span className="font-bold font-mono text-[#FFCC00] text-xs">
                {total2DAmount.toLocaleString()} Ks
              </span>
            </div>
            <div className="p-2 rounded-xl bg-black/60 border border-zinc-800">
              <span className="text-[10px] text-zinc-400 block">3D စုစုပေါင်း:</span>
              <span className="font-bold font-mono text-purple-400 text-xs">
                {total3DAmount.toLocaleString()} Ks
              </span>
            </div>
          </div>
        </div>

        <div className="flex p-1 bg-black rounded-2xl border border-zinc-800">
          <button
            type="button"
            onClick={() => setSelectedCategory('all')}
            className={`flex-1 py-2 rounded-xl text-xs font-bold transition cursor-pointer ${
              selectedCategory === 'all'
                ? 'bg-[#FFCC00] text-black shadow'
                : 'text-zinc-400 hover:text-white'
            }`}
          >
            အားလုံး ({betRecords.length})
          </button>
          <button
            type="button"
            onClick={() => setSelectedCategory('2D')}
            className={`flex-1 py-2 rounded-xl text-xs font-bold transition cursor-pointer ${
              selectedCategory === '2D'
                ? 'bg-[#FFCC00] text-black shadow'
                : 'text-zinc-400 hover:text-white'
            }`}
          >
            2D ထိုးစာရင်း
          </button>
          <button
            type="button"
            onClick={() => setSelectedCategory('3D')}
            className={`flex-1 py-2 rounded-xl text-xs font-bold transition cursor-pointer ${
              selectedCategory === '3D'
                ? 'bg-[#FFCC00] text-black shadow'
                : 'text-zinc-400 hover:text-white'
            }`}
          >
            3D ထိုးစာရင်း
          </button>
        </div>

        <div className="relative">
          <Search className="w-4 h-4 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="ဘောက်ချာနံပါတ်၊ ဖုန်း သို့မဟုတ် ဂဏန်းဖြင့် ရှာရန်..."
            className="w-full pl-9 pr-4 py-2.5 rounded-2xl bg-black border border-zinc-700 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-[#FFCC00]"
          />
        </div>

        <div className="space-y-3">
          <div className="flex items-center justify-between text-xs text-zinc-400 px-1 font-medium">
            <span>ထိုးထားသော စာရင်းများ</span>
            <span>(ဘောက်ချာကြည့်ရန် နှိပ်ပါ)</span>
          </div>

          {filteredBets.length === 0 ? (
            <div className="py-12 px-4 text-center rounded-3xl bg-zinc-900/40 border border-zinc-800">
              <Receipt className="w-10 h-10 text-zinc-600 mx-auto mb-2" />
              <p className="text-xs text-zinc-400 font-bold">ထိုးစာရင်း မရှိသေးပါ</p>
              <p className="text-[10px] text-zinc-500 mt-1">ရှာဖွေမှုစကားလုံး ပြန်လည်စစ်ဆေးပါ</p>
            </div>
          ) : (
            filteredBets.map((bet) => (
              <div
                key={bet.id}
                onClick={() => setSelectedBet(bet)}
                className="group p-4 rounded-3xl bg-black/90 border border-zinc-800 hover:border-[#FFCC00]/80 active:scale-[0.98] transition cursor-pointer shadow-md space-y-3 hover:shadow-[0_0_15px_rgba(255,204,0,0.12)]"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-black text-[#FFCC00] font-mono tracking-wide">
                      {bet.voucherNo}
                    </span>
                    <span
                      className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase ${
                        bet.category === '2D'
                          ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                          : 'bg-purple-500/20 text-purple-300 border border-purple-500/40'
                      }`}
                    >
                      {bet.category}
                    </span>
                  </div>

                  <span className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/30">
                    <CheckCircle2 className="w-3 h-3" />
                    <span>ထိုးပြီးပါပြီ</span>
                  </span>
                </div>

                <div className="flex items-center justify-between text-xs pt-1 border-t border-zinc-800/60">
                  <div className="flex items-center gap-1.5 text-zinc-300">
                    <User className="w-3.5 h-3.5 text-[#FFCC00]" />
                    <span className="font-semibold text-white">{bet.userName}</span>
                    <span className="text-[10px] font-mono text-zinc-500">({bet.userUid})</span>
                  </div>
                  {role === 'admin' ? (
                    <div className="flex items-center gap-1 text-zinc-400 font-mono text-[11px]">
                      <Smartphone className="w-3 h-3 text-zinc-500" />
                      <span>{bet.userPhone}</span>
                    </div>
                  ) : (
                    <div className="flex items-center gap-1 text-zinc-500 font-mono text-[11px]">
                      <Smartphone className="w-3 h-3 text-zinc-600" />
                      <span>09-••••••• (Hidden)</span>
                    </div>
                  )}
                </div>

                <div className="flex items-center justify-between bg-zinc-900/60 p-2.5 rounded-2xl border border-zinc-800/80">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    {bet.items.map((it, idx) => (
                      <span
                        key={idx}
                        className="inline-flex items-center gap-1 px-2 py-0.5 rounded-xl bg-black border border-zinc-700 text-xs font-mono font-black text-[#FFCC00]"
                      >
                        <span>{it.number}</span>
                        <span className="text-[9px] text-zinc-400 font-normal">
                          ({it.amount.toLocaleString()}Ks)
                        </span>
                      </span>
                    ))}
                  </div>
                  <span className="text-[10px] text-zinc-400 font-mono shrink-0 ml-1">
                    {bet.totalNumbers} ကွက်
                  </span>
                </div>

                <div className="flex items-center justify-between text-xs pt-1">
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-1 text-[11px] text-zinc-400 font-medium">
                      <Clock className="w-3 h-3 text-[#FFCC00]" />
                      <span>{bet.timeSlot}</span>
                    </div>
                    <span className="text-[9px] text-zinc-500 block font-mono">
                      {bet.dateFormatted}
                    </span>
                  </div>

                  <div className="text-right flex items-center gap-2">
                    <div>
                      <span className="text-sm font-black text-[#FFCC00] font-mono block">
                        {bet.totalAmount.toLocaleString()} Ks
                      </span>
                      <span className="text-[9px] text-zinc-400 block font-medium">
                        အလျော် {bet.multiplier} ဆ
                      </span>
                    </div>
                    <div className="w-7 h-7 rounded-full bg-[#FFCC00] text-black flex items-center justify-center group-hover:scale-110 transition shrink-0 shadow">
                      <Receipt className="w-3.5 h-3.5" />
                    </div>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      <BetReceiptModal bet={selectedBet} onClose={() => setSelectedBet(null)} />
    </div>
  );
}
