'use client';

import React, { useCallback, useEffect, useState } from 'react';
import {
  ArrowLeft,
  Wallet,
  TrendingUp,
  TrendingDown,
  Percent,
  Users,
  RefreshCw,
  CheckCircle2,
  Clock,
  X,
  BadgeDollarSign,
} from 'lucide-react';
import { AppAgent, UserRole } from '@/lib/types';

interface AgentBalanceViewProps {
  onBack: () => void;
  role?: UserRole;
  currentAgent?: AppAgent | null;
}

interface SummaryData {
  agent: {
    id: string;
    name: string;
    code: string;
    commission: number;
    balance: number;
    membersCount: number;
  };
  totals: {
    totalBet: number;
    totalWin: number;
    totalLoss: number;
    agentPercent: number;
    agentShare: number;
    adminShare: number;
    netBalance: number;
    settlementAmount: number;
  };
  payments: {
    grossPayout: number;
    paidAmount: number;
    remainingAmount: number;
    pendingCount: number;
    unpaidCount: number;
    partialCount: number;
    paidCount: number;
  };
}

interface Settlement {
  id: string;
  betId: string;
  uid: string;
  userName: string;
  agentCode: string;
  agentName: string;
  betType: string;
  session: string;
  winningNumber: string;
  betAmount: number;
  multiplier: number;
  grossPayout: number;
  agentPercent: number;
  agentShare: number;
  adminShare: number;
  paidAmount: number;
  remainingAmount: number;
  paymentStatus: string;
  paymentReference: string;
  operator: string;
  paidAt: string;
  isTood: boolean;
  createdAt: string;
}

function statusStyle(status: string): string {
  switch (status) {
    case 'paid':
      return 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40';
    case 'partial':
      return 'bg-amber-500/20 text-amber-300 border border-amber-500/40';
    case 'unpaid':
      return 'bg-rose-500/20 text-rose-300 border border-rose-500/40';
    default:
      return 'bg-zinc-700/40 text-zinc-300 border border-zinc-600/50';
  }
}

export function AgentBalanceView({ onBack, role = 'admin', currentAgent }: AgentBalanceViewProps) {
  const [agents, setAgents] = useState<AppAgent[]>([]);
  const [selectedCode, setSelectedCode] = useState<string>('');
  const [summary, setSummary] = useState<SummaryData | null>(null);
  const [settlements, setSettlements] = useState<Settlement[]>([]);
  const [loading, setLoading] = useState(false);
  const [statusFilter, setStatusFilter] = useState<'all' | 'pending' | 'unpaid' | 'partial' | 'paid'>('all');

  const [payTarget, setPayTarget] = useState<Settlement | null>(null);
  const [payAmount, setPayAmount] = useState('');
  const [payReference, setPayReference] = useState('');
  const [payError, setPayError] = useState('');

  const loadAgents = useCallback(async () => {
    if (role !== 'admin') return;
    try {
      const res = await fetch('/api/agents', { cache: 'no-store' });
      if (!res.ok) return;
      const json = await res.json();
      if (Array.isArray(json.data)) {
        setAgents(json.data as AppAgent[]);
        setSelectedCode((prev) => prev || (json.data[0]?.code as string) || '');
      }
    } catch {}
  }, [role]);

  const effectiveCode = role === 'agent' ? currentAgent?.code || '' : selectedCode;

  useEffect(() => {
    const timer = setTimeout(() => {
      void loadAgents();
    }, 0);
    return () => clearTimeout(timer);
  }, [loadAgents]);

  const loadData = useCallback(async (code: string) => {
    if (!code) return;
    setLoading(true);
    try {
      const [summaryRes, settlementsRes] = await Promise.all([
        fetch(`/api/agents/summary?code=${encodeURIComponent(code)}`, { cache: 'no-store' }),
        fetch(`/api/settlements?agent=${encodeURIComponent(code)}`, { cache: 'no-store' }),
      ]);
      if (summaryRes.ok) {
        const json = await summaryRes.json();
        if (json.success) setSummary(json.data as SummaryData);
      }
      if (settlementsRes.ok) {
        const json = await settlementsRes.json();
        if (json.success && Array.isArray(json.data)) setSettlements(json.data as Settlement[]);
      }
    } catch {}
    setLoading(false);
  }, []);

  useEffect(() => {
    const timer = setTimeout(() => {
      void loadData(effectiveCode);
    }, 0);
    return () => clearTimeout(timer);
  }, [effectiveCode, loadData]);

  const handlePay = async () => {
    if (!payTarget) return;
    const amount = Number(payAmount);
    if (!Number.isFinite(amount) || amount <= 0) {
      setPayError('ပမာဏ မှန်ကန်စွာ ထည့်ပါ');
      return;
    }
    try {
      const res = await fetch(`/api/settlements/${encodeURIComponent(payTarget.id)}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'pay', amount, reference: payReference }),
      });
      const json = await res.json();
      if (!res.ok || !json.success) {
        setPayError(json.error || 'ငွေပေးချေမှု မအောင်မြင်ပါ');
        return;
      }
      setPayTarget(null);
      setPayAmount('');
      setPayReference('');
      setPayError('');
      await loadData(effectiveCode);
    } catch {
      setPayError('ငွေပေးချေမှု မအောင်မြင်ပါ');
    }
  };

  const filteredSettlements = settlements.filter((s) =>
    statusFilter === 'all' ? true : s.paymentStatus === statusFilter
  );

  const totals = summary?.totals;
  const payments = summary?.payments;

  return (
    <div className="flex flex-col min-h-screen bg-[#101012] text-white pb-32">
      <div className="sticky top-0 z-30 flex items-center justify-between px-4 py-3 bg-[#101012]/95 backdrop-blur-md border-b border-zinc-900">
        <button
          onClick={onBack}
          className="w-10 h-10 rounded-full flex items-center justify-center text-[#FFCC00] hover:bg-zinc-800 transition active:scale-95"
          aria-label="Back"
        >
          <ArrowLeft className="w-7 h-7 stroke-[2.5]" />
        </button>
        <div className="text-center">
          <h1 className="text-xl font-bold tracking-wide text-[#FFCC00]">Agent Balance</h1>
          <p className="text-[10px] text-zinc-400">ကော်မရှင် / ငွေပေးချေမှု မှတ်တမ်း</p>
        </div>
        <button
          onClick={() => loadData(effectiveCode)}
          className="w-10 h-10 rounded-full flex items-center justify-center text-[#FFCC00] hover:bg-zinc-800 transition active:scale-95"
          aria-label="Refresh"
        >
          <RefreshCw className={`w-5 h-5 ${loading ? 'animate-spin' : ''}`} />
        </button>
      </div>

      <div className="flex-1 px-4 pt-3 max-w-sm mx-auto w-full space-y-3.5">
        {role === 'admin' && (
          <div className="p-3 rounded-2xl bg-black border border-zinc-800">
            <label className="text-[11px] text-zinc-400 block mb-1">Agent ရွေးပါ</label>
            <select
              value={selectedCode}
              onChange={(e) => setSelectedCode(e.target.value)}
              className="w-full h-10 px-3 rounded-xl bg-zinc-900 border border-zinc-700 text-sm text-white focus:outline-none focus:border-[#FFCC00]"
            >
              <option value="">-- Agent ရွေးပါ --</option>
              {agents.map((a) => (
                <option key={a.code} value={a.code}>
                  {a.name} ({a.code}) - {a.commission}%
                </option>
              ))}
            </select>
          </div>
        )}

        {summary && totals && payments && (
          <>
            <div className="p-4 rounded-3xl bg-gradient-to-br from-zinc-900 via-black to-zinc-900 border border-[#FFCC00]/50 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-sm font-black text-white">{summary.agent.name}</div>
                  <div className="text-[11px] font-mono text-amber-400">{summary.agent.code}</div>
                </div>
                <div className="text-right">
                  <div className="text-[10px] text-zinc-400 flex items-center gap-1 justify-end">
                    <Users className="w-3 h-3" /> Direct Members
                  </div>
                  <div className="text-lg font-black text-[#FFCC00] font-mono">
                    {summary.agent.membersCount}
                  </div>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="p-2 rounded-2xl bg-black border border-zinc-800">
                  <div className="text-[10px] text-zinc-400">Total Bet</div>
                  <div className="text-white font-bold font-mono">{totals.totalBet.toLocaleString()}</div>
                </div>
                <div className="p-2 rounded-2xl bg-black border border-zinc-800">
                  <div className="text-[10px] text-emerald-400">Total Win</div>
                  <div className="text-emerald-400 font-bold font-mono">{totals.totalWin.toLocaleString()}</div>
                </div>
                <div className="p-2 rounded-2xl bg-black border border-zinc-800">
                  <div className="text-[10px] text-rose-400">Total Loss</div>
                  <div className="text-rose-400 font-bold font-mono">{totals.totalLoss.toLocaleString()}</div>
                </div>
                <div className="p-2 rounded-2xl bg-black border border-zinc-800">
                  <div className="text-[10px] text-zinc-400 flex items-center gap-1">
                    <Percent className="w-3 h-3" /> Agent %
                  </div>
                  <div className="text-[#FFCC00] font-bold font-mono">{totals.agentPercent}%</div>
                </div>
              </div>

              <div className="p-3 rounded-2xl bg-black border border-[#FFCC00]/40 space-y-2 text-xs">
                <Row label="Net Balance (House)" value={totals.netBalance} />
                <Row
                  label="Agent Profit / Liability"
                  value={totals.agentShare}
                  valueClass={totals.agentShare >= 0 ? 'text-emerald-400' : 'text-rose-400'}
                  icon={totals.agentShare >= 0 ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                />
                <Row label="Admin Share" value={totals.adminShare} valueClass="text-amber-300" />
                <div className="flex items-center justify-between pt-1 border-t border-zinc-800">
                  <span className="text-[#FFCC00] font-bold">Settlement Amount</span>
                  <span className="text-[#FFCC00] font-black font-mono">
                    {totals.settlementAmount.toLocaleString()} MMK
                  </span>
                </div>
              </div>
            </div>

            <div className="p-4 rounded-3xl bg-black border border-zinc-800 space-y-2.5">
              <div className="flex items-center gap-1.5 text-xs font-bold text-[#FFCC00]">
                <BadgeDollarSign className="w-4 h-4" /> Payout Tracking
              </div>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <Row label="Gross Payout" value={payments.grossPayout} />
                <Row label="Paid Amount" value={payments.paidAmount} valueClass="text-emerald-400" />
                <Row label="Remaining" value={payments.remainingAmount} valueClass="text-rose-400" />
                <div className="flex items-center justify-between p-2 rounded-xl bg-zinc-950 border border-zinc-800">
                  <span className="text-zinc-400">Status</span>
                  <span className="text-white font-bold">
                    P{payments.pendingCount} / U{payments.unpaidCount} / Pt{payments.partialCount} /{' '}
                    <span className="text-emerald-400">Paid {payments.paidCount}</span>
                  </span>
                </div>
              </div>
            </div>

            <div className="flex p-1 bg-black rounded-2xl border border-zinc-800 gap-1 overflow-x-auto">
              {(['all', 'pending', 'unpaid', 'partial', 'paid'] as const).map((s) => (
                <button
                  key={s}
                  type="button"
                  onClick={() => setStatusFilter(s)}
                  className={`flex-1 min-w-[62px] py-1.5 rounded-xl text-[11px] font-bold capitalize transition ${
                    statusFilter === s ? 'bg-[#FFCC00] text-black' : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  {s}
                </button>
              ))}
            </div>

            <div className="space-y-3">
              {filteredSettlements.length === 0 ? (
                <div className="py-10 text-center text-xs text-zinc-500">Settlement မှတ်တမ်း မရှိပါ</div>
              ) : (
                filteredSettlements.map((s) => (
                  <div key={s.id} className="p-4 rounded-3xl bg-black border border-zinc-800 space-y-2.5">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span
                          className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase ${
                            s.betType === '2D'
                              ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                              : 'bg-purple-500/20 text-purple-300 border border-purple-500/40'
                          }`}
                        >
                          {s.betType}
                          {s.isTood ? ' TOOD' : ''}
                        </span>
                        <span className="text-[11px] text-zinc-400">{s.session}</span>
                      </div>
                      <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase ${statusStyle(s.paymentStatus)}`}>
                        {s.paymentStatus}
                      </span>
                    </div>

                    <div className="flex items-center justify-between text-xs">
                      <div>
                        <div className="text-white font-bold">{s.userName || s.uid}</div>
                        <div className="text-[10px] text-zinc-500 font-mono">UID: {s.uid}</div>
                      </div>
                      <div className="text-right">
                        <div className="text-[10px] text-zinc-400">Winning No</div>
                        <div className="text-emerald-400 font-mono font-bold">{s.winningNumber || '-'}</div>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-[11px]">
                      <Row label="Bet Amount" value={s.betAmount} />
                      <Row label={`Multiplier`} value={`${s.multiplier}x`} raw />
                      <Row label="Gross Payout" value={s.grossPayout} valueClass="text-emerald-400" />
                      <Row label={`Agent %`} value={`${s.agentPercent}%`} raw />
                      <Row label="Agent Share" value={s.agentShare} valueClass="text-amber-300" />
                      <Row label="Admin Share" value={s.adminShare} />
                      <Row label="Paid" value={s.paidAmount} valueClass="text-emerald-400" />
                      <Row label="Remaining" value={s.remainingAmount} valueClass="text-rose-400" />
                    </div>

                    <div className="text-[10px] text-zinc-500 border-t border-zinc-900 pt-1.5 space-y-0.5">
                      <div className="font-mono">Bet: {s.betId}</div>
                      <div>
                        {s.operator && <span>Operator: {s.operator} </span>}
                        {s.paymentReference && <span>| Ref: {s.paymentReference} </span>}
                        {s.paidAt && <span>| Paid: {new Date(s.paidAt).toLocaleString()}</span>}
                      </div>
                    </div>

                    {role === 'admin' && s.remainingAmount > 0 && (
                      <button
                        type="button"
                        onClick={() => {
                          setPayTarget(s);
                          setPayAmount(String(s.remainingAmount));
                          setPayReference('');
                          setPayError('');
                        }}
                        className="w-full py-2 rounded-xl bg-[#FFCC00] text-black text-xs font-extrabold hover:bg-amber-400 active:scale-[0.98] transition flex items-center justify-center gap-1.5"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" /> Record Payment
                      </button>
                    )}
                  </div>
                ))
              )}
            </div>
          </>
        )}

        {!summary && !loading && (
          <div className="py-16 text-center text-xs text-zinc-500 flex flex-col items-center gap-2">
            <Clock className="w-6 h-6 text-zinc-600" />
            <span>Agent ရွေးချယ်ပြီး ဒေတာ ကြည့်ပါ</span>
          </div>
        )}
      </div>

      {payTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-sm p-4">
          <div className="w-full max-w-xs rounded-3xl bg-[#141416] border border-[#FFCC00]/60 p-5 shadow-2xl">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-bold text-[#FFCC00] flex items-center gap-1.5">
                <Wallet className="w-4 h-4" /> Record Payment
              </h3>
              <button onClick={() => setPayTarget(null)} className="text-zinc-400 hover:text-white p-1">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="text-[11px] text-zinc-400 mb-2">
              {payTarget.userName} • Remaining{' '}
              <span className="text-rose-400 font-bold">{payTarget.remainingAmount.toLocaleString()}</span> MMK
            </div>

            {payError && (
              <div className="mb-2 p-2 rounded-xl bg-red-950/70 border border-red-500/60 text-red-300 text-[11px]">
                {payError}
              </div>
            )}

            <div className="space-y-2">
              <input
                type="number"
                value={payAmount}
                onChange={(e) => setPayAmount(e.target.value)}
                placeholder="Amount"
                className="w-full h-10 px-3 rounded-xl bg-black border border-zinc-700 text-sm text-white focus:outline-none focus:border-[#FFCC00]"
              />
              <input
                type="text"
                value={payReference}
                onChange={(e) => setPayReference(e.target.value)}
                placeholder="Payment Reference"
                className="w-full h-10 px-3 rounded-xl bg-black border border-zinc-700 text-sm text-white focus:outline-none focus:border-[#FFCC00]"
              />
            </div>

            <div className="flex gap-2 mt-4">
              <button
                type="button"
                onClick={() => setPayTarget(null)}
                className="flex-1 py-2.5 rounded-xl bg-zinc-800 text-zinc-200 text-xs font-bold hover:bg-zinc-700 transition"
              >
                မလုပ်တော့ပါ
              </button>
              <button
                type="button"
                onClick={handlePay}
                className="flex-1 py-2.5 rounded-xl bg-[#FFCC00] text-black text-xs font-extrabold hover:bg-amber-400 transition"
              >
                သိမ်းမည်
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function Row({
  label,
  value,
  valueClass = 'text-white',
  raw = false,
  icon,
}: {
  label: string;
  value: number | string;
  valueClass?: string;
  raw?: boolean;
  icon?: React.ReactNode;
}) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-zinc-400 flex items-center gap-1">{icon}{label}</span>
      <span className={`font-bold font-mono ${valueClass}`}>
        {typeof value === 'number' ? value.toLocaleString() : raw ? value : `${Number(value).toLocaleString()}`}
      </span>
    </div>
  );
}
