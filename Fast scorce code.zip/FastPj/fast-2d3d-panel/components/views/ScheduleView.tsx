'use client';

import React, { useState, useEffect } from 'react';
import { ArrowLeft, Calendar as CalendarIcon, Check, X, Lock, Trash2, Plus } from 'lucide-react';
import { ScheduleConfig, UserRole } from '@/lib/types';

interface ScheduleViewProps {
  schedule: ScheduleConfig;
  onBack: () => void;
  onUpdateSchedule: (schedule: ScheduleConfig) => void;
  role?: UserRole;
}

type AmPm = 'AM' | 'PM';

function to12h(hhmm: string): { h: number; m: number; ampm: AmPm } {
  const parts = (hhmm || '00:00').split(':');
  const H = parseInt(parts[0], 10) || 0;
  const M = parseInt(parts[1], 10) || 0;
  const ampm: AmPm = H >= 12 ? 'PM' : 'AM';
  let h = H % 12;
  if (h === 0) h = 12;
  return { h, m: M, ampm };
}

function from12h(h: number, m: number, ampm: AmPm): string {
  let H = h % 12;
  if (ampm === 'PM') H += 12;
  return `${String(H).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
}

function format12h(hhmm: string): string {
  const { h, m, ampm } = to12h(hhmm);
  return `${h}:${String(m).padStart(2, '0')} ${ampm}`;
}

function getMyanmarNowString(): string {
  const parts = new Intl.DateTimeFormat('en-GB', {
    timeZone: 'Asia/Yangon',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  }).formatToParts(new Date());
  const get = (t: string) => parts.find((p) => p.type === t)?.value || '00';
  return `${get('day')}/${get('month')}/${get('year')} ${get('hour')}:${get('minute')}`;
}

function TimePicker12({
  label,
  value,
  onChange,
  disabled,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  disabled?: boolean;
}) {
  const { h, m, ampm } = to12h(value);
  return (
    <div>
      <label className="block text-zinc-300 text-xs font-semibold mb-1">{label}</label>
      <div className="flex items-center gap-2">
        <select
          value={h}
          disabled={disabled}
          onChange={(e) => onChange(from12h(Number(e.target.value), m, ampm))}
          className="flex-1 h-11 px-2 rounded-xl bg-black border border-zinc-700 text-white text-sm focus:border-[#FFCC00] focus:outline-none"
        >
          {Array.from({ length: 12 }, (_, i) => i + 1).map((hh) => (
            <option key={hh} value={hh}>
              {hh}
            </option>
          ))}
        </select>
        <span className="text-zinc-500 font-bold">:</span>
        <select
          value={m}
          disabled={disabled}
          onChange={(e) => onChange(from12h(h, Number(e.target.value), ampm))}
          className="flex-1 h-11 px-2 rounded-xl bg-black border border-zinc-700 text-white text-sm focus:border-[#FFCC00] focus:outline-none"
        >
          {Array.from({ length: 60 }, (_, i) => i).map((mm) => (
            <option key={mm} value={mm}>
              {String(mm).padStart(2, '0')}
            </option>
          ))}
        </select>
        <div className="flex rounded-xl overflow-hidden border border-zinc-700">
          {(['AM', 'PM'] as AmPm[]).map((p) => (
            <button
              key={p}
              type="button"
              disabled={disabled}
              onClick={() => onChange(from12h(h, m, p))}
              className={`px-3 h-11 text-xs font-bold transition ${
                ampm === p ? 'bg-[#FFCC00] text-black' : 'bg-black text-zinc-400'
              }`}
            >
              {p}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

export function ScheduleView({ schedule, onBack, onUpdateSchedule, role = 'admin' }: ScheduleViewProps) {
  const [isClosedToday, setIsClosedToday] = useState(schedule.isClosedToday);
  const [morningStart, setMorningStart] = useState(schedule.morningStart || '09:30');
  const [morningEnd, setMorningEnd] = useState(schedule.morningEnd || '12:01');
  const [eveningStart, setEveningStart] = useState(schedule.eveningStart || '14:00');
  const [eveningEnd, setEveningEnd] = useState(schedule.eveningEnd || '16:30');
  const [threeDEnabled, setThreeDEnabled] = useState(schedule.threeDEnabled ?? true);
  const [threeDCloseTime, setThreeDCloseTime] = useState(schedule.threeDCloseTime || '15:30');
  const [threeDReopenTime, setThreeDReopenTime] = useState(schedule.threeDReopenTime || '09:00');
  const [closedDates, setClosedDates] = useState<string[]>(schedule.closedDates || []);
  const [threeDClosedDates, setThreeDClosedDates] = useState<string[]>(schedule.threeDClosedDates || []);
  const [newClosedDate, setNewClosedDate] = useState('');
  const [newThreeDClosedDate, setNewThreeDClosedDate] = useState('');
  const [showCalendarModal, setShowCalendarModal] = useState(false);
  const [showTimeModal, setShowTimeModal] = useState<'morning' | 'evening' | 'threeD' | null>(null);
  const [toastMessage, setToastMessage] = useState('');
  const [mmNow, setMmNow] = useState<string>(getMyanmarNowString());

  useEffect(() => {
    const timer = setInterval(() => setMmNow(getMyanmarNowString()), 30000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsClosedToday(schedule.isClosedToday);
      setMorningStart(schedule.morningStart || '09:30');
      setMorningEnd(schedule.morningEnd || '12:01');
      setEveningStart(schedule.eveningStart || '14:00');
      setEveningEnd(schedule.eveningEnd || '16:30');
      setThreeDEnabled(schedule.threeDEnabled ?? true);
      setThreeDCloseTime(schedule.threeDCloseTime || '15:30');
      setThreeDReopenTime(schedule.threeDReopenTime || '09:00');
      setClosedDates(schedule.closedDates || []);
      setThreeDClosedDates(schedule.threeDClosedDates || []);
    }, 0);
    return () => clearTimeout(timer);
  }, [schedule]);

  const isAgent = role === 'agent';

  const flash = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(''), 3000);
  };

  const handleToggleClosed = () => {
    if (isAgent) {
      flash('ရက်နှင့်အချိန် ပြင်ဆင်ခြင်းကို Master Admin သာ ခွင့်ပြုထားပါသည်');
      return;
    }
    const nextVal = !isClosedToday;
    setIsClosedToday(nextVal);
    onUpdateSchedule({ ...schedule, isClosedToday: nextVal });
    flash(nextVal ? 'ယနေ့ ပိတ်သိမ်းခြင်း စနစ်ကို ဖွင့်လိုက်ပါပြီ' : 'ယနေ့ ပုံမှန်အတိုင်း ဖွင့်လှစ်ပါမည်');
  };

  const handleToggleThreeD = () => {
    if (isAgent) {
      flash('3D ဖွင့်/ပိတ် ပြင်ဆင်ခြင်းကို Master Admin သာ ခွင့်ပြုထားပါသည်');
      return;
    }
    const nextVal = !threeDEnabled;
    setThreeDEnabled(nextVal);
    onUpdateSchedule({ ...schedule, threeDEnabled: nextVal });
    flash(nextVal ? '3D ထိုးသွင်းခြင်းကို ဖွင့်လိုက်ပါပြီ' : '3D ထိုးသွင်းခြင်းကို ပိတ်လိုက်ပါပြီ');
  };

  const handleOpenTimeModal = (session: 'morning' | 'evening' | 'threeD') => {
    if (isAgent) {
      flash('အချိန်သတ်မှတ်ချက် ပြင်ဆင်ခြင်းကို Master Admin သာ ခွင့်ပြုထားပါသည်');
      return;
    }
    setShowTimeModal(session);
  };

  const handleSaveTimes = () => {
    if (isAgent) return;
    onUpdateSchedule({
      ...schedule,
      morningStart,
      morningEnd,
      eveningStart,
      eveningEnd,
      threeDCloseTime,
      threeDReopenTime,
    });
    setShowTimeModal(null);
    flash('အချိန်သတ်မှတ်ချက်များကို သိမ်းဆည်းပြီးပါပြီ');
  };

  const handleAddClosedDate = (target: '2D' | '3D') => {
    if (isAgent) return;
    if (target === '2D') {
      const val = newClosedDate;
      if (!val || closedDates.includes(val)) return;
      const next = [...closedDates, val].sort();
      setClosedDates(next);
      setNewClosedDate('');
      onUpdateSchedule({ ...schedule, closedDates: next });
      flash(`2D ပိတ်ရက် ${val} ထည့်ပြီးပါပြီ`);
    } else {
      const val = newThreeDClosedDate;
      if (!val || threeDClosedDates.includes(val)) return;
      const next = [...threeDClosedDates, val].sort();
      setThreeDClosedDates(next);
      setNewThreeDClosedDate('');
      onUpdateSchedule({ ...schedule, threeDClosedDates: next });
      flash(`3D ပိတ်ရက် ${val} ထည့်ပြီးပါပြီ`);
    }
  };

  const handleRemoveClosedDate = (target: '2D' | '3D', date: string) => {
    if (isAgent) return;
    if (target === '2D') {
      const next = closedDates.filter((d) => d !== date);
      setClosedDates(next);
      onUpdateSchedule({ ...schedule, closedDates: next });
    } else {
      const next = threeDClosedDates.filter((d) => d !== date);
      setThreeDClosedDates(next);
      onUpdateSchedule({ ...schedule, threeDClosedDates: next });
    }
  };

  return (
    <div className="flex flex-col min-h-screen bg-[#101012] text-white selection:bg-amber-400 selection:text-black">
      <div className="sticky top-0 z-30 flex items-center justify-between px-4 py-3 bg-[#101012]/95 backdrop-blur-md border-b border-zinc-900">
        <button
          onClick={onBack}
          className="w-10 h-10 rounded-full flex items-center justify-center text-[#FFCC00] hover:bg-zinc-800 transition active:scale-95"
          aria-label="Back"
        >
          <ArrowLeft className="w-7 h-7 stroke-[2.5]" />
        </button>
        <div className="text-center">
          <h1 className="text-xl font-bold tracking-wide text-[#FFCC00]">အချိန်နှင့်ရက်</h1>
          <p className="text-[10px] text-amber-300/80 font-medium">Myanmar Time (MMT): {mmNow}</p>
        </div>
        <div className="w-10" />
      </div>

      {isAgent && (
        <div className="mx-4 mt-3 p-3 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center gap-2 text-xs text-amber-300">
          <Lock className="w-4 h-4 text-[#FFCC00] shrink-0" />
          <span>အချိန်နှင့်ရက် ကြည့်ရှုမှု (Master Admin သာ ပြင်ဆင်ခွင့်ရှိသည်)</span>
        </div>
      )}

      <div className="mx-4 mt-3 p-2.5 rounded-2xl bg-sky-500/10 border border-sky-500/30 text-[11px] text-sky-200 text-center">
        အချိန်/ရက်အားလုံးကို မြန်မာစံတော်ချိန် (MMT / Asia/Yangon) ဖြင့် သတ်မှတ်ပါသည်။
      </div>

      <div className="px-5 pt-4 pb-2">
        <div className="flex items-center gap-3">
          <button
            onClick={handleToggleClosed}
            disabled={isAgent}
            className={`relative inline-flex h-7 w-14 shrink-0 rounded-full border-2 border-transparent transition-colors duration-200 ${
              isAgent ? 'opacity-70 cursor-not-allowed' : 'cursor-pointer'
            } ${isClosedToday ? 'bg-red-600' : 'bg-zinc-800'}`}
          >
            <span
              className={`pointer-events-none inline-block h-6 w-6 transform rounded-full bg-[#FFCC00] shadow-lg transition duration-200 ${
                isClosedToday ? 'translate-x-7' : 'translate-x-0'
              }`}
            />
          </button>
          <span className="text-xs font-semibold uppercase text-zinc-400">{isClosedToday ? 'ON' : 'OFF'}</span>
          <span className="text-sm font-bold text-[#FFCC00] pl-1">ယနေ့ ပိတ်သည် (2D/3D)</span>
        </div>
      </div>

      {toastMessage && (
        <div className="mx-4 mt-2 p-2 rounded-xl bg-emerald-950/80 border border-emerald-500/50 text-emerald-300 text-xs text-center flex items-center justify-center gap-1.5">
          <Check className="w-4 h-4" />
          <span>{toastMessage}</span>
        </div>
      )}

      <div className="flex-1 px-4 pt-4 pb-32 max-w-sm mx-auto w-full space-y-5">
        <button
          onClick={() => handleOpenTimeModal('morning')}
          className={`w-full p-6 rounded-3xl bg-black border border-[#FFCC00] text-center shadow-lg transition ${
            isAgent ? 'cursor-default' : 'hover:border-amber-300 active:scale-[0.98] cursor-pointer'
          }`}
        >
          <h2 className="text-[#FFCC00] font-bold text-2xl tracking-wide">မနက်</h2>
          <div className="text-[#FFCC00] font-bold text-xl my-2">
            {format12h(morningStart)} &nbsp; to &nbsp; {format12h(morningEnd)}
          </div>
          <div className="text-[#FFCC00] font-bold text-base tracking-wider">AM</div>
        </button>

        <button
          onClick={() => handleOpenTimeModal('evening')}
          className={`w-full p-6 rounded-3xl bg-black border border-[#FFCC00] text-center shadow-lg transition ${
            isAgent ? 'cursor-default' : 'hover:border-amber-300 active:scale-[0.98] cursor-pointer'
          }`}
        >
          <h2 className="text-[#FFCC00] font-bold text-2xl tracking-wide">ညနေ</h2>
          <div className="text-[#FFCC00] font-bold text-xl my-2">
            {format12h(eveningStart)} &nbsp; to &nbsp; {format12h(eveningEnd)}
          </div>
          <div className="text-[#FFCC00] font-bold text-base tracking-wider">PM</div>
        </button>

        <div className="w-full p-5 rounded-3xl bg-black border border-[#FFCC00] shadow-lg">
          <div className="flex items-center justify-between">
            <h2 className="text-[#FFCC00] font-bold text-xl tracking-wide">3D</h2>
            <button
              onClick={handleToggleThreeD}
              disabled={isAgent}
              className={`relative inline-flex h-6 w-12 shrink-0 rounded-full transition-colors ${
                isAgent ? 'opacity-70 cursor-not-allowed' : 'cursor-pointer'
              } ${threeDEnabled ? 'bg-emerald-600' : 'bg-zinc-800'}`}
            >
              <span
                className={`pointer-events-none inline-block h-5 w-5 mt-0.5 ml-0.5 transform rounded-full bg-white shadow transition ${
                  threeDEnabled ? 'translate-x-6' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          <div className="mt-3 space-y-1 text-xs text-zinc-300">
            <div>
              <span className="text-zinc-500">1 ရက် / 16 ရက် ပိတ်ချိန်: </span>
              <span className="text-[#FFCC00] font-bold">{format12h(threeDCloseTime)}</span>
            </div>
            <div>
              <span className="text-zinc-500">2 ရက် / 17 ရက် ပြန်ဖွင့်ချိန်: </span>
              <span className="text-[#FFCC00] font-bold">{format12h(threeDReopenTime)}</span>
            </div>
            <div className="text-[#FFCC00]/70">ကျန်ရက်များ အမြဲဖွင့်ထားသည်</div>
          </div>

          <button
            onClick={() => handleOpenTimeModal('threeD')}
            disabled={isAgent}
            className={`mt-3 w-full py-2 rounded-xl border text-xs font-bold transition ${
              isAgent
                ? 'border-zinc-800 text-zinc-500 cursor-default'
                : 'border-[#FFCC00]/50 text-[#FFCC00] hover:bg-[#FFCC00]/10 cursor-pointer'
            }`}
          >
            အချိန် ပြင်ဆင်မည် (Set 3D Times)
          </button>
        </div>

        <div className="pt-2 text-center">
          <button
            onClick={() => setShowCalendarModal(true)}
            className="text-[#FFCC00] hover:text-amber-300 font-bold text-xl tracking-wide hover:underline transition active:scale-95 inline-flex items-center gap-2"
          >
            <CalendarIcon className="w-5 h-5 text-[#FFCC00]" />
            <span>Cleandar</span>
          </button>
        </div>
      </div>

      {showTimeModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-sm p-4">
          <div className="w-full max-w-sm rounded-3xl bg-[#141416] border border-[#FFCC00]/60 p-5 shadow-2xl max-h-[88vh] overflow-y-auto pretty-scrollbar">
            <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
              <h3 className="text-base font-bold text-[#FFCC00]">
                {showTimeModal === 'morning'
                  ? 'မနက်ပိုင်း အချိန် သတ်မှတ်ရန်'
                  : showTimeModal === 'evening'
                  ? 'ညနေပိုင်း အချိန် သတ်မှတ်ရန်'
                  : '3D အချိန် သတ်မှတ်ရန်'}
              </h3>
              <button onClick={() => setShowTimeModal(null)} className="text-zinc-400 hover:text-white p-1">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="mt-4 space-y-3">
              {showTimeModal === 'morning' && (
                <>
                  <TimePicker12 label="စတင်ဖွင့်ချိန် (Start Time - MMT)" value={morningStart} onChange={setMorningStart} />
                  <TimePicker12 label="ပိတ်သိမ်းချိန် (Closing Time - MMT)" value={morningEnd} onChange={setMorningEnd} />
                </>
              )}
              {showTimeModal === 'evening' && (
                <>
                  <TimePicker12 label="စတင်ဖွင့်ချိန် (Start Time - MMT)" value={eveningStart} onChange={setEveningStart} />
                  <TimePicker12 label="ပိတ်သိမ်းချိန် (Closing Time - MMT)" value={eveningEnd} onChange={setEveningEnd} />
                </>
              )}
              {showTimeModal === 'threeD' && (
                <>
                  <TimePicker12
                    label="1 ရက် / 16 ရက် ပိတ်ချိန် (Close Time - MMT)"
                    value={threeDCloseTime}
                    onChange={setThreeDCloseTime}
                  />
                  <TimePicker12
                    label="2 ရက် / 17 ရက် ပြန်ဖွင့်ချိန် (Reopen Time - MMT)"
                    value={threeDReopenTime}
                    onChange={setThreeDReopenTime}
                  />
                </>
              )}
              <div className="pt-3">
                <button
                  onClick={handleSaveTimes}
                  className="w-full py-2.5 rounded-xl bg-[#FFCC00] text-black font-bold text-sm hover:bg-[#ffbe00] transition"
                >
                  Save Schedule
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {showCalendarModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-sm p-4">
          <div className="w-full max-w-sm rounded-3xl bg-[#141416] border border-[#FFCC00]/60 p-5 shadow-2xl max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
              <h3 className="text-base font-bold text-[#FFCC00] flex items-center gap-2">
                <CalendarIcon className="w-4 h-4" />
                <span>Cleandar (ပိတ်ရက်ဇယား)</span>
              </h3>
              <button onClick={() => setShowCalendarModal(false)} className="text-zinc-400 hover:text-white p-1">
                <X className="w-5 h-5" />
              </button>
            </div>

            {isAgent ? (
              <div className="mt-4 text-xs text-zinc-400">ပိတ်ရက်ဇယားကို Master Admin သာ ပြင်ဆင်ခွင့်ရှိသည်။</div>
            ) : (
              <div className="mt-4 space-y-5 text-xs text-zinc-300">
                <div>
                  <div className="font-bold text-[#FFCC00] mb-2">2D ပိတ်ရက်များ</div>
                  <div className="flex gap-2">
                    <input
                      type="date"
                      value={newClosedDate}
                      onChange={(e) => setNewClosedDate(e.target.value)}
                      className="flex-1 h-9 px-2 rounded-lg bg-zinc-900 border border-zinc-700 text-white text-xs focus:border-[#FFCC00]"
                    />
                    <button
                      onClick={() => handleAddClosedDate('2D')}
                      className="px-3 h-9 rounded-lg bg-[#FFCC00] text-black font-bold text-xs flex items-center gap-1"
                    >
                      <Plus className="w-3 h-3" /> Add
                    </button>
                  </div>
                  <div className="mt-2 space-y-1.5">
                    {closedDates.length === 0 && <div className="text-zinc-500 text-[11px]">ပိတ်ရက် မရှိပါ</div>}
                    {closedDates.map((d) => (
                      <div
                        key={d}
                        className="flex items-center justify-between px-3 py-1.5 rounded-lg bg-zinc-950 border border-zinc-800"
                      >
                        <span className="font-mono text-[11px]">{d}</span>
                        <button onClick={() => handleRemoveClosedDate('2D', d)} className="text-red-400 hover:text-red-300">
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <div className="font-bold text-[#FFCC00] mb-2">3D ပိတ်ရက်များ</div>
                  <div className="flex gap-2">
                    <input
                      type="date"
                      value={newThreeDClosedDate}
                      onChange={(e) => setNewThreeDClosedDate(e.target.value)}
                      className="flex-1 h-9 px-2 rounded-lg bg-zinc-900 border border-zinc-700 text-white text-xs focus:border-[#FFCC00]"
                    />
                    <button
                      onClick={() => handleAddClosedDate('3D')}
                      className="px-3 h-9 rounded-lg bg-[#FFCC00] text-black font-bold text-xs flex items-center gap-1"
                    >
                      <Plus className="w-3 h-3" /> Add
                    </button>
                  </div>
                  <div className="mt-2 space-y-1.5">
                    {threeDClosedDates.length === 0 && <div className="text-zinc-500 text-[11px]">ပိတ်ရက် မရှိပါ</div>}
                    {threeDClosedDates.map((d) => (
                      <div
                        key={d}
                        className="flex items-center justify-between px-3 py-1.5 rounded-lg bg-zinc-950 border border-zinc-800"
                      >
                        <span className="font-mono text-[11px]">{d}</span>
                        <button onClick={() => handleRemoveClosedDate('3D', d)} className="text-red-400 hover:text-red-300">
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            <button
              onClick={() => setShowCalendarModal(false)}
              className="mt-4 w-full py-2.5 rounded-xl bg-[#FFCC00] text-black font-bold text-xs hover:bg-[#ffbe00] transition"
            >
              Done
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
