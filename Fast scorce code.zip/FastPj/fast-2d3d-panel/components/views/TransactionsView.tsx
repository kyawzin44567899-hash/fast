'use client';

import React, { useState } from 'react';
import { ArrowLeft, User, X, CheckCircle, XCircle, FileText, Check, Copy, ShieldCheck, Search } from 'lucide-react';
import { Transaction, UserRole, AppAgent } from '@/lib/types';

interface TransactionsViewProps {
  transactions: Transaction[];
  onBack: () => void;
  onApprove: (id: string) => void;
  onReject: (id: string) => void;
  role?: UserRole;
  currentAgent?: AppAgent | null;
}

export function TransactionsView({
  transactions,
  onBack,
  onApprove,
  onReject,
  role = 'admin',
  currentAgent,
}: TransactionsViewProps) {
  const [tab, setTab] = useState<'deposit' | 'withdrawal'>('deposit');
  const [statusFilter, setStatusFilter] = useState<'all' | 'pending' | 'approved' | 'rejected'>('all');
  const [selectedTx, setSelectedTx] = useState<Transaction | null>(null);
  const [toastMessage, setToastMessage] = useState('');
  const [copiedField, setCopiedField] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  const statusBadge = (status: string) => {
    if (status === 'pending') return 'bg-amber-500/20 text-amber-300 border border-amber-500/40';
    if (status === 'approved') return 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40';
    if (status === 'rejected') return 'bg-rose-500/20 text-rose-300 border border-rose-500/40';
    return 'bg-zinc-800 text-zinc-400 border border-zinc-700';
  };

  const handleCopy = async (text: string | undefined, field: string) => {
    if (!text) return;
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      try {
        const el = document.createElement('textarea');
        el.value = text;
        document.body.appendChild(el);
        el.select();
        document.execCommand('copy');
        document.body.removeChild(el);
      } catch {
        return;
      }
    }
    setCopiedField(field);
    setTimeout(() => setCopiedField(null), 2000);
  };

  const agentCode = currentAgent?.code || '';
  const scopedTransactions = role === 'agent'
    ? transactions.filter((tx) => tx.agentCode === agentCode)
    : transactions;

  const typeFiltered = scopedTransactions.filter((tx) =>
    tab === 'deposit' ? tx.type === 'deposit' : tx.type === 'withdraw'
  );
  const searchFiltered = typeFiltered.filter((tx) => {
    const q = searchQuery.trim().toLowerCase();
    if (!q) return true;
    return (
      (tx.orderNumber || '').toLowerCase().includes(q) ||
      (tx.userUid || '').toLowerCase().includes(q) ||
      (tx.userName || '').toLowerCase().includes(q) ||
      (tx.userPhone || '').toLowerCase().includes(q) ||
      (tx.refNumber || '').toLowerCase().includes(q)
    );
  });
  const filtered = searchFiltered.filter((tx) => statusFilter === 'all' || tx.status === statusFilter);

  const countFor = (status: 'all' | 'pending' | 'approved' | 'rejected') =>
    status === 'all' ? typeFiltered.length : typeFiltered.filter((t) => t.status === status).length;

  const handleApproveTx = (id: string) => {
    if (role !== 'admin') return;
    onApprove(id);
    setSelectedTx(null);
    setToastMessage('Transaction approved successfully (အတည်ပြုပြီးပါပြီ)');
    setTimeout(() => setToastMessage(''), 3000);
  };

  const handleRejectTx = (id: string) => {
    if (role !== 'admin') return;
    onReject(id);
    setSelectedTx(null);
    setToastMessage('Transaction rejected (ငြင်းပယ်ပြီးပါပြီ)');
    setTimeout(() => setToastMessage(''), 3000);
  };

  return (
    <div className="flex flex-col min-h-screen bg-[#101012] text-white selection:bg-amber-400 selection:text-black">
      <div className="sticky top-0 z-30 flex items-center justify-between px-4 py-3 bg-[#101012]/95 backdrop-blur-md border-b border-zinc-900">
        <button
          onClick={onBack}
          className="w-10 h-10 rounded-full flex items-center justify-center text-[#FFCC00] hover:bg-zinc-800 transition active:scale-95"
          aria-label="Back"
        >
          <ArrowLeft className="w-7 h-7 stroke-[2.5]" />
        </button>

        <div className="text-center">
          <h1 className="text-xl font-bold tracking-wide text-[#FFCC00]">
            ငွေသွင်း/ထုတ်
          </h1>
          <p className="text-[10px] text-zinc-400 font-medium">
            {role === 'agent' ? `Agent (${agentCode}) Transactions: ${scopedTransactions.length} ခု` : `Transactions (${scopedTransactions.length} ခု)`}
          </p>
        </div>

        <div className="w-10" />
      </div>

      {role === 'agent' && (
        <div className="mx-4 mt-3 p-2.5 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center gap-2 text-xs text-amber-300">
          <ShieldCheck className="w-4 h-4 text-[#FFCC00] shrink-0" />
          <span>
            သင့် Agent Code အောက်ရှိ အဖွဲ့ဝင်များ၏ ငွေသွင်း/ငွေထုတ်မှတ်တမ်းများ (View Only)
          </span>
        </div>
      )}

      <div className="px-4 pt-3">
        <div className="grid grid-cols-2 p-1 bg-zinc-900 rounded-2xl border border-zinc-800">
          <button
            type="button"
            onClick={() => {
              setTab('deposit');
              setStatusFilter('all');
            }}
            className={`py-2 text-sm font-bold rounded-xl transition ${
              tab === 'deposit' ? 'bg-[#FFCC00] text-black shadow' : 'text-zinc-400 hover:text-white'
            }`}
            id="tab-deposit"
          >
            Deposit
          </button>
          <button
            type="button"
            onClick={() => {
              setTab('withdrawal');
              setStatusFilter('all');
            }}
            className={`py-2 text-sm font-bold rounded-xl transition ${
              tab === 'withdrawal' ? 'bg-[#FFCC00] text-black shadow' : 'text-zinc-400 hover:text-white'
            }`}
            id="tab-withdrawal"
          >
            Withdrawal
          </button>
        </div>
      </div>

      <div className="px-4 pt-3">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Order Number / UID / Name / Phone ဖြင့် ရှာရန်"
            className="w-full pl-9 pr-3 py-2.5 rounded-2xl bg-zinc-900 border border-zinc-700 text-xs text-white focus:outline-none focus:border-[#FFCC00]"
            id="transactions-search-input"
          />
        </div>
      </div>

      <div className="flex items-center gap-2 px-4 py-2.5 overflow-x-auto pretty-scrollbar border-b border-zinc-900">
        {([
          { id: 'all', label: 'အားလုံး' },
          { id: 'pending', label: 'ဆိုင်းငံ့ (Pending)' },
          { id: 'approved', label: 'အတည်ပြု (Approved)' },
          { id: 'rejected', label: 'ငြင်းပယ် (Rejected)' },
        ] as const).map((tabItem) => (
          <button
            key={tabItem.id}
            onClick={() => setStatusFilter(tabItem.id)}
            className={`px-3.5 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition cursor-pointer ${
              statusFilter === tabItem.id
                ? 'bg-[#FFCC00] text-black shadow-md'
                : 'bg-zinc-900 text-zinc-400 hover:text-white border border-zinc-800'
            }`}
          >
            {tabItem.label} ({countFor(tabItem.id)})
          </button>
        ))}
      </div>

      {toastMessage && (
        <div className="mx-4 mt-3 p-2.5 rounded-xl bg-emerald-950/80 border border-emerald-500/50 text-emerald-300 text-xs text-center flex items-center justify-center gap-1.5 animate-in fade-in">
          <Check className="w-4 h-4" />
          <span>{toastMessage}</span>
        </div>
      )}

      <div className="flex-1 px-4 pt-4 pb-32 space-y-3 max-w-md mx-auto w-full">
        {filtered.map((tx) => (
          <div
            key={tx.id}
            className={`flex items-center justify-between p-4 rounded-3xl bg-black shadow-[0_4px_16px_rgba(0,0,0,0.5)] transition ${
              tx.status === 'pending'
                ? 'border-2 border-amber-500/70 hover:border-amber-400'
                : tx.status === 'approved'
                ? 'border-2 border-emerald-500/60 hover:border-emerald-400'
                : 'border-2 border-rose-500/60 hover:border-rose-400'
            }`}
          >
            <div className="w-14 h-14 rounded-full bg-[#FFCC00] flex items-center justify-center shrink-0 shadow-md">
              <User className="w-8 h-8 text-black fill-black" />
            </div>

            <div className="flex-1 px-4 min-w-0 text-left">
              <div className="flex items-center gap-2">
                <span className="text-[#FFCC00] font-bold text-base leading-tight truncate">
                  {tx.userName}
                </span>
                <span className={`text-[10px] uppercase font-bold px-1.5 py-0.5 rounded ${
                  tx.type === 'deposit' ? 'bg-emerald-500/20 text-emerald-300' : 'bg-rose-500/20 text-rose-300'
                }`}>
                  {tx.type === 'deposit' ? 'In' : 'Out'}
                </span>
                <span className={`text-[9px] uppercase font-bold px-1.5 py-0.5 rounded ${statusBadge(tx.status)}`}>
                  {tx.status}
                </span>
              </div>

              <div className="text-[#FFCC00] font-semibold text-xs tracking-wide mt-0.5 font-mono">
                {role === 'admin' ? tx.userPhone : (tx.agentCode ? `Agent: ${tx.agentCode}` : 'Member')}
              </div>

              <div className="text-[#FFCC00]/80 text-[11px] font-medium mt-0.5">
                {tx.dateTime} • {tx.amount.toLocaleString()} MMK
              </div>
              {tx.orderNumber && (
                <div className="text-zinc-400 text-[10px] font-mono mt-0.5">
                  {tx.orderNumber}
                </div>
              )}
            </div>

            <button
              onClick={() => setSelectedTx(tx)}
              className="p-2 text-[#FFCC00] hover:text-white transition active:scale-90 shrink-0 cursor-pointer"
              title="View Payment Slip & Details"
            >
              <svg viewBox="0 0 50 36" className="w-10 h-7 stroke-[#FFCC00] fill-none stroke-[2.2]">
                <path d="M5 18 C12 6, 38 6, 45 18 C38 30, 12 30, 5 18 Z" />
                <circle cx="25" cy="18" r="5" fill="#FFCC00" />
                <line x1="16" y1="28" x2="14" y2="33" stroke="#FFCC00" strokeWidth="2" strokeLinecap="round" />
                <line x1="21" y1="29" x2="20" y2="34" stroke="#FFCC00" strokeWidth="2" strokeLinecap="round" />
                <line x1="25" y1="29" x2="25" y2="35" stroke="#FFCC00" strokeWidth="2" strokeLinecap="round" />
                <line x1="29" y1="29" x2="30" y2="34" stroke="#FFCC00" strokeWidth="2" strokeLinecap="round" />
                <line x1="34" y1="28" x2="36" y2="33" stroke="#FFCC00" strokeWidth="2" strokeLinecap="round" />
              </svg>
            </button>
          </div>
        ))}

        {filtered.length === 0 && (
          <div className="text-center py-12 text-zinc-500 text-sm">
            မှတ်တမ်း မရှိပါ
          </div>
        )}
      </div>

      {selectedTx && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-sm p-4">
          <div className="w-full max-w-sm rounded-3xl bg-[#141416] border border-[#FFCC00]/60 p-5 shadow-2xl animate-in zoom-in-95 text-left">
            <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
              <div className="flex items-center gap-2 text-[#FFCC00] font-bold text-sm">
                <FileText className="w-4 h-4" />
                <span>ငွေလွှဲဘောက်ချာ (Payment Voucher)</span>
              </div>
              <button
                onClick={() => setSelectedTx(null)}
                className="text-zinc-400 hover:text-white p-1 rounded-full"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="mt-4 p-4 rounded-2xl bg-zinc-950 border border-zinc-800 space-y-2.5 text-xs">
              <div className="flex justify-between">
                <span className="text-zinc-400">အသုံးပြုသူ (User)</span>
                <span className="text-white font-bold">{selectedTx.userName}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-zinc-400">အသုံးပြုသူ ID (UID)</span>
                <div className="flex items-center gap-1.5">
                  <span className="text-zinc-200 font-mono text-[11px]">{selectedTx.userUid || '-'}</span>
                  <button
                    type="button"
                    onClick={() => handleCopy(selectedTx.userUid, 'uid')}
                    disabled={!selectedTx.userUid}
                    className="p-1 rounded-md text-zinc-400 hover:text-[#FFCC00] hover:bg-zinc-800 transition active:scale-90 disabled:opacity-40 disabled:cursor-not-allowed"
                    title="Copy UID"
                    id="copy-uid-btn"
                  >
                    {copiedField === 'uid' ? (
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                  </button>
                </div>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-zinc-400">အော်ဒါနံပါတ် (Order No.)</span>
                <div className="flex items-center gap-1.5">
                  <span className="text-[#FFCC00] font-mono text-[11px]">{selectedTx.orderNumber || '-'}</span>
                  <button
                    type="button"
                    onClick={() => handleCopy(selectedTx.orderNumber, 'order')}
                    disabled={!selectedTx.orderNumber}
                    className="p-1 rounded-md text-zinc-400 hover:text-[#FFCC00] hover:bg-zinc-800 transition active:scale-90 disabled:opacity-40 disabled:cursor-not-allowed"
                    title="Copy Order No."
                    id="copy-order-no-btn"
                  >
                    {copiedField === 'order' ? (
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                  </button>
                </div>
              </div>
              {role === 'admin' && (
                <div className="flex justify-between items-center">
                  <span className="text-zinc-400">ဖုန်းနံပါတ် (Phone)</span>
                  <div className="flex items-center gap-1.5">
                    <span className="text-white font-mono">{selectedTx.userPhone || '-'}</span>
                    <button
                      type="button"
                      onClick={() => handleCopy(selectedTx.userPhone, 'phone')}
                      disabled={!selectedTx.userPhone}
                      className="p-1 rounded-md text-zinc-400 hover:text-[#FFCC00] hover:bg-zinc-800 transition active:scale-90 disabled:opacity-40 disabled:cursor-not-allowed"
                      title="Copy Phone"
                      id="copy-phone-btn"
                    >
                      {copiedField === 'phone' ? (
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                    </button>
                  </div>
                </div>
              )}
              <div className="flex justify-between">
                <span className="text-zinc-400">အမျိုးအစား (Type)</span>
                <span className={`font-bold ${selectedTx.type === 'deposit' ? 'text-emerald-400' : 'text-rose-400'}`}>
                  {selectedTx.type === 'deposit' ? 'ငွေသွင်း (Deposit)' : 'ငွေထုတ် (Withdraw)'}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-zinc-400">ပမာဏ (Amount)</span>
                <span className="text-[#FFCC00] font-black text-sm">
                  {selectedTx.amount.toLocaleString()} MMK
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-zinc-400">ဘဏ် / ပိုက်ဆံအိတ်</span>
                <span className="text-white font-bold bg-[#FFCC00]/10 text-[#FFCC00] px-2 py-0.5 rounded">
                  {selectedTx.method}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-zinc-400">ပြေစာအမှတ် (Ref No.)</span>
                <div className="flex items-center gap-1.5">
                  <span className="text-zinc-300 font-mono text-[11px]">{selectedTx.refNumber || '-'}</span>
                  <button
                    type="button"
                    onClick={() => handleCopy(selectedTx.refNumber, 'ref')}
                    disabled={!selectedTx.refNumber}
                    className="p-1 rounded-md text-zinc-400 hover:text-[#FFCC00] hover:bg-zinc-800 transition active:scale-90 disabled:opacity-40 disabled:cursor-not-allowed"
                    title="Copy Ref No."
                    id="copy-ref-no-btn"
                  >
                    {copiedField === 'ref' ? (
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                  </button>
                </div>
              </div>
              <div className="flex justify-between">
                <span className="text-zinc-400">ရက်စွဲ (Date & Time)</span>
                <span className="text-zinc-300">{selectedTx.dateTime}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-zinc-400">အခြေအနေ (Status)</span>
                <span className={`capitalize font-bold ${
                  selectedTx.status === 'approved' ? 'text-emerald-400' : selectedTx.status === 'rejected' ? 'text-rose-400' : 'text-amber-400'
                }`}>
                  {selectedTx.status}
                </span>
              </div>
            </div>

            {selectedTx.slipUrl && (
              <div className="mt-4">
                <div className="text-[11px] text-zinc-400 mb-1.5 flex items-center gap-1">
                  <FileText className="w-3.5 h-3.5 text-[#FFCC00]" />
                  <span>ငွေလွှဲပြေစာ (Deposit Slip)</span>
                </div>
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={selectedTx.slipUrl}
                  alt="Deposit slip"
                  className="w-full rounded-2xl border border-zinc-700 max-h-72 object-contain bg-black"
                />
              </div>
            )}

            {role === 'admin' ? (
              selectedTx.status === 'pending' ? (
                <div className="mt-5 grid grid-cols-2 gap-3">
                  <button
                    onClick={() => handleRejectTx(selectedTx.id)}
                    className="py-2.5 rounded-xl bg-red-950 border border-red-500/50 text-red-300 font-bold text-xs hover:bg-red-900/60 active:scale-95 transition flex items-center justify-center gap-1.5"
                  >
                    <XCircle className="w-4 h-4" /> Reject
                  </button>
                  <button
                    onClick={() => handleApproveTx(selectedTx.id)}
                    className="py-2.5 rounded-xl bg-[#FFCC00] text-black font-bold text-xs hover:bg-[#ffbe00] active:scale-95 transition flex items-center justify-center gap-1.5 shadow-md"
                  >
                    <CheckCircle className="w-4 h-4" /> Approve (အတည်ပြု)
                  </button>
                </div>
              ) : (
                <div className="mt-4 pt-2 text-center text-zinc-500 text-xs">
                  This transaction is already completed ({selectedTx.status}).
                </div>
              )
            ) : (
              <div className="mt-4 p-2.5 rounded-xl bg-zinc-900 border border-zinc-800 text-center text-zinc-400 text-xs">
                (ငွေသွင်း/ငွေထုတ် အတည်ပြုခြင်းနှင့် ပယ်ဖျက်ခြင်းကို Master Admin သာ ဆောင်ရွက်ခွင့်ရှိပါသည်)
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
