'use client';

import React, { useState } from 'react';
import { Logo2D3D } from '../Logo2D3D';
import { ArrowLeft, Eye, EyeOff } from 'lucide-react';

interface AdminLoginViewProps {
  onSuccess: () => void;
  onBack: () => void;
}

export function AdminLoginView({ onSuccess, onBack }: AdminLoginViewProps) {
  const [email, setEmail] = useState('');
  const [adminId, setAdminId] = useState('');
  const [secretKey, setSecretKey] = useState('');
  const [showKey, setShowKey] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !adminId.trim() || !secretKey.trim()) {
      setError('Please fill in all Admin credentials');
      return;
    }
    setError('');
    setLoading(true);
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ role: 'admin', email, secretKey }),
      });
      const data = await res.json();
      if (!res.ok || !data.success) {
        setError(data.error || 'Login failed');
        return;
      }
      onSuccess();
    } catch {
      setError('Unable to reach the server');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col min-h-screen px-6 py-6 bg-black text-white selection:bg-amber-400 selection:text-black">
      <div className="w-full flex items-center justify-between">
        <button
          onClick={onBack}
          className="w-10 h-10 rounded-full flex items-center justify-center text-[#FFCC00] hover:bg-zinc-900 transition active:scale-95"
          aria-label="Back"
        >
          <ArrowLeft className="w-6 h-6" />
        </button>
      </div>

      <div className="flex flex-col items-center mt-2 mb-6">
        <Logo2D3D size="lg" showText={true} />

        <h2 className="mt-6 text-xl sm:text-2xl font-bold tracking-wide text-[#FFCC00]">
          Admin Login
        </h2>
      </div>

      <form onSubmit={handleLogin} className="w-full max-w-sm mx-auto space-y-4 flex-1 flex flex-col justify-center">
        {error && (
          <div className="p-2.5 rounded-xl bg-red-950/60 border border-red-500/50 text-red-300 text-xs text-center font-medium">
            {error}
          </div>
        )}

        <div>
          <label className="block text-[#FFCC00] text-sm font-semibold mb-1.5 pl-1">
            Admin Email
          </label>
          <div className="relative">
            <input
              id="input-admin-email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="e.g. admin@fast2d3d.com"
              className="w-full h-12 px-4 rounded-2xl bg-black border border-[#FFCC00] text-white placeholder-zinc-500 text-sm focus:outline-none focus:ring-2 focus:ring-[#FFCC00]/50"
            />
          </div>
        </div>

        <div>
          <label className="block text-[#FFCC00] text-sm font-semibold mb-1.5 pl-1">
            Admin ID
          </label>
          <div className="relative">
            <input
              id="input-admin-id"
              type="text"
              value={adminId}
              onChange={(e) => setAdminId(e.target.value)}
              placeholder="e.g. ADM-8899"
              className="w-full h-12 px-4 rounded-2xl bg-black border border-[#FFCC00] text-white placeholder-zinc-500 text-sm focus:outline-none focus:ring-2 focus:ring-[#FFCC00]/50"
            />
          </div>
        </div>

        <div>
          <label className="block text-[#FFCC00] text-sm font-semibold mb-1.5 pl-1">
            Admin Secret Key
          </label>
          <div className="relative">
            <input
              id="input-admin-secret-key"
              type={showKey ? 'text' : 'password'}
              value={secretKey}
              onChange={(e) => setSecretKey(e.target.value)}
              placeholder="Enter Admin Secret Key"
              className="w-full h-12 px-4 pr-12 rounded-2xl bg-black border border-[#FFCC00] text-white placeholder-zinc-500 text-sm focus:outline-none focus:ring-2 focus:ring-[#FFCC00]/50"
            />
            <button
              type="button"
              onClick={() => setShowKey(!showKey)}
              className="absolute right-3.5 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-[#FFCC00]"
            >
              {showKey ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
            </button>
          </div>
        </div>

        <div className="pt-6">
          <button
            id="btn-admin-submit-login"
            type="submit"
            disabled={loading}
            className="w-44 mx-auto py-3 px-6 rounded-2xl bg-[#FFCC00] hover:bg-[#ffbe00] active:scale-[0.98] text-black font-bold text-base flex items-center justify-center shadow-[0_4px_16px_rgba(255,204,0,0.3)] transition cursor-pointer disabled:opacity-60 disabled:cursor-not-allowed"
          >
            {loading ? 'Checking...' : 'Login'}
          </button>
        </div>
      </form>
    </div>
  );
}
