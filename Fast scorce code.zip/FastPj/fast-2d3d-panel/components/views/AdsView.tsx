'use client';

import React, { useState, useRef } from 'react';
import {
  ArrowLeft,
  Megaphone,
  Image as ImageIcon,
  Check,
  X,
  Plus,
  RotateCcw,
  Sparkles,
  Save,
  Upload,
  Trash2,
} from 'lucide-react';
import { AdsConfig } from '@/lib/types';

interface AdsViewProps {
  ads: AdsConfig;
  onBack: () => void;
  onUpdateAds: (ads: AdsConfig) => void;
}

export function AdsView({ ads, onBack, onUpdateAds }: AdsViewProps) {
  const [activeModal, setActiveModal] = useState<'notice' | 'banner' | null>(null);
  const [noticeTab, setNoticeTab] = useState<'notice1' | 'notice2' | 'both'>('notice1');

  const [notice1Text, setNotice1Text] = useState(ads.notice1 || ads.tickerNotice || '');
  const [notice2Text, setNotice2Text] = useState(ads.notice2 || '');
  const [toastMessage, setToastMessage] = useState('');

  const [bannerTitle, setBannerTitle] = useState('');
  const [bannerUrl, setBannerUrl] = useState('');
  const [bannerLink, setBannerLink] = useState('');
  const bannerFileInputRef = useRef<HTMLInputElement>(null);

  const handleOpenNoticeModal = () => {
    setNotice1Text(ads.notice1 || ads.tickerNotice || '');
    setNotice2Text(ads.notice2 || '');
    setActiveModal('notice');
  };

  const handleSaveNotices = () => {
    onUpdateAds({
      ...ads,
      notice1: notice1Text,
      notice2: notice2Text,
      tickerNotice: notice1Text,
    });
    setActiveModal(null);
    setToastMessage('စာတန်း၁ နှင့် စာတန်း၂ ကို အောင်မြင်စွာ သိမ်းဆည်းပြီးပါပြီ');
    setTimeout(() => setToastMessage(''), 3000);
  };

  const handleBannerUpload = (file: File) => {
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      setToastMessage('ပုံဖိုင် (Image file) သာ တင်ပေးပါ');
      setTimeout(() => setToastMessage(''), 2500);
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') setBannerUrl(reader.result);
    };
    reader.readAsDataURL(file);
  };

  const handleAddBanner = () => {
    if (!bannerTitle.trim() || !bannerUrl) {
      setToastMessage('Banner ခေါင်းစဉ်နှင့် ပုံ တင်ပေးပါ');
      setTimeout(() => setToastMessage(''), 2500);
      return;
    }
    const newBanners = [
      ...ads.banners,
      {
        id: `banner-${ads.banners.length + 1}-${bannerTitle.trim().toLowerCase().replace(/\s+/g, '')}`,
        title: bannerTitle.trim(),
        imageUrl: bannerUrl,
        link: bannerLink.trim(),
        active: true,
      },
    ];
    onUpdateAds({
      ...ads,
      banners: newBanners,
    });
    setBannerTitle('');
    setBannerUrl('');
    setBannerLink('');
    setToastMessage('Banner ကြော်ငြာ အသစ် ထည့်သွင်းပြီးပါပြီ');
    setTimeout(() => setToastMessage(''), 3000);
  };

  const handleDeleteBanner = (id: string) => {
    onUpdateAds({
      ...ads,
      banners: ads.banners.filter((b) => b.id !== id),
    });
  };

  const handleToggleBanner = (id: string) => {
    const updated = ads.banners.map((b) =>
      b.id === id ? { ...b, active: !b.active } : b
    );
    onUpdateAds({
      ...ads,
      banners: updated,
    });
  };

  return (
    <div className="flex flex-col min-h-screen bg-[#101012] text-white selection:bg-amber-400 selection:text-black">
      <div className="sticky top-0 z-30 flex items-center justify-between px-4 py-3 bg-[#101012]/95 backdrop-blur-md border-b border-zinc-900">
        <button
          onClick={onBack}
          className="w-10 h-10 rounded-full flex items-center justify-center text-[#FFCC00] hover:bg-zinc-800 transition active:scale-95"
          aria-label="Back"
        >
          <ArrowLeft className="w-7 h-7 stroke-[2.5]" />
        </button>

        <h1 className="text-xl font-bold tracking-wide text-[#FFCC00]">
          ကြော်ငြာများ
        </h1>

        <div className="w-10" />
      </div>

      {toastMessage && (
        <div className="mx-4 mt-3 p-2.5 rounded-xl bg-emerald-950/80 border border-emerald-500/50 text-emerald-300 text-xs text-center flex items-center justify-center gap-1.5 animate-in fade-in">
          <Check className="w-4 h-4" />
          <span>{toastMessage}</span>
        </div>
      )}

      <div className="flex-1 px-5 pt-6 pb-32 max-w-sm mx-auto w-full space-y-5 flex flex-col justify-start">
        <div className="space-y-2">
          <button
            id="btn-ad-notices"
            onClick={handleOpenNoticeModal}
            className="w-full py-4 px-6 rounded-2xl bg-black border-2 border-[#FFCC00] hover:border-amber-300 active:scale-[0.98] text-[#FFCC00] font-extrabold text-lg text-center shadow-lg transition cursor-pointer flex items-center justify-center gap-2"
          >
            <Megaphone className="w-5 h-5 text-[#FFCC00]" />
            <span>အသိပေးစာတန်းများ</span>
          </button>

          <div
            onClick={handleOpenNoticeModal}
            className="p-3.5 rounded-2xl bg-zinc-950 border border-zinc-800 hover:border-[#FFCC00]/40 transition cursor-pointer space-y-2"
          >
            <div className="flex items-center justify-between text-[11px] text-zinc-400">
              <span className="font-semibold text-zinc-300">လက်ရှိ စာတန်းများ (Active)</span>
              <span className="text-[#FFCC00] text-[10px] font-bold">ပြင်ဆင်ရန် နှိပ်ပါ &rarr;</span>
            </div>

            <div className="flex items-start gap-2 bg-black/60 p-2 rounded-xl border border-zinc-800/80">
              <span className="px-1.5 py-0.5 rounded bg-[#FFCC00] text-black text-[10px] font-extrabold shrink-0 mt-0.5">
                စာတန်း၁
              </span>
              <p className="text-xs text-amber-200 line-clamp-2 leading-relaxed">
                {ads.notice1 || ads.tickerNotice || 'စာတန်း မထည့်သွင်းရသေးပါ'}
              </p>
            </div>

            <div className="flex items-start gap-2 bg-black/60 p-2 rounded-xl border border-zinc-800/80">
              <span className="px-1.5 py-0.5 rounded bg-amber-400/20 text-[#FFCC00] border border-amber-400/40 text-[10px] font-extrabold shrink-0 mt-0.5">
                စာတန်း၂
              </span>
              <p className="text-xs text-zinc-300 line-clamp-2 leading-relaxed">
                {ads.notice2 || 'စာတန်း မထည့်သွင်းရသေးပါ'}
              </p>
            </div>
          </div>
        </div>

        <button
          id="btn-ad-banners"
          onClick={() => setActiveModal('banner')}
          className="w-full py-4 px-6 rounded-2xl bg-black border-2 border-[#FFCC00] hover:border-amber-300 active:scale-[0.98] text-[#FFCC00] font-extrabold text-lg text-center shadow-lg transition cursor-pointer flex items-center justify-center gap-2"
        >
          <ImageIcon className="w-5 h-5 text-[#FFCC00]" />
          <span>Banner ကြော်ငြာများ</span>
        </button>
      </div>

      {activeModal === 'notice' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-sm p-4 animate-in fade-in duration-200">
          <div className="w-full max-w-sm max-h-[90vh] flex flex-col rounded-3xl bg-[#141416] border border-[#FFCC00]/60 shadow-2xl overflow-hidden text-left">
            <div className="flex items-center justify-between px-5 py-3.5 border-b border-zinc-800 bg-black/40 shrink-0">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-[#FFCC00] flex items-center justify-center text-black font-bold">
                  <Megaphone className="w-4 h-4 text-black" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-[#FFCC00]">အသိပေးစာတန်းများ ပြင်ဆင်ရန်</h3>
                  <p className="text-[10px] text-zinc-400">စာတန်း၁ နှင့် စာတန်း၂ သတ်မှတ်ရန်</p>
                </div>
              </div>
              <button
                onClick={() => setActiveModal(null)}
                className="w-8 h-8 rounded-full flex items-center justify-center text-zinc-400 hover:text-white hover:bg-zinc-800 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="px-5 pt-3 shrink-0">
              <div className="grid grid-cols-3 gap-1 p-1 bg-black rounded-2xl border border-zinc-800">
                <button
                  type="button"
                  onClick={() => setNoticeTab('notice1')}
                  className={`py-1.5 text-xs font-bold rounded-xl transition ${
                    noticeTab === 'notice1'
                      ? 'bg-[#FFCC00] text-black shadow'
                      : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  စာတန်း၁
                </button>
                <button
                  type="button"
                  onClick={() => setNoticeTab('notice2')}
                  className={`py-1.5 text-xs font-bold rounded-xl transition ${
                    noticeTab === 'notice2'
                      ? 'bg-[#FFCC00] text-black shadow'
                      : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  စာတန်း၂
                </button>
                <button
                  type="button"
                  onClick={() => setNoticeTab('both')}
                  className={`py-1.5 text-xs font-bold rounded-xl transition ${
                    noticeTab === 'both'
                      ? 'bg-[#FFCC00] text-black shadow'
                      : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  အားလုံး (Both)
                </button>
              </div>
            </div>

            <div className="flex-1 overflow-y-auto px-5 py-3.5 space-y-4 pretty-scrollbar">
              {(noticeTab === 'notice1' || noticeTab === 'both') && (
                <div className="p-3.5 rounded-2xl bg-zinc-950 border border-zinc-800 space-y-2.5">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-[#FFCC00]" />
                      <label htmlFor="input-notice-1" className="text-xs font-bold text-[#FFCC00]">
                        စာတန်း၁ (Notice 1)
                      </label>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] text-zinc-500 font-mono">
                        {notice1Text.length} စာလုံး
                      </span>
                      {notice1Text && (
                        <button
                          type="button"
                          onClick={() => setNotice1Text('')}
                          className="text-[10px] text-zinc-400 hover:text-red-400 flex items-center gap-0.5"
                        >
                          <RotateCcw className="w-2.5 h-2.5" />
                          <span>ဖျက်မည်</span>
                        </button>
                      )}
                    </div>
                  </div>

                  <textarea
                    id="input-notice-1"
                    rows={3}
                    value={notice1Text}
                    onChange={(e) => setNotice1Text(e.target.value)}
                    placeholder="စာတန်း၁ ရေးသားပါ (ဥပမာ- ယနေ့ မနက်ပိုင်း မဲပိတ်ချိန် အသိပေးချက်...)"
                    className="w-full p-2.5 rounded-xl bg-black border border-zinc-700 text-white text-xs leading-relaxed focus:outline-none focus:border-[#FFCC00]"
                  />
                </div>
              )}

              {(noticeTab === 'notice2' || noticeTab === 'both') && (
                <div className="p-3.5 rounded-2xl bg-zinc-950 border border-zinc-800 space-y-2.5">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5">
                      <span className="w-2 h-2 rounded-full bg-amber-400" />
                      <label htmlFor="input-notice-2" className="text-xs font-bold text-amber-300">
                        စာတန်း၂ (Notice 2)
                      </label>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] text-zinc-500 font-mono">
                        {notice2Text.length} စာလုံး
                      </span>
                      {notice2Text && (
                        <button
                          type="button"
                          onClick={() => setNotice2Text('')}
                          className="text-[10px] text-zinc-400 hover:text-red-400 flex items-center gap-0.5"
                        >
                          <RotateCcw className="w-2.5 h-2.5" />
                          <span>ဖျက်မည်</span>
                        </button>
                      )}
                    </div>
                  </div>

                  <textarea
                    id="input-notice-2"
                    rows={3}
                    value={notice2Text}
                    onChange={(e) => setNotice2Text(e.target.value)}
                    placeholder="စာတန်း၂ ရေးသားပါ (ဥပမာ- ညနေပိုင်း မဲပိတ်ချိန် သို့မဟုတ် ငွေသွင်း/ထုတ် ဝန်ဆောင်မှု...)"
                    className="w-full p-2.5 rounded-xl bg-black border border-zinc-700 text-white text-xs leading-relaxed focus:outline-none focus:border-[#FFCC00]"
                  />
                </div>
              )}

              <div className="p-3 rounded-2xl bg-black border border-zinc-800 space-y-2">
                <div className="text-[11px] text-zinc-400 font-bold flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5 text-[#FFCC00]" />
                  <span>တိုက်ရိုက်ပြသမည့် ပုံစံ (Live Preview)</span>
                </div>

                <div className="space-y-1.5">
                  <div className="flex items-center gap-2 bg-zinc-950 p-2 rounded-xl border border-zinc-800">
                    <span className="text-[10px] bg-[#FFCC00] text-black font-extrabold px-1.5 py-0.5 rounded shrink-0">
                      စာတန်း၁
                    </span>
                    <div className="text-xs text-[#FFCC00] truncate font-medium">
                      {notice1Text || '(စာတန်း၁ မရှိသေးပါ)'}
                    </div>
                  </div>

                  <div className="flex items-center gap-2 bg-zinc-950 p-2 rounded-xl border border-zinc-800">
                    <span className="text-[10px] bg-amber-400/20 text-[#FFCC00] border border-amber-400/40 font-extrabold px-1.5 py-0.5 rounded shrink-0">
                      စာတန်း၂
                    </span>
                    <div className="text-xs text-zinc-300 truncate font-medium">
                      {notice2Text || '(စာတန်း၂ မရှိသေးပါ)'}
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="p-4 border-t border-zinc-800 bg-black/60 shrink-0">
              <button
                id="btn-save-notices"
                type="button"
                onClick={handleSaveNotices}
                className="w-full h-11 rounded-xl bg-[#FFCC00] hover:bg-[#ffc107] active:scale-[0.98] text-black font-extrabold text-sm flex items-center justify-center gap-2 transition shadow-[0_4px_16px_rgba(255,204,0,0.25)] cursor-pointer"
              >
                <Save className="w-4 h-4" />
                <span>သိမ်းဆည်းမည် (Save Notices)</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {activeModal === 'banner' && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-sm p-4">
          <div className="w-full max-w-sm rounded-3xl bg-[#141416] border border-[#FFCC00]/60 p-5 shadow-2xl animate-in zoom-in-95 text-left max-h-[85vh] flex flex-col">
            <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
              <h3 className="text-base font-bold text-[#FFCC00] flex items-center gap-2">
                <ImageIcon className="w-4 h-4" />
                <span>Banner ကြော်ငြာများ</span>
              </h3>
              <button
                onClick={() => setActiveModal(null)}
                className="text-zinc-400 hover:text-white p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="mt-4 flex-1 overflow-y-auto space-y-3 pr-1 pb-4 pretty-scrollbar">
              <div className="space-y-2">
                {ads.banners.map((banner) => (
                  <div
                    key={banner.id}
                    className="p-3 rounded-2xl bg-zinc-950 border border-zinc-800 flex items-center justify-between gap-3"
                  >
                    <div className="w-16 h-10 rounded-lg overflow-hidden bg-zinc-900 shrink-0 relative">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img
                        src={banner.imageUrl}
                        alt={banner.title}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="text-xs text-white font-semibold truncate">{banner.title}</div>
                      {banner.link && (
                        <div className="text-[10px] text-sky-400 truncate">{banner.link}</div>
                      )}
                      <span className={`text-[10px] font-bold ${banner.active ? 'text-emerald-400' : 'text-zinc-500'}`}>
                        {banner.active ? 'Active' : 'Inactive'}
                      </span>
                    </div>
                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        onClick={() => handleToggleBanner(banner.id)}
                        className={`px-2.5 py-1 rounded-lg text-[11px] font-bold ${
                          banner.active ? 'bg-zinc-800 text-zinc-300' : 'bg-[#FFCC00] text-black'
                        }`}
                      >
                        {banner.active ? 'Disable' : 'Enable'}
                      </button>
                      <button
                        onClick={() => handleDeleteBanner(banner.id)}
                        className="p-1.5 rounded-lg text-zinc-500 hover:text-red-400 hover:bg-zinc-900"
                        title="Delete banner"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              <div className="p-3 rounded-2xl bg-black border border-zinc-800 mt-3 space-y-2">
                <div className="text-xs font-bold text-[#FFCC00]">Add New Banner</div>
                <input
                  type="text"
                  value={bannerTitle}
                  onChange={(e) => setBannerTitle(e.target.value)}
                  placeholder="Ads Title (e.g. VIP Bonus)"
                  className="w-full h-9 px-3 rounded-xl bg-zinc-900 border border-zinc-700 text-xs text-white"
                />
                <input
                  type="text"
                  value={bannerLink}
                  onChange={(e) => setBannerLink(e.target.value)}
                  placeholder="Ads Link (https://...) (Optional)"
                  className="w-full h-9 px-3 rounded-xl bg-zinc-900 border border-zinc-700 text-xs text-white"
                />

                <input
                  ref={bannerFileInputRef}
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => {
                    if (e.target.files?.[0]) handleBannerUpload(e.target.files[0]);
                  }}
                />
                <button
                  type="button"
                  onClick={() => bannerFileInputRef.current?.click()}
                  className="w-full py-3 rounded-xl bg-zinc-900 border border-dashed border-zinc-700 text-zinc-300 text-xs font-semibold flex items-center justify-center gap-2 hover:border-[#FFCC00] transition"
                >
                  <Upload className="w-4 h-4 text-[#FFCC00]" />
                  <span>{bannerUrl ? 'Banner Photo Selected (Change)' : 'Upload Banner Photo from Device'}</span>
                </button>
                {bannerUrl && (
                  <div className="rounded-xl overflow-hidden border border-zinc-700">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img src={bannerUrl} alt="Banner preview" className="w-full h-24 object-cover" />
                  </div>
                )}

                <button
                  onClick={handleAddBanner}
                  className="w-full py-2 rounded-xl bg-[#FFCC00] text-black font-bold text-xs hover:bg-[#ffbe00]"
                >
                  <Plus className="w-3.5 h-3.5 inline mr-1" /> Add Banner
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
