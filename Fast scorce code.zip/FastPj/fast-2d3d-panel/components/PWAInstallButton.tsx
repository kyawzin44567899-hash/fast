'use client';

import React, { useState } from 'react';
import { usePWA } from '@/hooks/usePWA';
import { Download, Share2, X, Smartphone, CheckCircle } from 'lucide-react';

export function PWAInstallButton({ variant = 'compact' }: { variant?: 'compact' | 'banner' | 'profile' }) {
  const { isInstallable, isInstalled, isIOS, install } = usePWA();
  const [showIOSModal, setShowIOSModal] = useState(false);
  const [installSuccess, setInstallSuccess] = useState(false);

  if (isInstalled) {
    if (variant === 'profile') {
      return (
        <div className="flex items-center gap-2 p-3 bg-amber-500/10 border border-amber-500/30 rounded-xl text-amber-300 text-xs font-medium">
          <CheckCircle className="w-4 h-4 text-[#FFCC00]" />
          <span>App is installed as PWA (Standalone Mode)</span>
        </div>
      );
    }
    return null;
  }

  const handleInstallClick = async () => {
    if (isInstallable) {
      const ok = await install();
      if (ok) setInstallSuccess(true);
    } else if (isIOS) {
      setShowIOSModal(true);
    } else {

      setShowIOSModal(true);
    }
  };

  if (variant === 'profile') {
    return (
      <>
        <button
          onClick={handleInstallClick}
          className="w-full flex items-center justify-between p-3.5 bg-gradient-to-r from-amber-500/20 to-yellow-500/10 border border-[#FFCC00]/50 hover:border-[#FFCC00] rounded-xl text-[#FFCC00] font-semibold text-sm transition active:scale-[0.98]"
        >
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-[#FFCC00] text-black flex items-center justify-center font-bold">
              <Download className="w-4 h-4" />
            </div>
            <div className="text-left">
              <div className="text-white font-medium text-xs">Install PWA Application</div>
              <div className="text-[#FFCC00] text-[11px]">Add Fast 2D3D to your Home Screen</div>
            </div>
          </div>
          <span className="text-[10px] uppercase font-bold bg-[#FFCC00] text-black px-2 py-0.5 rounded-full">
            Install
          </span>
        </button>

        {showIOSModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm">
            <div className="w-full max-w-sm rounded-2xl bg-[#141416] border border-[#FFCC00]/40 p-5 shadow-2xl text-left">
              <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
                <div className="flex items-center gap-2 text-[#FFCC00] font-bold text-sm">
                  <Smartphone className="w-4 h-4" /> Install on Home Screen
                </div>
                <button
                  onClick={() => setShowIOSModal(false)}
                  className="text-zinc-400 hover:text-white p-1"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
              <div className="mt-4 space-y-3 text-xs text-zinc-300">
                <div className="flex items-start gap-3">
                  <span className="w-5 h-5 rounded-full bg-[#FFCC00] text-black font-bold flex items-center justify-center text-[10px] shrink-0">1</span>
                  <p>Tap the <strong>Share</strong> icon <Share2 className="w-3.5 h-3.5 inline mx-1 text-[#FFCC00]" /> in Safari or Chrome toolbar.</p>
                </div>
                <div className="flex items-start gap-3">
                  <span className="w-5 h-5 rounded-full bg-[#FFCC00] text-black font-bold flex items-center justify-center text-[10px] shrink-0">2</span>
                  <p>Scroll down and select <strong>&quot;Add to Home Screen&quot; (ပင်မစာမျက်နှာသို့ ထည့်မည်)</strong>.</p>
                </div>
                <div className="flex items-start gap-3">
                  <span className="w-5 h-5 rounded-full bg-[#FFCC00] text-black font-bold flex items-center justify-center text-[10px] shrink-0">3</span>
                  <p>Launch Fast 2D3D directly with native app experience and full screen!</p>
                </div>
              </div>
              <button
                onClick={() => setShowIOSModal(false)}
                className="mt-5 w-full rounded-xl bg-[#FFCC00] text-black font-bold py-2.5 text-xs hover:bg-[#ffc107] transition"
              >
                Got It
              </button>
            </div>
          </div>
        )}
      </>
    );
  }

  return (
    <>
      <button
        onClick={handleInstallClick}
        title="Install Fast 2D3D PWA"
        className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-[#FFCC00]/20 border border-[#FFCC00]/50 text-[#FFCC00] hover:bg-[#FFCC00] hover:text-black transition text-xs font-semibold"
      >
        <Download className="w-3.5 h-3.5" />
        <span className="text-[11px]">Install</span>
      </button>

      {showIOSModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm">
          <div className="w-full max-w-sm rounded-2xl bg-[#141416] border border-[#FFCC00]/40 p-5 shadow-2xl text-left">
            <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
              <div className="flex items-center gap-2 text-[#FFCC00] font-bold text-sm">
                <Smartphone className="w-4 h-4" /> Install Fast 2D3D PWA
              </div>
              <button
                onClick={() => setShowIOSModal(false)}
                className="text-zinc-400 hover:text-white p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="mt-4 space-y-3 text-xs text-zinc-300">
              <div className="flex items-start gap-3">
                <span className="w-5 h-5 rounded-full bg-[#FFCC00] text-black font-bold flex items-center justify-center text-[10px] shrink-0">1</span>
                <p>Tap your browser&apos;s <strong>Share</strong> or <strong>Options (⋮)</strong> menu.</p>
              </div>
              <div className="flex items-start gap-3">
                <span className="w-5 h-5 rounded-full bg-[#FFCC00] text-black font-bold flex items-center justify-center text-[10px] shrink-0">2</span>
                <p>Tap <strong>&quot;Add to Home Screen&quot;</strong> or <strong>&quot;Install App&quot;</strong>.</p>
              </div>
              <div className="flex items-start gap-3">
                <span className="w-5 h-5 rounded-full bg-[#FFCC00] text-black font-bold flex items-center justify-center text-[10px] shrink-0">3</span>
                <p>Enjoy Fast 2D3D panel in full-screen standalone mobile mode!</p>
              </div>
            </div>
            <button
              onClick={() => setShowIOSModal(false)}
              className="mt-5 w-full rounded-xl bg-[#FFCC00] text-black font-bold py-2.5 text-xs hover:bg-[#ffc107] transition"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </>
  );
}
