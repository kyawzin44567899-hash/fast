'use client';

import React from 'react';
import { Home, Globe, User } from 'lucide-react';
import { BottomTabType } from '@/lib/types';

interface BottomNavProps {
  activeTab: BottomTabType;
  onTabChange: (tab: BottomTabType) => void;
}

export function BottomNav({ activeTab, onTabChange }: BottomNavProps) {
  const tabs = [
    {
      id: 'home' as BottomTabType,
      label: 'ပင်မ',
      icon: Home,
    },
    {
      id: 'website' as BottomTabType,
      label: 'ဝဘ်ဆိုဒ်',
      icon: Globe,
    },
    {
      id: 'profile' as BottomTabType,
      label: 'ကျွန်ုပ်',
      icon: User,
    },
  ];

  return (
    <nav className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-[430px] z-40 bg-[#0E0E10] border-t border-zinc-900 shadow-[0_-4px_20px_rgba(0,0,0,0.6)]">
      <div className="w-full flex items-center justify-around h-18 px-4 pb-safe">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              id={`tab-${tab.id}`}
              onClick={() => onTabChange(tab.id)}
              className="flex-1 flex flex-col items-center justify-center py-1 transition-all active:scale-95 cursor-pointer"
            >
              <div
                className={`p-1 rounded-xl transition-all duration-200 ${
                  isActive ? 'text-[#FFCC00] scale-110' : 'text-zinc-400 hover:text-zinc-200'
                }`}
              >
                <Icon className={`w-6 h-6 stroke-[2.2] ${isActive ? 'fill-[#FFCC00]/20 text-[#FFCC00]' : ''}`} />
              </div>

              <span
                className={`text-[13px] font-bold tracking-tight transition-colors ${
                  isActive ? 'text-[#FFCC00]' : 'text-zinc-400'
                }`}
              >
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
