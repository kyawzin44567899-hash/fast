'use client';

import React from 'react';
import { X, Bell, ArrowRight, CheckCheck, Clock, Volume2, VolumeX } from 'lucide-react';
import { AppNotification } from '@/hooks/use-notifications';

interface NotificationModalProps {
  isOpen: boolean;
  onClose: () => void;
  notifications?: AppNotification[];
  onMarkRead?: (id: string) => void;
  onMarkAllRead?: () => void;
  soundEnabled?: boolean;
  onToggleSound?: (enabled: boolean) => void;
  onNavigate?: (screen: string) => void;
}

function formatTime(value: string): string {
  if (!value) return '';
  try {
    return new Date(value).toLocaleString('en-US', {
      day: '2-digit',
      month: 'short',
      hour: '2-digit',
      minute: '2-digit',
      hour12: true,
    });
  } catch {
    return '';
  }
}

export function NotificationModal({
  isOpen,
  onClose,
  notifications = [],
  onMarkRead,
  onMarkAllRead,
  soundEnabled = true,
  onToggleSound,
  onNavigate,
}: NotificationModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-sm p-4">
      <div className="w-full max-w-sm rounded-3xl bg-[#141416] border border-[#FFCC00]/60 p-5 shadow-2xl animate-in zoom-in-95 text-left">
        <div className="flex items-center justify-between pb-3 border-b border-zinc-800">
          <div className="flex items-center gap-2 text-[#FFCC00] font-bold text-base">
            <Bell className="w-5 h-5 fill-[#FFCC00]" />
            <span>အသိပေးချက်များ (Notifications)</span>
          </div>
          <div className="flex items-center gap-1.5">
            {onToggleSound && (
              <button
                onClick={() => onToggleSound(!soundEnabled)}
                className="text-zinc-400 hover:text-[#FFCC00] p-1 rounded-full"
                title={soundEnabled ? 'Mute sound' : 'Unmute sound'}
              >
                {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
              </button>
            )}
            {onMarkAllRead && notifications.some((n) => !n.isRead) && (
              <button
                onClick={onMarkAllRead}
                className="text-zinc-400 hover:text-[#FFCC00] p-1 rounded-full"
                title="Mark all read"
              >
                <CheckCheck className="w-4 h-4" />
              </button>
            )}
            <button onClick={onClose} className="text-zinc-400 hover:text-white p-1 rounded-full">
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div className="mt-3 space-y-2.5 max-h-[60vh] overflow-y-auto pr-1 pb-2 pretty-scrollbar">
          {notifications.length === 0 && (
            <div className="text-center py-10 text-zinc-500 text-sm">အသိပေးချက် မရှိသေးပါ</div>
          )}
          {notifications.map((item) => (
            <button
              key={item.id}
              onClick={() => {
                if (!item.isRead && onMarkRead) onMarkRead(item.id);
                const screen = typeof item.data?.screen === 'string' ? (item.data.screen as string) : '';
                if (screen && onNavigate) {
                  onNavigate(screen);
                  onClose();
                }
              }}
              className={`w-full p-3 rounded-2xl text-left transition border ${
                !item.isRead
                  ? 'bg-black border-[#FFCC00]/50 hover:border-[#FFCC00]'
                  : 'bg-zinc-950 border-zinc-800 hover:border-zinc-700'
              }`}
            >
              <div className="flex items-start justify-between gap-2">
                <span className="text-white font-bold text-xs">{item.title}</span>
                {!item.isRead && <span className="w-2 h-2 rounded-full bg-[#FFCC00] shrink-0 mt-1" />}
              </div>
              <p className="text-zinc-400 text-[11px] mt-1 line-clamp-2">{item.message}</p>
              <div className="flex items-center justify-between mt-2 pt-2 border-t border-zinc-900 text-[10px] text-zinc-500">
                <span className="flex items-center gap-1">
                  <Clock className="w-3 h-3" /> {formatTime(item.createdAt)}
                </span>
                <span className="text-[#FFCC00] font-semibold flex items-center gap-1">
                  View <ArrowRight className="w-3 h-3" />
                </span>
              </div>
            </button>
          ))}
        </div>

        <button
          onClick={onClose}
          className="mt-4 w-full py-2.5 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-300 font-bold text-xs hover:bg-zinc-800 transition"
        >
          ပိတ်မည် (Close)
        </button>
      </div>
    </div>
  );
}
