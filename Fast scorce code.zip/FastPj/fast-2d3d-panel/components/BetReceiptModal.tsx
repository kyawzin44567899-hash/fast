'use client';

import React, { useRef } from 'react';
import { X, Check, Copy, Printer, Share2, Sparkles, Download } from 'lucide-react';
import { BetRecord } from '@/lib/types';

interface BetReceiptModalProps {
  bet: BetRecord | null;
  onClose: () => void;
}

export function BetReceiptModal({ bet, onClose }: BetReceiptModalProps) {
  const [copied, setCopied] = React.useState(false);
  const receiptRef = useRef<HTMLDivElement>(null);

  if (!bet) return null;

  const handleCopyVoucher = () => {
    if (typeof navigator !== 'undefined' && navigator.clipboard) {
      navigator.clipboard.writeText(bet.voucherNo);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handlePrint = () => {
    if (typeof window !== 'undefined') {
      window.print();
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 overflow-y-auto animate-in fade-in">
      <div className="w-full max-w-sm my-auto flex flex-col items-center">
        <div className="w-full flex justify-end mb-2">
          <button
            type="button"
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-zinc-900/90 border border-zinc-700 text-zinc-300 hover:text-white hover:bg-zinc-800 flex items-center justify-center transition active:scale-95 shadow-lg"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div
          ref={receiptRef}
          className="w-full bg-[#0d0d10] border border-zinc-800/90 rounded-[28px] p-5 sm:p-6 shadow-2xl text-white relative select-none"
        >
          <div className="flex items-center justify-between text-[11px] font-mono tracking-wider text-amber-500/80 uppercase">
            <span>FAST 2D/3D LOTTERY</span>
            <span className="text-zinc-500 font-bold">{bet.voucherNo}</span>
          </div>

          <div className="border-b border-dashed border-zinc-800 my-3.5" />

          <div className="flex justify-center mb-2">
            <div className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full border border-[#FFCC00]/50 bg-[#FFCC00]/10 text-[#FFCC00] text-[11px] font-extrabold tracking-wide">
              <Sparkles className="w-3.5 h-3.5 fill-[#FFCC00]" />
              <span>FAST 2D3D OFFICIAL</span>
            </div>
          </div>

          <div className="text-center">
            <h2 className="text-xl sm:text-2xl font-black tracking-wide text-[#FFCC00] uppercase font-mono">
              {bet.category} LOTTERY RECEIPT
            </h2>
            <p className="text-[11px] text-zinc-300 mt-1 font-medium">
              အချိန် - <span className="font-semibold text-white">{bet.timeSlot}</span> | နေ့စွဲ -{' '}
              <span className="text-zinc-400 font-mono text-[10px]">{bet.dateFormatted}</span>
            </p>
          </div>

          <div className="mt-4 p-3.5 rounded-2xl bg-black/60 border border-zinc-800/90 space-y-2.5">
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div>
                <span className="text-[11px] text-zinc-400 block mb-0.5">ဘောက်ချာနံပါတ်</span>
                <span className="text-xs font-bold text-[#FFCC00] font-mono block">
                  {bet.voucherNo}
                </span>
              </div>
              <div>
                <span className="text-[11px] text-zinc-400 block mb-0.5">အသုံးပြုသူ</span>
                <span className="text-xs font-bold text-white font-mono block">
                  {bet.userPhone || bet.userUid}
                </span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs pt-2 border-t border-zinc-800/60">
              <div>
                <span className="text-[11px] text-zinc-400 block mb-0.5">ကစားနည်း</span>
                <span className="text-xs font-bold text-[#FFCC00] block">
                  {bet.category} ({bet.timeSlot})
                </span>
              </div>
              <div>
                <span className="text-[11px] text-zinc-400 block mb-0.5">အခြေအနေ</span>
                <span className="text-xs font-bold text-emerald-400 inline-flex items-center gap-1">
                  <span className="w-4 h-4 rounded-full border border-emerald-400/80 flex items-center justify-center shrink-0">
                    <Check className="w-2.5 h-2.5 stroke-[3]" />
                  </span>
                  <span>ထိုးပြီးပါပြီ</span>
                </span>
              </div>
            </div>
          </div>

          <div className="mt-4 flex items-center justify-between text-xs text-zinc-300 font-semibold px-1 mb-2">
            <span>ဂဏန်း / အမျိုးအစား</span>
            <span>ကွက်ရေ / ထိုးကြေး</span>
          </div>

          <div className="space-y-1.5">
            {bet.items.map((item, index) => (
              <div
                key={index}
                className="flex items-center justify-between p-3 rounded-2xl bg-black/70 border border-zinc-800/80"
              >
                <div className="flex items-center gap-2">
                  <span className="text-xs text-zinc-500 font-mono w-4">{index + 1}.</span>
                  <span className="text-lg font-black text-[#FFCC00] font-mono tracking-wider">
                    {item.number}
                  </span>
                </div>
                <div className="text-right">
                  <span className="text-sm font-bold text-white font-mono">
                    {item.amount.toLocaleString()}
                  </span>
                  <span className="text-xs text-zinc-400 font-medium ml-1">Ks</span>
                </div>
              </div>
            ))}
          </div>

          <div className="border-b border-dashed border-zinc-800 my-4" />

          <div className="p-4 rounded-2xl bg-[#13110a] border border-amber-500/40 space-y-2">
            <div className="flex items-center justify-between text-xs text-white">
              <span className="text-zinc-300 font-medium">စုစုပေါင်း ကွက်ရေ</span>
              <span className="text-sm font-bold font-mono">{bet.totalNumbers} ကွက်</span>
            </div>

            <div className="flex items-center justify-between text-xs text-white">
              <span className="text-zinc-300 font-medium">အလျော်ဆ</span>
              <span className="text-sm font-extrabold text-[#FFCC00] font-mono">
                {bet.multiplier} ဆ
              </span>
            </div>

            <div className="pt-2 border-t border-amber-500/30 flex items-center justify-between">
              <span className="text-sm sm:text-base font-extrabold text-[#FFCC00]">
                စုစုပေါင်း ထိုးငွေ
              </span>
              <div className="text-right">
                <span className="text-xl sm:text-2xl font-black text-[#FFCC00] font-mono tracking-tight">
                  {bet.totalAmount.toLocaleString()}
                </span>
                <span className="text-sm font-bold text-[#FFCC00] ml-1.5">Ks</span>
              </div>
            </div>
          </div>

          <div className="border-b border-dashed border-zinc-800 my-4" />

          <div className="text-center mt-1 pb-1">
            <p className="text-[9px] font-mono uppercase tracking-widest text-zinc-500 font-medium">
              AUTHENTICATED DIGITAL BETTING TICKET • THANK YOU & GOOD LUCK
            </p>
          </div>
        </div>

        <div className="w-full mt-3 grid grid-cols-2 gap-2">
          <button
            type="button"
            onClick={handleCopyVoucher}
            className="py-2.5 px-3 rounded-xl bg-zinc-900 border border-zinc-700 hover:border-[#FFCC00] text-xs font-bold text-white flex items-center justify-center gap-1.5 transition active:scale-95"
          >
            {copied ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span className="text-emerald-400">Copied!</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5 text-[#FFCC00]" />
                <span>Copy Voucher</span>
              </>
            )}
          </button>

          <button
            type="button"
            onClick={handlePrint}
            className="py-2.5 px-3 rounded-xl bg-[#FFCC00] hover:bg-[#ffc107] text-xs font-extrabold text-black flex items-center justify-center gap-1.5 transition active:scale-95 shadow"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print Receipt</span>
          </button>
        </div>
      </div>
    </div>
  );
}
