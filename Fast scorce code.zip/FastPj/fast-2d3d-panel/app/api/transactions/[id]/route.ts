import { NextRequest, NextResponse } from 'next/server';
import { sql, ensureTablesExist } from '@/lib/db';
import { getSession } from '@/lib/session';
import { createNotification } from '@/lib/notifications';

interface RouteContext {
  params: Promise<{ id: string }>;
}

export async function PATCH(req: NextRequest, ctx: RouteContext) {
  try {
    await ensureTablesExist();
    const session = await getSession();
    if (!session || session.kind !== 'admin') {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const { id } = await ctx.params;
    const body = await req.json();
    const action = body.action;

    if (action !== 'approve' && action !== 'reject') {
      return NextResponse.json({ success: false, error: 'Invalid action' }, { status: 400 });
    }

    const rows = await sql`
      SELECT id, uid, type, amount, status FROM transactions WHERE id = ${id} LIMIT 1;
    `;
    if (!rows || rows.length === 0) {
      return NextResponse.json({ success: false, error: 'Transaction not found' }, { status: 404 });
    }
    const tx = rows[0] as { id: string; uid: string; type: string; amount: string | number; status: string | null };

    if (tx.status !== 'pending') {
      return NextResponse.json({ success: false, error: 'Transaction already processed' }, { status: 409 });
    }

    if (action === 'reject') {
      const updated = await sql`
        UPDATE transactions SET status = 'rejected', slip_image = NULL
        WHERE id = ${id} AND status = 'pending'
        RETURNING id;
      `;
      if (!updated || updated.length === 0) {
        return NextResponse.json({ success: false, error: 'Transaction already processed' }, { status: 409 });
      }
      await createNotification({
        targetType: 'user',
        targetId: tx.uid,
        type: 'transaction',
        title: 'တောင်းဆိုမှု ပယ်ဖျက်ခဲ့ပါသည်',
        message: `သင့် ${Number(tx.amount).toLocaleString()} MMK ${tx.type === 'deposit' ? 'ငွေသွင်း' : 'ငွေထုတ်'} တောင်းဆိုမှုကို ပယ်ဖျက်ခဲ့ပါသည်။`,
        data: { screen: 'wallet' },
      });
      return NextResponse.json({ success: true, data: { id, status: 'rejected' } });
    }

    const amount = Number(tx.amount);

    const claimed = await sql`
      UPDATE transactions SET status = 'approved', slip_image = NULL
      WHERE id = ${id} AND status = 'pending'
      RETURNING id;
    `;
    if (!claimed || claimed.length === 0) {
      return NextResponse.json({ success: false, error: 'Transaction already processed' }, { status: 409 });
    }

    if (tx.type === 'withdraw') {
      const updated = await sql`
        UPDATE users SET balance = balance - ${amount}, updated_at = NOW()
        WHERE uid = ${tx.uid} AND balance >= ${amount}
        RETURNING balance;
      `;
      if (!updated || updated.length === 0) {

        await sql`UPDATE transactions SET status = 'pending' WHERE id = ${id};`;
        return NextResponse.json({ success: false, error: 'Insufficient balance' }, { status: 400 });
      }
    } else {
      await sql`
        UPDATE users SET balance = balance + ${amount}, updated_at = NOW()
        WHERE uid = ${tx.uid};
      `;
    }

    await createNotification({
      targetType: 'user',
      targetId: tx.uid,
      type: 'transaction',
      title: tx.type === 'withdraw' ? 'ငွေထုတ်မှု အတည်ပြုပြီးပါပြီ' : 'ငွေသွင်းမှု အတည်ပြုပြီးပါပြီ',
      message: `သင့် ${amount.toLocaleString()} MMK ${tx.type === 'deposit' ? 'ငွေသွင်း' : 'ငွေထုတ်'} ကို အတည်ပြုပြီးပါပြီ။`,
      data: { screen: 'wallet' },
    });

    return NextResponse.json({ success: true, data: { id, status: 'approved' } });
  } catch (error: unknown) {
    console.error('Process transaction failed:', error);
    return NextResponse.json({ success: false, error: 'Process transaction failed' }, { status: 500 });
  }
}
