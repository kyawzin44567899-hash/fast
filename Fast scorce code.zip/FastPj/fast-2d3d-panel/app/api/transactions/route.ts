import { NextRequest, NextResponse } from 'next/server';
import { sql, ensureTablesExist } from '@/lib/db';
import { getSession } from '@/lib/session';

function mapStatus(status: string | null): 'pending' | 'approved' | 'rejected' {
  if (status === 'pending') return 'pending';
  if (status === 'rejected') return 'rejected';
  return 'approved';
}

export async function GET(req: NextRequest) {
  try {
    await ensureTablesExist();
    const session = await getSession();
    if (!session || (session.kind !== 'admin' && session.kind !== 'agent')) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const scopedAgentCode = session.kind === 'agent' ? session.code : null;
    const search = (req.nextUrl.searchParams.get('search') || '').trim();
    const like = `%${search}%`;

    const rows = await sql`
      SELECT t.id, t.uid, t.type, t.amount, t.method, t.transaction_number, t.order_number,
             t.status, t.timestamp, t.slip_image, u.name AS user_name, u.phone AS user_phone,
             u.agent_code
      FROM transactions t
      LEFT JOIN users u ON u.uid = t.uid
      WHERE (${scopedAgentCode}::text IS NULL OR u.agent_code = ${scopedAgentCode})
        AND (
          ${search} = ''
          OR t.order_number ILIKE ${like}
          OR t.uid ILIKE ${like}
          OR u.name ILIKE ${like}
          OR u.phone ILIKE ${like}
        )
      ORDER BY t.created_at DESC
      LIMIT 500;
    `;

    const transactions = (rows || []).map((r) => {
      const row = r as Record<string, unknown>;
      return {
        id: String(row.id),
        userUid: String(row.uid),
        agentCode: row.agent_code ? String(row.agent_code) : '',
        userName: row.user_name ? String(row.user_name) : 'Unknown',
        userPhone: row.user_phone ? String(row.user_phone) : '',
        type: row.type === 'withdraw' ? 'withdraw' : 'deposit',
        amount: Number(row.amount),
        method: String(row.method || 'Direct'),
        refNumber: row.transaction_number ? String(row.transaction_number) : '',
        orderNumber: row.order_number ? String(row.order_number) : '',
        dateTime: String(row.timestamp || ''),
        status: mapStatus(row.status as string | null),
        slipUrl: row.slip_image ? String(row.slip_image) : '',
      };
    });

    return NextResponse.json({ success: true, data: transactions });
  } catch (error: unknown) {
    console.error('Fetch transactions failed:', error);
    return NextResponse.json({ success: false, error: 'Fetch transactions failed' }, { status: 500 });
  }
}
