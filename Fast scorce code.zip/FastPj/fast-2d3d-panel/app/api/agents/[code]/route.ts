import { NextRequest, NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';
import { sql, ensureTablesExist } from '@/lib/db';
import { getSession } from '@/lib/session';

interface RouteContext {
  params: Promise<{ code: string }>;
}

function serializeAgent(row: Record<string, unknown>) {
  return {
    id: String(row.id),
    name: String(row.name),
    code: String(row.code),
    email: row.email ? String(row.email) : '',
    phone: row.phone ? String(row.phone) : '',
    secretKey: '',
    commission: Number(row.commission || 0),
    membersCount: Number(row.members_count || 0),
    balance: Number(row.balance || 0),
    status: (row.status as string) === 'suspended' ? 'suspended' : 'active',
    createdAt: row.created_at ? new Date(row.created_at as string).toISOString().slice(0, 10) : '',
  };
}

async function loadAgent(code: string) {
  const rows = await sql`
    SELECT a.id, a.name, a.code, a.email, a.phone, a.commission, a.balance, a.status, a.created_at,
           (SELECT COUNT(*)::int FROM users u WHERE u.agent_code = a.code) AS members_count
    FROM agents a WHERE a.code = ${code} LIMIT 1;
  `;
  return rows && rows.length > 0 ? (rows[0] as Record<string, unknown>) : null;
}

export async function PATCH(req: NextRequest, ctx: RouteContext) {
  try {
    await ensureTablesExist();
    const session = await getSession();
    if (!session || session.kind !== 'admin') {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const { code } = await ctx.params;
    const existing = await loadAgent(code);
    if (!existing) {
      return NextResponse.json({ success: false, error: 'Agent not found' }, { status: 404 });
    }

    const body = await req.json();
    const { name, email, phone, secretKey, commission, status, balance } = body;

    if (name !== undefined) {
      await sql`UPDATE agents SET name = ${String(name).trim()}, updated_at = NOW() WHERE code = ${code};`;
    }
    if (email !== undefined) {
      const cleanEmail = email ? String(email).trim().toLowerCase() : null;
      if (cleanEmail) {
        const dupe = await sql`SELECT code FROM agents WHERE email = ${cleanEmail} AND code <> ${code} LIMIT 1;`;
        if (dupe && dupe.length > 0) {
          return NextResponse.json({ success: false, error: 'Email already in use' }, { status: 409 });
        }
      }
      await sql`UPDATE agents SET email = ${cleanEmail}, updated_at = NOW() WHERE code = ${code};`;
    }
    if (phone !== undefined) {
      await sql`UPDATE agents SET phone = ${phone ? String(phone).trim() : null}, updated_at = NOW() WHERE code = ${code};`;
    }
    if (secretKey !== undefined && String(secretKey).trim().length > 0) {
      const hash = await bcrypt.hash(String(secretKey).trim(), 10);
      await sql`UPDATE agents SET secret_key_hash = ${hash}, updated_at = NOW() WHERE code = ${code};`;
    }
    if (commission !== undefined && Number.isFinite(Number(commission))) {
      await sql`UPDATE agents SET commission = ${Number(commission)}, updated_at = NOW() WHERE code = ${code};`;
    }
    if (status !== undefined) {
      const nextStatus = status === 'suspended' ? 'suspended' : 'active';
      await sql`UPDATE agents SET status = ${nextStatus}, updated_at = NOW() WHERE code = ${code};`;
    }
    if (balance !== undefined && Number.isFinite(Number(balance))) {
      await sql`UPDATE agents SET balance = GREATEST(${Number(balance)}, 0), updated_at = NOW() WHERE code = ${code};`;
    }

    const updated = await loadAgent(code);
    return NextResponse.json({ success: true, data: serializeAgent(updated!) });
  } catch (error: unknown) {
    console.error('Update agent failed:', error);
    return NextResponse.json({ success: false, error: 'Update agent failed' }, { status: 500 });
  }
}

export async function DELETE(_req: NextRequest, ctx: RouteContext) {
  try {
    await ensureTablesExist();
    const session = await getSession();
    if (!session || session.kind !== 'admin') {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const { code } = await ctx.params;
    const existing = await loadAgent(code);
    if (!existing) {
      return NextResponse.json({ success: false, error: 'Agent not found' }, { status: 404 });
    }

    const agentId = String((existing as { id: number }).id);

    await sql`DELETE FROM otp_codes WHERE target_type = 'agent' AND target_id = ${agentId};`;
    await sql`DELETE FROM sessions WHERE kind = 'agent' AND subject_id = ${code};`;
    await sql`DELETE FROM login_history WHERE actor_type = 'agent' AND actor_id = ${code};`;
    await sql`DELETE FROM push_subscriptions WHERE target_type = 'agent' AND target_id = ${code};`;
    await sql`UPDATE users SET agent_code = NULL, updated_at = NOW() WHERE agent_code = ${code};`;
    await sql`DELETE FROM agents WHERE code = ${code};`;

    return NextResponse.json({ success: true, data: { code } });
  } catch (error: unknown) {
    console.error('Delete agent failed:', error);
    return NextResponse.json({ success: false, error: 'Delete agent failed' }, { status: 500 });
  }
}
