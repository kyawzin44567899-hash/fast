import { NextRequest, NextResponse } from 'next/server';
import { sql, ensureTablesExist } from '@/lib/db';
import { getSession } from '@/lib/session';
import { backfillWinSettlements } from '@/lib/commission';
import { computeAgentTotals } from '@/lib/payout';

export async function GET(req: NextRequest) {
  try {
    await ensureTablesExist();
    const session = await getSession();
    if (!session || (session.kind !== 'admin' && session.kind !== 'agent')) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    await backfillWinSettlements();

    const requested = (req.nextUrl.searchParams.get('code') || '').trim();
    const code = session.kind === 'agent' ? session.code || '' : requested;
    if (!code) {
      return NextResponse.json({ success: false, error: 'Agent code required' }, { status: 400 });
    }

    const agentRows = await sql`
      SELECT id, name, code, email, phone, commission, balance, status, created_at
      FROM agents WHERE code = ${code} LIMIT 1;
    `;
    if (!agentRows || agentRows.length === 0) {
      return NextResponse.json({ success: false, error: 'Agent not found' }, { status: 404 });
    }
    const agent = agentRows[0] as Record<string, unknown>;
    const agentPercent = Math.max(0, Math.min(100, Number(agent.commission) || 0));

    const totalsRows = await sql`
      SELECT
        (SELECT COUNT(*)::int FROM users u WHERE u.agent_code = ${code}) AS members_count,
        (SELECT COALESCE(SUM(b.amount), 0) FROM bets b JOIN users u ON u.uid = b.uid WHERE u.agent_code = ${code}) AS total_bet,
        (SELECT COALESCE(SUM(b.win_amount), 0) FROM bets b JOIN users u ON u.uid = b.uid
           WHERE u.agent_code = ${code} AND b.status IN ('win', 'TOOD_WIN')) AS total_win,
        (SELECT COALESCE(SUM(b.amount), 0) FROM bets b JOIN users u ON u.uid = b.uid
           WHERE u.agent_code = ${code} AND b.status = 'lose') AS total_loss,
        (SELECT COALESCE(SUM(w.gross_payout), 0) FROM win_settlements w WHERE w.agent_code = ${code}) AS gross_payout,
        (SELECT COALESCE(SUM(w.paid_amount), 0) FROM win_settlements w WHERE w.agent_code = ${code}) AS paid_amount,
        (SELECT COALESCE(SUM(w.remaining_amount), 0) FROM win_settlements w WHERE w.agent_code = ${code}) AS remaining_amount,
        (SELECT COUNT(*)::int FROM win_settlements w WHERE w.agent_code = ${code} AND w.payment_status = 'pending') AS pending_count,
        (SELECT COUNT(*)::int FROM win_settlements w WHERE w.agent_code = ${code} AND w.payment_status = 'unpaid') AS unpaid_count,
        (SELECT COUNT(*)::int FROM win_settlements w WHERE w.agent_code = ${code} AND w.payment_status = 'partial') AS partial_count,
        (SELECT COUNT(*)::int FROM win_settlements w WHERE w.agent_code = ${code} AND w.payment_status = 'paid') AS paid_count;
    `;
    const t = (totalsRows?.[0] || {}) as Record<string, unknown>;

    const totals = computeAgentTotals({
      totalBet: Number(t.total_bet || 0),
      totalWin: Number(t.total_win || 0),
      totalLoss: Number(t.total_loss || 0),
      agentPercent,
    });

    return NextResponse.json({
      success: true,
      data: {
        agent: {
          id: String(agent.id),
          name: String(agent.name),
          code: String(agent.code),
          email: agent.email ? String(agent.email) : '',
          phone: agent.phone ? String(agent.phone) : '',
          commission: agentPercent,
          balance: Number(agent.balance || 0),
          status: (agent.status as string) === 'suspended' ? 'suspended' : 'active',
          membersCount: Number(t.members_count || 0),
        },
        totals,
        payments: {
          grossPayout: Number(t.gross_payout || 0),
          paidAmount: Number(t.paid_amount || 0),
          remainingAmount: Number(t.remaining_amount || 0),
          pendingCount: Number(t.pending_count || 0),
          unpaidCount: Number(t.unpaid_count || 0),
          partialCount: Number(t.partial_count || 0),
          paidCount: Number(t.paid_count || 0),
        },
      },
    });
  } catch (error: unknown) {
    console.error('Fetch agent summary failed:', error);
    return NextResponse.json({ success: false, error: 'Fetch agent summary failed' }, { status: 500 });
  }
}
