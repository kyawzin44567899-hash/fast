import { NextRequest, NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';
import { sql, ensureTablesExist } from '@/lib/db';
import { getSession } from '@/lib/session';

function serializeAgent(row: Record<string, unknown>) {
  return {
    id: String(row.id),
    name: String(row.name),
    code: String(row.code),
    email: row.email ? String(row.email) : '',
    phone: row.phone ? String(row.phone) : '',
    secretKey: '',
    commission: Number(row.commission || 0),
    membersCount: Number(row.members_count || 0),
    balance: Number(row.balance || 0),
    status: (row.status as string) === 'suspended' ? 'suspended' : 'active',
    createdAt: row.created_at ? new Date(row.created_at as string).toISOString().slice(0, 10) : '',
  };
}

export async function GET() {
  try {
    await ensureTablesExist();
    const session = await getSession();
    if (!session || session.kind !== 'admin') {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const rows = await sql`
      SELECT a.id, a.name, a.code, a.email, a.phone, a.commission, a.balance, a.status, a.created_at,
             (SELECT COUNT(*)::int FROM users u WHERE u.agent_code = a.code) AS members_count
      FROM agents a
      ORDER BY a.created_at DESC
      LIMIT 500;
    `;

    return NextResponse.json({
      success: true,
      data: (rows || []).map((r) => serializeAgent(r as Record<string, unknown>)),
    });
  } catch (error: unknown) {
    console.error('Fetch agents failed:', error);
    return NextResponse.json({ success: false, error: 'Fetch agents failed' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    await ensureTablesExist();
    const session = await getSession();
    if (!session || session.kind !== 'admin') {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const body = await req.json();
    const { name, code, email, phone, secretKey, commission } = body;

    if (!name || !code || !secretKey) {
      return NextResponse.json(
        { success: false, error: 'Name, code and secret key are required' },
        { status: 400 }
      );
    }

    const cleanCode = String(code).trim();
    const cleanEmail = email ? String(email).trim().toLowerCase() : null;
    const cleanPhone = phone ? String(phone).trim() : null;

    const dupe = await sql`SELECT id FROM agents WHERE code = ${cleanCode} LIMIT 1;`;
    if (dupe && dupe.length > 0) {
      return NextResponse.json({ success: false, error: 'Agent code already exists' }, { status: 409 });
    }

    const hash = await bcrypt.hash(String(secretKey), 10);
    const rows = await sql`
      INSERT INTO agents (code, name, email, phone, secret_key_hash, commission, balance, status)
      VALUES (${cleanCode}, ${String(name).trim()}, ${cleanEmail}, ${cleanPhone}, ${hash},
              ${Number(commission) || 0}, 0.00, 'active')
      RETURNING id, name, code, email, phone, commission, balance, status, created_at;
    `;

    const agent = serializeAgent({ ...(rows[0] as Record<string, unknown>), members_count: 0 });
    return NextResponse.json({ success: true, data: agent });
  } catch (error: unknown) {
    console.error('Create agent failed:', error);
    return NextResponse.json({ success: false, error: 'Create agent failed' }, { status: 500 });
  }
}
