import { NextResponse } from 'next/server';
import { sql, ensureTablesExist } from '@/lib/db';
import { getSession } from '@/lib/session';

export async function GET() {
  try {
    await ensureTablesExist();
    const session = await getSession();
    if (!session || (session.kind !== 'admin' && session.kind !== 'agent')) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const actorType = session.kind;
    const actorId = session.kind === 'agent' ? session.code || '' : String(session.id);

    const rows = await sql`
      SELECT id, actor_type, actor_id, actor_name, device, ip, created_at
      FROM login_history
      WHERE actor_type = ${actorType} AND actor_id = ${actorId}
      ORDER BY created_at DESC
      LIMIT 30;
    `;

    return NextResponse.json({ success: true, data: rows || [] });
  } catch (error) {
    console.error('Fetch login history failed:', error);
    return NextResponse.json({ success: false, error: 'Failed' }, { status: 500 });
  }
}
