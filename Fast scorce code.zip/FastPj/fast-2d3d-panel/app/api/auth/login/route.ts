import { NextRequest, NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';
import { sql, ensureTablesExist, ensureDefaultAdmin } from '@/lib/db';
import { setSession } from '@/lib/session';
import { recordLogin } from '@/lib/loginHistory';

export async function POST(req: NextRequest) {
  try {
    await ensureTablesExist();
    const body = await req.json();
    const { role, email, secretKey } = body;

    if (role && role !== 'admin') {
      return NextResponse.json(
        { success: false, error: 'Agents must sign in with an Email OTP' },
        { status: 400 }
      );
    }
    if (!email || !secretKey) {
      return NextResponse.json(
        { success: false, error: 'Email and secret key are required' },
        { status: 400 }
      );
    }

    const cleanEmail = String(email).trim().toLowerCase();
    await ensureDefaultAdmin();

    const rows = await sql`
      SELECT id, email, name, secret_key_hash FROM admins WHERE email = ${cleanEmail} LIMIT 1;
    `;
    if (!rows || rows.length === 0) {
      return NextResponse.json({ success: false, error: 'Invalid credentials' }, { status: 401 });
    }
    const admin = rows[0] as {
      id: number;
      email: string;
      name: string;
      secret_key_hash: string;
    };
    const match = await bcrypt.compare(String(secretKey), admin.secret_key_hash);
    if (!match) {
      return NextResponse.json({ success: false, error: 'Invalid credentials' }, { status: 401 });
    }

    await setSession({ kind: 'admin', id: admin.id, name: admin.name, email: admin.email });
    await recordLogin(req, 'admin', String(admin.id), admin.name);
    return NextResponse.json({
      success: true,
      user: { role: 'admin', name: admin.name, email: admin.email },
    });
  } catch (error: unknown) {
    console.error('Admin login error:', error);
    return NextResponse.json({ success: false, error: 'Login failed' }, { status: 500 });
  }
}
