import { NextRequest, NextResponse } from 'next/server';
import { sql, ensureTablesExist } from '@/lib/db';
import { verifyAgentOtp } from '@/lib/otp';
import { setSession } from '@/lib/session';
import { recordLogin } from '@/lib/loginHistory';

const ERROR_MESSAGES: Record<string, string> = {
  not_found: 'OTP not found. Please request a new code.',
  expired: 'OTP has expired. Please request a new code.',
  locked: 'Too many attempts. Please request a new code.',
  invalid: 'Invalid OTP. Please try again.',
};

export async function POST(req: NextRequest) {
  try {
    await ensureTablesExist();
    const body = await req.json();
    const email = body?.email ? String(body.email).trim().toLowerCase() : '';
    const otp = body?.otp ? String(body.otp).trim() : '';

    if (!email || !otp) {
      return NextResponse.json({ success: false, error: 'Email and OTP are required' }, { status: 400 });
    }
    if (!/^\d{6}$/.test(otp)) {
      return NextResponse.json({ success: false, error: 'Invalid OTP' }, { status: 400 });
    }

    const result = await verifyAgentOtp(email, otp);
    if (!result.ok) {
      const status = result.error === 'invalid' ? 401 : 400;
      return NextResponse.json(
        { success: false, error: ERROR_MESSAGES[result.error || 'invalid'] || 'Verification failed' },
        { status }
      );
    }

    const rows = await sql`
      SELECT id, code, name, email, status FROM agents WHERE id = ${result.agentId} LIMIT 1;
    `;
    if (!rows || rows.length === 0) {
      return NextResponse.json({ success: false, error: 'Agent account not found' }, { status: 404 });
    }
    const agent = rows[0] as {
      id: number;
      code: string;
      name: string;
      email: string | null;
      status: string | null;
    };
    if ((agent.status || 'active') !== 'active') {
      return NextResponse.json({ success: false, error: 'Agent account is suspended' }, { status: 403 });
    }

    await setSession({
      kind: 'agent',
      id: agent.id,
      code: agent.code,
      name: agent.name,
      email: agent.email || undefined,
    });
    await recordLogin(req, 'agent', agent.code, agent.name);

    return NextResponse.json({
      success: true,
      user: { role: 'agent', name: agent.name, code: agent.code, email: agent.email },
    });
  } catch (error) {
    console.error('Verify agent OTP failed:', error);
    return NextResponse.json({ success: false, error: 'Verification failed' }, { status: 500 });
  }
}
