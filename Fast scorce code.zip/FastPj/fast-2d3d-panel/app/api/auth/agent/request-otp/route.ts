import { NextRequest, NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';
import { sql, ensureTablesExist } from '@/lib/db';
import { createAgentOtp } from '@/lib/otp';
import { sendAgentOtpEmail } from '@/lib/email';

export async function POST(req: NextRequest) {
  try {
    await ensureTablesExist();
    const body = await req.json();
    const email = body?.email ? String(body.email).trim().toLowerCase() : '';
    const agentCode = body?.agentCode ? String(body.agentCode).trim().toUpperCase() : '';
    const phone = body?.phone ? String(body.phone).trim() : '';
    const secretKey = body?.secretKey ? String(body.secretKey) : '';

    if (!email || !email.includes('@')) {
      return NextResponse.json({ success: false, error: 'Valid email is required' }, { status: 400 });
    }
    if (!agentCode || !phone || !secretKey) {
      return NextResponse.json(
        { success: false, error: 'Agent ID, phone and secret key are required' },
        { status: 400 }
      );
    }

    const rows = await sql`
      SELECT id, email, name, code, phone, secret_key_hash, status
      FROM agents
      WHERE LOWER(email) = ${email}
      LIMIT 1;
    `;
    if (!rows || rows.length === 0) {
      return NextResponse.json({ success: false, error: 'Invalid agent credentials' }, { status: 401 });
    }
    const agent = rows[0] as {
      id: number;
      email: string;
      name: string;
      code: string;
      phone: string | null;
      secret_key_hash: string;
      status: string | null;
    };

    if ((agent.status || 'active') !== 'active') {
      return NextResponse.json({ success: false, error: 'Agent account is suspended' }, { status: 403 });
    }
    if (String(agent.code).toUpperCase() !== agentCode) {
      return NextResponse.json({ success: false, error: 'Invalid agent credentials' }, { status: 401 });
    }
    if (!agent.phone || String(agent.phone).trim() !== phone) {
      return NextResponse.json({ success: false, error: 'Invalid agent credentials' }, { status: 401 });
    }
    const secretMatch = await bcrypt.compare(secretKey, agent.secret_key_hash);
    if (!secretMatch) {
      return NextResponse.json({ success: false, error: 'Invalid agent credentials' }, { status: 401 });
    }

    const result = await createAgentOtp(agent.id, email, agent.name);
    if (!result.ok) {
      if (result.error === 'cooldown') {
        return NextResponse.json(
          { success: false, error: 'Please wait before requesting another OTP' },
          { status: 429 }
        );
      }
      return NextResponse.json(
        { success: false, error: 'Too many OTP requests. Try again later.' },
        { status: 429 }
      );
    }

    const sent = await sendAgentOtpEmail(email, result.otp as string, agent.name, result.expiresInMinutes);
    if (!sent) {
      return NextResponse.json(
        { success: false, error: 'Unable to send OTP email. Please try again later.' },
        { status: 502 }
      );
    }

    return NextResponse.json({ success: true, data: { email, expiresInSeconds: 600 } });
  } catch (error) {
    console.error('Request agent OTP failed:', error);
    return NextResponse.json({ success: false, error: 'Request failed' }, { status: 500 });
  }
}
