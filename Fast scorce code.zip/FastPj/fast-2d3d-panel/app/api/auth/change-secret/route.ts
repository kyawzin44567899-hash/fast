import { NextRequest, NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';
import { sql, ensureTablesExist } from '@/lib/db';
import { getSession } from '@/lib/session';

export async function POST(req: NextRequest) {
  try {
    await ensureTablesExist();
    const session = await getSession();
    if (!session || session.kind !== 'admin') {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const body = await req.json();
    const currentSecret = String(body?.currentSecret || '');
    const newSecret = String(body?.newSecret || '');

    if (!currentSecret || !newSecret) {
      return NextResponse.json(
        { success: false, error: 'Current and new secret key are required' },
        { status: 400 }
      );
    }
    if (newSecret.length < 4) {
      return NextResponse.json(
        { success: false, error: 'New secret key must be at least 4 characters' },
        { status: 400 }
      );
    }

    const rows = await sql`
      SELECT secret_key_hash FROM admins WHERE id = ${session.id} LIMIT 1;
    `;
    if (!rows || rows.length === 0) {
      return NextResponse.json({ success: false, error: 'Admin not found' }, { status: 404 });
    }

    const match = await bcrypt.compare(currentSecret, (rows[0] as { secret_key_hash: string }).secret_key_hash);
    if (!match) {
      return NextResponse.json({ success: false, error: 'Current secret key is incorrect' }, { status: 401 });
    }

    const hash = await bcrypt.hash(newSecret, 10);
    await sql`UPDATE admins SET secret_key_hash = ${hash} WHERE id = ${session.id};`;

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Change secret failed:', error);
    return NextResponse.json({ success: false, error: 'Failed' }, { status: 500 });
  }
}
