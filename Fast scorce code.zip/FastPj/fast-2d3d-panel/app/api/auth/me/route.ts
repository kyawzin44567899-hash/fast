import { NextResponse } from 'next/server';
import { sql, ensureTablesExist } from '@/lib/db';
import { getSession } from '@/lib/session';

export async function GET() {
  await ensureTablesExist();
  const session = await getSession();
  if (!session) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  let agent: Record<string, unknown> | null = null;
  if (session.kind === 'agent' && session.code) {
    const rows = await sql`
      SELECT a.id, a.name, a.code, a.email, a.phone, a.commission, a.balance, a.status, a.created_at,
             (SELECT COUNT(*)::int FROM users u WHERE u.agent_code = a.code) AS members_count
      FROM agents a WHERE a.code = ${session.code} LIMIT 1;
    `;
    if (rows && rows.length > 0) {
      const row = rows[0] as Record<string, unknown>;
      agent = {
        id: String(row.id),
        name: String(row.name),
        code: String(row.code),
        email: row.email ? String(row.email) : '',
        phone: row.phone ? String(row.phone) : '',
        secretKey: '',
        commission: Number(row.commission || 0),
        membersCount: Number(row.members_count || 0),
        balance: Number(row.balance || 0),
        status: (row.status as string) === 'suspended' ? 'suspended' : 'active',
        createdAt: row.created_at
          ? new Date(row.created_at as string).toISOString().slice(0, 10)
          : '',
      };
    }
  }

  return NextResponse.json({
    user: {
      kind: session.kind,
      id: session.id,
      name: session.name,
      email: session.email,
      code: session.code,
    },
    agent,
  });
}
