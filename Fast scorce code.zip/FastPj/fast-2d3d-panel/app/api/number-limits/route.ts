import { NextRequest, NextResponse } from 'next/server';
import { sql, ensureTablesExist } from '@/lib/db';
import { getSession } from '@/lib/session';

type NumberType = '2D' | '3D';

function normalizeType(value: string | null): NumberType {
  return value === '3D' ? '3D' : '2D';
}

function widthFor(type: NumberType): number {
  return type === '2D' ? 2 : 3;
}

interface BetItemLike {
  number?: string;
  amount?: number;
  subNumbers?: { number: string; amount: number }[];
}

async function ensureRows(type: NumberType) {
  if (type === '2D') {
    await sql`
      INSERT INTO number_limits (number, type, max_bet_count, is_blocked)
      SELECT LPAD(g::text, 2, '0'), '2D', 100, false
      FROM generate_series(0, 99) AS g
      ON CONFLICT (number) DO NOTHING;
    `;
  } else {
    await sql`
      INSERT INTO number_limits (number, type, max_bet_count, is_blocked)
      SELECT LPAD(g::text, 3, '0'), '3D', 100, false
      FROM generate_series(0, 999) AS g
      ON CONFLICT (number) DO NOTHING;
    `;
  }
}

async function computeTodayCounts(type: NumberType): Promise<Record<string, number>> {
  const counts: Record<string, number> = {};
  const width = widthFor(type);
  const rows = await sql`
    SELECT items FROM bets
    WHERE type = ${type} AND created_at >= CURRENT_DATE;
  `;
  for (const r of rows || []) {
    let items: unknown = (r as { items: unknown }).items;
    if (typeof items === 'string') {
      try {
        items = JSON.parse(items);
      } catch {
        items = [];
      }
    }
    if (!Array.isArray(items)) continue;
    for (const it of items as BetItemLike[]) {
      const subs = it.subNumbers && it.subNumbers.length > 0 ? it.subNumbers : [{ number: it.number }];
      for (const s of subs) {
        const key = String(s.number || '').padStart(width, '0');
        if (key) counts[key] = (counts[key] || 0) + 1;
      }
    }
  }
  return counts;
}

async function computeTodayAmounts(type: NumberType): Promise<Record<string, number>> {
  const amounts: Record<string, number> = {};
  const width = widthFor(type);
  const rows = await sql`
    SELECT items FROM bets
    WHERE type = ${type} AND created_at >= CURRENT_DATE;
  `;
  for (const r of rows || []) {
    let items: unknown = (r as { items: unknown }).items;
    if (typeof items === 'string') {
      try {
        items = JSON.parse(items);
      } catch {
        items = [];
      }
    }
    if (!Array.isArray(items)) continue;
    for (const it of items as BetItemLike[]) {
      const subs =
        it.subNumbers && it.subNumbers.length > 0
          ? it.subNumbers
          : [{ number: it.number, amount: it.amount }];
      for (const s of subs) {
        const key = String(s.number || '').padStart(width, '0');
        if (key) amounts[key] = (amounts[key] || 0) + Number(s.amount || 0);
      }
    }
  }
  return amounts;
}

export async function GET(req: NextRequest) {
  try {
    await ensureTablesExist();
    const session = await getSession();
    if (!session || (session.kind !== 'admin' && session.kind !== 'agent')) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const type = normalizeType(new URL(req.url).searchParams.get('type'));
    await ensureRows(type);

    const rows = await sql`
      SELECT number, max_bet_count, max_bet_amount, is_blocked FROM number_limits
      WHERE type = ${type}
      ORDER BY number;
    `;
    const counts = await computeTodayCounts(type);
    const amounts = await computeTodayAmounts(type);
    const width = widthFor(type);

    const data = (rows || []).map((r) => {
      const row = r as {
        number: string;
        max_bet_count: number;
        max_bet_amount: string | number;
        is_blocked: boolean;
      };
      const number = String(row.number).padStart(width, '0');
      return {
        number,
        maxBetCount: Number(row.max_bet_count),
        maxBetAmount: Number(row.max_bet_amount || 0),
        currentBetCount: counts[number] || 0,
        currentBetAmount: amounts[number] || 0,
        isBlocked: Boolean(row.is_blocked),
      };
    });

    return NextResponse.json({ success: true, data });
  } catch (error) {
    console.error('Fetch number limits failed:', error);
    return NextResponse.json({ success: false, error: 'Failed' }, { status: 500 });
  }
}

export async function PUT(req: NextRequest) {
  try {
    await ensureTablesExist();
    const session = await getSession();
    if (!session || session.kind !== 'admin') {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const body = await req.json();
    const type = normalizeType(body.type ?? null);
    const width = widthFor(type);
    await ensureRows(type);

    if (body.applyAll !== undefined) {
      const max = Number(body.applyAll);
      if (!Number.isFinite(max) || max <= 0) {
        return NextResponse.json({ success: false, error: 'Invalid limit' }, { status: 400 });
      }
      await sql`UPDATE number_limits SET max_bet_count = ${max}, updated_at = NOW() WHERE type = ${type};`;
      return NextResponse.json({ success: true });
    }

    if (body.applyAllAmount !== undefined) {
      const maxAmount = Number(body.applyAllAmount);
      if (!Number.isFinite(maxAmount) || maxAmount < 0) {
        return NextResponse.json({ success: false, error: 'Invalid amount limit' }, { status: 400 });
      }
      await sql`UPDATE number_limits SET max_bet_amount = ${maxAmount}, updated_at = NOW() WHERE type = ${type};`;
      return NextResponse.json({ success: true });
    }

    const number = String(body.number || '').padStart(width, '0');
    const pattern = type === '2D' ? /^\d{2}$/ : /^\d{3}$/;
    if (!pattern.test(number)) {
      return NextResponse.json({ success: false, error: 'Invalid number' }, { status: 400 });
    }

    if (body.maxBetCount !== undefined) {
      const max = Number(body.maxBetCount);
      if (!Number.isFinite(max) || max <= 0) {
        return NextResponse.json({ success: false, error: 'Invalid limit' }, { status: 400 });
      }
      await sql`UPDATE number_limits SET max_bet_count = ${max}, updated_at = NOW() WHERE number = ${number} AND type = ${type};`;
    }
    if (body.maxBetAmount !== undefined) {
      const maxAmount = Number(body.maxBetAmount);
      if (!Number.isFinite(maxAmount) || maxAmount < 0) {
        return NextResponse.json({ success: false, error: 'Invalid amount limit' }, { status: 400 });
      }
      await sql`UPDATE number_limits SET max_bet_amount = ${maxAmount}, updated_at = NOW() WHERE number = ${number} AND type = ${type};`;
    }
    if (body.isBlocked !== undefined) {
      await sql`UPDATE number_limits SET is_blocked = ${Boolean(body.isBlocked)}, updated_at = NOW() WHERE number = ${number} AND type = ${type};`;
    }

    return NextResponse.json({ success: true, data: { number, type } });
  } catch (error) {
    console.error('Update number limit failed:', error);
    return NextResponse.json({ success: false, error: 'Failed' }, { status: 500 });
  }
}
