import { NextRequest, NextResponse } from 'next/server';
import { sql, ensureTablesExist } from '@/lib/db';
import { getSession } from '@/lib/session';

interface RouteContext {
  params: Promise<{ id: string }>;
}

async function loadSettlement(id: string) {
  const rows = await sql`
    SELECT id, gross_payout, paid_amount, remaining_amount, payment_status
    FROM win_settlements WHERE id = ${id} LIMIT 1;
  `;
  return rows && rows.length > 0 ? (rows[0] as Record<string, unknown>) : null;
}

export async function GET(_req: NextRequest, ctx: RouteContext) {
  try {
    await ensureTablesExist();
    const session = await getSession();
    if (!session || (session.kind !== 'admin' && session.kind !== 'agent')) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }
    const { id } = await ctx.params;

    const rows = await sql`
      SELECT * FROM win_settlements WHERE id = ${id} LIMIT 1;
    `;
    if (!rows || rows.length === 0) {
      return NextResponse.json({ success: false, error: 'Settlement not found' }, { status: 404 });
    }
    const settlement = rows[0] as Record<string, unknown>;
    if (session.kind === 'agent' && String(settlement.agent_code || '') !== (session.code || '')) {
      return NextResponse.json({ success: false, error: 'Forbidden' }, { status: 403 });
    }

    const payments = await sql`
      SELECT id, amount, reference, operator, note, created_at
      FROM settlement_payments WHERE settlement_id = ${id}
      ORDER BY created_at DESC LIMIT 200;
    `;

    return NextResponse.json({ success: true, data: { settlement, payments: payments || [] } });
  } catch (error: unknown) {
    console.error('Fetch settlement failed:', error);
    return NextResponse.json({ success: false, error: 'Fetch settlement failed' }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest, ctx: RouteContext) {
  try {
    await ensureTablesExist();
    const session = await getSession();
    if (!session || session.kind !== 'admin') {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const { id } = await ctx.params;
    const existing = await loadSettlement(id);
    if (!existing) {
      return NextResponse.json({ success: false, error: 'Settlement not found' }, { status: 404 });
    }

    const body = await req.json();
    const action = String(body.action || '');
    const operator = session.name || 'Admin';

    if (action === 'pay') {
      const amount = Number(body.amount);
      if (!Number.isFinite(amount) || amount <= 0) {
        return NextResponse.json({ success: false, error: 'Invalid amount' }, { status: 400 });
      }

      const gross = Number(existing.gross_payout || 0);
      const alreadyPaid = Number(existing.paid_amount || 0);
      const remainingBefore = Math.max(gross - alreadyPaid, 0);
      if (remainingBefore <= 0) {
        return NextResponse.json({ success: false, error: 'Already fully paid' }, { status: 409 });
      }
      const payAmount = Math.min(amount, remainingBefore);
      const newPaid = Math.round((alreadyPaid + payAmount) * 100) / 100;
      const newRemaining = Math.round((gross - newPaid) * 100) / 100;
      const newStatus = newRemaining <= 0 ? 'paid' : 'partial';
      const reference = body.reference ? String(body.reference).trim() : null;
      const note = body.note ? String(body.note).trim() : null;

      await sql`
        INSERT INTO settlement_payments (id, settlement_id, amount, reference, operator, note)
        VALUES (${`pay-${Date.now()}-${Math.floor(Math.random() * 1000)}`}, ${id}, ${payAmount},
                ${reference}, ${operator}, ${note});
      `;

      await sql`
        UPDATE win_settlements
        SET paid_amount = ${newPaid},
            remaining_amount = ${newRemaining},
            payment_status = ${newStatus},
            payment_reference = COALESCE(${reference}, payment_reference),
            operator = ${operator},
            paid_at = NOW(),
            updated_at = NOW()
        WHERE id = ${id};
      `;

      return NextResponse.json({
        success: true,
        data: { paidAmount: newPaid, remainingAmount: newRemaining, paymentStatus: newStatus },
      });
    }

    if (action === 'setStatus') {
      const status = String(body.status || '');
      if (!['pending', 'unpaid', 'partial', 'paid'].includes(status)) {
        return NextResponse.json({ success: false, error: 'Invalid status' }, { status: 400 });
      }
      const gross = Number(existing.gross_payout || 0);
      const paidAmount = status === 'paid' ? gross : Number(existing.paid_amount || 0);
      const remaining = status === 'paid' ? 0 : Math.max(gross - paidAmount, 0);

      await sql`
        UPDATE win_settlements
        SET payment_status = ${status}, paid_amount = ${paidAmount},
            remaining_amount = ${remaining}, operator = ${operator}, updated_at = NOW()
        WHERE id = ${id};
      `;

      return NextResponse.json({
        success: true,
        data: { paidAmount, remainingAmount: remaining, paymentStatus: status },
      });
    }

    return NextResponse.json({ success: false, error: 'Unknown action' }, { status: 400 });
  } catch (error: unknown) {
    console.error('Update settlement failed:', error);
    return NextResponse.json({ success: false, error: 'Update settlement failed' }, { status: 500 });
  }
}
