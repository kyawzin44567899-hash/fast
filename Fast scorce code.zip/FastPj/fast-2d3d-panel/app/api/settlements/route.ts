import { NextRequest, NextResponse } from 'next/server';
import { sql, ensureTablesExist } from '@/lib/db';
import { getSession } from '@/lib/session';
import { backfillWinSettlements } from '@/lib/commission';

export async function GET(req: NextRequest) {
  try {
    await ensureTablesExist();
    const session = await getSession();
    if (!session || (session.kind !== 'admin' && session.kind !== 'agent')) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    await backfillWinSettlements();

    const scopedAgentCode = session.kind === 'agent' ? session.code || null : null;
    const requestedAgent = (req.nextUrl.searchParams.get('agent') || '').trim();
    const agentFilter = scopedAgentCode ?? (requestedAgent || null);
    const statusFilter = (req.nextUrl.searchParams.get('status') || '').trim();
    const search = (req.nextUrl.searchParams.get('search') || '').trim();
    const like = `%${search}%`;

    const rows = await sql`
      SELECT id, bet_id, uid, user_name, agent_code, agent_name, bet_type, session,
             winning_number, bet_amount, multiplier, gross_payout, agent_percent,
             agent_share, admin_share, paid_amount, remaining_amount, payment_status,
             payment_reference, operator, paid_at, is_tood, created_at, updated_at
      FROM win_settlements
      WHERE (${agentFilter}::text IS NULL OR agent_code = ${agentFilter})
        AND (${statusFilter}::text = '' OR payment_status = ${statusFilter})
        AND (
          ${search} = '' OR
          uid ILIKE ${like} OR
          user_name ILIKE ${like} OR
          agent_code ILIKE ${like} OR
          bet_id ILIKE ${like} OR
          winning_number ILIKE ${like}
        )
      ORDER BY created_at DESC
      LIMIT 500;
    `;

    const data = (rows || []).map((r) => {
      const row = r as Record<string, unknown>;
      return {
        id: String(row.id),
        betId: String(row.bet_id),
        uid: String(row.uid),
        userName: row.user_name ? String(row.user_name) : '',
        agentCode: row.agent_code ? String(row.agent_code) : '',
        agentName: row.agent_name ? String(row.agent_name) : '',
        betType: String(row.bet_type),
        session: row.session ? String(row.session) : '',
        winningNumber: row.winning_number ? String(row.winning_number) : '',
        betAmount: Number(row.bet_amount || 0),
        multiplier: Number(row.multiplier || 0),
        grossPayout: Number(row.gross_payout || 0),
        agentPercent: Number(row.agent_percent || 0),
        agentShare: Number(row.agent_share || 0),
        adminShare: Number(row.admin_share || 0),
        paidAmount: Number(row.paid_amount || 0),
        remainingAmount: Number(row.remaining_amount || 0),
        paymentStatus: String(row.payment_status || 'pending'),
        paymentReference: row.payment_reference ? String(row.payment_reference) : '',
        operator: row.operator ? String(row.operator) : '',
        paidAt: row.paid_at ? new Date(row.paid_at as string).toISOString() : '',
        isTood: Boolean(row.is_tood),
        createdAt: row.created_at ? new Date(row.created_at as string).toISOString() : '',
        updatedAt: row.updated_at ? new Date(row.updated_at as string).toISOString() : '',
      };
    });

    return NextResponse.json({ success: true, data });
  } catch (error: unknown) {
    console.error('Fetch settlements failed:', error);
    return NextResponse.json({ success: false, error: 'Fetch settlements failed' }, { status: 500 });
  }
}
