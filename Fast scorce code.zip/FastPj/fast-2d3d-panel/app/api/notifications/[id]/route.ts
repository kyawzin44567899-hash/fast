import { NextRequest, NextResponse } from 'next/server';
import { ensureTablesExist } from '@/lib/db';
import { getSession } from '@/lib/session';
import { markNotificationRead, NotificationTarget } from '@/lib/notifications';

interface RouteContext {
  params: Promise<{ id: string }>;
}

export async function PATCH(_req: NextRequest, ctx: RouteContext) {
  try {
    await ensureTablesExist();
    const session = await getSession();
    if (!session || (session.kind !== 'admin' && session.kind !== 'agent')) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }
    const { id } = await ctx.params;
    const targetType = session.kind as NotificationTarget;
    const targetId = session.kind === 'agent' ? session.code || null : String(session.id);
    const updated = await markNotificationRead(id, targetType, targetId);
    if (!updated) {
      return NextResponse.json({ success: false, error: 'Notification not found' }, { status: 404 });
    }
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Mark notification read failed:', error);
    return NextResponse.json({ success: false, error: 'Failed' }, { status: 500 });
  }
}
