import { NextResponse } from 'next/server';
import { ensureTablesExist } from '@/lib/db';
import { getSession } from '@/lib/session';
import { markAllNotificationsRead, NotificationTarget } from '@/lib/notifications';

export async function POST() {
  try {
    await ensureTablesExist();
    const session = await getSession();
    if (!session || (session.kind !== 'admin' && session.kind !== 'agent')) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }
    const targetType = session.kind as NotificationTarget;
    const targetId = session.kind === 'agent' ? session.code || null : String(session.id);
    await markAllNotificationsRead(targetType, targetId);
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Mark all read failed:', error);
    return NextResponse.json({ success: false, error: 'Failed' }, { status: 500 });
  }
}
