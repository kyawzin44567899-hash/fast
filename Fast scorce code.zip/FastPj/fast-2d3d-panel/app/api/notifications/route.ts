import { NextResponse } from 'next/server';
import { ensureTablesExist } from '@/lib/db';
import { getSession } from '@/lib/session';
import { listNotifications, NotificationTarget } from '@/lib/notifications';

export async function GET() {
  try {
    await ensureTablesExist();
    const session = await getSession();
    if (!session || (session.kind !== 'admin' && session.kind !== 'agent')) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const targetType = session.kind as NotificationTarget;
    const targetId = session.kind === 'agent' ? session.code || null : String(session.id);

    const rows = await listNotifications(targetType, targetId);
    const unread = rows.filter((r) => !r.is_read).length;

    return NextResponse.json({
      success: true,
      data: {
        notifications: rows.map((r) => ({
          id: r.id,
          type: r.type,
          title: r.title,
          message: r.message,
          data: r.data || {},
          isRead: r.is_read,
          createdAt: r.created_at,
        })),
        unreadCount: unread,
      },
    });
  } catch (error) {
    console.error('List notifications failed:', error);
    return NextResponse.json({ success: false, error: 'Failed to load notifications' }, { status: 500 });
  }
}
