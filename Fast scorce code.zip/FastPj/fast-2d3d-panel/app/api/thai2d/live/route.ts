import { NextResponse } from 'next/server';

export const dynamic = 'force-dynamic';

function cleanJsonText(raw: string): string {
  const jsonStart = raw.search(/[{\[]/);
  if (jsonStart !== -1) {
    return raw.slice(jsonStart);
  }
  return raw;
}

export async function GET() {
  try {
    const response = await fetch('https://api.thaistock2d.com/live', {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
        Accept: 'application/json',
      },
      cache: 'no-store',
    });

    if (!response.ok) {
      throw new Error(`Thai 2D live API responded with status ${response.status}`);
    }

    const rawText = await response.text();
    const cleaned = cleanJsonText(rawText);
    const data = JSON.parse(cleaned);

    return NextResponse.json(data, {
      headers: {
        'Cache-Control': 'no-store, no-cache, must-revalidate',
      },
    });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    return NextResponse.json(
      {
        error: message,
        server_time: new Date().toISOString().replace('T', ' ').slice(0, 19),
        live: { set: '--', value: '--', time: '--', twod: '--' },
        result: [],
      },
      { status: 502 }
    );
  }
}
