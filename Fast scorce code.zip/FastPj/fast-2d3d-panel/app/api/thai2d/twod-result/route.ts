import { NextResponse } from 'next/server';

const SHWELAMIN_URL = 'https://backend.shwelamin.com/api/lv/twod-result';

export const dynamic = 'force-dynamic';

export async function GET() {
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 6000);
    const res = await fetch(SHWELAMIN_URL, {
      headers: { Accept: 'application/json', 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)' },
      signal: controller.signal,
      next: { revalidate: 30 },
    });
    clearTimeout(timeoutId);
    if (!res.ok) throw new Error(`status ${res.status}`);
    const json = await res.json();
    return NextResponse.json(json, {
      headers: { 'Cache-Control': 'public, s-maxage=30, stale-while-revalidate=60' },
    });
  } catch {
    return NextResponse.json({ result: 0, message: 'unavailable', data: [] }, { status: 502 });
  }
}
