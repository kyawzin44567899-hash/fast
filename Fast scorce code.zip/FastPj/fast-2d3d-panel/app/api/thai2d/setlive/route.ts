import { NextResponse } from 'next/server';

const SETLIVE_PAGE = 'https://setlive.myanmarnode.com/en/2d';
const SETLIVE_LIVE =
  'https://setlive.myanmarnode.com/live.json?_st=70194e292448049c9ce22e9e2f150798819e4c9bec583da133c96d660e368502&_fp=8601dfe2627bc621f770d404655ad77f';

export const dynamic = 'force-dynamic';

const KEYS = ['modern_930', 'internet_930', 'modern_200', 'internet_200'] as const;

interface SetLivePayload {
  result: number;
  data: Record<string, string>;
}

let cache: { at: number; payload: SetLivePayload | null } = { at: 0, payload: null };
const TTL_MS = 3000;

function extractInitialResults(html: string): Record<string, unknown> | null {
  const scriptRe = /<script\b[^>]*data-page="app"[^>]*>([\s\S]*?)<\/script>/i;
  const m = html.match(scriptRe);
  if (!m) return null;
  try {
    const obj = JSON.parse(m[1]) as { props?: Record<string, unknown> };
    const ir = obj?.props?.initialResults;
    return ir && typeof ir === 'object' ? (ir as Record<string, unknown>) : null;
  } catch {
    return null;
  }
}

function pick(obj: Record<string, unknown> | null): Record<string, string> | null {
  if (!obj) return null;
  const out: Record<string, string> = {};
  let found = false;
  for (const k of KEYS) {
    if (obj[k] !== undefined && obj[k] !== null) {
      out[k] = String(obj[k]);
      found = true;
    }
  }
  return found ? out : null;
}

function findFieldsDeep(value: unknown, depth = 0): Record<string, string> | null {
  if (!value || typeof value !== 'object' || depth > 6) return null;
  const direct = pick(value as Record<string, unknown>);
  if (direct) return direct;
  for (const v of Object.values(value as Record<string, unknown>)) {
    const nested = findFieldsDeep(v, depth + 1);
    if (nested) return nested;
  }
  return null;
}

async function fetchLiveJson(): Promise<Record<string, string> | null> {
  try {
    const res = await fetch(SETLIVE_LIVE, {
      headers: { Accept: 'application/json', 'User-Agent': 'Mozilla/5.0' },
      cache: 'no-store',
      signal: AbortSignal.timeout(5000),
    });
    if (!res.ok) return null;
    const json = await res.json();
    return findFieldsDeep(json);
  } catch {
    return null;
  }
}

async function fetchPageFields(): Promise<Record<string, string> | null> {
  try {
    const res = await fetch(SETLIVE_PAGE, {
      headers: {
        Accept: 'text/html',
        'User-Agent':
          'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Safari/537.36',
      },
      cache: 'no-store',
      signal: AbortSignal.timeout(8000),
    });
    if (!res.ok) return null;
    const html = await res.text();
    return pick(extractInitialResults(html));
  } catch {
    return null;
  }
}

export async function GET() {
  const now = Date.now();
  if (cache.payload && now - cache.at < TTL_MS) {
    return NextResponse.json(cache.payload, {
      headers: { 'Cache-Control': 'public, s-maxage=3, stale-while-revalidate=10' },
    });
  }

  const fields = (await fetchLiveJson()) ?? (await fetchPageFields());
  if (!fields) {
    return NextResponse.json({ result: 0, data: {} }, { status: 502 });
  }

  const payload: SetLivePayload = { result: 1, data: fields };
  cache = { at: now, payload };
  return NextResponse.json(payload, {
    headers: { 'Cache-Control': 'public, s-maxage=3, stale-while-revalidate=10' },
  });
}
