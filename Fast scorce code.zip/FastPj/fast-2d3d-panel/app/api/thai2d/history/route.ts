import { NextRequest, NextResponse } from 'next/server';

export const dynamic = 'force-dynamic';

function cleanJsonText(raw: string): string {
  const jsonStart = raw.search(/[{\[]/);
  if (jsonStart !== -1) {
    return raw.slice(jsonStart);
  }
  return raw;
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const dateParam = searchParams.get('date');
    const twodParam = searchParams.get('twod');

    let targetUrl = 'https://api.thaistock2d.com/history';
    if (twodParam && dateParam) {
      targetUrl = `https://api.thaistock2d.com/2d_history?twod=${encodeURIComponent(twodParam)}&date=${encodeURIComponent(dateParam)}`;
    } else if (dateParam) {
      targetUrl = `https://api.thaistock2d.com/history?date=${encodeURIComponent(dateParam)}`;
    }

    const response = await fetch(targetUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
        Accept: 'application/json',
      },
      cache: 'no-store',
    });

    if (!response.ok) {
      throw new Error(`Thai 2D history API responded with status ${response.status}`);
    }

    const rawText = await response.text();
    const cleaned = cleanJsonText(rawText);
    const data = JSON.parse(cleaned);

    return NextResponse.json(data, {
      headers: {
        'Cache-Control': 'no-store, no-cache, must-revalidate',
      },
    });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    return NextResponse.json({ error: message, history: [] }, { status: 502 });
  }
}
