import { NextRequest, NextResponse } from 'next/server';
import { sql, ensureTablesExist } from '@/lib/db';
import { getSession } from '@/lib/session';

export async function GET() {
  try {
    await ensureTablesExist();
    const session = await getSession();
    if (!session || (session.kind !== 'admin' && session.kind !== 'agent')) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const rows = await sql`SELECT key, value FROM settings;`;
    const map: Record<string, unknown> = {};
    for (const r of rows || []) {
      const row = r as { key: string; value: unknown };
      map[row.key] = row.value;
    }
    return NextResponse.json({ success: true, data: map });
  } catch (error: unknown) {
    console.error('Fetch settings failed:', error);
    return NextResponse.json({ success: false, error: 'Fetch settings failed' }, { status: 500 });
  }
}

export async function PUT(req: NextRequest) {
  try {
    await ensureTablesExist();
    const session = await getSession();
    if (!session || session.kind !== 'admin') {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const body = await req.json();
    const { key, value } = body;
    if (!key || typeof key !== 'string' || value === undefined) {
      return NextResponse.json({ success: false, error: 'Invalid settings payload' }, { status: 400 });
    }

    await sql`
      INSERT INTO settings (key, value, updated_at)
      VALUES (${key}, ${JSON.stringify(value)}, NOW())
      ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = NOW();
    `;

    return NextResponse.json({ success: true, data: { key, value } });
  } catch (error: unknown) {
    console.error('Update settings failed:', error);
    return NextResponse.json({ success: false, error: 'Update settings failed' }, { status: 500 });
  }
}
