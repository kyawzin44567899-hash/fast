import { NextRequest, NextResponse } from 'next/server';
import { ensureTablesExist, sql } from '@/lib/db';
import { getSession } from '@/lib/session';

export async function POST(req: NextRequest) {
  try {
    await ensureTablesExist();
    const session = await getSession();
    if (!session || (session.kind !== 'admin' && session.kind !== 'agent')) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const body = await req.json();
    const sub = body?.subscription;
    const endpoint = sub?.endpoint;
    const p256dh = sub?.keys?.p256dh;
    const auth = sub?.keys?.auth;

    if (!endpoint || !p256dh || !auth) {
      return NextResponse.json({ success: false, error: 'Invalid subscription' }, { status: 400 });
    }

    const targetType = session.kind;
    const targetId = session.kind === 'agent' ? session.code || '' : String(session.id);
    const id = `sub-${Date.now()}-${Math.floor(Math.random() * 100000)}`;

    await sql`
      INSERT INTO push_subscriptions (id, target_type, target_id, endpoint, p256dh, auth)
      VALUES (${id}, ${targetType}, ${targetId}, ${endpoint}, ${p256dh}, ${auth})
      ON CONFLICT (endpoint) DO UPDATE
        SET target_type = ${targetType}, target_id = ${targetId}, p256dh = ${p256dh}, auth = ${auth};
    `;

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Push subscribe failed:', error);
    return NextResponse.json({ success: false, error: 'Failed' }, { status: 500 });
  }
}
