import { NextRequest, NextResponse } from 'next/server';
import { sql, ensureTablesExist } from '@/lib/db';
import { getSession } from '@/lib/session';
import { isTood, normalize3D, TOOD_MULTIPLIER } from '@/lib/tood';

export async function GET(req: NextRequest) {
  try {
    await ensureTablesExist();
    const session = await getSession();
    if (!session || (session.kind !== 'admin' && session.kind !== 'agent')) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const result = normalize3D(req.nextUrl.searchParams.get('result'));
    if (!result || !isTood(result)) {
      return NextResponse.json({
        success: true,
        data: { result, isTood: false, multiplier: null, winners: 0, totalPayout: 0 },
      });
    }

    const rows = await sql`
      SELECT COUNT(*)::int AS winners, COALESCE(SUM(win_amount), 0) AS total
      FROM bets
      WHERE type = '3D' AND status = 'TOOD_WIN' AND winning_number = ${result};
    `;
    const row = (rows?.[0] || {}) as { winners?: number; total?: string | number };

    return NextResponse.json({
      success: true,
      data: {
        result,
        isTood: true,
        multiplier: TOOD_MULTIPLIER,
        winners: Number(row.winners || 0),
        totalPayout: Number(row.total || 0),
      },
    });
  } catch (error: unknown) {
    console.error('Fetch Tood summary failed:', error);
    return NextResponse.json({ success: false, error: 'Fetch Tood summary failed' }, { status: 500 });
  }
}
