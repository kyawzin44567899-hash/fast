import { NextRequest, NextResponse } from 'next/server';
import { sql, ensureTablesExist } from '@/lib/db';
import { getSession } from '@/lib/session';
import { createNotification } from '@/lib/notifications';
import { settleToodBets } from '@/lib/toodSettlement';
import { isTood, TOOD_MULTIPLIER } from '@/lib/tood';
import { normalizeResultDate } from '@/lib/date';

export async function GET(req: NextRequest) {
  try {
    await ensureTablesExist();
    const session = await getSession();
    if (!session || (session.kind !== 'admin' && session.kind !== 'agent')) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const typeFilter = (req.nextUrl.searchParams.get('type') || '').trim();
    const dateFilter = (req.nextUrl.searchParams.get('date') || '').trim();

    const rows = await sql`
      SELECT id, type, session, result_date, winning_number, created_at
      FROM results
      WHERE (${typeFilter}::text = '' OR type = ${typeFilter})
        AND (${dateFilter}::text = '' OR result_date = ${dateFilter})
      ORDER BY result_date DESC, type ASC, session ASC
      LIMIT 500;
    `;

    return NextResponse.json({ success: true, data: rows || [] });
  } catch (error: unknown) {
    console.error('Fetch results failed:', error);
    return NextResponse.json({ success: false, error: 'Fetch results failed' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    await ensureTablesExist();
    const session = await getSession();
    if (!session || session.kind !== 'admin') {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const body = await req.json();
    const { type, session: resultSession, resultDate, winningNumber } = body;

    if (!type || !resultSession || !winningNumber) {
      return NextResponse.json({ success: false, error: 'Invalid result payload' }, { status: 400 });
    }

    const cleanNumber = String(winningNumber).trim();
    const cleanSession = String(resultSession).trim();
    const effectiveDate = normalizeResultDate(resultDate);

    const existing = await sql`
      SELECT winning_number, result_date FROM results
      WHERE type = ${type} AND session = ${cleanSession} AND result_date = ${effectiveDate}
      ORDER BY created_at DESC
      LIMIT 1;
    `;
    const previous = existing?.[0] as
      | { winning_number: string; result_date: string | null }
      | undefined;
    const isNewResult = !previous || String(previous.winning_number) !== cleanNumber;

    await sql`
      INSERT INTO results (type, session, result_date, winning_number)
      VALUES (${type}, ${cleanSession}, ${effectiveDate}, ${cleanNumber})
      ON CONFLICT (type, session, COALESCE(result_date, ''))
      DO UPDATE SET winning_number = EXCLUDED.winning_number, created_at = NOW();
    `;

    if (isNewResult) {
      await createNotification({
        targetType: 'user',
        targetId: null,
        type: 'result',
        title: `${type} ပေါက်ဂဏန်း ထွက်ရှိပါပြီ`,
        message: `${cleanSession} အတွက် ပေါက်ဂဏန်း (${cleanNumber}) ထွက်ရှိပါပြီ။`,
        data: { screen: 'home' },
      });
    }

    let tood = { isToodResult: false, winners: 0, totalPayout: 0 };
    if (type === '3D') {
      tood = await settleToodBets(cleanSession, cleanNumber);
    }

    return NextResponse.json({
      success: true,
      data: {
        type,
        session: cleanSession,
        resultDate: effectiveDate,
        winningNumber: cleanNumber,
        isTood: type === '3D' ? isTood(cleanNumber) : false,
        toodMultiplier: type === '3D' && isTood(cleanNumber) ? TOOD_MULTIPLIER : null,
        toodWinners: tood.winners,
        totalToodPayout: tood.totalPayout,
      },
    });
  } catch (error: unknown) {
    console.error('Publish result failed:', error);
    return NextResponse.json({ success: false, error: 'Publish result failed' }, { status: 500 });
  }
}
