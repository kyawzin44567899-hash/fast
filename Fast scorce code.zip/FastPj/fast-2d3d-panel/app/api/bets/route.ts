import { NextRequest, NextResponse } from 'next/server';
import { sql, ensureTablesExist } from '@/lib/db';
import { getSession } from '@/lib/session';

function mapStatus(status: string | null): 'confirmed' | 'won' | 'lost' | 'pending' {
  if (status === 'win' || status === 'TOOD_WIN') return 'won';
  if (status === 'lose') return 'lost';
  return 'pending';
}

function parseItems(
  value: unknown
): { number: string; amount: number; subNumbers?: { number: string; amount: number }[] }[] {
  let arr: unknown = value;
  if (typeof value === 'string') {
    try {
      arr = JSON.parse(value);
    } catch {
      arr = [];
    }
  }
  if (!Array.isArray(arr)) return [];
  return arr.map((it) => {
    const item = it as {
      number?: unknown;
      amount?: unknown;
      subNumbers?: { number?: unknown; amount?: unknown }[];
    };
    const subNumbers = Array.isArray(item.subNumbers)
      ? item.subNumbers.map((s) => ({
          number: String(s.number ?? ''),
          amount: Number(s.amount ?? 0),
        }))
      : undefined;
    return {
      number: String(item.number ?? ''),
      amount: Number(item.amount ?? 0),
      ...(subNumbers && subNumbers.length > 0 ? { subNumbers } : {}),
    };
  });
}

export async function GET(req: NextRequest) {
  try {
    await ensureTablesExist();
    const session = await getSession();
    if (!session || (session.kind !== 'admin' && session.kind !== 'agent')) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const scopedAgentCode = session.kind === 'agent' ? session.code : null;
    const statusFilter = req.nextUrl.searchParams.get('status');

    const rows = await sql`
      SELECT b.id, b.uid, b.type, b.session, b.amount, b.items, b.numbers, b.status, b.date,
             b.winning_number, b.win_amount, b.win_details, b.payout_multiplier, b.is_tood, b.created_at,
             u.name AS user_name, u.phone AS user_phone, u.agent_code
      FROM bets b
      LEFT JOIN users u ON u.uid = b.uid
      WHERE (${scopedAgentCode}::text IS NULL OR u.agent_code = ${scopedAgentCode})
        AND (${statusFilter}::text IS NULL OR b.status = ${statusFilter}
             OR (${statusFilter} = 'win' AND b.status = 'TOOD_WIN'))
      ORDER BY b.created_at DESC
      LIMIT 500;
    `;

    const bets = (rows || []).map((r) => {
      const row = r as Record<string, unknown>;
      const items = parseItems(row.items);
      const category = row.type === '3D' ? '3D' : '2D';
      const totalNumbers = items.reduce(
        (sum, it) => sum + (it.subNumbers && it.subNumbers.length > 0 ? it.subNumbers.length : 1),
        0
      );
      return {
        id: String(row.id),
        voucherNo: String(row.id),
        userId: String(row.uid),
        userName: row.user_name ? String(row.user_name) : 'Unknown',
        userPhone: row.user_phone ? String(row.user_phone) : '',
        userUid: String(row.uid),
        agentCode: row.agent_code ? String(row.agent_code) : '',
        category,
        timeSlot: String(row.session || ''),
        dateFormatted: String(row.date || ''),
        items,
        totalNumbers,
        multiplier: row.is_tood
          ? Number(row.payout_multiplier || 10)
          : category === '2D'
          ? 85
          : 550,
        totalAmount: Number(row.amount),
        status: mapStatus(row.status as string | null),
        isTood: Boolean(row.is_tood) || row.status === 'TOOD_WIN',
        winningNumber: row.winning_number ? String(row.winning_number) : '',
        winAmount: Number(row.win_amount || 0),
        winDetails: row.win_details ? String(row.win_details) : '',
        createdAt: row.created_at ? new Date(row.created_at as string).toISOString().slice(0, 16).replace('T', ' ') : '',
      };
    });

    return NextResponse.json({ success: true, data: bets });
  } catch (error: unknown) {
    console.error('Fetch bets failed:', error);
    return NextResponse.json({ success: false, error: 'Fetch bets failed' }, { status: 500 });
  }
}
