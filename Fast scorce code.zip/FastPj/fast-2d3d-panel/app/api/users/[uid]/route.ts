import { NextRequest, NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';
import { sql, ensureTablesExist } from '@/lib/db';
import { getSession } from '@/lib/session';
import { createNotification } from '@/lib/notifications';

interface RouteContext {
  params: Promise<{ uid: string }>;
}

async function loadUser(uid: string, agentCode: string | null) {
  const rows = await sql`
    SELECT id, uid, name, phone, agent_code, balance, status, created_at
    FROM users
    WHERE uid = ${uid}
      AND (${agentCode}::text IS NULL OR agent_code = ${agentCode})
    LIMIT 1;
  `;
  return rows && rows.length > 0 ? (rows[0] as Record<string, unknown>) : null;
}

function serialize(row: Record<string, unknown>) {
  return {
    id: String(row.id),
    uid: String(row.uid),
    name: String(row.name),
    phone: String(row.phone),
    agentCode: row.agent_code ? String(row.agent_code) : '',
    balance: Number(row.balance),
    status: (row.status as string) === 'suspended' ? 'suspended' : 'active',
    createdAt: row.created_at ? new Date(row.created_at as string).toISOString().slice(0, 10) : '',
  };
}

export async function GET(_req: NextRequest, ctx: RouteContext) {
  try {
    await ensureTablesExist();
    const session = await getSession();
    if (!session || (session.kind !== 'admin' && session.kind !== 'agent')) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }
    const { uid } = await ctx.params;
    const scope = session.kind === 'agent' ? session.code || null : null;
    const row = await loadUser(uid, scope);
    if (!row) {
      return NextResponse.json({ success: false, error: 'User not found' }, { status: 404 });
    }

    const bets = await sql`
      SELECT id, type, session, amount, numbers, items, status,
             winning_number, win_amount, win_details, payout_multiplier, is_tood, date, created_at
      FROM bets WHERE uid = ${uid} ORDER BY created_at DESC LIMIT 100;
    `;
    const transactions = await sql`
      SELECT id, type, amount, method, transaction_number, order_number, status, timestamp, slip_image
      FROM transactions WHERE uid = ${uid} ORDER BY created_at DESC LIMIT 100;
    `;

    return NextResponse.json({
      success: true,
      data: { user: serialize(row), bets: bets || [], transactions: transactions || [] },
    });
  } catch (error: unknown) {
    console.error('Fetch user detail failed:', error);
    return NextResponse.json({ success: false, error: 'Fetch user failed' }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest, ctx: RouteContext) {
  try {
    await ensureTablesExist();
    const session = await getSession();
    if (!session || session.kind !== 'admin') {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const { uid } = await ctx.params;
    const body = await req.json();
    const { action } = body;

    const existing = await loadUser(uid, null);
    if (!existing) {
      return NextResponse.json({ success: false, error: 'User not found' }, { status: 404 });
    }

    if (action === 'adjustBalance') {
      const amount = Number(body.amount);
      const direction = body.direction === 'deduct' ? 'deduct' : 'add';
      if (!Number.isFinite(amount) || amount <= 0) {
        return NextResponse.json({ success: false, error: 'Invalid amount' }, { status: 400 });
      }

      let result;
      if (direction === 'add') {
        result = await sql`
          UPDATE users SET balance = balance + ${amount}, updated_at = NOW()
          WHERE uid = ${uid} RETURNING balance;
        `;
      } else {
        result = await sql`
          UPDATE users SET balance = GREATEST(balance - ${amount}, 0), updated_at = NOW()
          WHERE uid = ${uid} RETURNING balance;
        `;
      }
      const newBalance = Number((result[0] as { balance: string | number }).balance);

      const txId = `tx-adjust-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
      await sql`
        INSERT INTO transactions (id, uid, type, amount, method, transaction_number, status, timestamp)
        VALUES (${txId}, ${uid}, ${direction === 'add' ? 'deposit' : 'withdraw'}, ${amount},
                ${'Admin Adjust'}, ${'ADMIN'}, 'completed', ${new Date().toLocaleString()});
      `;

      await createNotification({
        targetType: 'user',
        targetId: uid,
        type: 'balance',
        title: direction === 'add' ? 'လက်ကျန်ငွေ ထည့်သွင်းပြီးပါပြီ' : 'လက်ကျန်ငွေ နုတ်ယူပြီးပါပြီ',
        message: `Admin မှ ${amount.toLocaleString()} MMK ${direction === 'add' ? 'ထည့်သွင်း' : 'နုတ်ယူ'} ပြုလုပ်ခဲ့ပါသည်။`,
        data: { screen: 'wallet' },
      });

      const updated = await loadUser(uid, null);
      return NextResponse.json({ success: true, data: { user: serialize(updated!), newBalance } });
    }

    if (action === 'setStatus') {
      const status = body.status === 'suspended' ? 'suspended' : 'active';
      await sql`UPDATE users SET status = ${status}, updated_at = NOW() WHERE uid = ${uid};`;
      await createNotification({
        targetType: 'user',
        targetId: uid,
        type: 'account',
        title: status === 'suspended' ? 'အကောင့် ပိတ်ထားပါသည်' : 'အကောင့် ပြန်လည်ဖွင့်ပြီးပါပြီ',
        message: status === 'suspended'
          ? 'သင့်အကောင့်ကို ပိတ်ထားပါသည်။ Support ကို ဆက်သွယ်ပါ။'
          : 'သင့်အကောင့်ကို ပြန်လည်ဖွင့်ပေးပြီးပါပြီ။',
        data: { screen: 'profile' },
      });
      const updated = await loadUser(uid, null);
      return NextResponse.json({ success: true, data: { user: serialize(updated!) } });
    }

    if (action === 'setPassword') {
      const password = String(body.password || '');
      if (password.length < 4) {
        return NextResponse.json({ success: false, error: 'Password too short' }, { status: 400 });
      }
      const hash = await bcrypt.hash(password, 10);
      await sql`UPDATE users SET password_hash = ${hash}, updated_at = NOW() WHERE uid = ${uid};`;
      const updated = await loadUser(uid, null);
      return NextResponse.json({ success: true, data: { user: serialize(updated!) } });
    }

    if (action === 'setAgent') {
      const agentCode = body.agentCode ? String(body.agentCode).trim() : null;
      if (agentCode) {
        const agent = await sql`
          SELECT code FROM agents WHERE code = ${agentCode} AND status = 'active' LIMIT 1;
        `;
        if (!agent || agent.length === 0) {
          return NextResponse.json({ success: false, error: 'Invalid agent code' }, { status: 400 });
        }
      }
      await sql`UPDATE users SET agent_code = ${agentCode}, updated_at = NOW() WHERE uid = ${uid};`;
      const updated = await loadUser(uid, null);
      return NextResponse.json({ success: true, data: { user: serialize(updated!) } });
    }

    if (action === 'update') {
      const name = body.name !== undefined ? String(body.name).trim() : null;
      const phone = body.phone !== undefined ? String(body.phone).trim() : null;
      if (name !== null && name.length === 0) {
        return NextResponse.json({ success: false, error: 'Invalid name' }, { status: 400 });
      }
      if (phone) {
        const dupe = await sql`
          SELECT uid FROM users WHERE phone = ${phone} AND uid <> ${uid} LIMIT 1;
        `;
        if (dupe && dupe.length > 0) {
          return NextResponse.json({ success: false, error: 'Phone already in use' }, { status: 409 });
        }
      }
      await sql`
        UPDATE users
        SET name = COALESCE(${name}, name),
            phone = COALESCE(${phone}, phone),
            updated_at = NOW()
        WHERE uid = ${uid};
      `;
      const updated = await loadUser(uid, null);
      return NextResponse.json({ success: true, data: { user: serialize(updated!) } });
    }

    return NextResponse.json({ success: false, error: 'Unknown action' }, { status: 400 });
  } catch (error: unknown) {
    console.error('Update user failed:', error);
    return NextResponse.json({ success: false, error: 'Update user failed' }, { status: 500 });
  }
}
