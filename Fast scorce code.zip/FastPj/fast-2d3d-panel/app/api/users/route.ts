import { NextRequest, NextResponse } from 'next/server';
import { sql, ensureTablesExist } from '@/lib/db';
import { getSession } from '@/lib/session';

export async function GET(req: NextRequest) {
  try {
    await ensureTablesExist();
    const session = await getSession();
    if (!session || (session.kind !== 'admin' && session.kind !== 'agent')) {
      return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });
    }

    const { searchParams } = new URL(req.url);
    const search = (searchParams.get('search') || '').trim();

    const scopedAgentCode = session.kind === 'agent' ? session.code : null;

    const rows = await sql`
      SELECT u.id, u.uid, u.name, u.phone, u.agent_code, u.balance, u.status, u.created_at,
             (SELECT COUNT(*)::int FROM bets b WHERE b.uid = u.uid) AS total_bets
      FROM users u
      WHERE (${scopedAgentCode}::text IS NULL OR u.agent_code = ${scopedAgentCode})
        AND (
          ${search} = '' OR
          u.name ILIKE ${'%' + search + '%'} OR
          u.phone ILIKE ${'%' + search + '%'} OR
          u.uid ILIKE ${'%' + search + '%'}
        )
      ORDER BY u.created_at DESC
      LIMIT 500;
    `;

    const users = (rows || []).map((r) => {
      const row = r as Record<string, unknown>;
      return {
        id: String(row.id),
        uid: String(row.uid),
        name: String(row.name),
        phone: String(row.phone),
        agentCode: row.agent_code ? String(row.agent_code) : '',
        balance: Number(row.balance),
        totalBets: Number(row.total_bets || 0),
        status: (row.status as string) === 'suspended' ? 'suspended' : 'active',
        createdAt: row.created_at ? new Date(row.created_at as string).toISOString().slice(0, 10) : '',
      };
    });

    return NextResponse.json({ success: true, data: users });
  } catch (error: unknown) {
    console.error('Fetch users failed:', error);
    return NextResponse.json({ success: false, error: 'Fetch users failed' }, { status: 500 });
  }
}
