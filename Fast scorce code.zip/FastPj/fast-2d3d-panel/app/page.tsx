'use client';

import React, { useState, useEffect, useCallback } from 'react';
import {
  ScreenType,
  BottomTabType,
  UserRole,
  AppUser,
  AppAgent,
  Transaction,
  WinningSlot,
  ScheduleConfig,
  AdsConfig,
  WebsiteSettings,
  Thai2DLiveResponse,
  Thai3DResponse,
  BetRecord,
} from '@/lib/types';
import {
  DEFAULT_ADS,
  DEFAULT_SCHEDULE,
  DEFAULT_WEBSITE_SETTINGS,
  DEFAULT_WINNING_SLOTS,
} from '@/lib/defaults';
import { fetchThai2DLive, fetchThai3DResults } from '@/lib/thaiLotteryService';

import { WelcomeView } from '@/components/views/WelcomeView';
import { AdminLoginView } from '@/components/views/AdminLoginView';
import { AgentLoginView } from '@/components/views/AgentLoginView';
import { DashboardView } from '@/components/views/DashboardView';
import { UserListView } from '@/components/views/UserListView';
import { AgentsListView } from '@/components/views/AgentsListView';
import { TransactionsView } from '@/components/views/TransactionsView';
import { NumbersManageView } from '@/components/views/NumbersManageView';
import { ScheduleView } from '@/components/views/ScheduleView';
import { AdsView } from '@/components/views/AdsView';
import { WinningNumbersView } from '@/components/views/WinningNumbersView';
import { LiveFeedView } from '@/components/views/LiveFeedView';
import { WebsiteView } from '@/components/views/WebsiteView';
import { ProfileView } from '@/components/views/ProfileView';
import { BetRecordsView } from '@/components/views/BetRecordsView';
import { WinBetsView } from '@/components/views/WinBetsView';
import { AgentBalanceView } from '@/components/views/AgentBalanceView';
import { ResultsHistoryView } from '@/components/views/ResultsHistoryView';

import { BottomNav } from '@/components/BottomNav';
import { NotificationModal } from '@/components/NotificationModal';
import { usePWA } from '@/hooks/usePWA';
import { useNotifications } from '@/hooks/use-notifications';
import { registerPushSubscription } from '@/hooks/use-push';
import { WifiOff } from 'lucide-react';

interface SessionUser {
  kind: 'admin' | 'agent';
  id: number;
  name: string;
  email?: string;
  code?: string;
}

export default function Fast2D3DApp() {

  const [screen, setScreen] = useState<ScreenType>('welcome');
  const [bottomTab, setBottomTab] = useState<BottomTabType>('home');
  const [role, setRole] = useState<UserRole>('admin');
  const [currentAgent, setCurrentAgent] = useState<AppAgent | null>(null);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);
  const [sessionInfo, setSessionInfo] = useState<{ name: string; email?: string; code?: string } | null>(null);

  const [users, setUsers] = useState<AppUser[]>([]);
  const [agents, setAgents] = useState<AppAgent[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [betRecords, setBetRecords] = useState<BetRecord[]>([]);
  const [winningSlots, setWinningSlots] = useState<WinningSlot[]>(DEFAULT_WINNING_SLOTS);
  const [schedule, setSchedule] = useState<ScheduleConfig>(DEFAULT_SCHEDULE);
  const [ads, setAds] = useState<AdsConfig>(DEFAULT_ADS);
  const [websiteSettings, setWebsiteSettings] = useState<WebsiteSettings>(DEFAULT_WEBSITE_SETTINGS);
  const [isLoading, setIsLoading] = useState(false);
  const [loadError, setLoadError] = useState('');

  const [thai2DLive, setThai2DLive] = useState<Thai2DLiveResponse | null>(null);
  const [thai3DData, setThai3DData] = useState<Thai3DResponse | null>(null);

  const loadData = useCallback(async (currentRole: UserRole) => {
    setIsLoading(true);
    setLoadError('');
    try {
      const requests: Promise<Response>[] = [
        fetch('/api/users', { cache: 'no-store' }),
        fetch('/api/transactions', { cache: 'no-store' }),
        fetch('/api/bets', { cache: 'no-store' }),
        fetch('/api/settings', { cache: 'no-store' }),
      ];
      if (currentRole === 'admin') {
        requests.push(fetch('/api/agents', { cache: 'no-store' }));
      }

      const responses = await Promise.all(requests);
      const [usersRes, txRes, betsRes, settingsRes, agentsRes] = responses;

      if (usersRes.ok) {
        const json = await usersRes.json();
        if (Array.isArray(json.data)) setUsers(json.data);
      }
      if (txRes.ok) {
        const json = await txRes.json();
        if (Array.isArray(json.data)) setTransactions(json.data);
      }
      if (betsRes.ok) {
        const json = await betsRes.json();
        if (Array.isArray(json.data)) setBetRecords(json.data);
      }
      if (currentRole === 'admin' && agentsRes?.ok) {
        const json = await agentsRes.json();
        if (Array.isArray(json.data)) setAgents(json.data);
      }
      if (settingsRes.ok) {
        const json = await settingsRes.json();
        const map = (json.data || {}) as Record<string, unknown>;
        if (map.website) setWebsiteSettings((prev) => ({ ...prev, ...(map.website as WebsiteSettings) }));
        if (map.ads) setAds((prev) => ({ ...prev, ...(map.ads as AdsConfig) }));
        if (map.schedule) setSchedule((prev) => ({ ...prev, ...(map.schedule as ScheduleConfig) }));
        if (Array.isArray(map.winningSlots) && map.winningSlots.length > 0) {
          setWinningSlots(map.winningSlots as WinningSlot[]);
        }
      }

      if (currentRole === 'agent') {
        try {
          const meRes = await fetch('/api/auth/me', { cache: 'no-store' });
          if (meRes.ok) {
            const meJson = await meRes.json();
            if (meJson?.agent) setCurrentAgent(meJson.agent as AppAgent);
          }
        } catch {}
      }
    } catch {
      setLoadError('ဒေတာ ဆွဲယူရာတွင် အဆင်မပြေပါ');
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    let isMounted = true;
    const restore = async () => {
      try {
        const res = await fetch('/api/auth/me', { cache: 'no-store' });
        if (!res.ok) return;
        const data = await res.json();
        const user = data?.user as SessionUser | undefined;
        if (!user || !isMounted) return;
        setRole(user.kind);
        setSessionInfo({ name: user.name, email: user.email, code: user.code });
        if (user.kind === 'agent') {
          const agentData = data?.agent as AppAgent | undefined;
          setCurrentAgent(
            agentData || {
              id: String(user.id),
              name: user.name,
              code: user.code || '',
              email: user.email || '',
              phone: '',
              secretKey: '',
              commission: 0,
              membersCount: 0,
              balance: 0,
              status: 'active',
              createdAt: '',
            }
          );
        }
        setScreen('dashboard');
        await loadData(user.kind);
      } catch {

      }
    };
    restore();
    return () => {
      isMounted = false;
    };
  }, [loadData]);

  const refreshTransactions = useCallback(async () => {
    try {
      const res = await fetch('/api/transactions', { cache: 'no-store' });
      if (!res.ok) return;
      const json = await res.json();
      if (Array.isArray(json.data)) setTransactions(json.data);
    } catch {}
  }, []);

  const refreshBets = useCallback(async () => {
    try {
      const res = await fetch('/api/bets', { cache: 'no-store' });
      if (!res.ok) return;
      const json = await res.json();
      if (Array.isArray(json.data)) setBetRecords(json.data);
    } catch {}
  }, []);

  useEffect(() => {
    if (!sessionInfo) return;
    const timer = setInterval(() => {
      if (typeof document !== 'undefined' && document.hidden) return;
      void refreshTransactions();
      void refreshBets();
    }, 12000);
    return () => clearInterval(timer);
  }, [sessionInfo, refreshTransactions, refreshBets]);

  useEffect(() => {
    let isMounted = true;

    const pollThai2D = async () => {
      const liveData = await fetchThai2DLive();
      if (!isMounted || !liveData) return;
      setThai2DLive(liveData);
    };

    const pollThai3D = async () => {
      const threed = await fetchThai3DResults();
      if (!isMounted || !threed) return;
      setThai3DData(threed);
    };

    pollThai2D();
    pollThai3D();

    const interval2D = setInterval(() => {
      if (typeof document !== 'undefined' && document.hidden) return;
      pollThai2D();
    }, 2000);

    const interval3D = setInterval(() => {
      if (typeof document !== 'undefined' && document.hidden) return;
      pollThai3D();
    }, 90000);

    return () => {
      isMounted = false;
      clearInterval(interval2D);
      clearInterval(interval3D);
    };
  }, []);

  const handleRefreshAllApiData = async () => {
    const liveData = await fetchThai2DLive();
    if (liveData) setThai2DLive(liveData);
    const threed = await fetchThai3DResults();
    if (threed) setThai3DData(threed);
  };

  const handleDashboardRefresh = async () => {
    await Promise.all([loadData(role), handleRefreshAllApiData()]);
  };

  const persistSetting = async (key: string, value: unknown) => {
    try {
      await fetch('/api/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ key, value }),
      });
    } catch {

    }
  };

  const { isOnline } = usePWA();
  const {
    notifications,
    unreadCount,
    markRead,
    markAllRead,
    soundEnabled,
    setSoundEnabled,
  } = useNotifications();

  const handleNotificationNavigate = (target: string) => {
    const screens: ScreenType[] = [
      'dashboard',
      'user_list',
      'agents_list',
      'transactions',
      'numbers_manage',
      'schedule',
      'ads',
      'winning_numbers',
      'live_feed',
      'bet_records',
      'win_bets',
    ];
    if (screens.includes(target as ScreenType)) {
      setBottomTab('home');
      setScreen(target as ScreenType);
    } else if (target === 'profile') {
      setBottomTab('profile');
    } else if (target === 'wallet') {
      setBottomTab('home');
      setScreen('transactions');
    } else {
      setBottomTab('home');
      setScreen('dashboard');
    }
  };

  const handleSelectRoleFromWelcome = (selectedRole: UserRole) => {
    setRole(selectedRole);
    setScreen(selectedRole === 'admin' ? 'admin_login' : 'agent_login');
  };

  const handleLoginSuccess = async () => {
    try {
      const res = await fetch('/api/auth/me', { cache: 'no-store' });
      if (res.ok) {
        const data = await res.json();
        const user = data?.user as SessionUser | undefined;
        if (user) {
          setRole(user.kind);
          setSessionInfo({ name: user.name, email: user.email, code: user.code });
          if (user.kind === 'agent') {
            const agentData = data?.agent as AppAgent | undefined;
            setCurrentAgent(
              agentData || {
                id: String(user.id),
                name: user.name,
                code: user.code || '',
                email: user.email || '',
                phone: '',
                secretKey: '',
                commission: 0,
                membersCount: 0,
                balance: 0,
                status: 'active',
                createdAt: '',
              }
            );
          } else {
            setCurrentAgent(null);
          }
        }
      }
    } catch {}
    setScreen('dashboard');
    setBottomTab('home');
    await loadData(role);
    void registerPushSubscription();
  };

  const handleLogout = async () => {
    try {
      await fetch('/api/auth/logout', { method: 'POST' });
    } catch {}
    setCurrentAgent(null);
    setSessionInfo(null);
    setUsers([]);
    setAgents([]);
    setTransactions([]);
    setBetRecords([]);
    setScreen('welcome');
    setBottomTab('home');
  };

  const handleBottomTabChange = (tab: BottomTabType) => {
    setBottomTab(tab);
    if (tab === 'home') setScreen('dashboard');
  };

  const handleApproveTransaction = async (id: string) => {
    try {
      const res = await fetch(`/api/transactions/${encodeURIComponent(id)}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'approve' }),
      });
      if (!res.ok) {
        const json = await res.json().catch(() => ({}));
        setLoadError(json.error || 'Transaction approval failed');
      }
    } catch {
      setLoadError('Transaction approval failed');
    }
    await loadData(role);
  };

  const handleRejectTransaction = async (id: string) => {
    try {
      await fetch(`/api/transactions/${encodeURIComponent(id)}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'reject' }),
      });
    } catch {}
    await loadData(role);
  };

  const handleUpdateWinningSlot = async (slotId: string, newNumber: string) => {
    const formatted = newNumber.padStart(2, '0');
    const current = winningSlots.find((s) => s.id === slotId);
    if (current && current.luckyNumber === formatted) return;
    const nextSlots = winningSlots.map((s) =>
      s.id === slotId ? { ...s, luckyNumber: formatted } : s
    );
    setWinningSlots(nextSlots);
    await persistSetting('winningSlots', nextSlots);

    const slot = nextSlots.find((s) => s.id === slotId);
    if (slot) {

      try {
        await fetch('/api/results', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            type: '2D',
            session: slot.timeSlot,
            winningNumber: formatted,
          }),
        });
      } catch {}
    }
  };

  const handleUpdateUser = async (updated: AppUser) => {
    try {
      await fetch(`/api/users/${encodeURIComponent(updated.uid)}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'update', name: updated.name, phone: updated.phone }),
      });
    } catch {}
    await loadData(role);
  };

  const handleAdjustBalance = async (
    uid: string,
    direction: 'add' | 'deduct',
    amount: number
  ): Promise<AppUser | null> => {
    try {
      const res = await fetch(`/api/users/${encodeURIComponent(uid)}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'adjustBalance', direction, amount }),
      });
      const json = await res.json();
      if (!res.ok || !json.success) return null;
      await loadData(role);
      return json.data.user as AppUser;
    } catch {
      return null;
    }
  };

  const handleSetStatus = async (
    uid: string,
    status: 'active' | 'suspended'
  ): Promise<AppUser | null> => {
    try {
      const res = await fetch(`/api/users/${encodeURIComponent(uid)}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'setStatus', status }),
      });
      const json = await res.json();
      if (!res.ok || !json.success) return null;
      await loadData(role);
      return json.data.user as AppUser;
    } catch {
      return null;
    }
  };

  const handleSetPassword = async (uid: string, password: string): Promise<boolean> => {
    try {
      const res = await fetch(`/api/users/${encodeURIComponent(uid)}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'setPassword', password }),
      });
      return res.ok;
    } catch {
      return false;
    }
  };

  const handleAddAgent = async (newAgent: AppAgent) => {
    try {
      await fetch('/api/agents', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: newAgent.name,
          code: newAgent.code,
          email: newAgent.email,
          phone: newAgent.phone,
          secretKey: newAgent.secretKey,
          commission: newAgent.commission,
        }),
      });
    } catch {}
    await loadData(role);
  };

  const handleUpdateAgent = async (updated: AppAgent) => {
    try {
      await fetch(`/api/agents/${encodeURIComponent(updated.code)}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: updated.name,
          email: updated.email,
          phone: updated.phone,
          secretKey: updated.secretKey,
          commission: updated.commission,
          status: updated.status,
          balance: updated.balance,
        }),
      });
    } catch {}
    await loadData(role);
  };

  const handleDeleteAgent = async (code: string) => {
    try {
      await fetch(`/api/agents/${encodeURIComponent(code)}`, { method: 'DELETE' });
    } catch {}
    await loadData(role);
  };

  const handleUpdateAds = async (next: AdsConfig) => {
    setAds(next);
    await persistSetting('ads', next);
  };

  const handleUpdateSchedule = async (next: ScheduleConfig) => {
    setSchedule(next);
    await persistSetting('schedule', next);
  };

  const handleUpdateSettings = async (next: WebsiteSettings) => {
    setWebsiteSettings(next);
    await persistSetting('website', next);
  };

  const isAuthScreen = screen === 'welcome' || screen === 'admin_login' || screen === 'agent_login';
  const showBottomNav = !isAuthScreen;

  return (
    <div className="min-h-screen bg-[#101012] flex justify-center text-white select-none">
      <div className="w-full max-w-[430px] min-h-screen bg-[#101012] relative flex flex-col">
        {!isOnline && (
          <div className="sticky top-0 z-50 flex items-center justify-center gap-2 bg-amber-500 py-1 px-3 text-black text-xs font-bold shadow">
            <WifiOff className="w-3.5 h-3.5" />
            <span>အင်တာနက် လိုင်းပြတ်တောက်နေပါသည် (Offline Cache)</span>
          </div>
        )}

        {loadError && !isAuthScreen && (
          <div className="mx-4 mt-3 p-2.5 rounded-xl bg-red-950/80 border border-red-500/50 text-red-300 text-xs text-center">
            {loadError}
          </div>
        )}

        {isLoading && !isAuthScreen && (
          <div className="mx-4 mt-3 p-2.5 rounded-xl bg-zinc-900 border border-zinc-800 text-zinc-300 text-xs text-center">
            ဒေတာ ရယူနေပါသည်...
          </div>
        )}

        <main className="flex-1 flex flex-col">
          {screen === 'welcome' && (
            <WelcomeView onSelectRole={handleSelectRoleFromWelcome} />
          )}

          {screen === 'admin_login' && (
            <AdminLoginView onSuccess={handleLoginSuccess} onBack={() => setScreen('welcome')} />
          )}

          {screen === 'agent_login' && (
            <AgentLoginView onSuccess={handleLoginSuccess} onBack={() => setScreen('welcome')} />
          )}

          {screen === 'dashboard' && bottomTab === 'home' && (
            <DashboardView
              onNavigate={(target) => setScreen(target)}
              onOpenNotifications={() => setIsNotificationsOpen(true)}
              onRefresh={handleDashboardRefresh}
              unreadCount={unreadCount}
              role={role}
              currentAgent={currentAgent}
            />
          )}

          {screen === 'user_list' && bottomTab === 'home' && (
            <UserListView
              users={users}
              onBack={() => setScreen('dashboard')}
              onUpdateUser={handleUpdateUser}
              role={role}
              currentAgent={currentAgent}
              onAdjustBalance={handleAdjustBalance}
              onSetStatus={handleSetStatus}
              onSetPassword={handleSetPassword}
            />
          )}

          {screen === 'agents_list' && bottomTab === 'home' && (
            <AgentsListView
              agents={agents}
              onBack={() => setScreen('dashboard')}
              onAddAgent={handleAddAgent}
              onUpdateAgent={handleUpdateAgent}
              onDeleteAgent={handleDeleteAgent}
            />
          )}

          {screen === 'transactions' && bottomTab === 'home' && (
            <TransactionsView
              transactions={transactions}
              onBack={() => setScreen('dashboard')}
              onApprove={handleApproveTransaction}
              onReject={handleRejectTransaction}
              role={role}
              currentAgent={currentAgent}
            />
          )}

          {screen === 'numbers_manage' && bottomTab === 'home' && (
            <NumbersManageView onBack={() => setScreen('dashboard')} role={role} />
          )}

          {screen === 'schedule' && bottomTab === 'home' && (
            <ScheduleView
              schedule={schedule}
              onBack={() => setScreen('dashboard')}
              onUpdateSchedule={handleUpdateSchedule}
              role={role}
            />
          )}

          {screen === 'ads' && bottomTab === 'home' && (
            <AdsView ads={ads} onBack={() => setScreen('dashboard')} onUpdateAds={handleUpdateAds} />
          )}

          {screen === 'winning_numbers' && bottomTab === 'home' && (
            <WinningNumbersView
              slots={winningSlots}
              onBack={() => setScreen('dashboard')}
              onUpdateSlot={handleUpdateWinningSlot}
              role={role}
            />
          )}

          {screen === 'live_feed' && bottomTab === 'home' && (
            <LiveFeedView
              onBack={() => setScreen('dashboard')}
              liveData={thai2DLive}
              threeDData={thai3DData}
              onRefreshAll={handleRefreshAllApiData}
            />
          )}

          {screen === 'bet_records' && bottomTab === 'home' && (
            <BetRecordsView
              onBack={() => setScreen('dashboard')}
              betRecords={betRecords}
              role={role}
              currentAgent={currentAgent}
            />
          )}

          {screen === 'win_bets' && bottomTab === 'home' && (
            <WinBetsView
              onBack={() => setScreen('dashboard')}
              role={role}
              currentAgent={currentAgent}
            />
          )}

          {screen === 'agent_balance' && bottomTab === 'home' && (
            <AgentBalanceView
              onBack={() => setScreen('dashboard')}
              role={role}
              currentAgent={currentAgent}
            />
          )}

          {screen === 'results_history' && bottomTab === 'home' && (
            <ResultsHistoryView onBack={() => setScreen('dashboard')} role={role} />
          )}

          {bottomTab === 'website' && (
            <WebsiteView
              ads={ads}
              slots={winningSlots}
              users={users}
              betRecords={betRecords}
              settings={websiteSettings}
              onUpdateSettings={handleUpdateSettings}
              role={role}
            />
          )}

          {bottomTab === 'profile' && (
            <ProfileView
              role={role}
              onSwitchRole={(targetRole) => setRole(targetRole)}
              onLogout={handleLogout}
              userName={sessionInfo?.name}
              userEmail={sessionInfo?.email}
              userCode={sessionInfo?.code}
              soundEnabled={soundEnabled}
              onToggleSound={setSoundEnabled}
            />
          )}
        </main>

        {showBottomNav && <BottomNav activeTab={bottomTab} onTabChange={handleBottomTabChange} />}

        <NotificationModal
          isOpen={isNotificationsOpen}
          onClose={() => setIsNotificationsOpen(false)}
          notifications={notifications}
          onMarkRead={markRead}
          onMarkAllRead={markAllRead}
          soundEnabled={soundEnabled}
          onToggleSound={setSoundEnabled}
          onNavigate={handleNotificationNavigate}
        />
      </div>
    </div>
  );
}
