import type { Metadata, Viewport } from 'next';
import './globals.css';

export const viewport: Viewport = {
  themeColor: '#0B0B0C',
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  viewportFit: 'cover',
};

export const metadata: Metadata = {
  title: 'Fast 2D3D Panel',
  description: 'Mobile-only PWA management panel for Fast 2D3D lottery operations, users, agents, transactions, betting numbers, schedule, and live results.',
  manifest: '/manifest.webmanifest',
  appleWebApp: {
    capable: true,
    statusBarStyle: 'black',
    title: 'Fast 2D3D',
  },
  icons: {
    icon: '/favicon.ico',
    apple: '/images/logo.png',
  },
  openGraph: {
    title: 'Fast 2D3D Panel',
    description: 'Mobile-only PWA management panel for Fast 2D3D lottery operations.',
    type: 'website',
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="my" className="dark bg-black select-none">
      <head>
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
        <meta name="mobile-web-app-capable" content="yes" />
      </head>
      <body
        suppressHydrationWarning
        className="min-h-screen bg-[#101012] text-white antialiased overflow-x-hidden"
      >
        {children}
      </body>
    </html>
  );
}

